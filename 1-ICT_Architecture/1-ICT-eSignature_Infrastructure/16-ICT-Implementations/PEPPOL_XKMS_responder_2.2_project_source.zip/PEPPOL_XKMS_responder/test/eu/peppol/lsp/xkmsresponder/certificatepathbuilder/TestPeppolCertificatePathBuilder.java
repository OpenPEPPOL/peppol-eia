/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certificatepathbuilder;

import java.rmi.AccessException;
import java.rmi.RemoteException;
import java.security.cert.CertPathBuilderException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import junit.framework.TestCase;
import eu.peppol.lsp.xkmsresponder.PeppolTestSuite;
import eu.peppol.lsp.xkmsresponder.certpathbuilder.CertPath;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.testutils.TestSessionHelper;


/*
 * <p>TestPeppolCertificatePathBuilder</p> <p>Tests to check the
 * certificatepathbuilder module</p>
 * @author Andre Jens
 * @author Nils Buengener
 */
public class TestPeppolCertificatePathBuilder extends TestCase
{
  private static Logger LOG = Logger.getLogger(TestPeppolCertificatePathBuilder.class.getName());

  private TestSessionHelper testSessionHelper;

  @Override
  protected void setUp() throws Exception
  {
    super.setUp();
    testSessionHelper = new TestSessionHelper();
    PeppolTestSuite.loadConfig();
  }

  @Override
  protected void tearDown() throws Exception
  {
    super.tearDown();
  }

  /**
   * Create certificate path from a given user certificate "user_cert_valid.crt".
   * The chain must be completed from configuration.:
   *
   * - User
   * - Common Name: BOS_CA
   * - Common Name: BOS_ROOT
   *
   * No CertificatePathBuilderException must be thrown. A complete chain
   * must be returned containing.the certificates above.
   */
  public void testBuildChainFromUserCert() throws Exception
  {
    X509Certificate cert1 = loadCert("user_cert_valid.crt");
    X509Certificate returnCert1 = loadCert("BOS_CA.crt");
    X509Certificate returnCert2 = loadCert("Bos_Root.crt");

    ArrayList<byte[]> target = new ArrayList<byte[]>();
    target.add(cert1.getEncoded());

    CertPath expectedReturn = null;
    ArrayList<X509Certificate> list = new ArrayList<X509Certificate>();
    list.add(cert1);
    list.add(returnCert1);
    list.add(returnCert2);

    CertPath certPath = new CertPath(list);
    expectedReturn = certPath;

    List<X509Certificate> returnedCertificates = buildPath(target);
    assertEquals("Expected certificate chain not found", expectedReturn.getCertificates(), returnedCertificates);
  }

  /**
   * Create certificate path from a list of certificates.
   *
   * - User
   * - Common Name: BOS_CA
   * - Common Name: BOS_ROOT
   *
   * No CertificatePathBuilderException must be thrown. A complete chain
   * must be returned containing.the certificates above.
   */
  public void testBuildChainFromGivenCertList() throws Exception
  {
    X509Certificate cert1 = loadCert("user_cert_valid.crt");
    X509Certificate cert2 = loadCert("BOS_CA.crt");
    X509Certificate cert3 = loadCert("Bos_Root.crt");
    assertNotNull("Cert1 is null", cert1);
    assertNotNull("Cert2 is null", cert2);
    assertNotNull("Cert3 is null", cert3);

    ArrayList<byte[]> target = new ArrayList<byte[]>();
    target.add(cert1.getEncoded());
    target.add(cert2.getEncoded());
    target.add(cert3.getEncoded());

    ArrayList<X509Certificate> list = new ArrayList<X509Certificate>();
    list.add(cert1);
    list.add(cert2);
    list.add(cert3);

    CertPath expectedReturn = new CertPath(list);
    List<X509Certificate> returnedCertificates = buildPath(target);

    if (returnedCertificates != null)
    {
      LOG.fine("Size of CertStore:" + returnedCertificates.size());

      for (int ti = 0; ti < returnedCertificates.size(); ti++)
      {
        LOG.fine("Cert " + ti + " in return: "
                  + (returnedCertificates.get(ti)).getSubjectX500Principal().getName());
      }
    }

    assertEquals("Expected certificate chain not found", expectedReturn.getCertificates(), returnedCertificates);
  }

  /**
   * Create certificate path from a list of certificates.
   * The given list contains a superfluous certificate:
   *
   * user-TeleSec-PKS-SigG-CA-13.crt
   * Common Name: TeleSec PKS SigG CA 13:PN
   * Common Name: 6R-Ca 1:PN
   * Common Name: 8R-CA 1:PN
   *
   * No CertificatePathBuilderException must be thrown. A complete chain
   * must be returned containing the following certificates:
   *
   * user-TeleSec-PKS-SigG-CA-13.crt
   * Common Name: TeleSec PKS SigG CA 13:PN
   * Common Name: 6R-Ca 1:PN
   */
  public void testBuildChainFromGivenCertListWithSuperfluousCert() throws Exception
  {
    X509Certificate cert1 = loadCert("user-TeleSec-PKS-SigG-CA-13.crt");
    X509Certificate cert2 = loadCert("TeleSec_PKS_SigG_CA_13_PN.crt");
    X509Certificate cert3 = loadCert("6R-Ca_1.PN.crt");
    X509Certificate cert4 = loadCert("8R-CA_1.PN.crt");
    assertNotNull("Cert1 is null", cert1);
    assertNotNull("Cert2 is null", cert2);
    assertNotNull("Cert3 is null", cert3);
    assertNotNull("Cert4 is null", cert4);

    ArrayList<byte[]> target = new ArrayList<byte[]>();
    target.add(cert1.getEncoded());
    target.add(cert2.getEncoded());
    target.add(cert3.getEncoded());
    target.add(cert4.getEncoded());

    ArrayList<X509Certificate> list = new ArrayList<X509Certificate>();
    list.add(cert1);
    list.add(cert2);
    list.add(cert3);

    CertPath expectedReturn = new CertPath(list);
    List<X509Certificate> returnedCertificates = buildPath(target);

    if (returnedCertificates != null)
    {
      LOG.fine("Size of CertStore:" + returnedCertificates.size());

      for (int ti = 0; ti < returnedCertificates.size(); ti++)
      {
        LOG.fine("Cert " + ti + " in return: "
                  + (returnedCertificates.get(ti)).getSubjectX500Principal().getName());
      }
    }

    assertEquals("Expected certificate chain not found", expectedReturn.getCertificates(), returnedCertificates);
  }

  /**
   * Create certificate path from a list of certificates.
   * The given list contains an inappropriate certificate:
   *
   * Common Name: user_cert_valid
   * Common Name: BOS_CA
   * Common Name: 8R-CA 1:PN
   *
   * No CertificatePathBuilderException must be thrown. A complete chain
   * must be returned containing.the following certificates
   * (the improper certificate 8R-CA 1:PN must be replaced):
   *
   * Common Name: user_cert_valid
   * Common Name: BOS_CA
   * Common Name: BOS_ROOT
   *
   */
  public void testBuildChainFromGivenCertListWithImproperCert() throws Exception
  {
    X509Certificate cert1 = loadCert("user_cert_valid.crt");
    X509Certificate cert2 = loadCert("BOS_CA.crt");
    X509Certificate cert3 = loadCert("8R-CA_1.PN.crt");
    assertNotNull("Cert1 is null", cert1);
    assertNotNull("Cert2 is null", cert2);
    assertNotNull("Cert3 is null", cert3);

    ArrayList<byte[]> target = new ArrayList<byte[]>();
    target.add(cert1.getEncoded());
    target.add(cert2.getEncoded());
    target.add(cert3.getEncoded());

    X509Certificate returncert3 = loadCert("Bos_Root.crt");
    ArrayList<X509Certificate> list = new ArrayList<X509Certificate>();
    list.add(cert1);
    list.add(cert2);
    list.add(returncert3);

    CertPath expectedReturn = new CertPath(list);
    List<X509Certificate> returnedCertificates = buildPath(target);

    if (returnedCertificates != null)
    {
      LOG.fine("Size of CertStore:" + returnedCertificates.size());

      for (int ti = 0; ti < returnedCertificates.size(); ti++)
      {
        LOG.fine("Cert " + ti + " in return: "
                  + (returnedCertificates.get(ti)).getSubjectX500Principal().getName());
      }
    }

    assertEquals("Expected certificate chain not found", expectedReturn.getCertificates(), returnedCertificates);
  }

  /**
   * Give a certificate with wrong signature.
   * An exception must be thrown.
   *
   */
  public void testBuildPathInvalid() throws Exception
  {
    X509Certificate cert1 = loadCert("wrongsig.crt");

    ArrayList<byte[]> target = new ArrayList<byte[]>();
    target.add(cert1.getEncoded());

    try
    {
      buildPath(target);
      fail("No Exception was thrown, but CertPathBuilderException was expected");
    }
    catch (CertPathBuilderException ex1)
    {
      // OK
    }
    catch (AccessException ex1)
    {
      if (ex1.getCause() instanceof CertPathBuilderException)
      {
        LOG.fine("testBuildPathInvalid() this is the expected result");
      }
    }
  }

  private X509Certificate loadCert(String inpFilename) throws Exception
  {
    return ResponderHelper.createCertificate(
    		TestPeppolCertificatePathBuilder.class.getResourceAsStream("/certificates/peppol/"+ inpFilename));
  }

  @SuppressWarnings("unchecked")
  private List<X509Certificate> buildPath(ArrayList<byte[]> target) throws Exception, RemoteException
  {
    return testSessionHelper.buildPath(target, null);
  }

}
