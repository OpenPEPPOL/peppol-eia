/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.security.cert.X509Certificate;
import java.util.logging.Logger;

import org.bouncycastle.util.encoders.Base64;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.inspectionTests.ResponderTestHelper;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;


/**
 * Tests for Italian certificates.
 * Contains three additional tests for requested CRL, certificate chain, OCSP responses.
 * One additional test for XKMS forward (mediated request).
 * @author buengener
 *
 */

public class PolandTest extends HttpEntryTest
{

	private final static Logger LOG = Logger.getLogger(PolandTest.class.getName());
	private String conf;
	private static final String SSL_CERT =
	      "MIIGLzCCBRegAwIBAgIQT3N1Ah31WNl4XOTVikHwgDANBgkqhkiG9w0BAQUFADB4MQswCQYDVQQG" +
	      "EwJQTDEiMCAGA1UEChMZVW5pemV0byBUZWNobm9sb2dpZXMgUy5BLjEnMCUGA1UECxMeQ2VydHVt" +
	      "IENlcnRpZmljYXRpb24gQXV0aG9yaXR5MRwwGgYDVQQDExNDZXJ0dW0gTGV2ZWwgSUlJIENBMB4X" +
	      "DTExMDYwMzEzNTMxNVoXDTEyMDYwMjEzNTMxNVowgYcxCzAJBgNVBAYTAlBMMSAwHgYDVQQKDBdV" +
	      "bml6ZXRvIFRlY2hub2xvZ2llcyBTQTEWMBQGA1UECwwNSVQgRGVwYXJ0bWVudDEZMBcGA1UEAxMQ" +
	      "Ki53ZWJub3Rhcml1cy5ldTEjMCEGCSqGSIb3DQEJARYUaW5mb2xpbmlhQHVuaXpldG8ucGwwggEi" +
	      "MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC5X74HnrDwCvm4uPtRVnj1spa8k0cEvCz7TdOv" +
	      "Qt3iSWweIZ1g9x2CXs1EYcdeUM2n6Hsyo8GJiUn2pwtB7ddeTpWzY9ZT8vBcm2MbH67xojlcPi4d" +
	      "6QtFnjs2oVqdUk+wdLdGtKk5Xp8epIt2y7yrnlIpU7HJuKmmG3CQHw7EmfDt26x1zSAIBKCoRL4e" +
	      "7K0LCjO//11CduA1sMuy2BFbxVzJTx4VOGtS+7jSOOsPrEh5AcuyYkRXCYWVsRDqrQdNHMpf+Av3" +
	      "nljF76EQwWczFUoWXsG+591sR8ofsH5OnX1N5aXUfGJr98zrQNDGYQu43+eZu3FLUTT1XO0mKF3X" +
	      "AgMBAAGjggKjMIICnzAMBgNVHRMBAf8EAjAAMCwGA1UdHwQlMCMwIaAfoB2GG2h0dHA6Ly9jcmwu" +
	      "Y2VydHVtLnBsL2wzLmNybDBaBggrBgEFBQcBAQROMEwwIQYIKwYBBQUHMAGGFWh0dHA6Ly9vY3Nw" +
	      "LmNlcnR1bS5wbDAnBggrBgEFBQcwAoYbaHR0cDovL3d3dy5jZXJ0dW0ucGwvbDMuY2VyMB8GA1Ud" +
	      "IwQYMBaAFATJ2prcSkl3rzADBGYux87y+Bd9MB0GA1UdDgQWBBQnOArIswajnzaDgw89s2lJq69I" +
	      "PzAOBgNVHQ8BAf8EBAMCBaAwggE9BgNVHSAEggE0MIIBMDCCASwGCiqEaAGG9ncCAgMwggEcMCUG" +
	      "CCsGAQUFBwIBFhlodHRwczovL3d3dy5jZXJ0dW0ucGwvQ1BTMIHyBggrBgEFBQcCAjCB5TAgFhlV" +
	      "bml6ZXRvIFRlY2hub2xvZ2llcyBTLkEuMAMCARcagcBVc2FnZSBvZiB0aGlzIGNlcnRpZmljYXRl" +
	      "IGlzIHN0cmljdGx5IHN1YmplY3RlZCB0byB0aGUgQ0VSVFVNIENlcnRpZmljYXRpb24gUHJhY3Rp" +
	      "Y2UgU3RhdGVtZW50IChDUFMpIGluY29ycG9yYXRlZCBieSByZWZlcmVuY2UgaGVyZWluIGFuZCBp" +
	      "biB0aGUgcmVwb3NpdG9yeSBhdCBodHRwczovL3d3dy5jZXJ0dW0ucGwvcmVwb3NpdG9yeS4wNAYD" +
	      "VR0lBC0wKwYIKwYBBQUHAwEGCCsGAQUFBwMCBgorBgEEAYI3CgMDBglghkgBhvhCBAEwEQYJYIZI" +
	      "AYb4QgEBBAQDAgZAMCsGA1UdEQQkMCKCDndlYm5vdGFyaXVzLmV1ghAqLndlYm5vdGFyaXVzLmV1" +
	      "MA0GCSqGSIb3DQEBBQUAA4IBAQBXCIik5uYurYSpcs17sCxf4hZnCOWfW2CGIE/MQecbmyJZsMD5" +
	      "OMSl8W8H91Mz3UM/qkQNEY3fV9+ml0i0BD0z4/xQTTIxO4KBFRUiZIxCettbNe5X2d5xuHj9ozdd" +
	      "EfYugXMlI7Zph3y51ggEw9bAIOUet/20s8KpmrRxbnu+adE4nlbwhblweqG9s/CsCy9W5hSlMxFp" +
	      "uBIBi+99A1drFv+x0zaJN1AgkZPKGhR8MjsBpYPbwqULtXL7JMSzvuR5PmeQ1OfKrqmT7My5OeE2" +
	      "NjfABSsYnz4gdicm5ghqFmAIu0X6NoB7IzuEnGoJSLPYGNkUAfbZ6KYbLa7hz2Yo";

	private static final String KEYSTORE =
		"MIACAQMwgAYJKoZIhvcNAQcBoIAkgASCBZAwgDCABgkqhkiG9w0BBwGggCSABIIFeDCCBXQwggVwB"
		+ "gsqhkiG9w0BDAoBAqCCBPkwggT1MCcGCiqGSIb3DQEMAQMwGQQUFwx1m7/tm6XpW/PuWJLOEf8H0"
		+ "zsCAWQEggTIcajwZf7cQiANoDmec5KUPY1pOiT7lLd0zsnux8OwqA9UYx0bOwK4B63ucyTsqVdTM"
		+ "cEJu1XsEBNlyJfCDnxUPLxn6JY9rUOgnbh7iC6ZGklcq1yka1cNwZcmeSBNgk30yXYTI1BVcMp/y"
		+ "CpJk0ipZI8R+eJfIF4FIrWCnBu2EPPCLhhj4PRonLqiKFU61LZgc6fQgxTxE/0sXeQAuTo/xPRaZ"
		+ "dAu7mFu2Cc8N9RcY9DCeW8aq8M3GTuBmWOSw4YsuuafX8AENM/sGuJNfoFtVHqsxScSmvkHfT7Ua"
		+ "+y8zCEYXLTr1jkLlL10V74lQef5sDTK+dusvU/y1Phy1unK9YrMpbHeHsuuepX5AOZS4ZHwYSckR"
		+ "SxY7dR91pZWz037YBwi5y6KwU1olKlGCycVgC6uKeUkyGPojsbbQbZeTs5QEnHnDHP5/S0uvpQKE"
		+ "Uf8C4oorQQEqlLdtW7huXH3tyjaTXklh0ukntw6J5xmhSx8BPJxJ17kOnSMeGeCPnYou1iVJqnTq"
		+ "QMuslTbKClzvxyGTPiLcbo2zFs3GSn5Tug6PYyxtdxagkqd0gvX1D0OOz30oAenwhO8+08DIdoET"
		+ "hfeL0aEoanOpi9OUalC2QRBFJIKDlSes9j9Y/0MK0vTbZ+rU8AHapzJFhsOkwFi5Ar1fjtCLbJKl"
		+ "mx04+5xzvoc8u8c/IeKXawux8WO537DVrmaJ5VooWRCDnkcMLUJ48gDi29Nmlz7OM5xYopvdQMyU"
		+ "1PQYSBN0VVsyFJ1XLJ9ACDipYGa44GJeX471F4jE/csoJxTytcOk59jv/FK8CeIi/TiKaeiH9h1I"
		+ "HNlMGtwLJkVTBA2qvi2foU1Nd07OFsVmYBxkBznLXlKIoCW4TOs1Av12Qk4soD8BaO7CynwvSuzz"
		+ "AfxkpJaJO08EG4CMQ67kfkscAUs1BCgKPHo17N1jB4QzaV3M59+YVO1cwnDVD+ezHhW3fgv0Xf3t"
		+ "Oo3ZxUQgQj5nV4Z65eDyFDonhbaSQ1P3cWz7QaiQBEs7qEkiGAunEm7WVfhqlZPTb99GDu6KsVOD"
		+ "Qky6h2zZLqsvce+etzJqiwOvXmguyaJAKSUCM6FR7q8XpgH1YrC32WwFfqJj+fOzCcnfe/XNj1zM"
		+ "Y7Dad9QYw47giyvNAqwTjqPl1LnVjnq/QuteHQ+s9cRsBqC40S8khAer7dW1YBI9YKcZZT8xV4ik"
		+ "WAVhrK+cHCWqmCruWAGT6u1sDAMghI8MvYZA7sqKupfxbNH0NXyMLY5j3dpkt37vvXgjiG/otWa8"
		+ "f21IDgXnJhfiMLZpzfEo7R1vDbisZUIladWoCqPlzD/BlITbA+PnC2LJX3Wteex1aHWWNqkKbj9V"
		+ "rIGK6sylJPCZq6/QUWPmSs6SBs8Z6z4Z9IsxJVY3KJvueWpKwkafafbO2lWcY2XyN/THQ3DeCLLc"
		+ "/lPq2vtqLow2kp5CmLkLiKLCALAFF1AUVJTMhipnKUAGL693/S+llAX+h9XZnj3RyJDQVZDnVT/U"
		+ "BnWoswyMXJaOeERt3PGLYk72K61+QEZ6hYwpyFq0+1RNsKX/HByOWz/U9FofA3rc9RWftUC1rU6m"
		+ "8wzRkwCLoEqQSor6ql0hKeHdkHSFzTvRGuKZ21YBtBDtucZMWQwIwYJKoZIhvcNAQkVMRYEFJMYY"
		+ "e2vQppMilZhSjjJeWaqVq3dMD0GCSqGSIb3DQEJFDEwHi4AWABLAE0AUwAtAFIAZQBzAHAAbwBuA"
		+ "GQAZQByACAAUwBpAGcAbgBhAHQAdQByAAQBAAQBAAQBAAQBAASCDaIAMIAGCSqGSIb3DQEHBqCAM"
		+ "IACAQAwgAYJKoZIhvcNAQcBMCcGCiqGSIb3DQEMAQYwGQQU1VcaYIx5nIy++8LqgvuvVJxjEZgCA"
		+ "WSggASCDVC76GgxjuAblq2MpNE7w+yl7Hw81gRO4V/pZw+LDDfN0QPbMzWCMmfutB1+NWpENg6Du"
		+ "TyE13NATyiZ/6wt3mAOJwc0g+pt0vY2hMOf5/OUol/Ao9mXVvtcih2DG8xq7addEzQ5YrWNoG7SC"
		+ "HixLeRnlWg4B60wHUqgYZju2r+6cihqTdb+HmHLVSQcgz9dOyqcNWfMOezgb7T0hseHWmzdqP7iF"
		+ "8DfNDSDWP3KHdyGJ/gGsganqYWsySK3J0cpUhaSufUCKIZ5VOATeEBzo8lgnVQxgg8Rk5aPWyQey"
		+ "kbVqWtFY/zcEyWTVifJ0IkaR+5/4kv9tAGW4WZx9j07QCppAEtD1KDP4SsrHh23Vf4LYixet5rd6"
		+ "iZX9iStHz0eCi3Vtgi8z/1dtkycBckrIJN1XMZxlNnvwtuWP0KoFSoP4Kku1oY/hWLYgKCLNWmJ+"
		+ "yOg0cSzXdSPRsk01z/gCyzbn9cw2q0yrxlqPW8gD2h8Rn/eHJig2rUYAVvzNb8uDpm74itPpk+Bu"
		+ "ic8iB2k+oSjOMGBqi3TciVfHVUMLvYauJb07B/Eh2rk1mydWZdwSeF23FLLRv4AMGbqviN38NZIn"
		+ "zFWlayty5rc1YpGvRKwjXEGP5Uya1Q50S5WRUfJeoS0yb3K7unqsbkjPafncdP9F/4MWXppaGU3V"
		+ "jjPx3xEcjfG+h4FAog/9xTBRqnvHKRidhmU2fsRTTfURA15TiKRJGZxbKkQciOB0JUM6FKVe4Mst"
		+ "YvEaYizpzgja2OX9+mbghYAP3X7G1Ql2Mp1kZ+979ggU45X177E2P1K2CgG1fa0GuAVCPN3icktn"
		+ "kmz52P/4O4iQOa87rNCB7/6LvynKX9kO9s3W1oBBFDhYmkqe4J4PZ185LkvDxcsy3KZMVhluo0PQ"
		+ "pddws9Y+i3JGkDXKfAzBXkFr4Dg67ZRgY1UnWXSQHPy5RRhHcc/f0qz5kTosxZsxagE7Xif27vgE"
		+ "FNRq9HGmLyOAfaH5Z2f52TCnJROkiXypfv23FvsdAn5PIRohvCvkAAYI46oDm+edsi/CvUayzTxE"
		+ "6JyDjPBUCE98ZG0LN3WkF7nw8c/b/wVGt+ADrB5rSboMlTl0QQIGoq0Idz+GPwyq1cwoiqYLYbK/"
		+ "CQvtlUQ2n8X8s78vN57XMWsPdcjC2ZelHDg0D2r4dM59jtXuj3qm/hKs6BQ6Vojb86FxH5qY98/l"
		+ "8D0AQEPMPAb/IiyqEMaDfW380KfBmDP5vYVTHgXFiW8BQfrLpjxCppIaoHwHzdzj0TvNOAjTXnV8"
		+ "bgbfiFewfZqYZy9q/H83SvEcKhIPlrU2JC/9rpnbGVU4PTnfgMA+JeGSYQhlVHIfMesOIvEE7cha"
		+ "9bKv5pw1z4qPtZzM/GlLxKXUiPEvr5/vqejufKxPQmi5hDDPO3zKzKnWO2rK/jU5+f/n2G2Fm9gY"
		+ "TmlPkwHlSRWZBtvQDEXX8j6bQ8L9QHkQ50Hm4+5+w1fhXDLLr5IYBDENKSOuzWplHbWv0+iHVhB6"
		+ "L3GMWQ1ArEmyXgsGQyYVsQWmkLywLZFQDwTWNKli0rC6ZracmeOMq7UqchWDepGMR5YxqtVdtm6m"
		+ "/ySNEy0YPWXXFJ9tj5CUVFe8PEIJLo8d+7+HFy+cnn5Hy8WlNC36k6f/Sve/0yslcA5c2s+9oyXv"
		+ "xzq/O2j9pHgJE09IEweyDq6+7uplqGKtKKo7BnuvTutlTjeQt97IXoRB5yy/zlGgRQRQc3AOjXDr"
		+ "J3bGaPL+kTWRP1oxjoL326F3M+lzejoWyZ8k3gcUW/SUXdhU7lYscK8F0g+wzgaEM2KYRdmZrabr"
		+ "xEU3qx6x091ui5B8YJddWoOxSxtFuaXnOCWMMjgDTXNYA512sBHGRrbu8cF69v4g6Obs2Stg/ZsG"
		+ "tNBhJNgPWhftn5BKZQ8mXNtTOSrpTPeghNbrr72jSD4IR2iywMKFbVQYdPWeCgpTOMUEMMF8HSre"
		+ "2Wc3MOZT4UAeoDf6YDXZOCw3Sfs5Q/baqvwu//rDCbgH0jBGzL2Prw+y4mquVDV2YEeBRyOc24AG"
		+ "dVFRCchJ9NQn5QHVXFAO2MTKUhsbcDxCmqhMQ8hfSGwfR74/ibDNOq69a40xWUshXm1Ek5y49JFj"
		+ "7fbnXyYc6UBi1d9C8tAH92KvdPGKW70EaV/7Xbu9V5X93UysGq5eWRrPNs/K5EThyGm2ukylVY82"
		+ "0nwJg6tXiM8g99EKjkjpD0GVrSZc429Wa3+YBNiWidOkELoxibpEuoQgEoulvcLOsbIasO6/1YUN"
		+ "P6FXBUOW7TrtcwJgWckMPpIsi0+Q9MLU7/jKsj3gh5GtlqdrfvqG01QLQHWydXxUitwejTSJy3O+"
		+ "Go3EWhA+vHgmqg6r1p5JTrtmItaioWkwa6ZvAiGhb29lbxlaMrblTnK9YAx5YXJFfr3t7RQwvnq3"
		+ "PdnpDZilrjKJKDDjurloXMo+vkkpGBAexvMRoM/gTPOXNSmM/hao+uFrPVhEU4tQz0HOzB5stKgJ"
		+ "4mvFv8lRoJF9q3IOOfkNd34OAA35jjnsiWy09MexTP8vytxCNme6nOpepu5CBEy0etHuWi2MKGRO"
		+ "Ha6ug9watK0r5b2WkOIatGHScrapaqHMb+gaDWs/FbvadJmgKK75nFcsMMvzNXeHKxeExFZsDtZz"
		+ "zKO2uYdmly6MeIGLthiLcIPTZNu78C1L+2OMxL5jVRrhqEnu/XeEJX195Ed0j4wAxJOteap6tTDl"
		+ "P+6BdrJik1/m16BiN/N8C+2vZES783XmFwx1O4o07GDElgnrlFr/KInz3aWbFPQeyFjBC/djFgBr"
		+ "fUQz0arZi15oDayjYVPLw24W7rOPKSVBoqMILRTaiSn3s7H6U60WwUfbFE/tj79FFV5MMUIBiJEX"
		+ "gTjCcqsPK2QOjUNzTk695tTZYblEfrSP4Tk0fuhuyh6+SqA/BUoN5FOAs9L/qITtsKd1eWtHSW2G"
		+ "LibsMCWuJd4kFHC9pcsJEv8IIeONC5mgHfnSHrC6SsapWkaupbgZVAyxDRPGHLwvacJjLCHA9V6T"
		+ "2evG6MxlGp3kcWCat/+JPhjbFgRHsVGyYABI8skmGsdHKXzkXhBJ2vcJpC5lZMeH62hhp8ZRIOV+"
		+ "WC5qnUTP+WUq3rupVESnAVjdeSKYFU0O6cSP+8uFncrJPFOVr4lmiKjWfamv7sKkWXQ7vdYhU18z"
		+ "NLmVVaiRgFEhg58z5QoWMN+odqKCmreQyTdqDAw+/e83pd2qB31QesMN4eERPRHq9Ffq/gEmnPT7"
		+ "loRK6pNZF3woeS69B9gi05zBU0RhTCGzXOKiIvGJHne8zahsUWntjcrjSfwLzff5Ob41o2SWSe20"
		+ "Iwx/XzwmyVnbpqm5Cq0knlM627K76T/ZJi46+hQSlCyyKCP+yunA93HX0QEtfqEwq9H8wmtHW7Oq"
		+ "MZ4h04sasifz6rXVxrRK2vpCqenMvTv2LzmntjpFgYDJdkA0WfXEm1SNiPrUDySyCaCNv2nmtW53"
		+ "6AkTcyziVbM9SDm/eLeZnJ3zVeyrLd/Z7vcTznW6TIbsoLaAoUqFyC41tzeec6Pmgl6W2uStpxA4"
		+ "CiuW/g30JYPpZ3kAqOiWuAmZwL1PKcJo3O6zF6nxa/BSjGvKUZWQNlkvWtcZPvHkwg+hdd8A/N99"
		+ "cXveA7blRSd7CZ1Ce94BJQU2+a13aTosM21UWTPISuGIMdHzM/0mddpaTbKhRzumMD12NEuJI0xI"
		+ "vmVEfZybcWZanw7cfwUqJ3xeb2h/bp7mu0doAr+pJcZ0i25wngeo2LtWzZG31Zagzm9aPy2nUYBy"
		+ "gpmaFn7OFkfbOz2ooaj/oZVoXj2jZcboLw0nTQG4mRcz2f1d4AOuT4bXoVARvgrin7kTGNFtRKyC"
		+ "Cq3F8IFTzbzV9mUATmlbtThjd14c89CIeIWXTeKLo8iBTc2orGmDVW94K5IzibkN/5tbhNsEpZUa"
		+ "VCbdjsn7i4tnAbdC/c/6V/VUJASIZ9b2WQchFrewE3bdl1yDo3st8vHtnuNu908eiEj8L6l25sg0"
		+ "cwKO0YFdATcoEBs3NHTDb24fNISsuHDgjygZADrf8lTrZNfMgAqT1Z5BplEY66sBkWEjPkppSLUJ"
		+ "pJf8mKp6HGG0SKCDdlwsHLxxPm11pdhIZ9fYG7CPq2ZFZkGSSkdCBM85UrIlLcNrxWYjcijPXSfm"
		+ "0n4P4rZexRPXUiTfLNqlw8Q6XBcYh5Q89jlV5qDwj+8JUuzbYVpbmt3MShwRvSeB6gkeJ1yXb5tD"
		+ "cd7IPfrVgJEppAUaPhI/E+Wzbl1zQI8c5SJJueBQQLWPb1uIsFaJ6LvYYSDqShOmpBMph5Fe6VWF"
		+ "2hPsvPhXJLqs6q9F7POoAL5/vP1uMZyPl6PVf+6xvOCOHJGUEMMJhXm6wm7Ef+dxPBXsnrzOS46+"
		+ "bxNnVY/HB3OHJbqVoMizkcYg2TgTqitcWGQJxHcw1lhxEjFXrFkzwjU0wggJ65SIPs8T0yKp8DSv"
		+ "SdiDDUPjfUlPr2Vwsuymxg/VAlwudqccdJmcHJ2/4LB1t0XSuPKQq/CI6FRtVJf5vO04qMABAEAB"
		+ "AEABAEABAEABAEABAEABAEABAEABAEABAEABAEAAAAAAAAAMDwwITAJBgUrDgMCGgUABBScQok8/"
		+ "8WV2zi10DyuzS/D2bytWAQU8VKDTU31GQ0m7epA8JowOUaBOx8CAWQAAA==";

	public PolandTest(String name)
	{
		super(name);
	}

	public void setUp()
	{
		conf = ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE;

		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("</TACertificates>", "<TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\"><X509Certificate>" + SSL_CERT + "</X509Certificate></TACertificate></TACertificates>");
		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("alias=\".*?\"", "alias=\"XKMS-Responder Signatur\"");
		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("pin=\".*?\"", "pin=\"bos:123\"");
		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE =
			ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE.replaceAll("<keystore>.*?</keystore>", "<keystore>"+ KEYSTORE + "</keystore>");

//	  	"<TACertificates><TACertificate insertDate=\"2011-01-06T14:21:00.179+01:00\" insertUser=\"admin\">"
//	  	+ "<X509Certificate>" +  SSL_CERT + "</X509Certificate></TACertificate></TACertificates>"
//	  	+ "<Proxy timeout=\"30"
//	  	+ "\" password=\"" + props.getProperty("responder_proxyPassword", "")
//	  	+ "\" nonProxyHosts=\"" + props.getProperty("responder_nonProxyHosts", "")
//	  	+ "\" username=\"" + props.getProperty("responder_proxyUsername", "")
//	  	+ "\" proxyPort=\"" + props.getProperty("responder_proxyPort", "")
//	  	+ "\" proxyHost=\"" + props.getProperty("responder_proxyHost", "")
//	  	+ "\"/><Signature pin=\"" + props.getProperty("responder_keystorePin", "")
//	  	+ "\" alias=\"" + props.getProperty("responder_keystoreAlias", "")
//	  	+ "\"><keystore>" + props.getProperty("responder_keystore", "")
//	  	+ "</keystore></Signature>";

		uploadConfig("/eu/peppol/lsp/xkmsresponder/entry/PeppolTestConfig_PL.xml");
		super.setUp();
	}

	public void tearDown()
	{
		ResponderTestHelper.RESPONDER_PROXY_AND_SIGNATURE = conf;;
	}

	public void testPolandLisitValid() throws Exception
	{
		performTest("/certificates/Poland/Unizeto/unizetoTestUser.cer", "Valid", null, "2011-02-09T11:26:29+01:00");
	}

	public static void main(String[] args)
	{
		try
	    {
			PolandTest het = new PolandTest(null);
	    	het.setUp();
	    	het.testPolandLisitValid();
	    	het.tearDown();

		}
	    catch (Exception e)
	    {
			e.printStackTrace();
		}
	  }
}
