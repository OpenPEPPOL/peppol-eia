/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.inspectionTests;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.bind.JAXBElement;

import junit.framework.TestCase;

import org.apache.xml.security.Init;
import org.bouncycastle.jce.provider.X509CertificateObject;
import org.etsi.uri._02231.v2.TSPServiceInformationType;
import org.junit.Before;
import org.junit.Test;
import org.tm_xml.xmlschema.common.ISOCountryCodeType;
import org.w3._2000._09.xmldsig.X509DataType;
import org.w3._2002._03.xkms.ResultType;
import org.w3._2002._03.xkms.ValidateRequestType;
import org.w3._2002._03.xkms.ValidateResultType;
import org.w3c.dom.Element;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.entry.HttpEntryTest;
import eu.peppol.lsp.xkmsresponder.requestcontroller.XKMSSignature;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;
import eu.peppol.uri.xkmsext.v2.EIDQualityType;
import eu.peppol.uri.xkmsext.v2.ErrorExtensionType;
import eu.peppol.uri.xkmsext.v2.ValidateResultExtEUType;
import eu.peppol.uri.xkmsext.v2.ValidationDetailsType;

/**
 * Tests for RespondWith mechanism.
 * The tests check basically the existence of requested elements in the response.
 * If the JAXB schema validation succeeds, the response is supposed to be OK.
 *
 * @author buengener
 *
 */
public class TestRespondWith extends TestCase
{
  private final static Logger LOG = Logger.getLogger(TestRespondWith.class.getName());

  private ResponderTestHelper.Proxy proxy = null;

  private X509CertificateObject checkUserCert = null;

  private X509CertificateObject checkUserCertCRL = null;

  private X509CertificateObject checkUserCertUnknown = null;

  @Before
  public void setUp() throws Exception
  {
	Init.init();
	HttpEntryTest.uploadConfig("/PeppolTestConfig.xml");
    proxy = ResponderTestHelper.getProxy();

    InputStream in1 = TestRespondWith.class.getResourceAsStream("/certificates/peppol/ajSig.crt");
    checkUserCert = (X509CertificateObject) ResponderHelper.createCertificate(in1);
    in1.close();

    InputStream in2 = TestRespondWith.class.getResourceAsStream("/certificates/peppol/STRUSTQualifiedSignatureCA2006-010-PN.crt");
    checkUserCertCRL = (X509CertificateObject) ResponderHelper.createCertificate(in2);
    in2.close();

    InputStream in3 = TestRespondWith.class.getResourceAsStream("/certificates/peppol/user_cert_unknown_keychain.crt");
    checkUserCertUnknown = (X509CertificateObject) ResponderHelper.createCertificate(in3);
    in3.close();
  }

  /**
   * Tests RespodWith URI "http://uri.peppol.eu/xkmsExt/v2#OCSP".
   */
  @Test
  public void testRespondWithOCSP() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithOCSP");
    ValidateResultType tmpValidateResult =
          validateCertificate(XKMSConstants.XKMS_RESPONDWITH_OCSP, checkUserCert);
    EIDQualityType eidqual = ((ValidateResultExtEUType)tmpValidateResult.getMessageExtension().get(0).getValue()).getEIDQuality();
    assertTrue("Unexpected EIDQuality response elementfound", eidqual==null);
    X509DataType x509dt = getX509DataType(tmpValidateResult);
    assertEquals("Expected OCSP response elementnot found", "EncapsulatedOCSPValue", ((Element)x509dt.getX509IssuerSerialOrX509SKIOrX509SubjectName().get(0)).getFirstChild().getFirstChild().getLocalName());
    assertTrue("Empty OCSP response elementfound", ((Element)x509dt.getX509IssuerSerialOrX509SKIOrX509SubjectName().get(0)).getFirstChild().getFirstChild().getFirstChild().getTextContent().length() > 0);
  }

  /**
   * Tests RespodWith URI "http://uri.peppol.eu/xkmsExt/v2#eIDQuality".
   */
  public void testRespondWithEIDQuality() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithEIDQuality");
    ValidateResultType tmpValidateResult =
          validateCertificate(XKMSConstants.XKMS_RESPONDWITH_EIDQUALITY, checkUserCert);
    EIDQualityType eidqual = ((ValidateResultExtEUType)tmpValidateResult.getMessageExtension().get(0).getValue()).getEIDQuality();
    ValidationDetailsType validationDetailsType = ((ValidateResultExtEUType)tmpValidateResult.getMessageExtension().get(0).getValue()).getValidationDetails();
    assertNotNull("Expected EIDQuality response element not found", eidqual);
    assertEquals("Expected cert quality not found", XKMSConstants.CertQuality_Qcpplus, eidqual.getCertificateQuality());
    assertEquals("Expected csp assurance not found", XKMSConstants.CSPAssurance_AccreditationWithExternalComplianceAudit, eidqual.getCSPAssurance());


    ValidateResultType tmpValidateResultUnknown =
      validateCertificate(XKMSConstants.XKMS_RESPONDWITH_EIDQUALITY, checkUserCertUnknown);
    EIDQualityType eidqualUnknown = ((ValidateResultExtEUType)tmpValidateResultUnknown.getMessageExtension().get(0).getValue()).getEIDQuality();
    assertNull("Unexpected EIDQuality response element found", eidqualUnknown);
  }

  /**
   * Tests RespodWith URI "http://uri.etsi.org/02231/v2#ServiceInformation".
   */
  public void testRespondWithTSLServiceInformation() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithTSLServiceInformation");
    ValidateResultType tmpValidateResult =
          validateCertificate(XKMSConstants.XKMS_RESPONDWITH_SERVICE_INFORMATION, checkUserCert);

    TSPServiceInformationType tspsit = ((ValidateResultExtEUType)tmpValidateResult.getMessageExtension().get(0).getValue()).getServiceInformation();

    assertNotNull("Expected TSPInfo response element not found", tspsit);
    assertTrue("Returned TSPServiceInfo seems not to be 'Deutsche Telekom AG'", tspsit.getServiceDigitalIdentity().getDigitalId().get(0).getX509SubjectName().contains("Deutsche Telekom AG"));
  }

  /**
   * Tests RespodWith URI "http://uri.peppol.eu/xkmsExt/v2#ValidationDetails".
   */
  public void testRespondWithValidationDetails() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithValidationDetails");
    ValidateResultType tmpValidateResult =
          validateCertificate(XKMSConstants.XKMS_RESPONDWITH_VALIDATION_DETAILS, checkUserCert);

    ValidationDetailsType vdt = ((ValidateResultExtEUType)tmpValidateResult.getMessageExtension().get(0).getValue()).getValidationDetails();

    assertNotNull("Expected ValidationDetails response element not found", vdt);
    assertEquals("Expected country code not found", 0, vdt.getCertIssuingCountry().compareTo(ISOCountryCodeType.DE));
  }

  /**
   * Tests an invalid RespodWith URI.
   */
  @Test
  public void testRespondWithUnknown() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithEIDQuality");
    ValidateResultType tmpValidateResult =
          validateCertificate("TEST_INVALID_RESPONDWITH", checkUserCert);
//    X509DataType x509dt = getX509DataType(tmpValidateResult);
    ErrorExtensionType eet =  ((ValidateResultExtEUType)tmpValidateResult.getMessageExtension().get(0).getValue()).getErrorExtension().get(0);
    assertEquals("Expected error reason not found", XKMSConstants.ERROR_EXTENSION_NOT_UNDERSTOOD, eet.getReason());
    assertEquals("Expected error detail not found", "TEST_INVALID_RESPONDWITH", eet.getDetail());
  }

  /**
   * Tests RespodWith URI "http://uri.peppol.eu/xkmsExt/v2#OCSPNoCache".
   */
  @Test
  public void testRespondWithOCSPNoCache() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithOCSPNoCache");
    ValidateResultType tmpValidateResult =
          validateCertificate(new String[]{XKMSConstants.XKMS_RESPONDWITH_OCSPNOCACHE,
          XKMSConstants.XKMS_RESPONDWITH_VALIDATION_DETAILS}, checkUserCert);

    ValidateResultExtEUType vrelt = ((ValidateResultExtEUType)tmpValidateResult.getMessageExtension().get(0).getValue());
    assertTrue("Expected OCSPNoCache not found", vrelt.getValidationDetails().isOCSPNoCache());
  }

  /**
   * Tests RespodWith URI "http://www.w3.org/2002/03/xkms#X509Chain".
   */
  @Test
  public void testRespondWithX509Chain() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithX509Chain");
    ValidateResultType tmpValidateResult =
          validateCertificate(XKMSConstants.XKMS_RESPONDWITH_X509CHAIN, checkUserCert);
    X509DataType x509dt = getX509DataType(tmpValidateResult);
    List<Object> tags = x509dt.getX509IssuerSerialOrX509SKIOrX509SubjectName();
    assertEquals("Expected certificate chain not found", 3, tags.size());
    for (Object element : tags)
    {
      JAXBElement tmpElement = (JAXBElement) element;
      byte[] x = (byte[])(tmpElement.getValue());
      assertNotNull("Failed to parse returned certificate in chain",
                    ResponderHelper.createCertificate(x));
    }
  }

  /**
   * Tests RespodWith URI "http://www.w3.org/2002/03/xkms#X509CRL".
   */
  @Test
  public void testRespondWithX509CRL() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithX509CRL");
    ValidateResultType tmpValidateResult =
          validateCertificate(XKMSConstants.XKMS_RESPONDWITH_X509CRL, checkUserCertCRL);
    X509DataType x509dt = getX509DataType(tmpValidateResult);
    List<Object> tags = x509dt.getX509IssuerSerialOrX509SKIOrX509SubjectName();
    assertEquals("Expected CRL not found or more than one", 1, tags.size());
    for (Object element : tags)
    {
      byte[] x = ((JAXBElement<byte[]>)element).getValue();
      CertificateFactory certificateFactory = CertificateFactory.getInstance("X509", ResponderHelper.SECURITYPROVIDER);
      assertTrue("Failed to parse returned CRL or empty CRL",
    		  ((X509CRL)certificateFactory.generateCRL(new ByteArrayInputStream(x))).getIssuerX500Principal().toString().contains("S-TRUST Qualified Root"));
    }
  }

  /**
   * Tests RespodWith URI "http://www.w3.org/2002/03/xkms#X509Cert".
   */
  @Test
  public void testRespondWithX509Certificate() throws Exception
  {
    System.out.println("=============================================");
    System.out.println("Testing RespondWithX509Certificate");
    ValidateResultType tmpValidateResult =
          validateCertificate(XKMSConstants.XKMS_RESPONDWITH_X509CERT, checkUserCert);
    X509DataType x509dt = getX509DataType(tmpValidateResult);
    List<Object> tags = x509dt.getX509IssuerSerialOrX509SKIOrX509SubjectName();
    assertEquals("Expected certificate not found or more than one", 1, tags.size());
    byte[] x = ((JAXBElement<byte[]>)tags.get(0)).getValue();
    assertNotNull("Failed to parse returned certificate",
                  ResponderHelper.createCertificate(x));
  }

  private X509DataType getX509DataType(ValidateResultType vrt)
  {
    ValidateResultExtEUType vrelt = ((ValidateResultExtEUType)vrt.getMessageExtension().get(0).getValue());
    return (X509DataType)
      ((JAXBElement)(vrt.getKeyBinding().get(0)).getKeyInfo().getContent().get(0)).getValue();
  }

  protected ValidateResultType validateCertificate(String inpRespondWith, X509CertificateObject cert) throws Exception
  {
	  return validateCertificate(new String[]{inpRespondWith}, cert);
  }

  protected ValidateResultType validateCertificate(String[] inpRespondWith, X509CertificateObject cert) throws Exception
  {
    ArrayList<String> keyUsage = new ArrayList<String>();
    String requestID = "a76WZIjk3AIJj5m3sgxT";
    X509Certificate checkCert = ResponderHelper.createCertificate(cert.getEncoded());
    ArrayList<String> rw = new ArrayList<String>();
    for (int i = 0; i < inpRespondWith.length; i++)
    	rw.add(inpRespondWith[i]);
    rw.add(XKMSConstants.XKMS_RESPONDWITH_EU_EXTENSION);
    ValidateRequestType validateRequest =
          ResponderTestHelper.createXKMSRequest(checkCert, new GregorianCalendar(2010, 10, 1), rw, true, keyUsage, requestID);

    ByteArrayOutputStream out = ResponderTestHelper.prepareRequest(validateRequest);
    System.out.println("Request fertig");

    String response = new String(ResponderTransport.sendHTTPRequest(ResponderTestHelper.URL_VALIDATION, ResponderTestHelper.prepareSoapOutputStream(out, validateRequest.getId()), ResponderTransport.HTTP_SOAP_HEADER), "UTF-8");

    FileWriter fw = new FileWriter("TestResponseWith.xml");
    fw.write(response);
    fw.close();
    ResultType tmpResult = ResponderTestHelper.parseXKMSResponse(response);
    return (ValidateResultType) tmpResult;
  }

  public static void main(String[] args)
  {
    try
    {
      TestRespondWith taeu = new TestRespondWith();
      taeu.setUp();
      taeu.testRespondWithEIDQuality();
      taeu.tearDown();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
