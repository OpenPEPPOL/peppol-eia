/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.trustcenterrequest;


import java.io.IOException;

import junit.framework.TestCase;

import org.junit.Before;

import eu.peppol.lsp.xkmsresponder.configuration.Configuration;

public class TestResponderTransport extends TestCase
{

	String post = "ctl00%24ctl00%24ctl00%24WholeBody%24ContentPane%24ContentArea%24ctl01%24ctl01%24Body%24ctl00_Hidden=False&__VIEWSTATE=%2FwEPDwULLTE3MzY2MzMwNDYPZBYCZg9kFgJmD2QWAmYPZBYCAgUPZBYCAgUPZBYCAgEPZBYCAgEPZBYCAgEPZBYCAgMPZBYCAgEPZBYCAgEPDxQrAwNoaGdkFgRmDw8WBB4IQ3NzQ2xhc3MFD3N1YnNlY3Rpb250aXRsZR4EXyFTQgICZBYCZg8PFgQfAAUPc3Vic2VjdGlvbnRpdGxlHwECAmQWAmYPDxYEHgtOYXZpZ2F0ZVVybAUBIx4HVG9vbFRpcAUYQ2xpY2sgdG8gZXhwYW5kL2NvbGxhcHNlFgYeB29uY2xpY2sFsAFyZXR1cm4gdG9nZ2xlX2V4Y19vcGdlZWsgKCdXaG9sZUJvZHlfQ29udGVudFBhbmVfQ29udGVudEFyZWFfY3RsMDFfQm9keV8wX2N0bDAwXzBfY3RsMDBfMCcsICdjdGwwMCRjdGwwMCRjdGwwMCRXaG9sZUJvZHkkQ29udGVudFBhbmUkQ29udGVudEFyZWEkY3RsMDEkY3RsMDEkQm9keSRjdGwwMF9IaWRkZW4nKR4Lb25tb3VzZW92ZXIFN3dpbmRvdy5zdGF0dXMgPSAnQ2xpY2sgdG8gZXhwYW5kL2NvbGxhcHNlJzsgcmV0dXJuIHRydWUeCm9ubW91c2VvdXQFH3dpbmRvdy5zdGF0dXMgPSAnJzsgcmV0dXJuIHRydWVkAgEPDxYEHwAFC3NlY3Rpb25ib2R5HwECAmQWAmYPDxYEHwAFC3NlY3Rpb25ib2R5HwECAmRkGAEFHl9fQ29udHJvbHNSZXF1aXJlUG9zdEJhY2tLZXlfXxYBBUpjdGwwMCRjdGwwMCRjdGwwMCRXaG9sZUJvZHkkQ29udGVudFBhbmUkQ29udGVudEFyZWEkY3RsMDEkY3RsMDEkQm9keSRjdGwwMG6uokeNzBJO4%2BRFfohbQNveFd9i&ctl00%24ctl00%24ctl00%24WholeBody%24ContentPane%24ContentArea%24ctl01%24ctl01%24Body%24ctl00%24ctl02=False&ctl00%24ctl00%24ctl00%24WholeBody%24ContentPane%24ContentArea%24ctl01%24ctl01%24Body%24textToDecode=SGFsbG8gV2VsdCAh&ctl00%24ctl00%24ctl00%24WholeBody%24ContentPane%24ContentArea%24ctl01%24ctl01%24Body%24ctl01=Safe+Decode";

	String[][] test_header = {{"Accept", "*/*"},
			{"Content-Type", "application/x-www-form-urlencoded"},
			{"Content-Length", Integer.toString(post.length())}};


	@Before
	public void setUp() throws Exception
	{
		Configuration.getProxyDto().setProxyHost("10.21.0.7");
		Configuration.getProxyDto().setProxyPort(8080);
	}

	public void testGetContent() throws IOException
	{
		String content = new String(ResponderTransport.sendHTTPRequest("http://www.google.de", null, null));
		assertTrue("Unexpected content", content.indexOf("google") > -1);
	}

	public void testPost() throws IOException
	{
		String content = new String(ResponderTransport.sendHTTPRequest(
			"http://www.opinionatedgeek.com/dotnet/tools/Base64Decode/safedecode.aspx",
			post.getBytes(), test_header));
		assertTrue("Unexpected content", content.indexOf("Hallo Welt !") > -1);
	}

	public static void main(String[] args)
	{
		try
		{
			Configuration.getProxyDto().setProxyHost("10.21.0.7");
			Configuration.getProxyDto().setProxyPort(8080);
			TestResponderTransport trt = new TestResponderTransport();
			trt.setUp();
			trt.testPost();
			trt.tearDown();
//			System.out.println(new String(ResponderTransport.sendHTTPRequest("http://localhost:8085", null, null)));
//			System.out.println(new String(ResponderTransport.sendHTTPRequest("http://www.google.de", null, null)));
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
