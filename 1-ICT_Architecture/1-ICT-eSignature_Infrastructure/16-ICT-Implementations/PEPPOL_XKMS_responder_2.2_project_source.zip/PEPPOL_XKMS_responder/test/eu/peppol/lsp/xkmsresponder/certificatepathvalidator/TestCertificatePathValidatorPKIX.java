/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certificatepathvalidator;

import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Logger;

import junit.framework.TestCase;
import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.Constants;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.testutils.TestSessionHelper;


/*
 * <p>TestCertificatePathValidatorChain</p> <p>Tests to check the
 * certificatepathvalidator module with validation model "PKIX" </p>
 * @author Andre Jens
 * @author Nils Buengener
 */
public class TestCertificatePathValidatorPKIX extends TestCase
{
  private final static Logger LOG = Logger.getLogger(TestCertificatePathValidatorPKIX.class.getName());

  private TestSessionHelper testSessionHelper;

  X509Certificate usercert1 = null;

  X509Certificate cacert1 = null;

  X509Certificate cacert2 = null;

  X509Certificate cacert3 = null;

  X509Certificate rootCert = null;

  CertificatevalidatorResult res1 = null;

  CertificatevalidatorResult res2 = null;

  CertificatevalidatorResult res3 = null;

  CertificatevalidatorResult res4 = null;

  CertificatevalidatorResult res5 = null;


  CPVResponse response = null;

  CPVResponse response1 = null;

  CPVResponse response2 = null;

  CPVRequest request = null;

  CPVRequest request1 = null;

  @Override
  protected void setUp() throws Exception
  {
    super.setUp();
    testSessionHelper = new TestSessionHelper();

    usercert1 =
          ResponderHelper.createCertificate(
                                 TestCertificatePathValidatorPKIX.class
                                                                   .getResourceAsStream("/certificates/peppol/ajSig.crt"));
    cacert1 =
          ResponderHelper.createCertificate(
                                 TestCertificatePathValidatorPKIX.class
                                                                   .getResourceAsStream("/certificates/peppol/TeleSec_CA.crt"));
    cacert2 =
          ResponderHelper.createCertificate(
                                 TestCertificatePathValidatorPKIX.class
                                                                   .getResourceAsStream("/certificates/peppol/4R-CA1.crt"));
    cacert3 =
          ResponderHelper.createCertificate(
                                 TestCertificatePathValidatorPKIX.class
                                                                   .getResourceAsStream("/certificates/peppol/4R-CA_1.PN.0.crt"));
    rootCert =
          ResponderHelper.createCertificate(
                                 TestCertificatePathValidatorPKIX.class
                                                                   .getResourceAsStream("/certificates/peppol/Freie-Hansestadt-Bremen-CA-Root.crt"));
    //create CPVRequest
    request = new CPVRequest();
    request1 = new CPVRequest();

    // set the Time-Instance in Request
    GregorianCalendar greg = new GregorianCalendar();

    // Format Year, Month, Day, Hour, Minute
    greg.set(2003, 5, 22, 12, 00);

    Calendar cal = Calendar.getInstance();
    cal.setTime(greg.getTime());
    request.setTimeInstance(cal);

    request.setRequestID("12334567");
    request1.setRequestID("12334567");
    request1.addCertifcate(cacert2.getEncoded());

    res1 = new CertificatevalidatorResult(usercert1);
    res1.setCertQuality("qcpplus");
    res1.addValidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    res1.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    res1.addValidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
    res1.addValidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
    res1.setChainpos(Integer.valueOf(0));
    res2 = new CertificatevalidatorResult(cacert1);
    res2.addValidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    res2.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    res2.addValidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
    res2.addValidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
    res2.setChainpos(Integer.valueOf(1));
    res3 = new CertificatevalidatorResult(cacert2);
    res3.addValidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    res3.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    res3.addValidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
    res3.addValidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
    res3.setChainpos(Integer.valueOf(2));
    res4 = new CertificatevalidatorResult(cacert3);
    res4.addValidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    res4.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    res4.addValidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
    res4.addValidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
    res4.setChainpos(Integer.valueOf(2));
    res5 = new CertificatevalidatorResult(rootCert);
    res5.addValidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    res5.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    res5.addValidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
    res5.addValidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
    res5.setChainpos(Integer.valueOf(1));
    response = new CPVResponse();
    response.addCertificateCheckList(res1);
    response.addCertificateCheckList(res2);
    response.addCertificateCheckList(res3);
    response1 = new CPVResponse();
    response1.addCertificateCheckList(res1);
    response1.addCertificateCheckList(res2);
    response1.addCertificateCheckList(res4);
    // create CPVRequest
    response2 = new CPVResponse();
    response2.addCertificateCheckList(res5);
  }

  @Override
  protected void tearDown() throws Exception
  {
    super.tearDown();
  }

  /**
   * Tests a valid chain.
   *
   */
  public void testCheckChainValid() throws Exception
  {
    Integer expectedReturn = Integer.valueOf(CertificatevalidatorResult.STATUS_VALID);
    CPVResponse actualReturn = testSessionHelper.checkChain(response, request, Constants.ATT_ISSUER_PATHVALIDATEMETHOD_PKIX);
    LOG.fine("InvalidReason: " + actualReturn.getCertificateCheckLists()[0].getInvalidReason());
    LOG.fine("ErrorCode: " + actualReturn.getCertificateCheckLists()[0].getErrorCode());
    assertEquals("Expected return value not found", expectedReturn, actualReturn.getResult());
  }

  /**
   * Tests a chain with an expired CA certificate.
   *
   */
  public void testCheckChainInvalidCAExpired() throws Exception
  {
    Integer expectedReturn = Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID);

    Calendar cal = Calendar.getInstance();
    cal.set(2004, 5, 22);
    request.setTimeInstance(cal);

    CPVResponse actualReturn = testSessionHelper.checkChain(response, request, Constants.ATT_ISSUER_PATHVALIDATEMETHOD_PKIX);
    LOG.fine("InvalidReason: " + actualReturn.getCertificateCheckLists()[0].getInvalidReason());
    LOG.fine("ErrorCode: " + actualReturn.getCertificateCheckLists()[0].getErrorCode());
    assertEquals("Expected return value not found", expectedReturn, actualReturn.getResult());
  }

  /**
   * Tests a chain with a revoked CA certificate.
   * The chain is valid because the CA certificate has been revoked after
   * the generation of the user certificate (even after its expiration).
   *
   */
  public void testCheckChainValidInvalidCARevocationTimeAfterCertGeneration() throws Exception
  {
    Integer expectedReturn = Integer.valueOf(CertificatevalidatorResult.STATUS_VALID);
    response.getValidatorResult(1).addInvalidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    response.getValidatorResult(1)
            .setRevokationReason(CertificatevalidatorResult.REVOCATIONREASON_CERTIFICATEHOLD);

    GregorianCalendar cal = new GregorianCalendar();
    // After certificate expiration
    cal.set(2004, 2, 10, 10, 10, 10);
    response.getValidatorResult(1).setRevokationTime(cal.getTime());

    //CPVResponse expectedReturn = null;
    CPVResponse actualReturn = testSessionHelper.checkChain(response, request, Constants.ATT_ISSUER_PATHVALIDATEMETHOD_PKIX);
    assertEquals("Expected return value not found", expectedReturn, actualReturn.getResult());
  }

  /**
   * Tests a chain with a revoked CA certificate.
   */
  public void testCheckChainInvalidCARevocationTimeBeforeCertGeneration() throws Exception
  {
    Integer expectedReturn = Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID);
    response.getValidatorResult(1).addInvalidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    response.getValidatorResult(1)
            .setRevokationReason(CertificatevalidatorResult.REVOCATIONREASON_CERTIFICATEHOLD);

    GregorianCalendar cal = new GregorianCalendar();
    cal.set(2001, 2, 10, 10, 10, 10);
    response.getValidatorResult(1).setRevokationTime(cal.getTime());

    //CPVResponse expectedReturn = null;
    CPVResponse actualReturn = testSessionHelper.checkChain(response, request, Constants.ATT_ISSUER_PATHVALIDATEMETHOD_PKIX);
    assertEquals("Expected return value not found", expectedReturn, actualReturn.getResult());
  }

  /**
   * Tests a valid chain consisting of a root certificate only.
   *
   */
  public void testOnlyRootCert() throws Exception
  {
    Integer expectedReturn = Integer.valueOf(CertificatevalidatorResult.STATUS_VALID);

    GregorianCalendar greg = new GregorianCalendar();
    greg.set(2005, 11, 23, 12, 00);
    Calendar cal = Calendar.getInstance();
    cal.setTime(greg.getTime());
    request1.setTimeInstance(cal);

    CPVResponse actualReturn = testSessionHelper.checkChain(response2, request1, Constants.ATT_ISSUER_PATHVALIDATEMETHOD_PKIX);
    assertEquals("Expected return value not found", expectedReturn, actualReturn.getResult());

  }

}
