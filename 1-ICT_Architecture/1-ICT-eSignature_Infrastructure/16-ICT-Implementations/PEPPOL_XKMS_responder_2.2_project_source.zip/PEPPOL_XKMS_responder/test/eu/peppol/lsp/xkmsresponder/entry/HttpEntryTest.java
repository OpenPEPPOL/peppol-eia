/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import junit.framework.TestCase;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.inspectionTests.ResponderTestHelper;
import eu.peppol.lsp.xkmsresponder.requestcontroller.XKMSSignature;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;


/**
 * Superclass for live tests.
 *
 */
public class HttpEntryTest extends TestCase // JUnitDoclet end extends_implements
{
	protected static final String EULSP_NS = "http://uri.peppol.eu/xkmsExt/v2#";

	protected static final String ETSI_NS = "http://uri.etsi.org/01903/v1.3.2#";

	protected static final String XKMS_NS = "http://www.w3.org/2002/03/xkms#";

	private final static Logger LOG = Logger.getLogger(HttpEntryTest.class.getName());

	protected static String configName = "";

	private volatile long time = 0;

	public HttpEntryTest(String name)
	{
		super(name);
	}

	public void setUp()
	{
		Configuration.initializeEnvironment();
		if (ResponderTestHelper.LOCAL_PROXY_HOST != null)
		{
	    	Configuration.getProxyDto().setProxyHost(ResponderTestHelper.LOCAL_PROXY_HOST);
	    	Configuration.getProxyDto().setProxyPort(ResponderTestHelper.LOCAL_PROXY_PORT);
		}
	}

	public static void uploadConfig(String name)
	{
		if (!name.equals(configName))
		{
			try
			{
				LOG.fine("Upload configuration file " + name);
				ResponderTestHelper.uploadConfig(name);
				configName = name;
// It may take some time until the responder has downloaded CRLs
				Thread.sleep(60000);
			}
			catch (Exception ioe)
			{
				ioe.printStackTrace();
				fail();
			}
		}
	}

	protected void performTest(String certFile, String expectedStatus, String revokationReason) throws Exception
	{
		  performTest(certFile, expectedStatus, revokationReason, null);
	}

	  protected void performTest(String certFile, String expectedStatus, String revokationReason, String timeInstant) throws Exception
	  {
		  byte[] rsp = ResponderTransport.sendHTTPRequest(ResponderTestHelper.URL_VALIDATION, createRequestMsg(certFile, timeInstant, null), ResponderTransport.HTTP_SOAP_HEADER);
//		  System.out.println(new String(rsp, "UTF-8"));
//	Uncomment to write response file
//		  FileOutputStream fos = new FileOutputStream("test.xml");
//		  fos.write(rsp);
//		  fos.close();
		  XMLSignatureTest.checkAndLogSig(rsp);
		  Document doc =  parseResponse(rsp);
		  assertEquals("Wrong number of ValidateResult elements in response: ", 1, doc.getElementsByTagNameNS(XKMS_NS, "ValidateResult").getLength());
		  assertEquals("Wrong number of ValidateResultExtLSP elements in response:", 1,
					doc.getElementsByTagNameNS(EULSP_NS, "ValidateResultExtEU").getLength());
		  assertEquals("Excpected Status not found", "http://www.w3.org/2002/03/xkms#" + expectedStatus,
					((Element)doc.getElementsByTagNameNS(XKMS_NS, "Status").item(0)).getAttributes().item(0).getNodeValue());
		  if (revokationReason != null)
			  assertEquals("Expected revocation reason not found", "http://www.w3.org/2002/03/xkms#" + revokationReason,
					  ((Element)doc.getElementsByTagNameNS(XKMS_NS, "InvalidReason").item(0)).getTextContent());
	  }

// Method for simple perfomance test
	  public void doTestPerformance() throws Exception
	  {
		  final byte[] req = createRequestMsg("/certificates/Deutschland/user_CA_TESTA_Deutschland_09.crt", null, null);
		  for (int i = 0; i < 10; i++)
		  {
			new Thread()
			{
				public void run()
				{
					for (int j = 0; j < 100; j++)
					{
						try
						{
							long start = System.currentTimeMillis();
							byte[] rsp = ResponderTransport.sendHTTPRequest(ResponderTestHelper.URL_VALIDATION, req, ResponderTransport.HTTP_SOAP_HEADER);
							time += (System.currentTimeMillis()-start);
							Document doc =  parseResponse(rsp);
							assertTrue("Excpected Status not found",
									((Element)doc.getElementsByTagNameNS(XKMS_NS, "Status").item(0)).getAttributes().item(0).getNodeValue().indexOf("Valid") > -1);
						}
						catch (Exception e)
						{
							LOG.log(Level.SEVERE, "Problem", e);
						}
					}
				}
			}.start();
		  }

	  }

  protected Document parseResponse(byte[] rsp) throws IOException, SAXException, ParserConfigurationException
  {
	  DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
	  fact.setNamespaceAware(true);
	  fact.setIgnoringElementContentWhitespace(true);
	  DocumentBuilder builder = fact.newDocumentBuilder();
	  return builder.parse(new InputSource(new ByteArrayInputStream(rsp)));
  }

  protected byte[] createRequestMsg(String certFile) throws Exception
  {
	  return createRequestMsg(certFile, null, null);
  }

  protected byte[] createRequestMsg(String certFile, String timeInstant, String[] respondWiths) throws Exception
  {
	  String msg = new String(ResponderTestHelper.readFile("/eu/peppol/lsp/xkmsresponder/entry/ValidateRequest_EULSP_tmpl.xml"), "UTF-8");
	  byte[] cert = ResponderTestHelper.readFile(certFile);

	  msg = msg.replace("${CERTIFICATE}", ResponderHelper.base64encode(cert));
	  if (timeInstant == null)
		  msg = msg.replace("${TIME_INSTANT}", "2010-02-09T11:26:29+01:00");
	  else
		  msg = msg.replace("${TIME_INSTANT}", timeInstant);

	  if (respondWiths != null)
		  for (int i = 0; i < respondWiths.length; i++)
			  msg = msg.replace("<!--xkms:RespondWith>" + respondWiths[i] + "</xkms:RespondWith-->",
					  "<xkms:RespondWith>" + respondWiths[i] + "</xkms:RespondWith>");

	  return ResponderTestHelper.prepareSoapOutputStream(msg.getBytes("UTF-8"), "I94d1048aa24259465d7271cb4433dbb4");

  }

}
