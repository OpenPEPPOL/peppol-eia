/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.entry;

import java.util.logging.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.inspectionTests.ResponderTestHelper;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;


/**
 * Tests for French certificates.
 * Contains two additional tests for compound requests.
 * @author buengener
 *
 */

public class FranceTest extends HttpEntryTest
{

	private final static Logger LOG = Logger.getLogger(FranceTest.class.getName());

	public FranceTest(String name)
	{
		super(name);
	}


	public void setUp()
	{
		uploadConfig("/eu/peppol/lsp/xkmsresponder/entry/PeppolTestConfig_FR.xml");
		super.setUp();
	}

	public void testFranceClickAndTrustMercanteo1Paiement() throws Exception
	{
		performTest("/certificates/France/ClickAndTrust/Mercanteo_User.crt", "Valid", null);
	}

	public void testFranceClickAndTrustMercanteo2Paiement() throws Exception
	{
		performTest("/certificates/France/ClickAndTrust/Mercanteo_User2.crt", "Valid", null);
	}

	public void testFranceClickAndTrustAdmineoValid() throws Exception
	{
		performTest("/certificates/France/ClickAndTrust/Admineo_User2.crt", "Valid", null);
	}

	public void testFranceClickAndTrustAdmineoRevoked() throws Exception
	{
		performTest("/certificates/France/ClickAndTrust/Admineo_User.crt", "Invalid", "RevocationStatus");
	}

	public void testFranceCertignaMerlin() throws Exception
	{
		performTest("/certificates/France/Certigna/Pascal MERLIN.crt", "Valid", null);
	}

	public void testFranceCertignaVerguin() throws Exception
	{
		performTest("/certificates/France/Certigna/Josselin VERGUIN.crt", "Valid", null);
	}

	// Unknown issuer; Test may fail if PPRS is enabled
	public void testFranceCertignaDelval() throws Exception
	{
		performTest("/certificates/France/Certigna/Romain Delval.crt", "Indeterminate", null);
	}

	public void testFranceCertinomis() throws Exception
	{
		performTest("/certificates/France/Certinomis/test.crt", "Valid", null, "2010-09-09T11:26:29+01:00");
	}

	public void testFranceCertinomisInvalidTime() throws Exception
	{
		performTest("/certificates/France/Certinomis/test.crt", "Indeterminate", null, "2040-09-09T11:26:29+01:00");
	}

	public void testCompoundRequest() throws Exception
	{
		byte[] rsp = ResponderTransport.sendHTTPRequest(ResponderTestHelper.URL_VALIDATION,
				  ResponderTestHelper.readFile("/eu/peppol/lsp/xkmsresponder/entry/CompoundRequest.xml"), ResponderTransport.HTTP_SOAP_HEADER);
		XMLSignatureTest.checkAndLogSig(rsp);
		Document doc =  parseResponse(rsp);
		assertEquals("Wrong number of ValidateResult elements in response: ", 2, doc.getElementsByTagNameNS(XKMS_NS, "ValidateResult").getLength());
		assertEquals("Wrong number of ValidateResultExtEU elements in response", 2,
				  doc.getElementsByTagNameNS(EULSP_NS, "ValidateResultExtEU").getLength());
		assertEquals("", "http://www.w3.org/2002/03/xkms#Valid",
				  ((Element)doc.getElementsByTagNameNS(XKMS_NS, "Status").item(0)).getAttributes().item(0).getNodeValue());
		assertEquals("", "http://www.w3.org/2002/03/xkms#Invalid", // Telesec cert J.W. Pelz is expired
				  ((Element)doc.getElementsByTagNameNS(XKMS_NS, "Status").item(1)).getAttributes().item(0).getNodeValue());
	}

	/**
	 * Send a compound request with corrupt signature. One validate request contains
	 * a RequestingNodeChain entry, so the responder must validate the signature
	 * (mediated request).
	 */
	public void testCompoundRequestCorruptSignature() throws Exception
	{
		String rsp = new String(ResponderTransport.sendHTTPRequest(ResponderTestHelper.URL_VALIDATION,
				ResponderTestHelper.readFile("/eu/peppol/lsp/xkmsresponder/entry/CompoundRequest_corruptSignature.xml"), ResponderTransport.HTTP_SOAP_HEADER), "UTF-8");
		assertTrue("No Fault element found", rsp.contains(":Fault"));
		assertTrue("Message 'Wrong signature' not found", rsp.contains("Wrong signature found !"));
	}

	public static void main(String[] args)
	{
	    try
	    {
//	    	Configuration.initializeEnvironment();
//	    	Configuration.getProxyDto().setProxyHost("10.21.0.7");
//	    	Configuration.getProxyDto().setProxyPort(8080);
	    	FranceTest het = new FranceTest(null);
	    	het.setUp();
	    	het.testFranceCertignaDelval();
	    	het.tearDown();
		}
	    catch (Exception e)
	    {
			e.printStackTrace();
		}
	}
}
