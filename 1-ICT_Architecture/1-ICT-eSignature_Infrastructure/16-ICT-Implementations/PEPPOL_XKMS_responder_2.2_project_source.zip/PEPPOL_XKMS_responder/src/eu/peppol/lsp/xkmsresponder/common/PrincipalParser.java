/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.common;

import java.io.UnsupportedEncodingException;
import java.util.TreeMap;

import javax.security.auth.x500.X500Principal;


/**
 *	This class is necessary to circumvent encoding problems
 *	caused by the getIssuer* and getSubject* methods of
 *	the X509CRL and X509Certificate classes.
 *
 * @author buengener
 *
 * 
*/
public class PrincipalParser
{
  private TreeMap<Long, String> tags = new TreeMap<Long, String>();

  private static final byte OID = 0x06;
  private static final byte PRINTABLE_STRING = 0x13;
  private static final byte UTF_STRING = 0x0c;
  private static final byte T61_STRING = 0x14;
  private static final byte BMP_STRING = 0x1e;

//  2.5.4.3
  private static final Long CN = Long.valueOf(0x550403);
  private static final Long SN = Long.valueOf(0x550404);
  private static final Long SERIAL_NO = Long.valueOf(0x550405);
  private static final Long C = Long.valueOf(0x550406);
  private static final Long LOCAL = Long.valueOf(0x550407);
  private static final Long O = Long.valueOf(0x55040a);
  private static final Long OU = Long.valueOf(0x55040b);
  private static final Long GN = Long.valueOf(0x55042a);
  private static final Long EMAILADDRESS = Long.valueOf(0x8b4886f70d010901L);
//  1.2.840.113549.1.9.1

  /**
   * Creates a new PrincipalParser object.
   *
   * @param p Principal to be parsed
   */
  public PrincipalParser(X500Principal p)
  {
    try
    {
      byte[] data = p.getEncoded();
      Long oid_long;
      String content;

      int i = 0;
      int j;
      int len;
      int typ;

      // 8 byte for an OID should be enough for everyone....
      long _oid;

      while (i < data.length)
      {
        // next tag
        while (data[i] != OID)
        {
          i++;

          if (i >= data.length)
            return;
        }

        len = data[++i];

        for (_oid = 0, j = 0; j < len; j++)
        {
          _oid <<= 8;
          _oid |= data[++i]&0xff;
        }

        typ = data[++i];
        len = data[++i] & 0xff;
        ++i;

        oid_long = Long.valueOf(_oid);

        switch (typ)
        {
        case PRINTABLE_STRING:
          // ISO-8859-1 seems to represent umlauts correctly
          content = new String(data, i, len, "ISO-8859-1");

          break;

        case UTF_STRING:
          content = new String(data, i, len, "UTF-8");

          break;

        case T61_STRING:
          content = replaceT61Characters(new String(data, i, len, "ISO-8859-1"));

          break;

        case BMP_STRING:
          // seems to work
          content = new String(data, i, len, "ISO-8859-1").replaceAll("\0", "");

          break;

        default:
          content = new String(data, i, len, "ISO-8859-1");

          continue;
        }

        if (tags.get(oid_long) == null)
          tags.put(oid_long, content);
        else
          tags.put(oid_long, (tags.get(oid_long)) + ", " + content);

        for (j = 1; j < len; j++)
          ++i;
      }
    }
    catch (UnsupportedEncodingException e)
    {
      // virtual
    }
    catch (ArrayIndexOutOfBoundsException e)
    {
      // exit
      return;
    }
  }

  public String getOrganization()
  {
    return tags.get(O);
  }

  public String getOrganizationalUnit()
  {
    return tags.get(OU);
  }

  public String getCommonName()
  {
    return tags.get(CN);
  }

  public String getGivenName()
  {
    return tags.get(GN);
  }

  public String getSurname()
  {
    return tags.get(SN);
  }

  public String getCountry()
  {
    return tags.get(C);
  }

  /**
   * This is not the certificates serial number.
   *
   * @return SerialNo-Tag of the issuer
   */
  public String getSerialNo()
  {
    return tags.get(SERIAL_NO);
  }

  public String getLocality()
  {
    return tags.get(LOCAL);
  }

  public String getEmailAddress()
  {
    return tags.get(EMAILADDRESS);
  }

  /**
   * Requests any tags
   * @param _oid DER-encoded tag OID
   * @return
   */
  public String getAny(byte[] _oid)
  {
    long key = 0;

    for (int i = 0; i < _oid.length; i++)
    {
      key <<= 8;
      key |= _oid[i]&0xff;
    }

    return tags.get(Long.valueOf(key));
  }

  /**
   * Replaces "T61" characters by the corresponding UTF-8 character.
   *
   * @param s the string to parse
   * @return the parsed string
   */
  public static String replaceT61Characters(String _s)
  {
    String s = _s;
    s = s.replaceAll("�a", "�");
    s = s.replaceAll("�o", "�");
    s = s.replaceAll("�u", "�");
    s = s.replaceAll("�A", "�");
    s = s.replaceAll("�O", "�");
    s = s.replaceAll("�U", "�");
    s = s.replaceAll("�", "�");
    s = s.replaceAll("�e", "�");
    s = s.replaceAll("�e", "�");

    return s;
  }


  public String toString()
  {
    return tags.toString();
  }
}
