/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.common;

import java.io.Serializable;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.etsi.uri._02231.v2.TSPInformationType;
import org.etsi.uri._02231.v2.TSPServiceInformationType;

import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;

/**
 * Represents the result of a certificate validation
 * @author buengener
 *
 * 
*/

public class CertificatevalidatorResult implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 6649660042076801454L;

  private static Logger LOG = Logger.getLogger(CertificatevalidatorResult.class.getName());

  /** Liste von ValidateMethod Objekten. */
  private int status = 2;

  private Date notBefore = null;

  private Date notOnOrAfter = null;

  private final List<Integer> validReason = new ArrayList<Integer>();

  private final List<Integer> invalidReason = new ArrayList<Integer>();

  private final List<Integer> indeterminateReason = new ArrayList<Integer>();

  private String caRating = null;

  private ValMethodType validateScheme = null;

  private boolean valSchemeOCSPCommonPKI;

  private String errorCode = null;

  private String errorMessage = null;

  private String validateMethod = null;

  private String countryCode = "";

  /** Ergebniss der Pfadpruefung */
  private CPVResponse cPVResponse;

  /** Ungeprueftes Zertifikat*/
  private byte[] certificateEncoded;

  /** Geprueftes Zertifikat*/
  protected X509Certificate certificate;

  private Integer chainpos;

  /** Zertifikat ist OK */
  public static final int STATUS_VALID = 0;

  public static final int STATUS_INVALID = 1;

  public static final int STATUS_INDETERMINATE = 2;

  /** Grund warum das Zertifikat zurueckgezogen wurde.*/
  private int revocationReason = 11;

  public static final int REVOCATIONREASON_UNSPECIFIED = 0;

  public static final int REVOCATIONREASON_KEYCOMPROMISE = 1;

  public static final int REVOCATIONREASON_CACOMPROMISE = 2;

  public static final int REVOCATIONREASON_AFFILIATIONCHANGED = 3;

  public static final int REVOCATIONREASON_SUPERSEDED = 4;

  public static final int REVOCATIONREASON_CESSATIONOFOPERATION = 5;

  public static final int REVOCATIONREASON_CERTIFICATEHOLD = 6;

  // 7 missing, see rfc5280
  public static final int REVOCATIONREASON_REMOVEFROMCRL = 8;

  // nicht Common PKI
  public static final int REVOCATIONREASON_PRIVILEGE_WITHDRAWN = 9;

  public static final int REVOCATIONREASON_AA_COMPROMISE = 10;

  public static final int REVOCATIONREASON_NONE = 11;

  public static final String INDETERMINATEREASON_ISSUER_ONLINE_CHECK_NOT_SUPPORTED = "INDETERMINATEREASON_ISSUER_ONLINE_CHECK_NOT_SUPPORTED";

  public static final String INDETERMINATEREASON_INTERNAL_ERROR = "INDETERMINATEREASON_INTERNAL_ERROR";

  public static final Integer XKMSREASONS_REVOCATION_STATUS = Integer.valueOf(10000);

  public static final Integer XKMSREASONS_ISSUER_TRUST = Integer.valueOf(10001);

  public static final Integer XKMSREASONS_SIGNATURE = Integer.valueOf(10002);

  public static final Integer XKMSREASONS_VALIDITYINTERVAL = Integer.valueOf(10003);

  /** Time of revocation */
  private Date revocationTime = null;

  private String certQuality;

  private String cspAssurance;

  private String tslIdentifier;

  private String algPolicyIdentifier;

  private TSPInformationType tspInformation;

  private TSPServiceInformationType tspServiceInformation;

  private String configVersion;

  private String validationModel;

  private Calendar validationTimeQueried;

  /** Validation result issuer certificate */
  private CertificatevalidatorResult issuerValidationResult;

  /** Hash algorithm  of certificate signature */
  private String digestAlgorithm;

  /** Cipher algorithm of certificate signature */
  private String cipherAlgorithm;

  /** Timestamp signature */
  private Integer timestampSignature;

  /** Timestamp */
  private byte[] timestamp;

  /** Timestamp certificate validation result */
  private CPVResponse timestampCertificateCPVResult;


  /**
   * Creates a new CertifacatevalidatorResult object.
   *
   * @param certificate
   *
   * @throws IllegalArgumentException
   */
  public CertificatevalidatorResult(X509Certificate certificate) throws IllegalArgumentException
  {
    if (certificate == null)
    {
      throw new IllegalArgumentException("Certificate can't be null");
    }

    this.certificate = certificate;

    //@ToDo: other algorithms / elliptic curves...
    String oid = certificate.getSigAlgOID();
    if (oid.equals("1.2.840.113549.1.1.11")) // SHA256
    {
      cipherAlgorithm = "1.2.840.113549.1.1.1";
      digestAlgorithm = "2.16.840.1.101.3.4.2.1";
    }
    else if (oid.equals("1.2.840.113549.1.1.4")) // MD5
    {
      cipherAlgorithm = "1.2.840.113549.1.1.1";
      digestAlgorithm = "1.2.840.113549.2.5";
    }
    else if (oid.equals("1.2.840.113549.1.1.5")) // SHA-1
    {
      cipherAlgorithm = "1.2.840.113549.1.1.1";
      digestAlgorithm = "1.3.14.3.2.26";
    }

  }

  /**
   * Creates a new CertifacatevalidatorResult object.
   *
   * @param errorcode
   */
  public CertificatevalidatorResult(String errorcode)
  {
    errorCode = errorcode;
    certQuality = Constants.ATT_ISSUER_QUALITY_NONE;
  }

  public X509Certificate getCertificate()
  {
    return certificate;
  }

  public String getCaRating()
  {
    return caRating;
  }

  public List<Integer> getIndeterminateReason()
  {
    return indeterminateReason;
  }

  public List<Integer> getInvalidReason()
  {
    return invalidReason;
  }

  public Date getNotBefore()
  {
    return ((notBefore != null) ? (Date) notBefore.clone() : null);
  }

  public Date getNotOnOrAfter()
  {
    return ((notOnOrAfter != null) ? (Date) notOnOrAfter.clone() : null);
  }

  public int getStatus()
  {
    return status;
  }

  public ValMethodType getValidateScheme()
  {
    return validateScheme;
  }

  public List<Integer> getValidReason()
  {
    return validReason;
  }

  public Date getRevokationTime()
  {
    return ((revocationTime != null) ? (Date) revocationTime.clone() : null);
  }

  public void setErrorCode(String errorCode)
  {
    this.errorCode = errorCode;
  }

  public String getErrorCode()
  {
    return errorCode;
  }

  public void setErrorMessage(String errorMsg)
  {
    this.errorMessage = errorMsg;
  }

  public String getErrorMessage()
  {
    return errorMessage;
  }

  public void setRevokationTime(Date _revocationTime)
  {
    revocationTime = _revocationTime;
  }

  public void setRevokationReason(int revocationReason)
  {
    this.revocationReason = revocationReason;
  }

  public int getRevokationReason()
  {
    return revocationReason;
  }

  public void setCaRating(String caRating)
  {
    this.caRating = caRating;
  }

  public void setCertificate(X509Certificate certificate)
  {
    this.certificate = certificate;
  }

  public void addIndeterminateReason(Integer _indeterminateReson)
  {
    if (!indeterminateReason.contains(_indeterminateReson))
    {
      indeterminateReason.add(_indeterminateReson);
    }
    checkForDuplicateReasonCodes();
  }

  public void addInvalidReason(Integer _invalidReson)
  {
    if (!invalidReason.contains(_invalidReson))
    {
      invalidReason.add(_invalidReson);
    }
    checkForDuplicateReasonCodes();
  }

  public void setNotBefore(Date notBefore)
  {
    this.notBefore = (Date) notBefore.clone();
  }

  public void setStatus(int status)
  {
    this.status = status;
  }

  public void setValidateScheme(ValMethodType validateScheme)
  {
    this.validateScheme = validateScheme;
  }

  public boolean isValSchemeOCSPCommonPKI()
  {
	  return valSchemeOCSPCommonPKI;
  }

  public void setValSchemeOCSPCommonPKI(boolean commonPKI)
  {
	  valSchemeOCSPCommonPKI = commonPKI;
  }

  public void addValidReason(Integer _validReason)
  {
    if (!validReason.contains(_validReason))
    {
      validReason.add(_validReason);
    }
    checkForDuplicateReasonCodes();
  }

  public void setCPVResponse(CPVResponse cPVResponse)
  {
    this.cPVResponse = cPVResponse;
  }

  public CPVResponse getCPVResponse()
  {
    return cPVResponse;
  }

  public Integer getChainpos()
  {
    return chainpos;
  }

  public void setChainpos(Integer chainpos)
  {
    this.chainpos = chainpos;
  }

  public void setNotOnOrAfter(Date notOnOrAfter)
  {
    this.notOnOrAfter = (Date) notOnOrAfter.clone();
  }

  public String getCertQuality()
  {
    return certQuality;
  }

  public void setCertQuality(String certQuality)
  {
    this.certQuality = certQuality;
  }

  public String getCSPAssurance()
  {
    LOG.fine("CertificatevalidatorResult.getCSPAssurance: " + cspAssurance);
    return cspAssurance;
  }

  public void setCSPAssurance(String cspAssurance)
  {
    this.cspAssurance = cspAssurance;
    LOG.fine("CertificatevalidatorResult.setCSPAssurance: " + cspAssurance);
  }

  public byte[] getCertificateEncoded()
  {
    return certificateEncoded.clone();
  }

  public void setCertificateEncoded(byte[] inpCertificateEncoded)
  {
    certificateEncoded = inpCertificateEncoded.clone();
  }

  private void checkForDuplicateReasonCodes()
  {
    for (int ti = 0; ti < invalidReason.size(); ti++)
    {
      Integer tmpInvalidReason = invalidReason.get(ti);
      validReason.remove(tmpInvalidReason);
      indeterminateReason.remove(tmpInvalidReason);
    }
    for (int ta = 0; ta < indeterminateReason.size(); ta++)
    {
      Integer tmpIndeterminateReason = indeterminateReason.get(ta);
      validReason.remove(tmpIndeterminateReason);
    }
  }

  public CertificatevalidatorResult getIssuerValidationResult()
  {
    return issuerValidationResult;
  }

  public void setIssuerValidationResult(CertificatevalidatorResult issuerValidationResult)
  {
    this.issuerValidationResult = issuerValidationResult;
  }

  public Integer getTimestampSignature()
  {
    return timestampSignature;
  }


  public void setTimestampSignature(Integer timestampSignature)
  {
    this.timestampSignature = timestampSignature;
  }


  public byte[] getTimestamp()
  {
    return timestamp;
  }


  public void setTimestamp(byte[] timestamp)
  {
    this.timestamp = timestamp;
  }


  public CPVResponse getTimestampCertificateCPVResult()
  {
    return timestampCertificateCPVResult;
  }


  public void setTimestampCertificateCPVResult(CPVResponse timestampCertificateCPVResult)
  {
    this.timestampCertificateCPVResult = timestampCertificateCPVResult;
  }

  public String getDigestAlgorithm()
  {
    return digestAlgorithm;
  }

  public String getCipherAlgorithm()
  {
    return cipherAlgorithm;
  }

  public String getConfigVersion()
  {
    return configVersion;
  }

  public void setConfigVersion(String configVersion)
  {
    this.configVersion = configVersion;
  }

  public String getTslIdentifier()
  {
    return tslIdentifier;
  }

  public void setTslIdentifier(String tslIdentifier)
  {
    this.tslIdentifier = tslIdentifier;
  }

  public String getAlgPolicyIdentifier()
  {
    return algPolicyIdentifier;
  }

  public void setAlgPolicyIdentifier(String algPolicyIdentifier)
  {
    this.algPolicyIdentifier = algPolicyIdentifier;
  }

  public String getValidationModel()
  {
    return validationModel;
  }

  public void setValidationModel(String validationModel)
  {
    this.validationModel = validationModel;
  }

  public Calendar getValidationTimeQueried()
  {
    return validationTimeQueried;
  }

  public void setValidationTimeQueried(Calendar validationTimeQueried)
  {
    this.validationTimeQueried = validationTimeQueried;
  }

  public void setCountryCode(String inpCountryCode)
  {
    countryCode = inpCountryCode;
  }

  public String getCountryCode()
  {
    return countryCode;
  }

  public TSPInformationType getTspInformation()
  {
		return tspInformation;
  }

  public void setTspInformation(TSPInformationType tspInformation)
  {
	  this.tspInformation = tspInformation;
  }

  public TSPServiceInformationType getTspServiceInformation()
  {
	  return tspServiceInformation;
  }

  public void setTspServiceInformation(TSPServiceInformationType tspServiceInformation)
  {
	  this.tspServiceInformation = tspServiceInformation;
  }
}
