/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.trustcenterrequest.ocsp;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.bouncycastle.ocsp.BasicOCSPResp;
import org.bouncycastle.ocsp.CertificateID;
import org.bouncycastle.ocsp.OCSPException;
import org.bouncycastle.ocsp.OCSPReq;
import org.bouncycastle.ocsp.OCSPReqGenerator;
import org.bouncycastle.ocsp.OCSPResp;
import org.bouncycastle.ocsp.RevokedStatus;
import org.bouncycastle.ocsp.UnknownStatus;
import org.bouncycastle.util.encoders.Base64;

import eu.peppol.lsp.xkmsresponder.certificatepathvalidator.CertificatePathValidatorProcess;
import eu.peppol.lsp.xkmsresponder.certificatevalidator.OCSPResponseCache;
import eu.peppol.lsp.xkmsresponder.certificatevalidator.OCSPResponseCacheEntry;
import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvOCSPResult;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ProxyDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodOcspDto;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;

/**
 * This class performs OCSP requests.
 *
 * @author Andre jens
 * @author Marc Horstmann
 * @author buengener
 * 
*/
public class OCSPRequester
{
  private static final Logger LOG = Logger.getLogger(OCSPRequester.class.getName());

  private static final Logger LOG_OCSP_Response = Logger.getLogger("OCSP_Response");

  private OCSPRequester()
  {
    // just to make the constructor private
  }

  /**
   * Process the OCSP-Request.
   *
   * @param issuer Issuer of the Certificate to be checked
   * @param user The Certificate to be checked
   * @param validateMethod the information where and how to check the certificate
   * @param ocspNoCache use ocsp cache ?
   * @param _requestID the original requestIDs
   *
   * @return CvOCSPResult
   *
   * @throws IllegalArgumentException DOCUMENT ME!
   */
  public static CvOCSPResult doRequest(final X509Certificate issuer, final X509Certificate user,
                                       final ValMethodOcspDto validateMethod, final boolean ocspNoCache,
                                       Long _requestID)
  {
    if (issuer == null)
    {
      throw new IllegalArgumentException("Param issuer can't be null");
    }

    if (user == null)
    {
      throw new IllegalArgumentException("Param user can't be null");
    }

    if (validateMethod == null)
    {
      throw new IllegalArgumentException("Param pruefmethode can't be null");
    }

    if (_requestID == null)
    {
      throw new IllegalArgumentException("Param requestID can't be null");
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("(start) doRequest(issuer " + issuer.getSubjectDN().getName() + " , user "
                + user.getSubjectDN().getName() + " , ValMethod " + validateMethod.getName() + " )");
    }

    Vector<String> errorIndicator = new Vector<String>();
    CvOCSPResult cvOCSPResult = null;

    try
    {
      boolean usedcache = false;
      CertificateID id = buildID(issuer, user);
      byte[] resp = null;

      if (validateMethod.getUseCache() && !ocspNoCache)
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("Trying to use OCSP-Cache. Value of ocspNoCache: " + ocspNoCache);
        }

        cvOCSPResult = new CvOCSPResult(user);
        OCSPResponseCacheEntry tmpEntry = OCSPResponseCache.findEntry(user);

        if (tmpEntry != null)
        {
          LOG.fine("Cached entry found ");
          usedcache = true;
//          cvOCSPResult = tmpEntry.getCvOCSPResult();
          cvOCSPResult.setStatus(tmpEntry.getStatus());
          cvOCSPResult.setProducedAt(tmpEntry.getProducedAt());
          cvOCSPResult.setOcspResp(tmpEntry.getOcspResp());
          cvOCSPResult.setOcspRespSignature(tmpEntry.getOcspRespSignature());
          cvOCSPResult.setOcspRespStatus(tmpEntry.getOcspRespStatus());
          cvOCSPResult.setRevokationReason(tmpEntry.getRevocationReason());
          cvOCSPResult.setRevokationTime(tmpEntry.getRevocationTime());
          cvOCSPResult.setCommonPKIIndeterminate(tmpEntry.isCommonPKIIndeterminate());
          cvOCSPResult.setErrorCode(tmpEntry.getErrorCode());
          cvOCSPResult.setCPVResponse(tmpEntry.getCpvResponse());
          tmpEntry.addReasons(cvOCSPResult);
        }
        else
        {
          LOG.fine("No cached entry found ");
//          cvOCSPResult = new CvOCSPResult(user);
        }
      }

      if (!usedcache)
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("No cached OCSP-Result found. Start new Request.");
          LOG.fine("Is ocspNoCache set ? " + ocspNoCache);
        }

        cvOCSPResult = new CvOCSPResult(user);

        byte[] request = buildOCSPRequest(id);
        resp = sendOCSPRequest(validateMethod.getUrl(), request);

        final BasicOCSPResp brep = buildOCSPResponse(resp, cvOCSPResult); // ToDO
        if (LOG_OCSP_Response.isLoggable(Level.FINE))
        {
          LOG_OCSP_Response.fine("\n\n\nRequestID: " + _requestID);
          LOG_OCSP_Response.fine("Request CertID: " + ResponderHelper.base64encode(id.toASN1Object().getEncoded()));
          LOG_OCSP_Response
                           .fine("Respone CertID"
                                  + ResponderHelper.base64encode((brep.getResponses()[0].getCertID().toASN1Object()
                                		  .getEncoded())));
          LOG_OCSP_Response.fine("Request: \n " + ResponderHelper.base64encode(request));
          LOG_OCSP_Response.fine("Response: \n" + ResponderHelper.base64encode(resp));
        }


        if (!equalCertIDs(brep.getResponses()[0].getCertID(), id))
        {
          cvOCSPResult = new CvOCSPResult(user);
          cvOCSPResult.setErrorCode(CvOCSPResult.OCSPResp_MALFORMED_REQUEST);
          cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_UNCHECKED);
          cvOCSPResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
          cvOCSPResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
          errorIndicator.add(validateMethod.getName());
          ResponderHelper.setOCSPSuccess(validateMethod.getName(), Boolean.FALSE);
          LOG_OCSP_Response.severe("\n\n\nWrong CertID for RequestID: " + _requestID);
          LOG_OCSP_Response.severe("RequestCertID: " + ResponderHelper.base64encode(id.toASN1Object().getEncoded()));
          LOG_OCSP_Response
                           .severe("Respone CertID"
                                  + new String(Base64.encode((brep.getResponses()[0].getCertID().toASN1Object()
                                		  .getEncoded()))));
          LOG_OCSP_Response.severe("Request: \n " + ResponderHelper.base64encode(request));
          LOG_OCSP_Response.severe("Response: \n" + ResponderHelper.base64encode(resp));

          return cvOCSPResult;
        }

        if (validateMethod.getCheckRespSignature().booleanValue())
        {
          checkOCSPRespSignature(brep, cvOCSPResult, ocspNoCache, _requestID, issuer);
        }
        else
        {
          cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_UNCHECKED);
        }

        // extended logging for probative facts

        Object state = brep.getResponses()[0].getCertStatus();
        if (state instanceof UnknownStatus)
        {

          LOG_OCSP_Response.severe("\n\n\nUnknownStatus for RequestID: " + _requestID);
          LOG_OCSP_Response.severe("Request for username: " + user.getSubjectDN().getName()
                                  + " and CA certificate: " + issuer.getSubjectDN().getName());
          LOG_OCSP_Response.severe("RequestCertID: " + ResponderHelper.base64encode(id.toASN1Object().getEncoded()));
          LOG_OCSP_Response.severe("Request: \n " + ResponderHelper.base64encode(request));
          LOG_OCSP_Response.severe("Response: \n" + ResponderHelper.base64encode(resp));
        }
        if (state instanceof RevokedStatus)
        {
          LOG_OCSP_Response.severe("\n\n\nRevokedStatus for RequestID: " + _requestID);
          LOG_OCSP_Response.severe("Request for username: " + user.getSubjectDN().getName()
                                  + " and CA certificate: " + issuer.getSubjectDN().getName());
          LOG_OCSP_Response.severe("RequestCertID: " + ResponderHelper.base64encode(id.toASN1Object().getEncoded()));
          LOG_OCSP_Response.severe("Request: \n " + ResponderHelper.base64encode(request));
          LOG_OCSP_Response.severe("Response: \n" + ResponderHelper.base64encode(resp));
        }


        int res = parseOCSPResp(brep, cvOCSPResult, validateMethod);
        int tmpRespSignature = cvOCSPResult.getOcspRespSignature();

        // cachen ??
        if (validateMethod.getUseCache() && (res == CertificatevalidatorResult.STATUS_VALID) // @todo check
            && (tmpRespSignature == CvOCSPResult.OCSPResp_VALID))
        {
          long cacheTimeout =
                System.currentTimeMillis() + (validateMethod.getCacheTimeout().longValue() * 1000);
          if (cvOCSPResult.isCommonPKIIndeterminate())
          {
            res = CertificatevalidatorResult.STATUS_INDETERMINATE;
          }
          OCSPResponseCache.addEntry(user, cacheTimeout, res, cvOCSPResult);
        }
      }

      if (errorIndicator.contains(validateMethod.getName()))
      {
        errorIndicator.remove(validateMethod.getName());
      }

      ResponderHelper.setOCSPSuccess(validateMethod.getName(), Boolean.TRUE);
      return cvOCSPResult;
    }
    catch (RuntimeException ex)
    {
      cvOCSPResult = handleException(user, validateMethod, errorIndicator, ex);
      return cvOCSPResult;
    }
    catch (Exception ex)
    {
      cvOCSPResult = handleException(user, validateMethod, errorIndicator, ex);
      return cvOCSPResult;
    }
  }

  private static boolean equalCertIDs(CertificateID req, CertificateID rsp)
  {
	  if (!req.getHashAlgOID().equals(rsp.getHashAlgOID()))
		  return false;
	  if (!req.getSerialNumber().equals(rsp.getSerialNumber()))
		  return false;
	  if (!Arrays.equals(req.getIssuerNameHash(), rsp.getIssuerNameHash()))
		  return false;
	  if (!Arrays.equals(req.getIssuerKeyHash(), rsp.getIssuerKeyHash()))
		  return false;
	  return true;
  }

  private static CvOCSPResult handleException(final X509Certificate user,
                                              final ValMethodOcspDto validateMethod,
                                              Vector<String> errorIndicator, Exception ex)
  {
    CvOCSPResult cvOCSPResult;
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.log(Level.FINE, "Exception", ex);
    }

    cvOCSPResult = new CvOCSPResult(user);
    cvOCSPResult.setErrorCode(CvOCSPResult.OCSPResp_INTERNAL_ERROR);
    cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_UNCHECKED);
    cvOCSPResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    cvOCSPResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
    errorIndicator.add(validateMethod.getName());
    ResponderHelper.setOCSPSuccess(validateMethod.getName(), Boolean.FALSE);
    return cvOCSPResult;
  }

  private static CertificateID buildID(final X509Certificate issuerCert, final X509Certificate userCert)
        throws OCSPException
  {
    CertificateID id = null;

    try
    {
      id =
            new CertificateID(CertificateID.HASH_SHA1, issuerCert,
                              userCert.getSerialNumber());
    }
    catch (OCSPException ex)
    {
      LOG.log(Level.SEVERE, "Can't create CertificateID", ex);

      throw ex;
    }

    return id;
  }

  /**
   * Build a OCSPRequest Structure.
   *
   * @param issuerCert Issuer Certificate
   * @param userCert User Certificate
   * @param signRequest -- Platzhalter muss noch gekl?rt werden wie
   */
  private static byte[] buildOCSPRequest(final CertificateID id) throws OCSPException, IOException
  {
    OCSPReqGenerator gen = new OCSPReqGenerator();
    gen.addRequest(id);

    OCSPReq req = null;

    try
    {
      req = gen.generate();
    }
    catch (OCSPException ex)
    {
      LOG.log(Level.SEVERE, "Can't create OCSPRequest.", ex);

      throw ex;
    }

    try
    {
      return req.getEncoded();
    }
    catch (IOException ex)
    {
      LOG.log(Level.SEVERE, "Error while encoding OCSPRequest", ex);

      throw ex;
    }
  }

  /**
   *
   */
  private static BasicOCSPResp buildOCSPResponse(final byte[] resp, CvOCSPResult cvOCSPResult)
        throws OCSPException, NoSuchProviderException, IOException
  {
    LOG.fine("(start) buildOCSPResponse");

    OCSPResp response = new OCSPResp(new ByteArrayInputStream(resp));

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("OCSPResponse Status : " + response.getStatus());
    }

    cvOCSPResult.setOcspRespStatus(response.getStatus());

    if (response.getStatus() == 0)
    {
      BasicOCSPResp brep = (BasicOCSPResp) response.getResponseObject();
      cvOCSPResult.setOcspResp(resp);

      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("Produced at :" + brep.getProducedAt().toString());
      }

      cvOCSPResult.setProducedAt(brep.getProducedAt().toString());
      LOG.fine("Count SingleResponses in OCSPResponse: " + brep.getResponses().length);

      if (LOG.isLoggable(Level.FINE))
      {
    	  if (brep.getCerts(ResponderHelper.SECURITYPROVIDER.getName()).length > 0)
    		  LOG.fine("Certificate: " + brep.getCerts(ResponderHelper.SECURITYPROVIDER.getName())[0].getSubjectDN().getName());

        if (brep.getResponses()[0].getCertStatus() == null)
        {
          LOG.fine("Status OK");
        }
        else
        {
          LOG.severe("STATUS not OK. Got a :" + brep.getResponses()[0].getCertStatus());
        }
      }

      return brep;
    }

    throw new OCSPException("received answer with status != 0");
  }

  /**
   * @param uri
   * @param request
   */
  private static byte[] sendOCSPRequest(String url, byte[] request) throws IOException
  {
    if (LOG.isLoggable(Level.FINE))
    {
        LOG.fine("(start) sendOCSPRequest(" + url + " , _request_ )");
    }

    ProxyDto tmpProxyDto = null;
    try
    {
      tmpProxyDto = Configuration.getProxyDto();
    }
    catch (Exception e)
    {
      tmpProxyDto = new ProxyDto();
    }

    try
    {
      int tmpTimeOut = tmpProxyDto.getTimeout().intValue() * 1000; // convert seconds to millis
      return ResponderTransport.sendHTTPRequest(url, request, ResponderTransport.HTTP_OCSP_HEADER);
    }
    catch (final Exception ex)
    {
      IOException tmpException = new IOException("Can't connect to " + url + " . " + ex.getMessage());
      tmpException.initCause(ex);
      throw tmpException; // Modulgrenze
    }
  }

  private static int parseOCSPResp(final BasicOCSPResp bresp, CvOCSPResult refCvOCSPResult,
                                      ValMethodOcspDto inpValMethodOcspDto)
  {
    try
    {
      Object state = bresp.getResponses()[0].getCertStatus();

      if (state == null)
      {
        refCvOCSPResult.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        refCvOCSPResult.setStatus(CertificatevalidatorResult.STATUS_VALID);
        LOG.fine("STATUS valid");

        return CertificatevalidatorResult.STATUS_VALID;
      }


      if ((state instanceof UnknownStatus))
      {
        if (inpValMethodOcspDto.getSubType().equalsIgnoreCase("rfc"))
        {
          refCvOCSPResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
          refCvOCSPResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("OCSP-Subtype was RFC and Certificate-Status was unknown. Returning Indeterminate.");
            LOG.fine("Certificate: " + refCvOCSPResult.getCertificate().getSubjectDN().getName()
                      + " Has the following status: " + state.toString());
          }

          return CertificatevalidatorResult.STATUS_INDETERMINATE;
        }

        // bei Common PKI konformen OCSP-Responsern bedeutet Unknown, das dem
        // Herausgeber das Zertifikat nicht bekannt ist. Deshalb wird das
        // Zertifikat auf Invalid gesetzt.
        refCvOCSPResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        LOG.warning("OCSP-Subtype was not RFC and Certificate-Status was Unknown. Returning Invalid.");
        refCvOCSPResult.setRevokationReason(CertificatevalidatorResult.REVOCATIONREASON_NONE);

        Date revdate = new Date();
        revdate.setTime(0);
        refCvOCSPResult.setRevokationTime(revdate);
        // fuers caching, wird dort wieder auf Indeterminate gesetzt,
        // damit wieder geprueft wird, falls das Zertifikat doch
        // noch eingestellt wurde.
        refCvOCSPResult.setCommonPKIIndeterminate(true);
        refCvOCSPResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
        LOG.fine("STATUS invalid");

        return CertificatevalidatorResult.STATUS_INVALID;
      }

      refCvOCSPResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);

      RevokedStatus rev = (RevokedStatus) state;
      if (rev.hasRevocationReason())
      {
        LOG.fine("RevocationReason in OCSPRequester: " + rev.getRevocationReason());
        LOG.fine("RevocationTime in OCSPRequester: " + rev.getRevocationTime());
        refCvOCSPResult.setRevokationReason(rev.getRevocationReason());
        refCvOCSPResult.setRevokationTime(rev.getRevocationTime());
      }
      else
      {
    	LOG.fine("RevocationTime in OCSPRequester: " + rev.getRevocationTime());
        refCvOCSPResult.setRevokationReason(CertificatevalidatorResult.REVOCATIONREASON_NONE);
        refCvOCSPResult.setRevokationTime(rev.getRevocationTime());
      }

      refCvOCSPResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
      LOG.fine("STATUS invalid");

      return CertificatevalidatorResult.STATUS_INVALID;
    }
    catch (java.lang.NullPointerException ex)
    {
      refCvOCSPResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
      refCvOCSPResult.setErrorCode(CertificatevalidatorResult.INDETERMINATEREASON_INTERNAL_ERROR);
      LOG.log(Level.SEVERE, "Error in parseOCSPRespose", ex);
      refCvOCSPResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
      LOG.fine("STATUS indeterminate");

      return CertificatevalidatorResult.STATUS_INDETERMINATE;
    }
  }

  /**
   * Signatur der OCSP-Antwort pr?fen.
   *
   * Zu dem Pr?fen der Signatur geh?rt auch das Pr?fen der Zertifikate. Daherr geht hier alles den gewohnten Gang. Also
   * erst Pathbuilder dann Verifyer.
   *
   * @param brep
   */
  private static void checkOCSPRespSignature(BasicOCSPResp brep, CvOCSPResult cvOCSPResult,
                                             final boolean ocspNoCache, Long _requestID, X509Certificate issuerCert)
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("(start) checkOCSPRespSignature");
    }

    byte[] signature = brep.getSignature();
    X509Certificate[] signerCertChain = null;

    try
    {
      X509Certificate[] tmpCerts = brep.getCerts(ResponderHelper.SECURITYPROVIDER.getName());
      if (tmpCerts.length ==0)
      {
	      signerCertChain = new X509Certificate[1];
	      signerCertChain[0] = issuerCert;
      }
      else
      {
	      signerCertChain = new X509Certificate[tmpCerts.length];
	      for (int ti = 0; ti < tmpCerts.length; ti++)
	      {
	        signerCertChain[ti] = tmpCerts[ti];
	        LOG.fine("Certificate added");
	      }
      }

    }
    catch (NoSuchProviderException e)
    {
      LOG.fine("NoSuchProvider: " + e);
      cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_UNCHECKED);

      return;
    }
    catch (OCSPException e)
    {
      LOG.fine("OCSPException: " + e);
      cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_UNCHECKED);

      return;
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "Error while getting certificates from OCSPResponse", ex);
      return;
    }

    // Response was signed
    if (signature != null)
    {
      LOG.fine("Signature not null");
      try
      {
        /** DTrust stellt Zertifikate doppelt ein */
        ArrayList<X509Certificate> certs = new ArrayList<X509Certificate>();
        boolean currentlyChecked = false;

        for (int i = 0; i < signerCertChain.length; i++)
        {
          boolean check =
                ResponderHelper.isCurrentlyValidatingSignatureCertificate(_requestID, signerCertChain[i]);

          if (check && (i == 0))
          {
            LOG.fine("Signature is currently checked");
            currentlyChecked = true;
          }

          if (!check && currentlyChecked)
          {
            if (LOG.isLoggable(Level.FINE))
            {
              LOG.fine("Certificate dont found in Check: "
                        + signerCertChain[i].getSubjectX500Principal().getName() + ". Checking !!!");
            }

            currentlyChecked = false;
          }

          if (!certs.contains(signerCertChain[i]))
          {
            certs.add(signerCertChain[i]);
            ResponderHelper.addCurrentlyValidatingSignatureCertificate(_requestID, signerCertChain[i]);
            LOG.fine("Certificate added : " + signerCertChain[i].getSubjectDN().getName());
          }
          else
          {
            LOG.fine("Found duplicate Entry : " + signerCertChain[i].getSubjectDN().getName());
          }
        }

        signerCertChain = certs.toArray(new X509Certificate[certs.size()]);
        boolean trustedAnchor = false;
        for (X509Certificate tmpElement : signerCertChain)
        {
          if (brep.verify(tmpElement.getPublicKey(), ResponderHelper.SECURITYPROVIDER.getName()))
          {
            trustedAnchor = isTACert(tmpElement);
          }
        }

        if (!currentlyChecked)
        {
          if (!trustedAnchor)
          {
            LOG.fine("CertificateChain not currently checked !!!");

            CPVResponse cPVResponse =
                  verifyCertificate(signerCertChain, ocspNoCache, _requestID);
            cvOCSPResult.setCPVResponse(cPVResponse);
            LOG.fine("Check ends here");

            if (cPVResponse.getResult().intValue() == 0)
            {
              // Jetzt CPVResponse interpretieren.
              // Signatur pruefen
              boolean signerCert = false;

              for (X509Certificate tmpElement : signerCertChain)
              {
                if (brep.verify(tmpElement.getPublicKey(), ResponderHelper.SECURITYPROVIDER.getName()))
                {
                  signerCert = true;
                }
              }

              if (signerCert)
              {
                cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_VALID);
              }
              else
              {
                cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_INVALID);

                if (LOG.isLoggable(Level.FINE))
                {
                  for (int ti = 0; ti < signerCertChain.length; ti++)
                  {
                    LOG.fine("Certificate # " + ti + " " + signerCertChain[ti].getSubjectDN().getName());
                  }
                }

                if (LOG.isLoggable(Level.FINE))
                {
                  LOG.severe("OCSP-Response Signature is invalid");
                }
              }
            }
            else if (cPVResponse.getResult().intValue() == 2)
            {
              cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_INDETERMINATE);
              if (LOG.isLoggable(Level.FINE))
              {
                LOG.severe("OCSP-Response Signature is indeterminate");
              }
            }
            else
            {
              cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_INVALID);

              if (LOG.isLoggable(Level.FINE))
              {
                for (int ti = 0; ti < signerCertChain.length; ti++)
                {
                  LOG.fine("Certificate # " + ti + " " + signerCertChain[ti].getSubjectDN().getName());
                }
              }
            }
          }
          else
          {

            cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_VALID);
            LOG.fine("OCSPResponse was signed with TACert. No need to verify");
          }
          for (X509Certificate tmpElement : signerCertChain)
          {
            ResponderHelper.removeCurrentlyValidatingSignatureCertificate(_requestID, tmpElement);
          }
        }
        else
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Chain of OCSP-Response will also be checked. Not checking again !!!");
          }

          cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_VALID);
        }
      }
      catch (OCSPException ex)
      {
        cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_UNCHECKED);

        if (LOG.isLoggable(Level.FINE))
        {
          LOG.log(Level.FINE, "Problem", ex);
        }

        for (X509Certificate tmpElement : signerCertChain)
        {
          ResponderHelper.removeCurrentlyValidatingSignatureCertificate(_requestID, tmpElement);
        }
      }
      catch (NoSuchProviderException ex)
      {
        cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_UNCHECKED);

        if (LOG.isLoggable(Level.FINE))
        {
          LOG.log(Level.FINE, "Problem", ex);
        }

        for (X509Certificate tmpElement : signerCertChain)
        {
          ResponderHelper.removeCurrentlyValidatingSignatureCertificate(_requestID, tmpElement);
        }
      }
    }
    else
    {
      LOG.fine("Signature is null");
      cvOCSPResult.setOcspRespSignature(CvOCSPResult.OCSPResp_NOT_SIGNED);
    }
  }

  /**
   * Die fuer die Signatur der OCSP-Antwort verwendeten Zertifikate pruefen.
   *
   * Diese Zertifikate durchlaufen die selbe Pruefung, wie alle anderen Zertifikate.
   *
   *
   * @param certchain
   *
   */
  private static CPVResponse verifyCertificate(X509Certificate[] certificates, final boolean ocspNoCache,
                                               Long _requestID)
  {
    CPVRequest cpvReq = new CPVRequest();
    cpvReq.setOcspRequestID(_requestID);

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("verifyCertificate() - Number of certificates: " + certificates.length);
    }

    for (X509Certificate tmpElement : certificates)
    {
      try
      {
        cpvReq.addCertifcate(tmpElement.getEncoded());
      }
      catch (CertificateEncodingException ex)
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.log(Level.FINE, "CertificateEncoding - Error in verifyCertificate", ex);
        }
      }

    }

    cpvReq.setOcspNoCache(ocspNoCache);

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("verifyCertificate() sending Message");
    }

    return CertificatePathValidatorProcess.execute(cpvReq);
  }

  private static boolean isTACert(X509Certificate inpCert)
  {
    try
    {
      String tmpFingerprint = ResponderHelper.getFingerprint(inpCert);
      CertificateDto tmpTrustedAnchorDto =
    	  Configuration.getTrustedAnchor(tmpFingerprint);

      if (tmpTrustedAnchorDto == null)
      {
        return false;
      }

      return true;
    }
    catch (Exception ex)
    {
      return false;
    }
  }

}
