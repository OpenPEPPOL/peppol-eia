/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.requestcontroller;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3._2002._03.xkms.StatusType;

import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.xkms.TranslationTable;


/**
 * Helper class for getting validation status from validation result.
 * @author buengener
 *
 * 
*/
public class StatusHelper
{
  private static Logger LOG = Logger.getLogger(StatusHelper.class.getName());

  /**
   * Creates a new StatusHelper object.
   */
  private StatusHelper()
  {
    // nothing todo
  }

  public static StatusType getStatus(CPVResponse pCPVResponse)
  {
    StatusType status = null;
    CertificatevalidatorResult certValidatorResult = null;

    try
    {
      certValidatorResult = pCPVResponse.getValidatorResult(0);

      if (certValidatorResult != null)
      {
        status = new StatusType();

        //Status Value Valid
        if (pCPVResponse.getResult().intValue() == 0)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("STATUS = 0");
          }

          status.setStatusValue(TranslationTable.XKMS_STATUS_TABLE.get(0));

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("nochmal statusvalue in VALID: " + status.getStatusValue());
          }
        }

        //Status Value Invalid
        if (pCPVResponse.getResult().intValue() == 1)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("STATUS = 1");
          }

          status.setStatusValue(TranslationTable.XKMS_STATUS_TABLE.get(1));

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("nochmal statusvalue in INVALID: " + status.getStatusValue());
          }
        }

        //Status Value Indeterminate
        if (pCPVResponse.getResult().intValue() == 2)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("STATUS = 2");
          }

          status.setStatusValue(TranslationTable.XKMS_STATUS_TABLE.get(2));

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("nochmal statusvalue in Indeterminate: " + status.getStatusValue());
          }
        }

        //Valid Reason
        java.util.List<Integer> rvList = certValidatorResult.getValidReason();

        if ((rvList != null) && !rvList.isEmpty())
        {
          for (int i = 0; i < rvList.size(); i++)
          {
            Integer count = rvList.get(i);

            if (TranslationTable.XKMS_REASON_TABLE.get(count) != null)
            {
              String qn = TranslationTable.XKMS_REASON_TABLE.get(count);

              if (LOG.isLoggable(Level.FINE))
                  LOG.fine("Reason_ Valid Reason = " +  qn);

              status.getValidReason().add(qn);
            }
          }
        }

        //Invalid Reason
        java.util.List<Integer> rinvList = certValidatorResult.getInvalidReason();

        if ((rinvList != null) && !rinvList.isEmpty())
        {
          for (int i = 0; i < rinvList.size(); i++)
          {
            Integer count = rinvList.get(i);

            if (TranslationTable.XKMS_REASON_TABLE.get(count) != null)
            {
              String qn = TranslationTable.XKMS_REASON_TABLE.get(count);
              LOG.fine("Reason_ Invalid Reason = " + qn);
              status.getInvalidReason().add(qn);
            }
          }
        }

        //Indeterminate Reason
        java.util.List<Integer> riList = certValidatorResult.getIndeterminateReason();

        if ((riList != null) && !riList.isEmpty())
        {
          for (int i = 0; i < riList.size(); i++)
          {
            Integer count = riList.get(i);

            if (TranslationTable.XKMS_REASON_TABLE.get(count) != null)
            {
              String qn = TranslationTable.XKMS_REASON_TABLE.get(count);
              LOG.fine("Reason_ Indeterminate Reason = " + qn);
              status.getIndeterminateReason().add(qn);
            }
          }
        }
      }

      return status;
    }
    catch (Exception e)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.log(Level.SEVERE, "Problem", e);
      }
      return null;
    }
  }
}
