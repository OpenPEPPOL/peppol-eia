/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.requestcontroller;

import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;


/**
 * Helper class for handling certificate key usage
 * @author buengener
 *
 * 
*/
public class KeyUsageHelper
{
  private static Logger LOG = Logger.getLogger(KeyUsageHelper.class.getName());

  private KeyUsageHelper()
  {
    // nothing todo
  }

  public static List<String> getKeyUsageForResult(X509Certificate pX509Cert)
  {
    ArrayList<String> KeyUsagesList = new ArrayList<String>();

    try
    {
      //digitalSignature        (0),
      //nonRepudiation          (1),
      //keyEncipherment         (2),
      //dataEncipherment        (3),
      //keyAgreement            (4),
      //keyCertSign             (5),
      //cRLSign                 (6),
      //encipherOnly            (7),
      //decipherOnly            (8)
      boolean[] keyUsages = pX509Cert.getKeyUsage();

      if ((keyUsages != null) && (keyUsages.length > 0))
      {
        if (keyUsages[0])
        {
          KeyUsagesList.add(XKMSConstants.XKMS_KEYUSAGE_SIGNATURE);
        }

        if (keyUsages[3] || keyUsages[2])
        {
          KeyUsagesList.add(XKMSConstants.XKMS_KEYUSAGE_ENCRYPTION);
        }

        if (keyUsages[4])
        {
          KeyUsagesList.add(XKMSConstants.XKMS_KEYUSAGE_EXCHANGE);
        }
      }

      return KeyUsagesList;
    }
    catch (Exception e)
    {
      if (LOG.isLoggable(Level.WARNING))
      {
        LOG.log(Level.WARNING, "Problem reading key usage", e);
      }

      return new ArrayList<String>();
    }
  }

}
