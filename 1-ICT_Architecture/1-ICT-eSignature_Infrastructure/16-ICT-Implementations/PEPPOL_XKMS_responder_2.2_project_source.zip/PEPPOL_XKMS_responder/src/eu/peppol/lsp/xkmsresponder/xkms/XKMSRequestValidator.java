/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.xkms;

import java.io.ByteArrayInputStream;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.bind.JAXBElement;

import org.w3._2000._09.xmldsig.KeyInfoType;
import org.w3._2000._09.xmldsig.X509DataType;
import org.w3._2002._03.xkms.CompoundRequestType;
import org.w3._2002._03.xkms.QueryKeyBindingType;
import org.w3._2002._03.xkms.RequestAbstractType;
import org.w3._2002._03.xkms.ValidateRequestType;


/*
 * Tool to perform some plausibility check on a parsed XKMS2 request object. This checks required
 * properties of the XML which are not specified correctly in the schema. <p>Copyright: Copyright
 * (c) 2003 bremen online services GmbH</p>
 * @author Hamed Tabrizi
 * @author tt (completely new implementation)
 * @version $
 * 
*/
public class XKMSRequestValidator
{
  private static final Logger LOG = Logger.getLogger(XKMSRequestValidator.class.getName());

  private static final List<String> ALLOWED_RESPONDWITH_VALUES = new java.util.ArrayList<String>(4);

  private static final List<String> ALLOWED_RESPONSEMECHANISM_VALUES = new java.util.ArrayList<String>(2);
  static
  {
    //    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_OCSP);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_X509CERT);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_X509CHAIN);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_X509CRL);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_OCSP);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_OCSPNOCACHE);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_EIDQUALITY);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_VALIDATION_DETAILS);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_SERVICE_INFORMATION);
    ALLOWED_RESPONDWITH_VALUES.add(XKMSConstants.XKMS_RESPONDWITH_EU_EXTENSION);

    ALLOWED_RESPONSEMECHANISM_VALUES.add(XKMSConstants.XKMS_RESPONSEMECHANISM_REPRESENT);
    ALLOWED_RESPONSEMECHANISM_VALUES.add(XKMSConstants.XKMS_RESPONSEMECHANISM_PENDING);

  }

  private static CertificateFactory cf;

  static
  {
    try
    {
      cf = CertificateFactory.getInstance("X509");
    }
    catch (CertificateException e)
    {
      e.printStackTrace();
    }
  }

  /**
   * Return true if the message extensions satisfy the following undocumented rules.
   * A CompoundRequest may not contain a message extensions, each other request type may contain
   * at most one extension. The message extension may not contain a EU result.
   * @param pRequestAbstractType RequestAbstractType
   * @return boolean Returns true if succeed
   */
  private boolean checkMessageExtension(RequestAbstractType pRequestAbstractType)
  {
    if (!pRequestAbstractType.getMessageExtension().isEmpty())
    {
      if (pRequestAbstractType instanceof CompoundRequestType)
      {
        LOG.severe("XKMS compliance error: CompoundRequest is not allowed to have a MessageExtension");
        return false;
      }

      //@Todo: EU and DE Extension in one message allowed ?
      if (pRequestAbstractType.getMessageExtension().size() > 1)
      {
        LOG.severe("XKMS compliance error: no request is allowed to have more than one MessageExtension");
        return false;
      }

    }
    return true;
  }

  /**
   * Return true if the respondWith fields satisfy the following partially documented rules.
   * A compoundRequest may not specifiy RespondWith. Any other request must adhere to the schema
   * @param pRequestAbstractType RequestAbstractType
   */
  public static List<String> checkRespondWith(RequestAbstractType pRequestAbstractType)
  {
    ArrayList<String> ret = new ArrayList<String>();
    if (!ALLOWED_RESPONDWITH_VALUES.containsAll(pRequestAbstractType.getRespondWith()))
    {
      ret.addAll(pRequestAbstractType.getRespondWith());
      boolean mod =  ret.removeAll(ALLOWED_RESPONDWITH_VALUES);
      LOG.severe("XKMS compliance error: found illegal value in RespondWith field.");
    }

    return ret;
  }

  /**
   * Return true if the ResponseMechanism fields satisfy the following partially documented rules.
   * A compoundRequest may not specifiy ResponseMechanism. Any other request must adhere to the schema.
   * @param pRequestAbstractType RequestAbstractType
   */
  private boolean checkResponseMechanism(RequestAbstractType pRequestAbstractType)
  {
    if ((pRequestAbstractType instanceof CompoundRequestType)
        && !pRequestAbstractType.getResponseMechanism().isEmpty())
    {
      LOG
         .severe("XKMS compliance error: CompoundRequest is not allowed to specify ResponseMechanism directly");
      // Check is not supported TODO: Why not???
      // return false;
    }

    if (!ALLOWED_RESPONSEMECHANISM_VALUES.containsAll(pRequestAbstractType.getResponseMechanism()))
    {
      LOG.severe("XKMS compliance error: found illegal value in ResponseMechanism field.");
      return false;
    }

    return true;
  }

  /**
   * Checks the RequestAbstractType for validity
   * @param _request RequestAbstractType
   * @return boolean Returns true if succeed
   */
  private boolean checkRequestAbstractType(RequestAbstractType _request, boolean compound)
  {
    if (!((_request instanceof CompoundRequestType && !compound) || _request instanceof ValidateRequestType))
    {
      LOG.severe("XKMS compliance error: request is neither compound nor validate request.");
      return false;
    }


    if (!checkMessageExtension(_request) || !checkResponseMechanism(_request))
    {
      return false;
    }

    if ((_request.getOriginalRequestId() != null) || (_request.getResponseLimit() != null)
        || (_request.getPendingNotification() != null))
    {
      LOG
         .severe("XKMS compliance error: one of the unsupported attributes OriginalRequestId, ResponseLimitFound or PendingNotification is set");
      return false;
    }


    if (_request instanceof ValidateRequestType)
    {
      return checkQueryKeyBinding(((ValidateRequestType) _request).getQueryKeyBinding());
    }

    return true;
  }

  /**
   * X509Data validity check.
   * @param _x509Data X509DataType
   * @return boolean Return true if succeed
   */
  private boolean checkX509Data(X509DataType _x509Data)
  {
    for (Iterator<Object> it = _x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName().iterator(); it
                                                                                                       .hasNext();)
    {
      Object tmpElement = it.next();
      if (tmpElement instanceof JAXBElement)
      {
        JAXBElement tmpJAXBElement = (JAXBElement) tmpElement;
        Object tmpEntryObject = tmpJAXBElement.getValue();

        if (tmpEntryObject != null && tmpJAXBElement.getName().getLocalPart().equals("X509Certificate"))
        {
          try
          {
            cf.generateCertificate(new ByteArrayInputStream((byte[])tmpJAXBElement.getValue()));
          }
          catch (CertificateException e)
          {
              LOG
                 .severe("XKMS compliance error: the data of X509Certificate cannot be converted to a X509Certificate.");

              return false;
          }
        }
        else
        {
          LOG.severe("XKMS compliance error: all children of X509Data must be of type X509Certificate.");

          return false;
        }
      }
    }

    return true;
  }

  /**
   * KeyInfo may contain at most one element, that must be of type X509DataType.
   * Note that line breaks(which are completely legal) may be listed as String element
   * @param _keyInfo KeyInfoType
   * @return boolean Returns true if succeed
   */
  protected boolean checkKeyInfo(KeyInfoType _keyInfo)
  {
    List<Object> listKeyInfo = _keyInfo.getContent();
    int countRealElements = 0;
    for (Iterator<Object> it = listKeyInfo.iterator(); it.hasNext();)
    {
      Object entry = it.next();
      if (entry instanceof String && ((String) entry).trim().length() == 0)
      {
        // that was no XML element but formatting
        continue;
      }
      countRealElements++;
      if (countRealElements > 1)
      {
        LOG.severe("XKMS compliance error: at most one child of KeyInfo allowed");
        return false;
      }
      if (!(entry instanceof JAXBElement) || !(((JAXBElement) entry).getValue() instanceof X509DataType))
      {
        LOG.severe("XKMS compliance error: child of KeyInfo must be X509Data");
        return false;
      }
      return checkX509Data(((JAXBElement<X509DataType>) entry).getValue());
    }

    return true;
  }

  /**
   * QueryKeyBinding validity check
   * @param _queryKeyBinding QueryKeyBinding
   * @return boolean Returns true if succeed
   */
  protected boolean checkQueryKeyBinding(QueryKeyBindingType _queryKeyBinding)
  {
    if (_queryKeyBinding.getKeyInfo() == null || _queryKeyBinding.getKeyInfo().getContent().isEmpty())
    {
      return true;
    }
    return checkKeyInfo(_queryKeyBinding.getKeyInfo());
  }

  /**
   * Make sure that the parsed XKMS request satisfies some properties which
   * are needed for the request to be executed by the responder. These properties
   * are mostly are not imposed by the XKMS2 schema. This includes several rules documented
   * in private methods of this class as well as:
   * Any two consecutive contained requests must have different IDs.
   * @param _request RequestAbstractType
   * @throws XKMSNotSupportedException if one of the checked rules is not satisfied
   */
  public void assertResponderCompliance(RequestAbstractType _request) throws XKMSNotSupportedException
  {
    if (!checkRequestAbstractType(_request, false))
    {
      throw new XKMSNotSupportedException(XKMSConstants.ERROR_MESSAGE_NOTSUPPORTED);
    }

    if (_request instanceof CompoundRequestType)
    {
      List<RequestAbstractType> requests =
            ((CompoundRequestType) _request).getLocateRequestOrValidateRequestOrRegisterRequest();

      ArrayList<String> tmpIDs = new ArrayList<String>(requests.size() + 1);
      tmpIDs.add(_request.getId());

      for (Iterator<RequestAbstractType> it = requests.iterator(); it.hasNext();)
      {
        RequestAbstractType request = it.next();

        if (request.getId() == null || tmpIDs.contains(request.getId()))
        {
          throw new XKMSNotSupportedException(XKMSConstants.ERROR_MESSAGE_REQUESTIDWRONG);
        }
        tmpIDs.add(request.getId());

        if (!checkRequestAbstractType(request, true))
        {
          throw new XKMSNotSupportedException(XKMSConstants.ERROR_MESSAGE_NOTSUPPORTED);
        }
      }
    }
  }
}
