/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.requestcontroller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBElement;

import org.etsi.uri._01903.v1_3.EncapsulatedPKIDataType;
import org.etsi.uri._01903.v1_3.OCSPValuesType;
import org.etsi.uri._01903.v1_3.RevocationValuesType;
import org.w3._2000._09.xmldsig.KeyInfoType;
import org.w3._2000._09.xmldsig.X509DataType;

import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvCRLLDAPResult;
import eu.peppol.lsp.xkmsresponder.common.CvCRLResult;
import eu.peppol.lsp.xkmsresponder.common.CvOCSPResult;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;

/**
 * Helper class for processing RespondWith tags.
 * @author buengener
 *
 * 
*/
public class RespondWithHelper
{
  private static Logger LOG = Logger.getLogger(RespondWithHelper.class.getName());

  /**
   * Creates a new RespondWithHelper object.
   */
  public RespondWithHelper()
  {
  }

  private ArrayList<String> respondWithSorter(List<String> pResWithList)
  {
    ArrayList<String> tmpRespondWith = new ArrayList<String>();

    try
    {
      for (int i = 0; i < pResWithList.size(); i++)
      {
        String qn = pResWithList.get(i);
        tmpRespondWith.add(qn);
      }

      if (tmpRespondWith.contains(XKMSConstants.XKMS_RESPONDWITH_X509CERT)
          && tmpRespondWith.contains(XKMSConstants.XKMS_RESPONDWITH_X509CHAIN))
      {
        tmpRespondWith.remove(XKMSConstants.XKMS_RESPONDWITH_X509CERT);
      }

      return tmpRespondWith;
    }
    catch (Exception e)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.log(Level.FINE, "Problem sorting respondWith tags", e);
      }

      return new ArrayList<String>();
    }
  }

  public org.w3._2000._09.xmldsig.KeyInfoType createRespondWithCertificate(
                                                                            CertificatevalidatorResult[] pCertValidatorRes,
                                                                            Set<String> pResWithList)
  {
    org.w3._2000._09.xmldsig.ObjectFactory xmlsigOF = new org.w3._2000._09.xmldsig.ObjectFactory();
    X509DataType x509Data = xmlsigOF.createX509DataType();

    try
    {
      LOG.fine("Size of ResWithList: " + String.valueOf(pResWithList.size()));
      ArrayList<String> tmpRespWithList = new ArrayList<String>();
      for (Iterator<String> tmpIt = pResWithList.iterator(); tmpIt.hasNext();)
      {
        tmpRespWithList.add((String) tmpIt.next());
      }

      ArrayList<String> tmpRespondWith = respondWithSorter(tmpRespWithList);
      for (Iterator<String> it = tmpRespondWith.iterator(); it.hasNext();)
      {
        String tmpLocalPart = it.next();
        LOG.fine("RespondWith: " + tmpLocalPart);

        if (tmpLocalPart.equalsIgnoreCase(XKMSConstants.XKMS_RESPONDWITH_X509CERT))
        {
          LOG.fine("Respond With X509Cert");

          byte[] certificate;

          if (pCertValidatorRes[0].getCertificate() != null)
          {
            certificate = pCertValidatorRes[0].getCertificate().getEncoded();
          }
          else
          {
            certificate = pCertValidatorRes[0].getCertificateEncoded();
          }

          {
            JAXBElement<byte[]> tmpX509CertificateType = xmlsigOF.createX509DataTypeX509Certificate(certificate);
            x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName().add(tmpX509CertificateType);
          }

          LOG.fine("Count Certificates :" + x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName().size());
        }

        if (tmpLocalPart.equalsIgnoreCase(XKMSConstants.XKMS_RESPONDWITH_X509CHAIN))
        {
          LOG.fine("pCertValidatorRes.length: " + pCertValidatorRes.length);
          for (CertificatevalidatorResult tmpElement : pCertValidatorRes)
          {
            LOG.fine("Respond With X509CHAIN");

            byte[] tmpChainCertificate = tmpElement.getCertificate().getEncoded();
            JAXBElement<byte[]> tmpX509CertificateType = xmlsigOF.createX509DataTypeX509Certificate(tmpChainCertificate);
            x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName().add(tmpX509CertificateType);
          }
        }

        if (tmpLocalPart.equalsIgnoreCase(XKMSConstants.XKMS_RESPONDWITH_X509CRL))
        {
          try
          {
            LOG.fine("Respond With X509CRL");
            byte[] crlResp = null;

            if (pCertValidatorRes[0] instanceof CvCRLResult)
            {
              CvCRLResult crlResult = (CvCRLResult) pCertValidatorRes[0];
              crlResp = crlResult.getX509Crl();
            }
            else if (pCertValidatorRes[0] instanceof CvCRLLDAPResult)
            {
              CvCRLLDAPResult crlResult = (CvCRLLDAPResult) pCertValidatorRes[0];
              crlResp = crlResult.getX509Crl();
            }

            if (crlResp != null)
            {
              LOG.fine("CRLDownload in CvCRLResult:" + crlResp.length);

              JAXBElement<byte[]> tmpCRLResponse = xmlsigOF.createX509DataTypeX509CRL(crlResp);
              x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName().add(tmpCRLResponse);
            }
          }
          catch (Exception ex)
          {
            LOG.log(Level.SEVERE, "Error while adding CRLDownload to Response", ex);
          }
        }

        if (tmpLocalPart.equalsIgnoreCase(XKMSConstants.XKMS_RESPONDWITH_OCSP))
        {
          try
          {
            LOG.fine("createRespondWithCertificate() Respond With X509OCSP");

            if (pCertValidatorRes[0] instanceof CvOCSPResult)
            {
              LOG.fine("createRespondWithCertificate() found instance of CvOCSPResult");
              CvOCSPResult ocspResult = (CvOCSPResult)pCertValidatorRes[0];

              if (ocspResult.getOcspResp() != null)
              {
                LOG.fine("createRespondWithCertificate() found OCSP response in CvOCSPResult");
                org.etsi.uri._01903.v1_3.ObjectFactory etsiOF = new org.etsi.uri._01903.v1_3.ObjectFactory();
                RevocationValuesType rvt = etsiOF.createRevocationValuesType();
                OCSPValuesType ovt = etsiOF.createOCSPValuesType();
                EncapsulatedPKIDataType epdt = etsiOF.createEncapsulatedPKIDataType();
                epdt.setValue(ocspResult.getOcspResp());
                ovt.getEncapsulatedOCSPValue().add(epdt);
                rvt.setOCSPValues(ovt);
                x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName().add(etsiOF.createRevocationValues(rvt));
              }
            }
          }
          catch (Exception ex)
          {
            LOG.log(Level.SEVERE, "Error while adding OCSP to Response", ex);
          }
        }

      }

      if (x509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName().size() > 0)
      {
        KeyInfoType keyInfo = xmlsigOF.createKeyInfoType();
        JAXBElement<X509DataType> tmpX509Data = xmlsigOF.createX509Data(x509Data);
        keyInfo.getContent().add(tmpX509Data);

        return keyInfo;
      }

      return null;
    }
    catch (Exception e)
    {
      LOG.log(Level.FINE, "Problem", e);
      return null;
    }
  }
}
