/**
 *
 */
/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;

import java.io.Serializable;


/*
 * Parent class for validate method DTO objects.
 * @author nagel
 * 
 */
public abstract class AbstractValMethodDto implements Serializable, Cloneable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  protected String refId = null;

  protected String name = "";

  protected String url = "";

  /**
   *
   */
  public AbstractValMethodDto(String inpName)
  {
    super();
    if ((inpName == null) || (inpName.trim().length() == 0))
    {
      throw new IllegalArgumentException("Name of Valmethod may not be empty. Illegal name = " + inpName);
    }
    name = inpName;
  }

  @Override
  public Object clone()
  {
    try
    {
      AbstractValMethodDto ret = (AbstractValMethodDto) super.clone();
      return ret;
    }
    catch (CloneNotSupportedException e)
    {
      throw new InternalError(e.getMessage());
    }
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }

    if (obj == null)
    {
      return false;
    }

    if (getClass() != obj.getClass())
    {
      return false;
    }

    final AbstractValMethodDto other = (AbstractValMethodDto) obj;

    if (name == null)
    {
      if (other.name != null)
      {
        return false;
      }
    }
    else if (!name.equals(other.name))
    {
      return false;
    }

    return true;
  }

  @Override
  public int hashCode()
  {
    final int PRIME = 31;
    int result = 17;
    result = (PRIME * result) + ((name == null) ? 0 : name.hashCode());

    return result;
  }

  @Override
  public String toString()
  {
    String returnString = "RefId=" + refId;
    returnString += (", name=" + name);

    return returnString;
  }

  public String getRefId()
  {
    return refId;
  }

  public void setRefId(String id)
  {
    refId = DtoHelper.getNullAsEmptyString(id);
  }

  public String getName()
  {
    return name;
  }

  /**
   * Set the friendly name of this val method
   * @param name free String
   */
  public void setName(String name)
  {
    this.name = DtoHelper.getNullAsEmptyString(name);
  }

}
