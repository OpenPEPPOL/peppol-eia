/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certpathbuilder;

import java.security.InvalidAlgorithmParameterException;
import java.security.cert.CertPathBuilderException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.security.auth.x500.X500Principal;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;


/*
 * <p>Title: </p> <p>Description: Diese Klasse ist die Basis Klasse fuer den Aufbau einer
 * Zertifikatskette. Als Parameter werden hier ein zu pruefendes Zertifikat und ein CertStore
 * uebergeben. Diese Klasse akzeptiert eine beliebige Anzahl von Zertifikaten, welche in der Kette
 * vorkommen oder nicht vorkommen duerfen. Die uebergebenen Zertifikate muessen keine Kette bilden.
 * Fehlende Zertifikate werden im CertStore gesucht. Es wird immer genau eine Kette zurueckgegeben.
 * Weitere Ketten erhaelt man durch entsprechende bestueckung der doNotUse Liste. Bei jeder Anfrage
 * werden alle Ketten erneut berechnet. Es erfolgt also kein cashing der Ketten. Auf diesen
 * Mechanismus wurde verzichtet, da es aktuell meist nur eine Kette gibt. Aufgerufen wird die
 * Methode engineBuild. </p> <p>Copyright: Copyright (c) 2003 bremen online service GmbH</p>
 * @author Gregor Leander
 * @author Andre Jens
 * @author mho
 * @version $Revision: 1.4 $
 * 
*/
public class CertPathBuilder
{
  private static final Logger LOG = Logger.getLogger(CertPathBuilder.class.getName());

  private static final Logger LOG_CHAINBUILD_ERROR = Logger.getLogger("CanNotBuildCertPath");

  private static final String ERROR02 = "Could not build path to a trusted anchor";

  public static final String ERROR04 = "More than one UserCert found. I do not know whitch one is correct.";

  private static final String ERROR05 = "No UserCert found.";

  private static final String ERROR06 = "Wrong Parameter. Parameter can't be null";

  private static final int SELFSIGNED = 1;

  private static final int INVALID_SIGNATURE = 2;

  private static final int NOTSELFSIGNED = 3;

  /**
   * Given the parameters containing the target certificate and a cert store,
   * builds a certpath for the target certificate to a trusted root.
   *
   * @param params MUST be an instance of BuilderParameter.
   * @return the result of the building process.
   * @throws InvalidAlgorithmParameterException  if params is not an instance of BuilderParameters
   *  or if there is an intersection of the "use" and "not use" clauses
   * @throws CertPathBuilderException if now certpath could be build.
   */
  public CertPathBuilderResult build(final BuilderParameters params)
        throws CertPathBuilderException, InvalidAlgorithmParameterException
  {
    LOG.fine("(start) build");

    try
    {
      if (params == null)
      {
        LOG.severe(ERROR06);

        throw new InvalidAlgorithmParameterException();
      }

      // Uebergabeparameter fuer diesen Builder
      final BuilderParameters buildparams = params;
      LOG.fine("Buildparams read.");

      // Liste aller uebergebenen Zertifikate
      List<X509Certificate> inputCertList = buildparams.getTargetAsArrayList();
      LOG.fine("InputList read.");

      // Liste der Zertifikate, welche nicht verwendet werden duerfen.
      List<X509Certificate> doNotUseCertList = buildparams.getDoNotUseAsArrayList();
      LOG.fine("DoNotUseList read.");

      // Tabelle aller Knoten.
      Hashtable<X509Certificate, Knot> knotTable = new Hashtable<X509Certificate, Knot>();

      // Baum der Zertifikate aufbauen
      Knot realBaseKnot = buildKnotTree(inputCertList, doNotUseCertList, knotTable, buildparams);
      LOG.fine("All Knots built.");

      // Einen moeglichen Pfad bilden
      CertPath certPath = new CertPath(findOnePossibleChain(realBaseKnot, buildparams));
      LOG.fine("One CertPath created.");

      // Und das Resultat aller Bemuehungen :)
      CertPathBuilderResult result = new CertPathBuilderResult(certPath);
      LOG.fine("Result created.");

      return result;
    }
    finally
    {
      LOG.fine("(end) engineBuild");
    }
  }

  /**
   * Suche nach allen Moeglichen Nachfolgern.
   *
   * @param knot  Knot to
   * @param inputList  Certificate list-
   * @param doNotUse  Certificates that must not be used
   * @param knotTable  List of all Knots
   * @param buildparams  The Buildparams.
   * @return Knot
   */
  private Knot buildChainForKnot(Knot knot, List<X509Certificate> inputList,
                                 final List<X509Certificate> doNotUse,
                                 Map<X509Certificate, Knot> knotTable, BuilderParameters buildparams,
                                 List<X509Certificate> usedCerts) throws CertPathBuilderException
  {
    LOG.fine("buildChainForKnot(___) - InputList size=" + inputList.size());

    X509Certificate[] certs = null;

    // In der Liste der uebergebenen Zertifikate nachsehen.
    if (inputList.size() > 0)
    {
      LOG.fine("Search in InputList");
      certs = findIssuerInList(knot.cert, inputList, doNotUse);
    }

    if ((certs == null) || (certs.length == 0))
    {
      // Wenn ich in der Liste nichts gefunden habe ab in die Datenbank
      certs = findIssuerInCertStore(knot.cert, doNotUse);
      LOG.fine("Certificates found in CertStore. Count = " + certs.length);
    }

    ///////////// ???was soll das (mho)
    if (certs.length == 0)
    { // Keinen Nachfolger gefunden
      knot.rootCert = false;

      return knot;
    }

    // Koennte ein Herausgeberzertifikat sein
    for (X509Certificate tmpElement : certs)
    {
      int ti = getSelfSigned(tmpElement);

      if (ti == CertPathBuilder.SELFSIGNED)
      {
        LOG.fine("Found Selfsigned Certificate : " + tmpElement.getSubjectDN());

        Knot rootknoten = new Knot(tmpElement);
        rootknoten.rootCert = true;
        rootknoten.baseCert = false;
        knot.untestKnoten.add(rootknoten);

        return knot;
      }
      else if (ti == CertPathBuilder.INVALID_SIGNATURE)
      {
        throw new CertPathBuilderException(ERROR02);
      }
    }

    // Jetzt muss ich wiederum zu allen diesen Zertifikaten alle Nachfolger finden.
    for (X509Certificate tmpElement : certs)
    {
      // Erste Frage: Ist der Knoten in dieser Suche nach einem Pfad bereits verwendet worden
      // Also 5->6->5=Alarm
      if (usedCerts.contains(tmpElement))
      {
        continue; // Also naechsten Schleifendurchlauf
      }

      Knot temp = knotTable.get(tmpElement); // In der Liste Aller Knoten nachsehen.

      if (temp == null)
      { // Knoten ist neu

        Knot newknoten = new Knot(tmpElement);
        usedCerts.add(tmpElement);
        newknoten = buildChainForKnot(newknoten, inputList, doNotUse, knotTable, buildparams, usedCerts);
        newknoten.baseCert = false; // Hat Vorgaenger - ist also nicht das UserCert
        knot.untestKnoten.add(newknoten);
        knotTable.put(tmpElement, newknoten);
      }
      else
      {
        temp.baseCert = false;
        knot.untestKnoten.add(temp);
      }
    }

    return knot;
  }

  /**
   * Prft, ob ein Zertifikat selbstsigniert oder Vertrauenswurdig ist.
   *
   * @param cert The Certificate
   * @return 1 = Selfsigned
   *         2 = Signature not OK
   *         3 = not selfsigned
   */
  private int getSelfSigned(X509Certificate cert)
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("S/I : " + cert.getSubjectX500Principal().getName() + "="
                + cert.getIssuerX500Principal().getName());
    }

    if (cert.getSubjectX500Principal().equals(cert.getIssuerX500Principal()))
    {
      LOG.fine("Issuer equals Subject");

      try
      {
        cert.verify(cert.getPublicKey());
        LOG.fine("Verify Certificatesignature OK");
        return CertPathBuilder.SELFSIGNED;
      }
      catch (Exception ex)
      {
        String tmpAuthorityKeyIdentifier = ResponderHelper.getAuthorityKeyIdentifier(cert);
        if (!tmpAuthorityKeyIdentifier.equals(""))
        {
    		CertificateDto tmpCheckDto = null;
        	try
        	{
        		String tmpSubjectDN = ResponderHelper.getSubjectDN(cert);
        		if (Configuration.getIssuerCertificateByUserCertificate(cert) != null)
            		return CertPathBuilder.NOTSELFSIGNED;
        	}
        	catch (Exception ex1)
        	{
        		return CertPathBuilder.INVALID_SIGNATURE;
        	}
          return CertPathBuilder.INVALID_SIGNATURE;
        }
        LOG.fine("Certificate signature is invalid");

        return CertPathBuilder.INVALID_SIGNATURE;
      }
    }

    return CertPathBuilder.NOTSELFSIGNED;
  }

  /**
   * Sucht Nachfolger in der Liste der mitgelieferten Zertifikate.
   *
   * @param cert
   * @return
   */
  private X509Certificate[] findIssuerInList(final X509Certificate cert,
                                                List<X509Certificate> inputList,
                                                final List<X509Certificate> doNotUse)
  {
    if (cert == null)
    {
      LOG.severe("Certificate is null");

      return null;
    }

    Vector<X509Certificate> respList = new Vector<X509Certificate>();
    X500Principal principal = cert.getIssuerX500Principal();
    Iterator<X509Certificate> it = inputList.iterator();

    while (it.hasNext())
    {
      X509Certificate destination = it.next();

      if (destination == null)
      {
        LOG.severe("Destinationcert is null");
      }

      if (doNotUse.contains(destination))
      {
        continue;
      }
      if ((destination != null) && (principal.equals(destination.getSubjectX500Principal())))
      {
        try
        {
          cert.verify(destination.getPublicKey());
          respList.add(destination);
        }
        catch (Exception ex)
        {
          LOG.warning("Certificatesignature verification error.");
        }
      }
    }

    X509Certificate[] certs = respList.toArray(new X509Certificate[0]);

    for (X509Certificate tmpElement : certs)
    {
      inputList.remove(tmpElement);
    }

    return certs;
  }

  /**
   * Sucht nach einem Nachfolger im CertStore
   *
   * @param cert
   * @return
   */
  private X509Certificate[] findIssuerInCertStore(X509Certificate cert,
                                                       List<X509Certificate> doNotUse)
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("(start) findIssuerInCertStore( ZertifikateWrapper )");
    }

    Vector<X509Certificate> resp = new Vector<X509Certificate>();

    try
    {
      //      String tmpUserIssuerDN = ResponderHelper.getIssuerDN(cert);
      //      String tmpUserIssuerKeyId = ResponderHelper.getAuthorityKeyIdentifier(cert);
      //
      //      CertificateDto tmpCertificateDto = CertificateDelegateLocal.getInstance().findBySubjectDNAndKeyId(tmpUserIssuerDN, tmpUserIssuerKeyId);
      //      if(tmpCertificateDto == null){
      //         Collection<CertificateDto> tmpDtos = CertificateDelegateLocal.getInstance().findBySubjectDN(tmpUserIssuerDN);
      //        if(tmpDtos.size() == 1){
      //          tmpCertificateDto = tmpDtos.iterator().next();
      //        } else {
      //
      //        }
      CertificateDto tmpCertificateDto = Configuration.getIssuerCertificateByUserCertificate(cert);
      if (tmpCertificateDto != null)
      {
	      LOG.fine("findIssuerInCertStore Process certificate with SubjectDN : "
	                + tmpCertificateDto.getSubjectDN() + " : IssuerDN: " + tmpCertificateDto.getIssuerDN());

	      X509Certificate tmpX509Certificate =
	            tmpCertificateDto.getX509Certificate();

	      if (!doNotUse.contains(tmpX509Certificate))
	        resp.add(tmpX509Certificate);
      }
    }
    catch (Exception ex1)
    {
        LOG.log(Level.SEVERE, "Error in findInCertStore", ex1);
    }

    return resp.toArray(new X509Certificate[0]);
  }

  /**
   * Build a possible chain
   *
   * @param inpStartKnot
   * @return ArrayList<X509Certificate>
   * @throws CertPathBuilderException
   */
  public ArrayList<X509Certificate> findOnePossibleChain(Knot inpStartKnot,
                                                            final BuilderParameters buildparams)
        throws CertPathBuilderException
  {
    LOG.fine("_start findOnePossibleChain");

    Knot startKnot = inpStartKnot;
    List<X509Certificate> inputList = buildparams.getTargetAsArrayList();

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("inputlist size :" + inputList.size());
    }

    ArrayList<Knot> oneList = new ArrayList<Knot>();
    oneList.add(startKnot);

    do
    {
      boolean noMoreCerts = false;

      do
      {
        if (startKnot.untestKnoten.size() == 0)
        {
          LOG.fine("######## No more certs");
          noMoreCerts = true;
        }
        else
        {
          LOG.fine("noch was da");
          startKnot = startKnot.untestKnoten.remove(0);
          oneList.add(startKnot);
        }
      }
      while ((noMoreCerts == false) && !startKnot.rootCert);

      LOG.fine("no more certs");

      if (startKnot.rootCert)
      {
        LOG.fine("startKnot.rootCert");

        ArrayList<X509Certificate> resp = new ArrayList<X509Certificate>(oneList.size());

        for (int i = 0; i < oneList.size(); i++)
        {
          resp.add(oneList.get(i).cert);
        }

        return resp;
      }

      LOG.fine("No Root-Certificate found.");

      // Bei Nein letztes Element rauswerfen aus der Liste
      do
      {
        if (oneList.size() > 0)
        {
          //          Knot oldcert = (Knot) oneList.remove(oneList.size() - 1);
          oneList.remove(oneList.size() - 1);
        }

        if (oneList.size() == 0)
        {
          break;
        }

        startKnot = oneList.get(oneList.size() - 1); // Vorletztes Element ist jetzt aktuell

        for (int o = 0; o < startKnot.untestKnoten.size(); o++)
        {
          startKnot.untestKnoten.get(o);
        }
      }
      while ((startKnot.untestKnoten.size() == 0) || (oneList.size() == 0));

      if (oneList.size() == 0)
      {
        try
        {
          if (!startKnot.cert.getSubjectDN().getName().equals(startKnot.cert.getIssuerDN().getName()))
          {
            LOG_CHAINBUILD_ERROR.info("-------------" + "\nSubject: "
                                      + startKnot.cert.getSubjectDN().getName() + "\nIssuer: "
                                      + startKnot.cert.getIssuerDN().getName() + "\nBase64Cert: \n"
                                      + ResponderHelper.base64encode(startKnot.cert.getEncoded())
                                      + "\n-------------");
          }

        }
        catch (CertificateEncodingException e)
        {
          //virtuell
        }
      }

      throw new CertPathBuilderException("No Chain built for CertificateSubject:"
                                         + startKnot.cert.getSubjectDN().getName() + " with Issuer: "
                                         + startKnot.cert.getIssuerDN().getName());
    }
    while (true);
  }

  /**
   * Aufbau des Knotenbaums
   *
   * @return
   * @throws CertPathBuilderException
   */
  private Knot buildKnotTree(List<X509Certificate> input, List<X509Certificate> doNotUse,
                             Map<X509Certificate, Knot> knotTable, final BuilderParameters buildparams)
        throws CertPathBuilderException
  {
    LOG.fine("(start) buildKnotTree(_/_)");

    int listSize = input.size();

    do
    {
      Knot knot = new Knot(input.remove(0));

      // Add to knot list
      knotTable.put(knot.cert, knot);

      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("Add Certificate to List : " + knot.cert.getSubjectX500Principal().getName());
      }

      ArrayList<X509Certificate> usedCerts = new ArrayList<X509Certificate>();
      int ti = getSelfSigned(knot.cert);

      if (ti == CertPathBuilder.NOTSELFSIGNED)
      {
        // Build up following knots recursiveley
        buildChainForKnot(knot, input, doNotUse, knotTable, buildparams, usedCerts);
      }
      else if (ti == CertPathBuilder.SELFSIGNED)
      {
        knot.rootCert = true;

        if (listSize > 1)
        {
          if (knot.cert.getSubjectX500Principal().equals(knot.cert.getIssuerX500Principal()))
          {
            LOG.fine("Issuer equals Subject in buildKnotTree");

            try
            {
              knot.cert.verify(knot.cert.getPublicKey());
              LOG.fine("Verify Certificatesignature OK. Setting baseCert == false");
              knot.baseCert = false;
            }
            catch (RuntimeException ex)
            {
              LOG.fine("Certificate signature is invalid");
            }
            catch (Exception ex)
            {
              LOG.fine("Certificate signature is invalid");
            }
          }
        }
      }
      else
      {
        throw new CertPathBuilderException(ERROR02);
      }
    }
    while (input.size() > 0); // Until all "must" certificate are consumed

    // Find base knot
    Knot realBaseKnot = null;
    Iterator<Knot> allKnots = knotTable.values().iterator();

    while (allKnots.hasNext())
    {
      Knot temp = allKnots.next();
      LOG.fine("Found in allKnots: " + temp.cert.getSubjectX500Principal().getName());
      LOG.fine("Is certificate baseCert ?" + temp.baseCert);
      LOG.fine("Has allKnots more elements ? " + allKnots.hasNext());

      if (temp.baseCert)
      {
        if (realBaseKnot == null)
        {
          realBaseKnot = temp;
        }
        else
        {
          throw new CertPathBuilderException(ERROR04);
        }
      }
    }

    if (realBaseKnot == null)
    {
      throw new CertPathBuilderException(ERROR05);
    }

    return realBaseKnot;
  }

  /**
   * Represents an knot
   *
   * <p>Title: </p>
   * <p>Description: </p>
   * <p>Copyright: Copyright (c) 2003</p>
   * <p>Company: </p>
   * @author unbekannt
   * @version 1.0
   */
  static class Knot
  {
    // Ist dies Ein SelfSignedCert
    public boolean rootCert = false;

    // Hat dieser Knoten Vorgaenger
    public boolean baseCert = true;

    // Liste aller Nochfolger
    public Vector<Knot> untestKnoten = new Vector<Knot>();

    public X509Certificate cert;

    public Knot(Object obj)
    {
      cert = (X509Certificate) obj;
    }
  }
}
