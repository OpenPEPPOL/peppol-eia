/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration;

import java.io.IOException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.UnmarshallerHandler;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.NamespaceSupport;
import org.xml.sax.helpers.XMLFilterImpl;

import eu.peppol.lsp.xkmsresponder.importexport.schema.Config;

/**
 * Parser and serializer for configuration objects.
 * @author buengener
 *
 * 
 */

public class ParseImportExportConfig extends XMLFilterImpl
{

  private static final Logger LOG = Logger.getLogger(ParseImportExportConfig.class.getName());

  private static final String SAX_NAMESPACE = "http://xml.org/sax/features/namespaces";

  private Config configuration = null;

  private int depth;

  private final static String rootelement = "Config";


  /**
   * Used to keep track of in-scope namespace bindings.
   *
   * For JAXB unmarshaller to correctly unmarshal documents, it needs
   * to know all the effective namespace declarations.
   */
  private final NamespaceSupport namespaces = new NamespaceSupport();

  /**
   * Reference to the unmarshaller which is unmarshalling
   * an object.
   */
  private UnmarshallerHandler unmarshallerHandler = null;

  /**
   * Keeps a reference to the locator object so that we can later
   * pass it to a JAXB unmarshaller.
   */
  private Locator locator;

  /**
   * Creates a new BasicCVConfigurationHandler object.
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   */
  public Config parseDefaultConfig(InputSource _config)
        throws ParserConfigurationException, SAXException, IOException

  {
    SAXParserFactory factory = SAXParserFactory.newInstance();
    factory.setFeature(ParseImportExportConfig.SAX_NAMESPACE, true);
    factory.setNamespaceAware(true);
    XMLReader reader = factory.newSAXParser().getXMLReader();
    reader.setContentHandler(this);
    reader.parse(_config);
    return configuration;
  }


  /**
   * Receive notification of the beginning of an element.
   *
   * @param namespaceURI The Namespace URI, or the empty string if the element has no Namespace URI or if Namespace
   *   processing is not being performed.
   * @param localName The local name (without prefix), or the empty string if Namespace processing is not being
   *   performed.
   * @param qName The qualified name (with prefix), or the empty string if qualified names are not available.
   * @param atts The attributes attached to the element. If there are no attributes, it shall be an empty Attributes
   *   object.
   * @throws SAXException Any SAX exception, possibly wrapping another exception.
   */
  @SuppressWarnings("unchecked")
  @Override
  public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
        throws SAXException
  {
    //    LOG.fine("(start) startElement( " + namespaceURI + " , " + localName + " , " + qName + " , atts)");

    if (depth != 0)
    {
      // we are in the middle of forwarding events.
      // continue to do so.
      depth++;
      super.startElement(namespaceURI, localName, qName, atts);

      return;
    }

    if (localName.equals(rootelement))
    {
      JAXBContext context = null;

      try
      {
        context =
              JAXBContext.newInstance("eu.peppol.lsp.xkmsresponder.importexport.schema",
                                      this.getClass().getClassLoader());
      }
      catch (JAXBException ex)
      {
        LOG.log(Level.SEVERE, "Can not find jaxb context for DefaultConfig", ex);

        return;
      }

      Unmarshaller unmarshaller;

      try
      {
        unmarshaller = context.createUnmarshaller();
      }
      catch (JAXBException e)
      {
        // there's no way to recover from this error.
        // we will abort the processing.
        throw new SAXException(e);
      }

      unmarshallerHandler = unmarshaller.getUnmarshallerHandler();
      // set it as the content handler so that it will receive
      // SAX events from now on.
      setContentHandler(unmarshallerHandler);
      // fire SAX events to emulate the start of a new document.
      unmarshallerHandler.startDocument();
      unmarshallerHandler.setDocumentLocator(locator);

      for (Enumeration<String> e = namespaces.getPrefixes(); e.hasMoreElements();)
      {
        String prefix = e.nextElement();
        String uri = namespaces.getURI(prefix);
        unmarshallerHandler.startPrefixMapping(prefix, uri);
      }

      String defaultURI = namespaces.getURI("");

      if (defaultURI != null)
      {
        unmarshallerHandler.startPrefixMapping("", defaultURI);
      }

      super.startElement(namespaceURI, localName, qName, atts);
      // count the depth of elements and we will know when to stop.
      depth = 1;
    }
  }

  @Override
  public void setDocumentLocator(Locator locator)
  {
    super.setDocumentLocator(locator);
    this.locator = locator;
  }

  @Override
  public void startPrefixMapping(String prefix, String uri) throws SAXException
  {
    namespaces.pushContext();
    namespaces.declarePrefix(prefix, uri);
    super.startPrefixMapping(prefix, uri);
  }

  @Override
  public void endPrefixMapping(String prefix) throws SAXException
  {
    namespaces.popContext();
    super.endPrefixMapping(prefix);
  }

  /**
   * Receive notification of the end of an element.
   *
   * @param namespaceURI The Namespace URI, or the empty string if the element has no Namespace URI or if Namespace
   *   processing is not being performed.
   * @param localName The local name (without prefix), or the empty string if Namespace processing is not being
   *   performed.
   * @param qName The qualified XML 1.0 name (with prefix), or the empty string if qualified names are not available.
   * @throws SAXException Any SAX exception, possibly wrapping another exception.
   */
  @SuppressWarnings("unchecked")
  @Override
  public void endElement(String namespaceURI, String localName, String qName) throws SAXException
  {
    //    LOG.fine("(start) endElement ( " + namespaceURI + " , " + localName + " , " + qName + " )");
    // forward this event
    super.endElement(namespaceURI, localName, qName);

    if (depth != 0)
    {
      depth--;

      if (depth == 0)
      {
        // Is DIResult finished ?
        // just finished sending one chunk.
        // emulate the end of a document.
        Enumeration<String> e = namespaces.getPrefixes();

        while (e.hasMoreElements())
        {
          String prefix = e.nextElement();
          unmarshallerHandler.endPrefixMapping(prefix);
        }

        String defaultURI = namespaces.getURI("");

        if (defaultURI != null)
        {
          unmarshallerHandler.endPrefixMapping("");
        }

        unmarshallerHandler.endDocument();
        // stop forwarding events by setting a dummy handler.
        // XMLFilter doesn't accept null, so we have to give it something,
        // hence a DefaultHandler, which does nothing.
        setContentHandler(new DefaultHandler());

        // then retrieve the fully unmarshalled object
        try
        {
          LOG.fine("get Result");
          configuration = (Config) unmarshallerHandler.getResult();
        }
        catch (JAXBException ex)
        {
          LOG.log(Level.SEVERE, "Unable to unmarschall Result.", ex);

          return;
        }

        unmarshallerHandler = null;
      }
    }
  }

}
