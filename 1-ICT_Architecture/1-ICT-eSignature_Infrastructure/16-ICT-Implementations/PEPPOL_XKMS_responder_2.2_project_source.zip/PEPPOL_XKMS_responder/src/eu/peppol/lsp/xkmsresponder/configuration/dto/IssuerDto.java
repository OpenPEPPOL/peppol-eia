/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;

import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

import org.etsi.uri._02231.v2.TSPInformationType;
import org.etsi.uri._02231.v2.TSPServiceInformationType;


/*
 * Data holder class for issuer
 * @author horstmann
 * 
*/
public class IssuerDto implements Serializable, Cloneable
{
  /**
   *
   */
  private static final long serialVersionUID = 9083780589844631634L;

  private static final Logger LOG = Logger.getLogger(IssuerDto.class.getName());

  public Map<String, CertificateDto> certificateMap = new TreeMap<String, CertificateDto>(); // of key=FriendlyName,value=CertificateDto

  private String refId = null;

  private boolean enabled;

  private String name;

  private ValMethodType valMethod;

  private String quality;

  private String cspAssurance;

  private String validateModel;

  private String tslIdentifier;

  private TSPInformationType tspInformation;

  private TSPServiceInformationType tspServiceInformation;

  private String algPolicyIdentifier;

  private ValMethodCrlDto valMethodCrlDto;

  private ValMethodLdapDto valMethodLdapDto;

  private ValMethodOcspDto valMethodOcspDto;

  private ValMethodXKMSDto valMethodXkmsDto;


  /**
   * Creates a new IssuerDto object.
   */
  public IssuerDto(String inpName)
  {
    super();
    valMethodCrlDto = new ValMethodCrlDto(inpName);
    valMethodLdapDto = new ValMethodLdapDto(inpName);
    valMethodOcspDto = new ValMethodOcspDto(inpName);
    valMethodXkmsDto = new ValMethodXKMSDto(inpName);
    name = inpName;
  }

  public boolean getEnabled()
  {
    return enabled;
  }

  public void setEnabled(boolean _active)
  {
	  enabled = _active;
  }

  public String getName()
  {
    return name;
  }

  public void setName(String inpName)
  {
    name = DtoHelper.getNullAsEmptyString(inpName);
    valMethodCrlDto.setName(name);
    valMethodLdapDto.setName(name);
    valMethodOcspDto.setName(name);
    valMethodXkmsDto.setName(name);
  }

  /* (non-Javadoc)
   * generated
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }

    if (obj == null)
    {
      return false;
    }

    if (getClass() != obj.getClass())
    {
      return false;
    }

    final IssuerDto other = (IssuerDto) obj;

    if (enabled != other.enabled)
    {
      return false;
    }

    if (name == null)
    {
      if (other.name != null)
      {
        return false;
      }
    }
    else if (!name.equals(other.name))
    {
      return false;
    }

    if (valMethod == null)
    {
      if (other.valMethod != null)
      {
        return false;
      }
    }
    else if (!valMethod.equals(other.valMethod))
    {
      return false;
    }

    if (quality == null)
    {
      if (other.quality != null)
      {
        return false;
      }
    }
    else if (!quality.equals(other.quality))
    {
      return false;
    }
    if (cspAssurance == null)
    {
      if (other.cspAssurance != null)
      {
        return false;
      }
    }
    else if (!cspAssurance.equals(other.cspAssurance))
    {
      return false;
    }
    else if (!tslIdentifier.equals(other.tslIdentifier))
    {
      return false;
    }
    else if (!algPolicyIdentifier.equals(other.algPolicyIdentifier))
    {
      return false;
    }
    else if (!validateModel.equals(other.validateModel))
    {
      return false;
    }

    return true;
  }

  /**
   * @return a deep copy
   */
  @Override
  public Object clone()
  {
    try
    {
      IssuerDto ret = (IssuerDto) super.clone();
      ret.setValMethodCrlDto((ValMethodCrlDto) valMethodCrlDto.clone());
      ret.setValMethodLdapDto((ValMethodLdapDto) valMethodLdapDto.clone());
      ret.setValMethodOcspDto((ValMethodOcspDto) valMethodOcspDto.clone());
      ret.setValMethodXkmsDto((ValMethodXKMSDto) valMethodXkmsDto.clone());

      return ret;
    }
    catch (CloneNotSupportedException e)
    {
      throw new InternalError(e.getMessage());
    }
  }

  /* (non-Javadoc)
   * generated
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode()
  {
    final int PRIME = 31;
    int result = 17;
    result = (PRIME * result) + (enabled ? 0 : 1);
    result = (PRIME * result) + ((name == null) ? 0 : name.hashCode());
    result = (PRIME * result) + ((valMethod == null) ? 0 : valMethod.hashCode());
    result = (PRIME * result) + ((quality == null) ? 0 : quality.hashCode());
    result = (PRIME * result) + ((cspAssurance == null) ? 0 : cspAssurance.hashCode());
    result = (PRIME * result) + ((tslIdentifier == null) ? 0 : tslIdentifier.hashCode());
    result = (PRIME * result) + ((algPolicyIdentifier == null) ? 0 : algPolicyIdentifier.hashCode());
    result = (PRIME * result) + ((validateModel == null) ? 0 : validateModel.hashCode());

    return result;
  }

  @Override
  public String toString()
  {
    String returnString = "";
    returnString += "enabled=" + enabled;
    returnString += (", name=" + name);
    returnString += (", valMethod=" + valMethod);
    returnString += (", quality=" + quality);
    returnString += (", cspAssurance=" + cspAssurance);
    returnString += (", tslIdentifier=" + tslIdentifier);
    returnString += (", algPolicyIdentifier=" + algPolicyIdentifier);
    returnString += (", validateModel=" + validateModel);

    return returnString;
  }

  public boolean changed(IssuerDto inpOtherIssuerDto)
  {
    if (!equals(inpOtherIssuerDto))
    {
      return true;
    }

    if (valMethodCrlDto.changed(inpOtherIssuerDto.valMethodCrlDto))
    {
      return true;
    }

    if (valMethodLdapDto.changed(inpOtherIssuerDto.valMethodLdapDto))
    {
      return true;
    }

    if (valMethodOcspDto.changed(inpOtherIssuerDto.valMethodOcspDto))
    {
      return true;
    }
    if (valMethodXkmsDto.changed(inpOtherIssuerDto.valMethodXkmsDto))
    {
      return true;
    }

    return false;
  }

  /**
   * @return the quality
   */
  public String getQuality()
  {
    return quality;
  }

  /**
   * @param inpQuality the quality to set
   */
  public void setQuality(String inpQuality)
  {
    quality = DtoHelper.getNullAsEmptyString(inpQuality);
  }

  /**
   * @return the cspAssurance
   */
  public String getCSPAssurance()
  {
    return cspAssurance;
  }

  /**
   * @param inpQuality the quality to set
   */
  public void setCSPAssurance(String inpCSPAssurance)
  {
    cspAssurance = DtoHelper.getNullAsEmptyString(inpCSPAssurance);
  }

  /**
   * @return the tslIdentifier
   */
  public String getTSLIdentifier()
  {
    return tslIdentifier;
  }

  /**
   * @param inpTSLIdentifier the TSLIdentifier to set
   */
  public void setTSLIdentifier(String inpTSLIdentifier)
  {
    tslIdentifier = DtoHelper.getNullAsEmptyString(inpTSLIdentifier);
  }

  /**
   * @return the algPolicyIdentifier
   */
  public String getAlgPolicyIdentifier()
  {
    return algPolicyIdentifier;
  }

  /**
   * @param inpAlgPolicyIdentifier the AlgPolicyIdentifier to set
   */
  public void setAlgPolicyIdentifier(String inpAlgPolicyIdentifier)
  {
    algPolicyIdentifier = DtoHelper.getNullAsEmptyString(inpAlgPolicyIdentifier);
  }

  /**
   * @return the valMethod
   */
  public ValMethodType getValMethod()
  {
    if (valMethod == null)
    {
      return ValMethodType.NONE;
    }

    return valMethod;
  }

  /**
   * @param inpValMethod the valMethod to set
   */
  public void setValMethod(ValMethodType inpValMethod)
  {
    valMethod = inpValMethod;
  }

  /**
   * @return the validateModel
   */
  public String getValidateModel()
  {

    return validateModel;
  }

  /**
   * @param inpValidateModel the ValidateModel to set
   */

  public void setValidateModel(String inpValidateModel)
  {
    validateModel = DtoHelper.getNullAsEmptyString(inpValidateModel);
  }

  /**
   * @return the refId
   */
  public String getRefId()
  {
    return refId;
  }

  /**
   * @param inpRefId the refId to set
   */
  public void setRefId(String inpRefId)
  {
    refId = DtoHelper.getNullAsEmptyString(inpRefId);
  }

  public ValMethodCrlDto getValMethodCrlDto()
  {
    return valMethodCrlDto;
  }

  public void setValMethodCrlDto(ValMethodCrlDto inpValMethodCrlDto)
  {
    valMethodCrlDto = inpValMethodCrlDto;
  }

  public ValMethodLdapDto getValMethodLdapDto()
  {
    return valMethodLdapDto;
  }

  public void setValMethodLdapDto(ValMethodLdapDto inpValMethodLdapDto)
  {
    valMethodLdapDto = inpValMethodLdapDto;
  }

  public ValMethodOcspDto getValMethodOcspDto()
  {
    return valMethodOcspDto;
  }

  public void setValMethodOcspDto(ValMethodOcspDto inpValMethodOcspDto)
  {
    valMethodOcspDto = inpValMethodOcspDto;
  }

  public ValMethodXKMSDto getValMethodXkmsDto()
  {
    return valMethodXkmsDto;
  }

  public void setValMethodXkmsDto(ValMethodXKMSDto inpValMethodXkmsDto)
  {
    valMethodXkmsDto = inpValMethodXkmsDto;
  }

  public TSPInformationType getTSPInformation()
  {
	  return tspInformation;
  }

  public void setTSPInformation(TSPInformationType tspInformation)
  {
	  this.tspInformation = tspInformation;
  }

  public TSPServiceInformationType getTSPServiceInformation()
  {
	  return tspServiceInformation;
  }

  public void setTSPServiceInformation(
			TSPServiceInformationType tspServiceInformation)
  {
	  this.tspServiceInformation = tspServiceInformation;
  }

}
