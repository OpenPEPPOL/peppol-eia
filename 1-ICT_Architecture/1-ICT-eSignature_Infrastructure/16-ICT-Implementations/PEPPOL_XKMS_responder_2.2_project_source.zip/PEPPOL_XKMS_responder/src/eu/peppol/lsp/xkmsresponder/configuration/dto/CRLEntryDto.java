/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;


/**
 * Data holder class for CRL entries
 * @author buengener
 *
 * 
*/

public class CRLEntryDto implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 6609943805588108704L;

  private Integer aReasonCode;

  private Integer aHoldInstructionCode;

  private String aInvalidityDate;

  private String aCertificateIssuer;

  private Date aRevocationDate;

  private BigInteger serialNo;

  private String issuerName;

  public CRLEntryDto(String inpIssuerName, BigInteger inpSerialNumber)
  {
    this.issuerName = inpIssuerName;
    this.serialNo = inpSerialNumber;
  }

  public BigInteger getSerialNo()
  {
	return serialNo;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((serialNo == null) ? 0 : serialNo.hashCode());
    result +=  ((issuerName == null) ? 0 : issuerName.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;

    CRLEntryDto other = (CRLEntryDto) obj;

    if (serialNo == null)
    {
      if (other.serialNo != null)
        return false;
    }
    else if (!serialNo.equals(other.serialNo))
      return false;

    if (issuerName == null)
    {
      if (other.issuerName != null)
        return false;
    }
    else if (!issuerName.equals(other.issuerName))
      return false;

    return true;
  }

  @Override
  public String toString()
  {
    String returnString = "IssuerName = " + issuerName;
    returnString += (", SerialNo = " + serialNo);
    returnString += (", ReasonCode = " + aReasonCode);
    returnString += (", HoldInstructionCode = " + aHoldInstructionCode);
    returnString += (", InvalidityDate = " + aInvalidityDate);
    returnString += (", CertificateIssuer = " + aCertificateIssuer);

    return returnString;
  }

  public Integer getReasonCode()
  {
    return aReasonCode;
  }

  public void setReasonCode(Integer inpReasonCode)
  {
    aReasonCode = inpReasonCode;
  }

  public Integer getHoldInstructionCode()
  {
    return aHoldInstructionCode;
  }

  public void setHoldInstructionCode(Integer inpHoldInstructionCode)
  {
    aHoldInstructionCode = inpHoldInstructionCode;
  }

  public String getInvalidityDate()
  {
    return aInvalidityDate;
  }

  public void setInvalidityDate(String inpInvalidityDate)
  {
    aInvalidityDate = inpInvalidityDate;
  }

  public String getCertificateIssuer()
  {
    return aCertificateIssuer;
  }

  public void setCertificateIssuer(String inpCertificateIssuer)
  {
    aCertificateIssuer = inpCertificateIssuer;
  }

  public Date getRevocationDate()
  {
    return (Date) aRevocationDate.clone();
  }

  public void setRevocationDate(Date inpRevocationDate)
  {
    aRevocationDate = (Date) inpRevocationDate.clone();
  }

}
