/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certificatepathvalidator;

import java.io.IOException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.bouncycastle.jce.provider.X509CertificateObject;

import eu.peppol.lsp.xkmsresponder.certificatevalidator.CertificateValidatorBean;
import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CVRequest;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.Constants;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.xkms.TranslationTable;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;


/*
 * This class is responsible for the examination of the Cert-Tree. First its checks the validity-time
 * of every Certificate for the given validation-Time. If a Certificate inside the chain is revoked,
 * it looks for the reason. Only if the Revocation-Reason is "unknown", or key-compromised" the chek
 * will give a negative result.
 * @author Andre Jens
 * @author mho
 * @author buengener
 * @version $Revision: 1.42 $
 * 
 */
public abstract class CertificatePathValidatorProcess
{
  private static final Logger LOG = Logger.getLogger(CertificatePathValidatorProcess.class.getName());

  private static final String CVInbound = "java:comp/env/CVInbound";

  private static final String CVOutbound = "java:comp/env/CVOutbound";

  private static CertificateFactory cf = null;

  private static int refID = 0;

  static
  {
    try
    {
      cf = CertificateFactory.getInstance("X509", ResponderHelper.SECURITYPROVIDER);
    }
    catch (Exception ex)
    {
      LOG.log(Level.FINE, "Error in static: ", ex);
    }
  }

  /**
   * Creates a new CertificatePathValidator object.
   */
  private CertificatePathValidatorProcess()
  {
    // just to make it private
  }

  public static CPVResponse execute(CPVRequest inpCPVRequest)
  {
    CPVResponse retCPVResponse = null;

    try
    {
      CVRequest[] tmpCVRequests = master(inpCPVRequest);

      // remove self signed certificates that are not configured as trusted anchors

      if (tmpCVRequests.length == 1)
      {
        X509Certificate tmpCert = tmpCVRequests[0].getUsercert();
        if (!Configuration.containsIssuerCertificate(tmpCert))
        	return createSelfsignedResponse(tmpCert, inpCPVRequest);
      }

      List<CertificatevalidatorResult> tmpResponses = null;
      tmpResponses = executeParallel(tmpCVRequests);

      if (tmpResponses == null)
      {
        return CertificatePathValidatorHelper.createErrorResponse(inpCPVRequest);
      }

      retCPVResponse = CertificatePathValidatorHelper.sortResults(tmpResponses);
      retCPVResponse.getValidatorResult(0).setValidationTimeQueried(inpCPVRequest.getTimeInstance());
      retCPVResponse.getValidatorResult(0).addValidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
      retCPVResponse.getValidatorResult(0).addValidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);


      IssuerDto tmpIssuerDto =
            Configuration.getIssuerDtoByUserCertificate(retCPVResponse.getValidatorResult(0)
                                                                                  .getCertificate());
      String tmpValidateModel = tmpIssuerDto.getValidateModel();
      LOG.fine("ValidateModel for Issuer: " + tmpIssuerDto.getName() + " is: " + tmpValidateModel);
      retCPVResponse = checkChain(retCPVResponse, inpCPVRequest, tmpValidateModel);
      return retCPVResponse;
    }
    catch (CertificatePathValidatorException ex)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("could not build Certificate.Chain !!");
      }

      retCPVResponse = ex.getResp();

      if (retCPVResponse != null)
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("ErrorResponse: " + retCPVResponse.getErrorCode());
          LOG.fine("IndeterminateReason: " + TranslationTable.XKMS_REASON_TABLE.get(retCPVResponse.getValidatorResult(0).getIndeterminateReason()));
        }
      }
      else
      {
        retCPVResponse = CertificatePathValidatorHelper.createErrorResponse(inpCPVRequest);
      }

      return retCPVResponse;
    }
    catch (Exception ex)
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.log(Level.FINE, "Error in onMessage", ex);
      }

      retCPVResponse = CertificatePathValidatorHelper.createErrorResponse(inpCPVRequest);

      return retCPVResponse;
    }
  }

  private static CPVResponse createSelfsignedResponse(X509Certificate inpCert, CPVRequest inpCPVRequest)
  {
	LOG.warning("Unconfigured self signed certifcate found.");
    CPVResponse tmpResponse = new CPVResponse();
    CertificatevalidatorResult tmpResult = new CertificatevalidatorResult(inpCert);
    tmpResult.setValidationTimeQueried(inpCPVRequest.getTimeInstance());
    tmpResult.setChainpos(Integer.valueOf(0));
    tmpResult.addValidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
    tmpResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);

    boolean tmpValidityIntervall =
          CertificatePathValidatorHelper.isCertificateInsideValidityIntervall(inpCert, inpCPVRequest);

    if (tmpValidityIntervall)
    {
      tmpResult.addValidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      tmpResponse.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INDETERMINATE));
    }
    else
    {
      tmpResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      tmpResponse.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
    }

    tmpResponse.addCertificateCheckList(tmpResult);
    tmpResponse.setRequestID(inpCPVRequest.getRequestID());
    tmpResponse.setErrorMessage("a untrusted selfsigned certificate was found");

    return tmpResponse;
  }

  private static List<CertificatevalidatorResult> executeParallel(CVRequest[] inpCVRequests)
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("executeParallel no of CVRequests in execute: " + inpCVRequests.length);
    }

    Hashtable<Integer, CertificatevalidatorResult> retResponses = new Hashtable<Integer, CertificatevalidatorResult>();

    try
    {
        CertificateValidatorBean[] cvs = new CertificateValidatorBean[inpCVRequests.length];
        LOG.fine("Before sendAndReceive");
        synchronized (inpCVRequests)
        {
  	      for (int i = 0; i < inpCVRequests.length; i++)
  	      {
  	    	  cvs[i] = new CertificateValidatorBean(inpCVRequests, i);
	    	  LOG.fine("Starting thread " + cvs[i].getName() + " for index " + i);
  	    	  cvs[i].start();
  	      }

  	      CertificatevalidatorResult rsp;
  	      long start = System.currentTimeMillis();
  	      while (retResponses.size() < cvs.length
  	    		  && (System.currentTimeMillis() - start) < Configuration.VALIDATION_TIMEOUT)
  	      {
  	    	  LOG.fine("WAIT");
  	    	  inpCVRequests.wait(Configuration.VALIDATION_TIMEOUT);
  	    	  LOG.fine("NOTIFIED");
  		      for (int i = 0; i < cvs.length; i++)
  		      {
  		    	  if (retResponses.get(i) == null)
  		    	  {
  		    		  rsp = cvs[i].getCVResponse();

  		    		  if (rsp != null)
  		    		  {
  		    			  if (LOG.isLoggable(Level.FINE))
  		    			  {
  		  		    		  LOG.fine("NOTIFIED FROM " + i);

  		  		    		  List<Integer> reason = rsp.getValidReason();

  		    				  if (reason != null)
  		    				  {
  		    					  for (Integer tmpInteger : reason)
  		    						  LOG.fine("ValidReason ResonCode: " + TranslationTable.XKMS_REASON_TABLE.get(tmpInteger));
  		    				  }
  		    			  }
  		    			  retResponses.put(Integer.valueOf(i), rsp);
  		    		  }
  		    	  }
  		      }
  	      }
        }
        LOG.finest("CertificatePathValidator get response");
    }
    catch (Exception ex2)
    {
    	LOG.log(Level.SEVERE, "Error while sending or receiving Messages.", ex2);
    }

    if (retResponses.size() < inpCVRequests.length)
      LOG.fine("Not enough messages received.");

    return new ArrayList<CertificatevalidatorResult>(retResponses.values());
  }

  /**
   * DOCUMENT ME!
   *
   * @param cpvRequest DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  private static CVRequest[] master(CPVRequest cpvRequest) throws CertificatePathValidatorException
  {
    LOG.fine("(start) master(???)");

    List<X509Certificate> certs = CertificatePathValidatorHelper.buildCertPath(cpvRequest);
    Long reqID;
    if (cpvRequest.getOcspRequestID() != null)
    {
      reqID = cpvRequest.getOcspRequestID();
    }
    else
    {
      reqID = Long.valueOf(refID++);
    }

    CVRequest[] cvRequest = process(certs, cpvRequest.isOcspNoCache(), reqID);
    LOG.fine("(stop) master(???)");

    return cvRequest;
  }


  /**
   * Building a CVRequest-Array from the given information
   *
   * @param _certs certificates in the right order of the certificate path
   *
   */
  private static CVRequest[] process(final List<X509Certificate> _certs, boolean useOCSPCache,
                                     Long _reqID) throws CertificatePathValidatorException
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("(start) process(___ , " + _reqID + " )");
    }

    CVRequest[] cvrequest = new CVRequest[_certs.size()];
    boolean tmpIsTACert = false;

    try
    {
      for (int i = 0; i < _certs.size(); i++)
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("## Chain (" + (i + 1) + ") " + _certs.get(i).getSubjectDN().getName() + "-"
                    + _certs.get(i).getIssuerDN().getName());
        }

        if (i == (_certs.size() - 1))
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificates in process Subject: " + (_certs.get(i)).getEncoded().length);
          }

          if (!tmpIsTACert)
          {
            tmpIsTACert = isTACert(_certs.get(i));

            if (LOG.isLoggable(Level.FINE))
            {
              LOG.fine("CertificateSubject: " + (_certs.get(i)).getSubjectDN().getName() + " IsTACert? :"
                        + tmpIsTACert);
            }
          }

          cvrequest[i] =
                new CVRequest(_certs.get(i), _certs.get(i), Integer.valueOf(i), useOCSPCache, _reqID,
                              tmpIsTACert, false);
        }
        else
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificates in process Subject: " + (_certs.get(i)).getEncoded().length);
          }

          if (!tmpIsTACert)
          {
            LOG.fine("Class of Cert:" + _certs.get(i).getClass().getName());
            tmpIsTACert = isTACert(_certs.get(i));

            if (LOG.isLoggable(Level.FINE))
            {
              LOG.fine("CertificateSubject: " + (_certs.get(i)).getSubjectDN().getName() + " IsTACert? :"
                        + tmpIsTACert);
            }
          }

          cvrequest[i] =
                new CVRequest((_certs.get(i)), (_certs.get(i + 1)), Integer.valueOf(i), useOCSPCache, _reqID,
                              tmpIsTACert, false);
        }

      }
    }
    catch (IllegalArgumentException ex1)
    {
      CPVResponse resp = new CPVResponse();
      resp.setErrorCode(XKMSConstants.ErrorExtension_Unknown);
      LOG.log(Level.FINE, "IllegalArgumentException", ex1);
      throw new CertificatePathValidatorException(resp);
    }
    catch (CertificateEncodingException ex1)
    {
      CPVResponse resp = new CPVResponse();
      resp.setErrorCode(XKMSConstants.ErrorExtension_WrongCertificateFormat);
      LOG.log(Level.FINE, "CertificateEncodingException", ex1);
      throw new CertificatePathValidatorException(resp);
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("(stop) process(___ , " + _reqID + " )");
    }

    return cvrequest;
  }


  /**
   * Aggregate the results of the single certificate checks into the result and error code /message fields
   * of the given response.
   * Checks the cert-path for validity and revocation status.
   *
   * @param req  the informations out of the original request - only request
   *         ID and time instance are considered
   * @param response contains the array of results of the respective cert checks of the
   *        complete cert path
   *
   * @return the original response given as parameter with all information currently
   *        gathered
 * @throws IOException
   */
  public static CPVResponse checkChain(CPVResponse response, CPVRequest req, String valModel) throws IOException
  {
    LOG.fine("(start) checkChain");
    CertificatevalidatorResult[] certs = response.getCertificateCheckLists();

    response.setRequestID(req.getRequestID());
    Calendar tmpActulTime = Calendar.getInstance();
    CertificatevalidatorResult userResult = response.getValidatorResult(0);

    if (req.getTimeInstance() == null)
    {
      req.setTimeInstance(tmpActulTime);

      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("No Time instance included in request. I will use current time.");
      }
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("TimeInstance used for validating certificate:" + req.getTimeInstance().getTime().toString());
    }

    if (req.getTimeInstance().getTime().after(tmpActulTime.getTime()))
    {
      return createErrorResponseTimeInstance(response, userResult, req.getTimeInstance());
    }

    if (LOG.isLoggable(Level.FINE))
    {
      for (int ti = 0; ti < userResult.getValidReason().size(); ti++)
      {
        LOG.fine("VALID-Reason in checkChain: " + TranslationTable.XKMS_REASON_TABLE.get(userResult.getValidReason().get(ti)));
        LOG.fine("ErrorCodes in CheckChain:" + userResult.getErrorCode());
      }
    }

    userResult.setNotBefore(userResult.getCertificate().getNotBefore());
    userResult.setNotOnOrAfter(userResult.getCertificate().getNotAfter());


    try
    {
      userResult.getCertificate().checkValidity(req.getTimeInstance().getTime());
    }
    catch (CertificateExpiredException ex)
    {
      userResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      response.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
      userResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
      CertificatePathValidatorHelper.checkForIndeterminate(certs);
      LOG.fine("Certificate expired " + userResult.getCertificate().getSubjectDN());

      return response;
    }
    catch (CertificateNotYetValidException ex)
    {
      userResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      response.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
      userResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
      CertificatePathValidatorHelper.checkForIndeterminate(certs);
      LOG.fine("Certificate notYetValid");

      return response;
    }

    if (!userResult.getInvalidReason().isEmpty())
    {
      if (req.getTimeInstance().after(userResult.getRevokationTime()))
      {
        response.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
        userResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
        userResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
        CertificatePathValidatorHelper.checkForIndeterminate(certs);

        return response;
      }
    }

    boolean validAtDate = false;
    if (valModel.equals(Constants.ATT_ISSUER_PATHVALIDATEMETHOD_CHAIN))
    {
      validAtDate = checkValidityAtDateChain(certs, req);
    }
    else if (valModel.equals(Constants.ATT_ISSUER_PATHVALIDATEMETHOD_ESCAPEROUTE))
    {
      validAtDate = checkValidityAtDateEscapeRoute(certs, req);
    }
    else // default
    {
      validAtDate = checkValidityAtDatePKIX(certs, req);
    }

    if (!validAtDate)
    {
      response.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
      userResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      userResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
      CertificatePathValidatorHelper.checkForIndeterminate(certs);

      return response;
    }

    userResult.addValidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);

    boolean indeterminatestatus = CertificatePathValidatorHelper.checkForIndeterminate(certs);
    boolean revocationstatus = false;

    if (valModel.equals(Constants.ATT_ISSUER_PATHVALIDATEMETHOD_CHAIN))
    	revocationstatus = checkForRevocationStatusChain(certs, req);
    else if (valModel.equals(Constants.ATT_ISSUER_PATHVALIDATEMETHOD_ESCAPEROUTE))
    	revocationstatus = checkForRevocationStatusEscapeRoute(certs, req);
    else
    	revocationstatus = checkForRevocationStatusPKIX(certs, req);

    if (!indeterminatestatus || !revocationstatus)
    {
      if (!indeterminatestatus)
      {
        userResult.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
        response.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INDETERMINATE));
      }

      if (!revocationstatus)
      {
        userResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
        response.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
      }
    }
    else
    {
      userResult.setStatus(CertificatevalidatorResult.STATUS_VALID);
      response.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_VALID));
    }

    LOG.fine("CertQuality in CertificatePathValidator: " + userResult.getCertQuality());

    boolean validExtensions = checkForValidExtensions(certs);

    if (!validExtensions)
    {
    	LOG.fine("Extensions are not complicant to Common PKI ");

    	userResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
        userResult.setStatus(CertificatevalidatorResult.STATUS_INVALID);
        response.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
    }
    return response;
  }

  /**
   * Check whether all certificates in the chain where inside their respective validity intervals
  * when the signature was made. If only one certificate was not inside its  validity interval,
  * the whole signature is invalid.
  *
  * @param cert       certs a CertificateCheckList for every Certificate in the chain
  * @param signDate   the Request, which contains
  *
  * @return    boolean  true if all Certificates are inside their validity interfall, false if not
  */
  private static boolean checkValidityAtDatePKIX(CertificatevalidatorResult[] certs, CPVRequest req)
  {
	LOG.fine("(start) checkValidityAtDatePKIX(???)");
	boolean userCertValid = true;
	CertificatevalidatorResult userlist = certs[0];

	for ( CertificatevalidatorResult tmpCert : certs )
	{
		X509Certificate cert = tmpCert.getCertificate();

		try
		{
			cert.checkValidity(req.getTimeInstance().getTime());
			LOG.fine("Certificate valid at given time instance");
		}
		catch (CertificateExpiredException ex)
		{
			LOG.fine("Certificate expired");
			userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
			userCertValid = false;
		}
		catch (CertificateNotYetValidException ex)
		{
			LOG.fine("Certificate not yet valid");
			userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
			userCertValid = false;
		}
	}
	return userCertValid;
  }

  /**
   * Check if all certificates in the chain where inside their respective validity intervals
   * when the signature was made. If only one certificate was not inside its  validity interval,
   * the whole signature is invalid. This been based on the acceptance, that Common PKI is right,
   * when  they say, that every Root- or CA-Certificate has to be inside the validity interval
   * until the last User-Cert is valid.
   *
   * @param cert       certs a CertificateCheckList for every Certificate in the chain
   * @param signDate   the Request, which contains
   *
   * @return    boolean  true if all Certificates are inside their validity interfall, false if not
   */
  private static boolean checkValidityAtDateEscapeRoute(CertificatevalidatorResult[] certs, CPVRequest req)
  {
    LOG.fine("(start) checkValidityAtDate(???)");

    boolean userCertValid = true;
    CertificatevalidatorResult userlist = certs[0];

    if (req.getTimeInstance() == null)
    {
      req.setTimeInstance(Calendar.getInstance());
      LOG.fine("No time instance included in request, use current local time.");
    }

    try
    {
      userlist.getCertificate().checkValidity(req.getTimeInstance().getTime());
    }
    catch (CertificateExpiredException ex)
    {
      LOG.fine("Certificate expired");
      userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      userCertValid = false;
    }
    catch (CertificateNotYetValidException ex)
    {
      LOG.fine("Certificate not yet valid");
      userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      userCertValid = false;
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Number of certificates in the chain: " + certs.length);
    }

    for (int ti = 0; ti < (certs.length); ti++)
    {
      LOG.fine("Counter = " + ti);
      // User-Cert checked above
      if (ti == 0 && certs.length > 1)
      {
        CertificatevalidatorResult usercert = certs[ti];
        CertificatevalidatorResult issuercert = certs[ti + 1];
        // Time of signature creation inside validity interval ?
        try
        {
          LOG.fine("Checking certificate: " + usercert.getCertificate().getSubjectDN().getName());
          LOG.fine("checking issuingCert " + issuercert.getCertificate().getSubjectDN().getName());
          issuercert.getCertificate().checkValidity(usercert.getCertificate().getNotBefore());

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificate is inside validity-interval: "
                      + issuercert.getCertificate().getSubjectDN().getName());
          }
        }
        catch (CertificateExpiredException ex2)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificate outside validity-interval: "
                      + issuercert.getCertificate().getSubjectDN().getName());
          }

          userCertValid = false;
          LOG.fine("(stop) checkValidityAtDate(???)");

          return userCertValid;
        }
        catch (CertificateNotYetValidException ex2)
        {
          // Issuer not valid yet
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificate outside validity-interval: "
                      + issuercert.getCertificate().getSubjectDN().getName());
          }

          userCertValid = false;
          LOG.fine("(stop) checkValidityAtDate(???)");

          return userCertValid;
        }
      }

      // Check succeeding certificates!
      if (ti > 0)
      {

        CertificatevalidatorResult usercert = certs[ti];
        try
        {
          LOG.fine("Checking certificate: " + certs[ti - 1].getCertificate().getSubjectDN().getName());
          LOG.fine("checking issuingCert " + usercert.getCertificate().getSubjectDN().getName());
          Date creationDate = CertificatePathValidatorHelper.getDateOfCertGen(certs[ti - 1].getCertificate());

          if (creationDate == null)
          {
            usercert.getCertificate().checkValidity(certs[ti - 1].getCertificate().getNotBefore());

            if (LOG.isLoggable(Level.FINE))
            {
              LOG.fine("Certificate is inside validity-interval: "
                        + usercert.getCertificate().getSubjectDN().getName());
            }
          }
          else
          {
            usercert.getCertificate().checkValidity(creationDate);

            if (LOG.isLoggable(Level.FINE))
            {
              LOG.fine("Certificate is inside validity-interval: "
                        + usercert.getCertificate().getSubjectDN().getName());
            }
          }
        }
        catch (CertificateExpiredException ex1)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificate outside validity-interval: "
                      + usercert.getCertificate().getSubjectDN().getName());
          }

          usercert.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
          userCertValid = false;

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("(stop) checkValidityAtDate(???)");
          }

          return userCertValid;
        }
        catch (CertificateNotYetValidException ex1)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificate outside validity-interval: "
                      + usercert.getCertificate().getSubjectDN().getName());
          }

          usercert.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
          userCertValid = false;
          LOG.fine("(stop) checkValidityAtDate(???)");

          return userCertValid;
        }
      }
    }

    return userCertValid;
  }

  /**
   * Check if all certificates in the chain where inside their respective validity intervals
   * when the signature was made. If only one certificate was not inside its  validity interval,
   * the whole signature is invalid. This been based on the acceptance, that Common PKI is right,
   * when  they say, that every Root- or CA-Certificate has to be inside the validity interval
   * until the last User-Cert is valid.
   *
   * @param cert       certs a CertificateCheckList for every Certificate in the chain
   * @param signDate   the Request, which contains
   *
   * @return    boolean  true if all Certificates are inside their validity interfall, false if not
   */
  private static boolean checkValidityAtDateChain(CertificatevalidatorResult[] certs, CPVRequest req)
  {
    LOG.fine("(start) checkValidityAtDate(???)");

    boolean chainValidAtDate = true;
    CertificatevalidatorResult userlist = certs[0];

    if (req.getTimeInstance() == null)
    {
      req.setTimeInstance(Calendar.getInstance());
      LOG.fine("No time instance included in request, use current local time.");
    }

    try
    {
      userlist.getCertificate().checkValidity(req.getTimeInstance().getTime());
    }
    catch (CertificateExpiredException ex)
    {
      LOG.fine("Certificate expired");
      userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      chainValidAtDate = false;
    }
    catch (CertificateNotYetValidException ex)
    {
      LOG.fine("Certificate not yet valid");
      userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
      chainValidAtDate = false;
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Number of certificates in the chain: " + certs.length);
    }

    for (int ti = 1; ti < (certs.length); ti++)
    {
      LOG.fine("Counter = " + ti);
      // User-Cert checked above
      // Check succeeding certificates!
          CertificatevalidatorResult usercert = certs[ti-1];
          CertificatevalidatorResult issuercert = certs[ti];
        try
        {
          LOG.fine("Checking certificate: " + usercert.getCertificate().getSubjectDN().getName());
          LOG.fine("checking issuingCert " + issuercert.getCertificate().getSubjectDN().getName());
          Date creationDate = CertificatePathValidatorHelper.getDateOfCertGen(usercert.getCertificate());

          if (creationDate == null)
          {
        	  issuercert.getCertificate().checkValidity(usercert.getCertificate().getNotBefore());

            if (LOG.isLoggable(Level.FINE))
            {
              LOG.fine("Certificate is inside validity-interval: "
                        + issuercert.getCertificate().getSubjectDN().getName());
            }
          }
          else
          {
        	  issuercert.getCertificate().checkValidity(creationDate);

            if (LOG.isLoggable(Level.FINE))
            {
              LOG.fine("Certificate is inside validity-interval: "
                        + issuercert.getCertificate().getSubjectDN().getName());
            }
          }
        }
        catch (CertificateExpiredException ex1)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificate outside validity-interval: "
                      + issuercert.getCertificate().getSubjectDN().getName());
          }

          issuercert.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
          chainValidAtDate = false;

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("(stop) checkValidityAtDate(???)");
          }

          return chainValidAtDate;
        }
        catch (CertificateNotYetValidException ex1)
        {
          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Certificate outside validity-interval: "
                      + usercert.getCertificate().getSubjectDN().getName());
          }

          issuercert.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
          chainValidAtDate = false;
          LOG.fine("(stop) checkValidityAtDate(???)");

          return chainValidAtDate;
        }
    }

    return chainValidAtDate;
  }

  /**
   * Checks if the extensions in the Certificates are compilant with the Common PKI specification
   * @param certs CertifacatevalidatorResult[]
   * @param req CPVRequest
   * @return boolean
   */
  private static boolean checkForValidExtensions(CertificatevalidatorResult[] certs) throws IOException
  {
    boolean validExtensions = true;

    ArrayList<X509CertificateObject> tmpList = new ArrayList<X509CertificateObject>();


    if (certs != null)
    {
    	for (int ta = 0; ta < certs.length; ta++)
        {
          LOG.fine("Certificate at Position: " + ta + " SubjectDN: "
                    + certs[ta].getCertificate().getSubjectDN().toString());
        }

        for (int i = (certs.length - 1); i >= 0; i--)
        {
//        	ByteArrayInputStream bIn = new ByteArrayInputStream(certs[i].getCertificate().getEncoded());
        	tmpList.add((X509CertificateObject) certs[i].getCertificate());
        }

        ValidateCertExtensions extensionValidator = new ValidateCertExtensions();
        validExtensions =
              extensionValidator.validateCertPath(tmpList.toArray(new X509CertificateObject[tmpList.size()]));

    }

    LOG.fine("checkForValidExtension: " + validExtensions);

    return validExtensions;
  }

  /**
   * These Method verifies, if all Certificates inside the Chain are not revoked. If one of the
   * certificates was revoked the check return false.
   *
   * @param cert       certs a CertificateCheckList for every Certificate in the chain
   * @param signDate   the Request, which contains
   *
   * @return    boolean  true if all Certificates,except the user-Certificate,
   *                     are not revoked with the reason code "keycompromised" or "unknown". If the
   *                     User-Certificate was revoked before time instance (or revocation date is unknown),
   *                     it will always be false.
   */
  private static boolean checkForRevocationStatusPKIX(CertificatevalidatorResult[] certs, CPVRequest req)
  {
    LOG.fine("(start) checkForRevocationStatus(???)");

    CertificatevalidatorResult userResult = certs[0];

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("InvalidReason in CertificatePathValidator ( userlist) : "
                + userResult.getInvalidReason().toString());
      LOG.fine("InvalidReason length ( userlist) :" + userResult.getInvalidReason().size());
    }

    if (userResult.getInvalidReason().size() != 0)
    {
      if
      ((userResult.getRevokationReason() == CertificatevalidatorResult.REVOCATIONREASON_UNSPECIFIED)
        || (userResult.getRevokationReason() == CertificatevalidatorResult.REVOCATIONREASON_KEYCOMPROMISE)
        || (userResult.getRevokationReason() == CertificatevalidatorResult.REVOCATIONREASON_CACOMPROMISE)
        || (userResult.getRevokationReason() == CertificatevalidatorResult.REVOCATIONREASON_AA_COMPROMISE))
      {

        return false;
      }

      LOG.fine("UserCert revocation time is " + userResult.getRevokationTime());
      if (userResult.getRevokationTime() != null)
      {
        if (userResult.getRevokationTime().before(req.getTimeInstance().getTime()))
        {
          return false;
        }

        userResult.getIndeterminateReason().remove(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        userResult.getInvalidReason().remove(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        userResult.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
      }
      else
      {
        return false;
      }
    }

    for ( int ti = 1 ; ti < certs.length ; ti++ )
    {
      CertificatevalidatorResult issuerResult = certs[ti];

      // enthaelt des jeweilige Zertifikat ein Grund, warum es ungueltig ist ?
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("InvalidReason in CertificatePathValidator ( checklist ) : "
                  + issuerResult.getInvalidReason().toString());
        LOG.fine("InvalidReason length ( checklist ) :" + issuerResult.getInvalidReason().size());
      }

      if (issuerResult.getInvalidReason().contains(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS))
      {
    	  if (issuerResult.getRevokationTime().before(req.getTimeInstance().getTime()))
    	  {
    		  userResult.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
	          userResult.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
	          LOG.fine("(stop) checkForRevocationStatus(???)");
	          if (LOG.isLoggable(Level.FINE))
	          {
	            LOG.fine("Found a revoked Certificate: " + issuerResult.getCertificate().getSubjectDN());
	            LOG.fine("SerialNumber: " + issuerResult.getCertificate().getSerialNumber());
	            LOG.fine("RevocationTime: " + issuerResult.getRevokationTime());
	            LOG.fine("RevocationReason: " + issuerResult.getRevokationReason());
	          }
	          return false;
    	  }
      }
    }
    return true;
  }

  /**
   * These Method verifies, if all Certificates inside the Chain are not revoked. If the user
   * certificate was revoked befor the requested validation time or another
   * certificate was revoked before its signing date, the check returns false.
   *
   * @param cert       certs a CertificateCheckList for every Certificate in the chain
   * @param signDate   the request, which contains
   *
   * @return    boolean  true if all certificates are not revoked before the time of signature
   * 					creation. If the user certificate was revoked, it will always be false.
   */
  private static boolean checkForRevocationStatusChain(CertificatevalidatorResult[] certs,
                                                             CPVRequest req)
  {
    // zuerst mal pr?fen, ob das User-Zertifikat gesperrt ist. Wenn ja, ist die Signatur ung?ltig
    LOG.fine("(start) checkForRevocationStatus(???)");

    CertificatevalidatorResult userlist = certs[0];

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("InvalidReason in CertificatePathValidator ( userlist) : "
                + userlist.getInvalidReason().toString());
      LOG.fine("InvalidReason length ( userlist) :" + userlist.getInvalidReason().size());
    }

    if (userlist.getInvalidReason().size() != 0)
    {
      if (userlist.getRevokationTime() != null)
      {
        if (userlist.getRevokationTime().before(req.getTimeInstance().getTime()))
        {

          return false;
        }

        userlist.getIndeterminateReason().remove(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        userlist.getInvalidReason().remove(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        userlist.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
      }
      else
      {
        return false;
      }
    }

    for ( int ti = 1 ; ti < certs.length ; ti++ )
    {
      CertificatevalidatorResult checklist = certs[ti];

      // enthaelt des jeweilige Zertifikat ein Grund, warum es ungueltig ist ?
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("InvalidReason in CertificatePathValidator ( checklist ) : "
                  + checklist.getInvalidReason().toString());
        LOG.fine("InvalidReason length ( checklist ) :" + checklist.getInvalidReason().size());
      }

      if (checklist.getInvalidReason().contains(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS))
      {
        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("Found a revoked Certificate: " + checklist.getCertificate().getSubjectDN());
          LOG.fine("SerialNumber: " + checklist.getCertificate().getSerialNumber());
          LOG.fine("RevocationTime: " + checklist.getRevokationTime());
          LOG.fine("RevocationReason: " + checklist.getRevokationReason());
        }

        Date creationDate = CertificatePathValidatorHelper.getDateOfCertGen(certs[ti - 1].getCertificate());
        if (creationDate == null)
          creationDate = certs[ti - 1].getCertificate().getNotBefore();

        if (checklist.getRevokationTime().before(creationDate))
        {
          userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
          userlist.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
          LOG.fine("(stop) checkForRevocationStatus(???)");

          return false;
        }
      }
    }


    return true;
  }

  /**
   * This Method verifies, if all Certificates inside the Chain are not revoked. If the
   * User-Certificate was revoked, before Signature-Date, the check returns false. If one of the
   * CA- or Root-Certificates is revoked, the revocation-reason was examined. Only if the Reason is
   * "keyCompromised" or "unknown" the method returns false. For all other reason, the check was
   * resumed.
   *
   * @param cert       certs a CertificateCheckList for every Certificate in the chain
   * @param signDate   the Request, which contains
   *
   * @return    boolean  true if all Certificates,except the user-Certificate,
   *                     are not revoked with the reason code "keycompromised" or "unknown". If the
   *                     User-Certificate was revoked, it will always be false.
   */
  private static boolean checkForRevocationStatusEscapeRoute(CertificatevalidatorResult[] certs,
                                                             CPVRequest req)
  {
    // zuerst mal pr?fen, ob das User-Zertifikat gesperrt ist. Wenn ja, ist die Signatur ung?ltig
    LOG.fine("(start) checkForRevocationStatus(???)");

    CertificatevalidatorResult userlist = certs[0];

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("InvalidReasons in CertificatePathValidator ( userlist):");
      for (Integer e : userlist.getInvalidReason())
          LOG.fine("InvalidReason " + TranslationTable.XKMS_REASON_TABLE.get(e));
    }

    if (userlist.getInvalidReason().size() != 0)
    {
//        if ((userlist.getRevokationReason() == 0) || (userlist.getRevokationReason() == 1))
    	if (userlist.getRevokationReason() == 1)
      {

        return false;
      }

      if (userlist.getRevokationTime() != null)
      {
        if (userlist.getRevokationTime().before(req.getTimeInstance().getTime()))
        {

          return false;
        }

        userlist.getIndeterminateReason().remove(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        userlist.getInvalidReason().remove(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
        userlist.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
      }
      else
      {
        return false;
      }
    }

    for (int ti = 1; ti < certs.length; ti++)
    {
      CertificatevalidatorResult checklist = certs[ti];

      // enthaelt des jeweilige Zertifikat ein Grund, warum es ungueltig ist ?
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("InvalidReasons in CertificatePathValidator ( checklist):");
        for (Integer e : userlist.getInvalidReason())
            LOG.fine("InvalidReason " + TranslationTable.XKMS_REASON_TABLE.get(e));
      }

      if (checklist.getInvalidReason().size() != 0)
      {
        // Unknown revocation reason or key compromised -> signature invalid
        if ((checklist.getRevokationReason() == CertificatevalidatorResult.REVOCATIONREASON_KEYCOMPROMISE)
            || (checklist.getRevokationReason() == CertificatevalidatorResult.REVOCATIONREASON_UNSPECIFIED)
            || (checklist.getRevokationReason() == CertificatevalidatorResult.REVOCATIONREASON_AA_COMPROMISE))
        {
          userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
          userlist.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
          LOG.fine("(stop) checkForRevocationStatus(???)");

          return false;
        }

        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("Found a revoked Certificate: " + checklist.getCertificate().getSubjectDN());
          LOG.fine("SerialNumber: " + checklist.getCertificate().getSerialNumber());
          LOG.fine("RevocationTime: " + checklist.getRevokationTime());
          LOG.fine("RevocationReason: " + checklist.getRevokationReason());
        }

        if (checklist.getRevokationTime().before(certs[ti - 1].getCertificate().getNotBefore()))
        {
          userlist.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
          userlist.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
          LOG.fine("(stop) checkForRevocationStatus(???)");

          return false;
        }
      }
    }


    return true;
  }


  static class CertifacatevalidatorResultsComparatorByChainPos implements
        Comparator<CertificatevalidatorResult>
  {
    private static CertifacatevalidatorResultsComparatorByChainPos singleton =
          new CertifacatevalidatorResultsComparatorByChainPos();

    /* (non-Javadoc)
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(CertificatevalidatorResult inpCertifacatevalidatorResult1,
                       CertificatevalidatorResult inpCertifacatevalidatorResult2)
    {
      CertificatevalidatorResult tmpCertifacatevalidatorResult1 = inpCertifacatevalidatorResult1;
      CertificatevalidatorResult tmpCertifacatevalidatorResult2 = inpCertifacatevalidatorResult2;

      return tmpCertifacatevalidatorResult1.getChainpos().intValue()
             - tmpCertifacatevalidatorResult2.getChainpos().intValue();
    }

    public static CertifacatevalidatorResultsComparatorByChainPos getSingleton()
    {
      return singleton;
    }
  }


  private static boolean isTACert(X509Certificate inpCert)
  {
    try
    {
      String tmpFingerprint = ResponderHelper.getFingerprint(inpCert);
      CertificateDto tmpTrustedAnchorDto =
            Configuration.getTrustedAnchor(tmpFingerprint);

      if (tmpTrustedAnchorDto == null)
      {
        return false;
      }

      return true;
    }
    catch (Exception ex)
    {
      return false;
    }
  }

  private static CPVResponse createErrorResponseTimeInstance(CPVResponse inpResponse,
                                                             CertificatevalidatorResult inpUserResult,
                                                             Calendar inpTime)
  {
    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Got a wrong TimeInstance. Creating Error-Response.");
      LOG.fine("TimeZone in request: " + inpTime.getTimeZone().getDisplayName());
    }

    inpResponse.setErrorMessage("Wrong time instant");
    inpResponse.setErrorCode(XKMSConstants.ErrorExtension_WrongTimeInstant);
    inpResponse.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INDETERMINATE));
    inpUserResult.setErrorCode(XKMSConstants.ErrorExtension_WrongTimeInstant);
    inpUserResult.setErrorMessage("Wrong time instant");
    inpUserResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    inpUserResult.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    inpUserResult.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    inpUserResult.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);

    return inpResponse;
  }
}
