/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;

import java.io.Serializable;

import eu.peppol.lsp.xkmsresponder.common.Constants;

/**
 * Represents a CRL validation method configuration
 * @author horstmann
 * 
*/
public class ValMethodCrlDto extends AbstractValMethodDto implements Serializable
{
  private static final long serialVersionUID = -6110122909425002646L;

  private String subType = Constants.ATT_VM_CRL_SUBTYPE_HTTP;

  private String searchbase = "";

  private String attribute = "";

  private Integer interval = Integer.valueOf(30);

  private boolean ignoreNextUpdate = false;

  private Integer escalation = Integer.valueOf(7);

  /**
   * Creates a new ValMethodCrlDto object.
   */
  public ValMethodCrlDto(String inpName)
  {
    super(inpName);
  }

  public String getSubType()
  {
    return subType;
  }

  public void setSubType(String subType)
  {
    if ((subType == null) || (subType.length() == 0))
    {
      this.subType = Constants.ATT_VM_CRL_SUBTYPE_HTTP;
    }
    else
    {
      this.subType = subType;
    }
  }

  public String getSearchbase()
  {
    return searchbase;
  }

  public void setSearchbase(String searchbase)
  {
    this.searchbase = DtoHelper.getNullAsEmptyString(searchbase);
  }

  public String getUrl()
  {
    return url;
  }

  public void setUrl(String url)
  {
    this.url = DtoHelper.getNullAsEmptyString(url);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (!super.equals(obj))
    {
      return false;
    }

    final ValMethodCrlDto other = (ValMethodCrlDto) obj;

    if (attribute == null)
    {
      if (other.attribute != null)
      {
        return false;
      }
    }
    else if (!attribute.equals(other.attribute))
    {
      return false;
    }

    if (interval == null)
    {
      if (other.interval != null)
      {
        return false;
      }
    }
    else if (!interval.equals(other.interval))
    {
      return false;
    }

    if (searchbase == null)
    {
      if (other.searchbase != null)
      {
        return false;
      }
    }
    else if (!searchbase.equals(other.searchbase))
    {
      return false;
    }

    if (subType == null)
    {
      if (other.subType != null)
      {
        return false;
      }
    }
    else if (!subType.equals(other.subType))
    {
      return false;
    }

    if (url == null)
    {
      if (other.url != null)
      {
        return false;
      }
    }
    else if (!url.equals(other.url))
    {
      return false;
    }

    if (ignoreNextUpdate != other.ignoreNextUpdate)
    {
      return false;
    }

    if (escalation == null)
    {
      if (other.escalation != null)
      {
        return false;
      }
    }
    else if (!escalation.equals(other.escalation))
    {
      return false;
    }

    return true;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode()
  {
    final int PRIME = 31;
    int result = super.hashCode();
    result = (PRIME * result) + ((url == null) ? 0 : url.hashCode());

    return result;
  }

  /**
   * @return a deep copy
   */
  @Override
  public Object clone()
  {
    ValMethodCrlDto ret = (ValMethodCrlDto) super.clone();
    return ret;
  }

  @Override
  public String toString()
  {
	  StringBuilder ret = new StringBuilder();
	  String[] values = {Integer.toString(ValMethodType.CRL_TYPE), refId, name, url, searchbase,
			  attribute, interval.toString(), Boolean.toString(ignoreNextUpdate)};
	  for (String val : values)
	  {
		  ret.append(val);
		  ret.append("\t");
	  }
	  return ret.toString();
  }

  public boolean changed(ValMethodCrlDto inpOtherValMethodCrlDto)
  {
    if (!equals(inpOtherValMethodCrlDto))
    {
      return true;
    }

    return false;
  }

  /**
   * @return the attribute
   */
  public String getAttribute()
  {
    return attribute;
  }

  /**
   * @param inpAttribute the attribute to set
   */
  public void setAttribute(String inpAttribute)
  {
    attribute = DtoHelper.getNullAsEmptyString(inpAttribute);
  }

  /**
   * @return the intervall
   */
  public Integer getIntervall()
  {
    return interval;
  }

  /**
   * @param inpInterval the interval to set
   */
  public void setInterval(Integer inpInterval)
  {
    interval = DtoHelper.getNullAsEmptyInteger(inpInterval);
  }

  /**
   * @return the ignoreNextUpdate
   */
  public boolean getIgnoreNextUpdate()
  {
    return ignoreNextUpdate;
  }

  /**
   * @param inpIgnoreNextUpdate the ignoreNextUpdate to set
   */
  public void setIgnoreNextUpdate(boolean inpIgnoreNextUpdate)
  {
    ignoreNextUpdate = inpIgnoreNextUpdate;
  }

  public Integer getEscalation()
  {
    return escalation;
  }

  public void setEscalation(Integer escalation)
  {
    this.escalation = DtoHelper.getNullAsEmptyInteger(escalation);
  }

}
