/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.configuration.dto;

import java.io.Serializable;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.common.PrincipalParser;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;


/*
 * Represents a certificate within the certificate store together with reference to validation
 * method.
 * @author aj, tt, rl, an
 * @version $Revision: 1.13 $
 * 
*/
public class CertificateDto implements Serializable, Cloneable
{
  /**
   *
   */
  private static final long serialVersionUID = 6178215854122418164L;

  private static final Logger LOG = Logger.getLogger(CertificateDto.class.getName());

  private String refId = null;

  private transient String fingerprint;

  private transient String subjectKeyId;

  private transient String subjectDN;

  private transient String subjectDNPrincipal;

  private transient String issuerDN;

  private transient X509Certificate x509Certificate;

  private String friendlyName;

  private String issuerName;

  private byte[] x509Bytes = null;

  /**
   * Constructor
   * @param inpIssuerKey
   * @param inpCertificate
   * @param inpFriendlyName
   * @param inpCheckOnline
   * @throws CertificateEncodingException
   */
  public CertificateDto(String inpIssuerName, X509Certificate inpCertificate, String inpFriendlyName,
                        boolean inpCheckOnline)
  {
    super();
    issuerName = inpIssuerName;
    try
    {
      x509Bytes = inpCertificate.getEncoded();
    }
    catch (CertificateEncodingException e)
    {
      if (LOG.isLoggable(Level.SEVERE))
      {
        LOG.log(Level.SEVERE, "CertificateDto() ", e);
      }
    }
    friendlyName = inpFriendlyName;
  }

  public String getFingerprint()
  {
    if (fingerprint == null)
    {
      fingerprint = ResponderHelper.getFingerprintHex(x509Bytes);
    }
    return fingerprint;
  }

  public String getSubjectDN()
  {
    if (subjectDN == null)
    {
      subjectDN = ResponderHelper.getSubjectDN(getX509Certificate());
    }
    return subjectDN;
  }

  public String getSubjectDNPrincipal()
  {
    if (subjectDNPrincipal == null)
    {
      subjectDNPrincipal = new PrincipalParser(getX509Certificate().getSubjectX500Principal()).toString();
    }
    return subjectDNPrincipal;
  }

  public String getIssuerDN()
  {
    if (issuerDN == null)
    {
      issuerDN = ResponderHelper.getIssuerDN(getX509Certificate());
    }
    return issuerDN;
  }

  public String getFriendlyName()
  {
    return friendlyName;
  }

  public void setFriendlyName(String inpFriendlyName)
  {
    friendlyName = DtoHelper.getNullAsEmptyString(inpFriendlyName);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    final CertificateDto other = (CertificateDto) obj;
    if (getFingerprint() == null)
    {
      if (other.getFingerprint() != null)
      {
        return false;
      }
    }
    else if (!getFingerprint().equals(other.getFingerprint()))
    {
      return false;
    }
    if (friendlyName == null)
    {
      if (other.friendlyName != null)
      {
        return false;
      }
    }
    else if (!friendlyName.equals(other.friendlyName))
    {
      return false;
    }
    if (issuerName == null)
    {
      if (other.issuerName != null)
      {
        return false;
      }
    }
    else if (!issuerName.equals(other.issuerName))
    {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((getFingerprint() == null) ? 0 : getFingerprint().hashCode());
    result = prime * result + ((friendlyName == null) ? 0 : friendlyName.hashCode());
    result = prime * result + ((issuerName == null) ? 0 : issuerName.hashCode());
    return result;
  }

  @Override
  public String toString()
  {
    String returnString = "";
    returnString += "SubjectDN = " + getSubjectDN();
    returnString += (", IssuerDN = " + getIssuerDN());
    returnString += (", FriendlyName = " + getFriendlyName());
    returnString += (", IssuerName = " + getIssuerName());
    returnString += (", SubjectKeyId = " + getSubjectKeyId());

    return returnString;
  }

  public X509Certificate getX509Certificate()
  {
    if (x509Certificate == null)
    {
      try
      {
        x509Certificate = ResponderHelper.createCertificate(x509Bytes);
      }
      catch (Exception ex)
      {
        x509Certificate = null;
      }
    }
    return x509Certificate;
  }

  private void setX509Bytes(byte[] inpCertificateBytes)
  {
    x509Bytes = inpCertificateBytes;
  }

  public String getIssuerName()
  {
    return issuerName;
  }

  private void setIssuerName(String inpIssuerName)
  {
    issuerName = DtoHelper.getNullAsEmptyString(inpIssuerName);
  }

  @Override
  public Object clone()
  {
    try
    {
      CertificateDto ret = (CertificateDto) super.clone();
      ret.setX509Bytes((x509Bytes != null) ? (byte[]) x509Bytes.clone() : null);

      return ret;
    }
    catch (CloneNotSupportedException e)
    {
      throw new InternalError(e.getMessage());
    }
  }

  public String getSubjectKeyId()
  {
    if (subjectKeyId == null)
    {
      subjectKeyId = ResponderHelper.getSubjectKeyIdentifier(getX509Certificate());
    }
    return subjectKeyId;
  }

  public String getRefId()
  {
    return refId;
  }

  public void setRefId(String inpRefId)
  {
    refId = DtoHelper.getNullAsEmptyString(inpRefId);
  }

}
