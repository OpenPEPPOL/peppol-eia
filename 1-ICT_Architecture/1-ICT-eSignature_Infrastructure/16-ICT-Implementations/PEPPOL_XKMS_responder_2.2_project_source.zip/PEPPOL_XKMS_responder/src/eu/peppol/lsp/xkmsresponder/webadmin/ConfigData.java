/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.webadmin;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.logging.Logger;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import eu.peppol.lsp.xkmsresponder.common.Constants;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;
import eu.peppol.lsp.xkmsresponder.requestcontroller.XKMSSignature;

/**
 * This class contains helper methods and constants
 * for the {@link WebAdmin} class.
 *
 * @author buengener
 * 
*/

public class ConfigData
{
	private final static Logger LOG = Logger.getLogger(WebAdmin.class.getName());

	public static final String[] QUALITIES = {Constants.ATT_ISSUER_QUALITY_UNKNOWN,
		Constants.ATT_ISSUER_QUALITY_LOW, Constants.ATT_ISSUER_QUALITY_LCP,
		Constants.ATT_ISSUER_QUALITY_NCP, Constants.ATT_ISSUER_QUALITY_NCPPLUS,
		Constants.ATT_ISSUER_QUALITY_QCP, Constants.ATT_ISSUER_QUALITY_QCPPLUS};

	public static final String[] VAL_MODEL = {Constants.ATT_ISSUER_PATHVALIDATEMETHOD_PKIX,
		Constants.ATT_ISSUER_PATHVALIDATEMETHOD_ESCAPEROUTE,
		Constants.ATT_ISSUER_PATHVALIDATEMETHOD_CHAIN};

	public static final String[] CSPA = {"none", "IndependentDocumentReview",
		"InternalComplianceAudit", "SupervisionWithoutComplianceAudit",
		"ExternalComplianceAudit", "ExternalComplianceAuditCertified",
		"SupervisionWithExternalComplianceAudit", "AccreditationWithExternalComplianceAudit"};


	private static BouncyCastleProvider bc = new BouncyCastleProvider();


	public static Hashtable<String, String> getProperties() throws GeneralSecurityException, IOException
	{
		Hashtable<String, String> ret = new Hashtable<String, String>();
		ret.put("proxyhost", Configuration.getProxyDto().getProxyHost());
		ret.put("proxyport", Configuration.getProxyDto().getProxyPort().toString());
		ret.put("timeout", Configuration.getProxyDto().getTimeout().toString());
		ret.put("nonproxyhosts", Configuration.getProxyDto().getNonProxyHosts());
		ret.put("username", Configuration.getProxyDto().getUserName());
		ret.put("password", Configuration.getProxyDto().getPassword());

		byte[] p12 = Configuration.getSignatureTokenDto().getData();
		if (p12 != null && p12.length > 0)
		{
			ret.put("keystoreentries", getKeyStoreEntries(Configuration.getSignatureTokenDto().getData(),
					Configuration.getSignatureTokenDto().getPin().getBytes(WebAdmin.CHARSET)));
			ret.put("sigalias", Configuration.getSignatureTokenDto().getAlias());
		}
		else
		{
			ret.put("sigalias", "");
			ret.put("keystoreentries", "No keystore configured.");
		}

		return ret;
	}

	public static void applyProps(Hashtable<String, byte[]> items) throws Exception
	{
		Configuration.getProxyDto().setProxyHost(new String(items.get("proxyhost"), WebAdmin.CHARSET));
		if (items.get("proxyport") != null && items.get("proxyport").length > 0)
			Configuration.getProxyDto().setProxyPort(Integer.parseInt(new String(items.get("proxyport"), WebAdmin.CHARSET)));
		else
			Configuration.getProxyDto().setProxyPort(0);
		if (items.get("timeout") != null && items.get("timeout").length > 0)
			Configuration.getProxyDto().setTimeout(Integer.parseInt(new String(items.get("timeout"), WebAdmin.CHARSET)));
		else
			Configuration.getProxyDto().setTimeout(30);
		Configuration.getProxyDto().setNonProxyHosts(new String(items.get("nonproxyhosts"), WebAdmin.CHARSET));
		Configuration.getProxyDto().setUserName(new String(items.get("username"), WebAdmin.CHARSET));
		Configuration.getProxyDto().setPassword(new String(items.get("password"), WebAdmin.CHARSET));
		Configuration.getSignatureTokenDto().setAlias(new String(items.get("signalias"), WebAdmin.CHARSET));
		Configuration.storeConfiguration();
	}

	public static String loadKeyStore(byte[] data, byte[] passwd) throws GeneralSecurityException, IOException, Exception
	{
		String entries;
		if (data == null || data.length == 0)
		{
			Configuration.getSignatureTokenDto().setData(data);
			Configuration.getSignatureTokenDto().setAlias("");
			Configuration.getSignatureTokenDto().setPin("");
			entries = "No keystore configured.";
		}
		else
		{
			if (passwd == null || passwd.length == 0)
				return "Could not open keystore, password required !";

			entries = getKeyStoreEntries(data, passwd);
			if (entries.trim().length()==0)
				return "No private keys found in keystore !";
			Configuration.getSignatureTokenDto().setData(data);
			Configuration.getSignatureTokenDto().setAlias(entries.substring(0, entries.indexOf("\t")));
			// @todo: Password as string
			Configuration.getSignatureTokenDto().setPin(new String(passwd, WebAdmin.CHARSET));
			for (int i = 0; i < passwd.length; i++)
				passwd[i] = 0;
		}
		Configuration.storeConfiguration();
		XKMSSignature.reloadSignatureKey(Configuration.getSignatureTokenDto());
		return entries;
	}

	public static IssuerDto createIssuer(String name) throws Exception
	{
		while (Configuration.containsIssuer(name))
			name += "_";
		IssuerDto issdto = new IssuerDto(name);
		issdto.setQuality(QUALITIES[0]);
		issdto.setEnabled(false);
		issdto.setCSPAssurance(CSPA[0]);
		issdto.setValMethod(ValMethodType.NONE);
		issdto.setValidateModel(VAL_MODEL[0]);
		issdto.setTSLIdentifier("UNKNOWN");
		issdto.setAlgPolicyIdentifier("UNKNOWN");
		Configuration.putIssuerDto(issdto);
		try
		{
			Configuration.storeConfiguration();
		}
		catch (Exception e)
		{
			Configuration.removeIssuer(issdto.getName());
			throw e;
		}
		return issdto;
	}

	public static void deleteIssuers(String[] names) throws Exception
	{
		for (int i = 0; i < names.length; i++)
			Configuration.removeIssuer(names[i]);
		Configuration.storeConfiguration();
	}

	public static void deleteIssuerCerts(String issuerName, String[] names) throws Exception
	{
		for (int i = 0; i < names.length; i++)
			Configuration.removeIssuerCertificateDto(issuerName, names[i]);
		Configuration.storeConfiguration();
	}

	public static void addIssuerCertificate(String issName, byte[] cert) throws Exception
	{
		if (cert.length == 0)
			return;
		X509Certificate x509 =  ResponderHelper.createCertificate(cert);
		if (x509 == null)
			x509 = ResponderHelper.createCertificate(ResponderHelper.base64decode(new String(cert)));
		String name = parseCN(x509);
		while (Configuration.getIssuerDto(issName).certificateMap.containsKey(name))
			name += "_";
		Configuration.putIssuerCertificateDto(issName,
				new CertificateDto(issName, x509, name, true));
		Configuration.storeConfiguration();
	}

	public static void changeIssuerState(String issuerName) throws CertificateException, Exception
	{
		boolean status = Configuration.getIssuerDto(issuerName).getEnabled();
		Configuration.getIssuerDto(issuerName).setEnabled(!status);
		Configuration.storeConfiguration();
	}

	public static String insertValMethodProps(IssuerDto issdto, int valMethod) // throws Exception
	{
		int vm = valMethod;
		if (vm < 0)
			vm = issdto.getValMethod().ordinal();

		String ret = WebAdmin.valMethodProperties[vm];

		switch (vm)
		{
			case ValMethodType.LOCAL_TYPE: break;
			case ValMethodType.OCSP_TYPE:
				ret = ret.replace("${relayOcspDO.url}", issdto.getValMethodOcspDto().getUrl());
				if (issdto.getValMethodOcspDto().getSubType().equals("Common PKI"))
				{
					ret = ret.replace("${relayOcspDO.subType.commonpki}", "checked=\"checked\"");
					ret = ret.replace("${relayOcspDO.subType.rfc}", "");
				}
				else if (issdto.getValMethodOcspDto().getSubType().equals("RFC"))
				{
					ret = ret.replace("${relayOcspDO.subType.commonpki}", "");
					ret = ret.replace("${relayOcspDO.subType.rfc}", "checked=\"checked\"");
				}
				if (issdto.getValMethodOcspDto().getUseCache())
				{
					ret = ret.replace("${relayOcspDO.useCache.true}", "checked=\"checked\"");
					ret = ret.replace("${relayOcspDO.useCache.false}", "");
				}
				else
				{
					ret = ret.replace("${relayOcspDO.useCache.true}", "");
					ret = ret.replace("${relayOcspDO.useCache.false}", "checked=\"checked\"");
				}
				ret = ret.replace("${relayOcspDO.cacheTimeout}", issdto.getValMethodOcspDto().getCacheTimeout().toString());
				if (issdto.getValMethodOcspDto().getCheckRespSignature().booleanValue())
				{
					ret = ret.replace("${relayOcspDO.checkRespSignature.true}", "checked=\"checked\"");
					ret = ret.replace("${relayOcspDO.checkRespSignature.false}", "");
				}
				else
				{
					ret = ret.replace("${relayOcspDO.checkRespSignature.true}", "");
					ret = ret.replace("${relayOcspDO.checkRespSignature.false}", "checked=\"checked\"");
				}
				break;
			case ValMethodType.CRL_TYPE:
				ret = insertCRLValMethodProps(issdto, ret);
				break;
			case ValMethodType.LDAP_TYPE:
				ret = insertLDAPValMethodProps(issdto, ret);
				break;
			case ValMethodType.CRL_LDAP_TYPE:
				ret = insertCRLValMethodProps(issdto, ret);
				ret = insertLDAPValMethodProps(issdto, ret);
				break;
			case ValMethodType.NONE_TYPE: break;
			case ValMethodType.XKMS_TYPE:
				ret = ret.replace("${relayXkmsDO.url}", issdto.getValMethodXkmsDto().getUrl());
				if (issdto.getValMethodXkmsDto().getSigCertificate() != null && issdto.getValMethodXkmsDto().getSigCertificate().length > 0)
					ret = ret.replace("${relayXkmsDO.signerCertCN}", parseCN(ResponderHelper.createCertificate(issdto.getValMethodXkmsDto().getSigCertificate())));
				else
					ret = ret.replace("${relayXkmsDO.signerCertCN}", "");
				break;

			default: break;
		}
		return ret;
	}

	private static String insertCRLValMethodProps(IssuerDto issdto, String vmProps)
	{
		String ret = vmProps;
		ret = ret.replace("${relayCrlDO.url}", issdto.getValMethodCrlDto().getUrl());
		ret = ret.replace("${relayCrlDO.searchbase}", issdto.getValMethodCrlDto().getSearchbase());
		ret = ret.replace("${relayCrlDO.attribute}", issdto.getValMethodCrlDto().getAttribute());
		if (issdto.getValMethodCrlDto().getIgnoreNextUpdate())
		{
			ret = ret.replace("${relayCrlDO.ignoreNextUpdate.true}", "checked=\"checked\"");
			ret = ret.replace("${relayCrlDO.ignoreNextUpdate.false}", "");
		}
		else
		{
			ret = ret.replace("${relayCrlDO.ignoreNextUpdate.true}", "");
			ret = ret.replace("${relayCrlDO.ignoreNextUpdate.false}", "checked=\"checked\"");
		}
		ret = ret.replace("${relayCrlDO.interval}", issdto.getValMethodCrlDto().getIntervall().toString());
		return ret;
	}

	private static String insertLDAPValMethodProps(IssuerDto issdto, String vmProps)
	{
		String ret = vmProps;
		ret = ret.replace("${relayLdapDO.url}", issdto.getValMethodLdapDto().getUrl());
		if (issdto.getValMethodLdapDto().getAuthenticationType().equals("none"))
		{
			ret = ret.replace("${relayLdapDO.authenticationType.none}", "checked=\"checked\"");
			ret = ret.replace("${relayLdapDO.authenticationType.simple}", "");
		}
		else if (issdto.getValMethodLdapDto().getAuthenticationType().equals("simple"))
		{
			ret = ret.replace("${relayLdapDO.authenticationType.none}", "");
			ret = ret.replace("${relayLdapDO.authenticationType.simple}", "checked=\"checked\"");
		}
		ret = ret.replace("${relayLdapDO.authenticationPrincipal}", issdto.getValMethodLdapDto().getAuthenticationPrincipal());
		ret = ret.replace("${relayLdapDO.authenticationCredentials}", issdto.getValMethodLdapDto().getAuthenticationCredentials());
		ret = ret.replace("${relayLdapDO.searchbase}", issdto.getValMethodLdapDto().getSearchbase().toString());
		ret = ret.replace("${relayLdapDO.filter}", issdto.getValMethodLdapDto().getFilter());
		ret = ret.replace("${relayLdapDO.attribute}", issdto.getValMethodLdapDto().getAttribute());

		return ret;
	}

	public static void applyIssuerProps(IssuerDto issdto, int valmethod, Hashtable<String, byte[]> items) throws CertificateException, Exception
	{
		try
		{
			String value = new String(items.get("tslId"), WebAdmin.CHARSET);
			issdto.setTSLIdentifier(value.length() > 0 ? value : "UNKNOWN");

			value = new String(items.get("algPolId"), WebAdmin.CHARSET);
			issdto.setAlgPolicyIdentifier(value.length() > 0 ? value : "UNKNOWN");

			issdto.setQuality(new String(items.get("quality"), WebAdmin.CHARSET));

			issdto.setCSPAssurance(new String(items.get("cspa"), WebAdmin.CHARSET));

			issdto.setValidateModel(new String(items.get("valmodel"), WebAdmin.CHARSET));

			switch (valmethod)
			{
				case ValMethodType.LOCAL_TYPE:
					issdto.setValMethod(ValMethodType.LOCAL);
					break;
				case ValMethodType.OCSP_TYPE:
					issdto.setValMethod(ValMethodType.OCSP);
					issdto.getValMethodOcspDto().setUrl(new String(items.get("relayOcspDO.url"), WebAdmin.CHARSET));
					issdto.getValMethodOcspDto().setSubType(new String(items.get("relayOcspDO.subType"), WebAdmin.CHARSET));
					issdto.getValMethodOcspDto().setUseCache(new String(items.get("relayOcspDO.useCache"), WebAdmin.CHARSET).equalsIgnoreCase("true"));
					issdto.getValMethodOcspDto().setCacheTimeout(Integer.parseInt(new String(items.get("relayOcspDO.cacheTimeout"), WebAdmin.CHARSET)));
					issdto.getValMethodOcspDto().setCheckRespSignature(new String(items.get("relayOcspDO.checkRespSignature"), WebAdmin.CHARSET).equalsIgnoreCase("true"));
					break;
				case ValMethodType.CRL_TYPE:
					issdto.setValMethod(ValMethodType.CRL);
					applyCRLValMethodProps(issdto, items);
					break;
				case ValMethodType.LDAP_TYPE:
					issdto.setValMethod(ValMethodType.LDAP);
					applyLDAPValMethodProps(issdto, items);
					break;
				case ValMethodType.CRL_LDAP_TYPE:
					issdto.setValMethod(ValMethodType.CRL_LDAP);
					applyCRLValMethodProps(issdto, items);
					applyLDAPValMethodProps(issdto, items);
					break;
				case ValMethodType.NONE_TYPE:
					issdto.setValMethod(ValMethodType.NONE);
					break;
				case ValMethodType.XKMS_TYPE:
					issdto.setValMethod(ValMethodType.XKMS);
					issdto.getValMethodXkmsDto().setUrl(new String(items.get("relayXkmsDO.url"), WebAdmin.CHARSET));
					issdto.getValMethodXkmsDto().setSigCertificate(items.get("addXKMSCertFile"));
					break;
				default: break;
			}
		}
		catch (UnsupportedEncodingException uee)
		{
			// no
		}
		Configuration.storeConfiguration();
	}

	private static void applyCRLValMethodProps(IssuerDto issdto, Hashtable<String, byte[]> items)
	{
		try
		{
			String url = new String(items.get("relayCrlDO.url"), WebAdmin.CHARSET);
			issdto.getValMethodCrlDto().setUrl(url);
			issdto.getValMethodCrlDto().setSubType(url.startsWith("http:") ? "HTTP" : "LDAP");
			issdto.getValMethodCrlDto().setSearchbase(new String(items.get("relayCrlDO.searchbase"), WebAdmin.CHARSET));
			issdto.getValMethodCrlDto().setAttribute(new String(items.get("relayCrlDO.attribute"), WebAdmin.CHARSET));
			issdto.getValMethodCrlDto().setIgnoreNextUpdate(new String(items.get("relayCrlDO.ignoreNextUpdate"), WebAdmin.CHARSET).equalsIgnoreCase("true"));
			issdto.getValMethodCrlDto().setInterval(Integer.parseInt(new String(items.get("relayCrlDO.interval"), WebAdmin.CHARSET)));
		}
		catch (UnsupportedEncodingException uee)
		{
			// no
		}
	}

	private static void applyLDAPValMethodProps(IssuerDto issdto, Hashtable<String, byte[]> items)
	{
		try
		{
			issdto.getValMethodLdapDto().setUrl(new String(items.get("relayLdapDO.url"), WebAdmin.CHARSET));
			issdto.getValMethodLdapDto().setAuthenticationType(new String(items.get("relayLdapDO.authenticationType"), WebAdmin.CHARSET));
			issdto.getValMethodLdapDto().setAuthenticationPrincipal(new String(items.get("relayLdapDO.authenticationPrincipal"), WebAdmin.CHARSET));
			issdto.getValMethodLdapDto().setAuthenticationCredentials(new String(items.get("relayLdapDO.authenticationCredentials"), WebAdmin.CHARSET));
			issdto.getValMethodLdapDto().setSearchbase(new String(items.get("relayLdapDO.searchbase"), WebAdmin.CHARSET));
			issdto.getValMethodLdapDto().setFilter(new String(items.get("relayLdapDO.filter"), WebAdmin.CHARSET));
			issdto.getValMethodLdapDto().setAttribute(new String(items.get("relayLdapDO.attribute"), WebAdmin.CHARSET));
		}
		catch (UnsupportedEncodingException uee)
		{
			// no
		}
	}

	public static String getTACertDisplay(String tAName) throws IOException
	{
		return dumpCertificate(Configuration.getTrustedAnchor(tAName).getX509Certificate());
	}

	public static String getIssuerCertDisplay(String issuerName, String certName) throws IOException
	{
		IssuerDto iss = Configuration.getIssuerDto(issuerName);

		return dumpCertificate(Configuration.getIssuerCertificateDto(iss.getName(), certName)
			.getX509Certificate());
	}

	public static String dumpCertificate(X509Certificate cert) throws IOException
	{
		return "<html><head><title>Certificate details</title>"
					+ "<meta http-equiv=\"content-type\" content=\"text/html;charset=iso-8859-1\"/>"
					+ "</head><body><h1>Certificate details for '"
					+ parseCN(cert)
					+ "'</h1><p>"
					+ cert.toString().replace("\n", "<br>")
					+ "</p></body></html>";
	}

	public static void addTA(byte[] cert) throws CertificateEncodingException, Exception
	{
		X509Certificate x509 = ResponderHelper.createCertificate(cert);
		if (x509 == null)
			x509 = ResponderHelper.createCertificate(ResponderHelper.base64decode(new String(cert)));
		String fingerprint = ResponderHelper.getFingerprint(x509);
		if (Configuration.getTrustedAnchor(fingerprint) != null)
			return;

		String name = parseCN(x509);
		HashSet<String> names = new HashSet<String>();
		for (CertificateDto cdto : Configuration.getTrustedAnchorMap().values())
			names.add(cdto.getFriendlyName());
		while (names.contains(name))
			name += "_";
		Configuration.putTrustedAnchor(fingerprint,
				new CertificateDto("", x509, name, false));
		Configuration.storeConfiguration();
	}

	public static String getKeyStoreEntries(byte[] data, byte[] passwd) throws GeneralSecurityException, IOException
	{
		KeyStore ks = KeyStore.getInstance("PKCS12", bc);
		char[] pwd = new char[256];
		InputStreamReader isr = new InputStreamReader(new ByteArrayInputStream(passwd), WebAdmin.CHARSET);
		int len = isr.read(pwd);
		char[] p = new char[len];
		System.arraycopy(pwd, 0, p, 0, len);
		ks.load(new ByteArrayInputStream(data), p);
		for (int i = 0; i < p.length; i++)
		{
			pwd[i] = 0;
			p[i] = 0;
		}

		String entries = "";
		Enumeration<String> e = ks.aliases();
		String alias;
		X509Certificate cert;
		while (e.hasMoreElements())
		{
			alias = e.nextElement();
			if (ks.isKeyEntry(alias))
			{
				cert = (X509Certificate)ks.getCertificate(alias);
				entries += alias + "\t" + parseCN(cert) + "\n";
			}
		}
		return entries;
	}

	public static void deleteTAs(String[] fingerprints) throws Exception
	{
		for (int i = 0; i < fingerprints.length; i++)
			Configuration.removeTrustedAnchor(fingerprints[i]);
		Configuration.storeConfiguration();
	}

	public static String parseCN(X509Certificate cert)
	{
		String cn = ResponderHelper.getSubjectDN(cert);
		String ret = cn.substring(cn.indexOf("CN=") + 3);
		if (ret.indexOf(',') > -1)
			ret = ret.substring(0, ret.indexOf(','));
		return ret;
	}

}
