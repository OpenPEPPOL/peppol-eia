/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.certificatepathvalidator;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidParameterException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DEROctetString;

import eu.peppol.lsp.xkmsresponder.certificatepathvalidator.CertificatePathValidatorProcess.CertifacatevalidatorResultsComparatorByChainPos;
import eu.peppol.lsp.xkmsresponder.certpathbuilder.BuilderParameters;
import eu.peppol.lsp.xkmsresponder.certpathbuilder.CertPath;
import eu.peppol.lsp.xkmsresponder.certpathbuilder.CertPathBuilder;
import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.xkms.TranslationTable;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;

/**
 * Helper class for certificate path validation.
 * @author buengener
 *
 * 
 */

public class CertificatePathValidatorHelper
{
  private static final Logger LOG = Logger.getLogger(CertificatePathValidatorHelper.class.getName());

  /**
   * Gets the extension "dateOfCertGen" out of the certificate
   *
   * @param  cert the certificate, which generation date is required
   * @return Date the Date, when the certificate has created,
   *
   *
   */
  public static Date getDateOfCertGen(X509Certificate cert)
  {
    ASN1InputStream tmpASN1In = null;
    try
    {
      byte[] tmpExtensionValue = cert.getExtensionValue("1.3.36.8.3.1");
      if (tmpExtensionValue != null)
      {
        tmpASN1In = new ASN1InputStream(tmpExtensionValue);
        byte[] data = ((DEROctetString) tmpASN1In.readObject()).getOctets();
        ASN1InputStream dIn = new ASN1InputStream(new ByteArrayInputStream(data));
        return ((DERGeneralizedTime) dIn.readObject()).getDate();
      }
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "Could not read Extension", ex);
    }
    finally
    {
      if (tmpASN1In != null)
      {
        try
        {
          tmpASN1In.close();
        }
        catch (IOException e)
        {
          // Nothing to do here
        }
      }
    }


    return null;
  }

  public static CPVResponse createErrorResponse(CPVRequest req)
  {
    LOG.fine("(start) createErrorResponse(???)");

    CPVResponse resp = new CPVResponse();
    resp.setRequestID(req.getRequestID());

    CertificatevalidatorResult res = null;

    try
    {
      res = new CertificatevalidatorResult(req.getCertificates()[0]);
      res.setValidationTimeQueried(req.getTimeInstance());

      res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);

      boolean tmpValidityIntervall = isCertificateInsideValidityIntervall(res.getCertificate(), req);

      if (tmpValidityIntervall)
      {
        res.addValidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
        resp.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INDETERMINATE));
        res.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
      }
      else
      {
        res.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
        resp.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
        res.setStatus(CertificatevalidatorResult.STATUS_INVALID);
      }

      resp.addCertificateCheckList(res);
      resp.setErrorCode(XKMSConstants.ErrorExtension_UnknownCA);
      LOG.fine("No Chain built. Generating Error-Response !!!");
      LOG.fine("(stop) createErrorResponse(???)");

    }
    catch (IllegalArgumentException ex)
    {
    	LOG.log(Level.SEVERE, "Fehler in createErrorResponse", ex);
    }

    return resp;
  }

  public static boolean isCertificateInsideValidityIntervall(X509Certificate inpCert, CPVRequest inpRequest)
  {
    Date tmpValidateTime = null;

    if (inpRequest.getTimeInstance() == null)
    {
      tmpValidateTime = new Date();
    }
    else
    {
      tmpValidateTime = inpRequest.getTimeInstance().getTime();
    }

    try
    {
      inpCert.checkValidity(tmpValidateTime);

      return true;
    }
    catch (Exception ex)
    {
      return false;
    }
  }


  public static CPVResponse createErrorResponseCertificateNotValid(CPVRequest req)
  {
    LOG.fine("(start) createErrorResponseCertificateNotValid(???)");

    CPVResponse resp = new CPVResponse();
    resp.setRequestID(req.getRequestID());

    CertificatevalidatorResult res = new CertificatevalidatorResult((String)null);
    res.setValidationTimeQueried(req.getTimeInstance());
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
    res.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
    res.setCertificateEncoded(req.getCertificatesBytes().get(0));
    resp.addCertificateCheckList(res);
    resp.setErrorCode(XKMSConstants.ErrorExtension_WrongCertificateFormat);
    resp.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INDETERMINATE));
    LOG.fine("No Chain built. Generating Error-Response !!!");

    return resp;
  }

  public static CPVResponse createErrorResponseSignature(CPVRequest req)
  {
    LOG.fine("(start) createErrorResponseSignature(???");

    CPVResponse resp = new CPVResponse();
    resp.setRequestID(req.getRequestID());

    CertificatevalidatorResult res = null;

    try
    {
      res = new CertificatevalidatorResult(req.getCertificates()[0]);
      res.setValidationTimeQueried(req.getTimeInstance());

      res.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
      res.setStatus(CertificatevalidatorResult.STATUS_INVALID);
      resp.addCertificateCheckList(res);
      resp.setErrorCode(XKMSConstants.ErrorExtension_UnknownCA);
      resp.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INVALID));
      LOG.fine("Signature of Certificate invalid. Generating Error-Response !!!");
    }
    catch (IllegalArgumentException ex)
    {
    	LOG.log(Level.SEVERE, "Fehler in createErrorResponseSignature", ex);
    }

    return resp;
  }

  public static CPVResponse createErrorResponseUserCertificate(CPVRequest req)
  {
    LOG.fine("(start) createErrorResponseUserCertificate(???)");

    CPVResponse resp = new CPVResponse();
    resp.setRequestID(req.getRequestID());

    CertificatevalidatorResult res = new CertificatevalidatorResult((String)null);
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_SIGNATURE);
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_VALIDITYINTERVAL);
    res.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);
    res.setErrorCode(XKMSConstants.ErrorExtension_UnknownCA);
    if (req.getCertificatesBytes().size() != 0)
    {
      res.setCertificateEncoded(req.getCertificatesBytes().get(0));
    }
    res.setCertificate(req.getCertificates()[0]);
    resp.addCertificateCheckList(res);
    resp.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INDETERMINATE));
    LOG.fine("No Chain built. Generating Error-Response !!!");

    return resp;
  }

  /**
   * Sorts all certifcates of the chain back to the right order. The certificates which hve to be cheked is at Position
   * 0. The issuer certificate is at Position 1 an so on.
   *
   * @param inpCertificatevalidatorResults a set of responses from the CertificateValidator, which has made validity-checks for single
   *          certificates
   * @return CPVResponse a response with a set of CertificatesCheckLists inside, which are in the right order
   *
   *
   */
  public static CPVResponse sortResults(List<CertificatevalidatorResult> inpCertificatevalidatorResults)
  {
    LOG.fine("(start) sortResults(???)");

    CPVResponse retCPVResponse = new CPVResponse();

    if ((inpCertificatevalidatorResults == null) || (inpCertificatevalidatorResults.size() == 0))
    {
      retCPVResponse.setErrorCode(XKMSConstants.ErrorExtension_Unknown);
      retCPVResponse.setErrorMessage("No Answers from CV.");

      return retCPVResponse;
    }

    Collections.sort(inpCertificatevalidatorResults,
                     CertifacatevalidatorResultsComparatorByChainPos.getSingleton());

    for (CertificatevalidatorResult tmpCertifacatevalidatorResult : inpCertificatevalidatorResults)
    {
      retCPVResponse.addCertificateCheckList(tmpCertifacatevalidatorResult);
    }

    if (LOG.isLoggable(Level.FINE))
    {
      LOG.fine("Anzahl der CertificateCheckLists in sortResults: "
                + retCPVResponse.getCertificateCheckLists().length);
    }

    return retCPVResponse;
  }

  /**
   * Creates a certpath
   *
   * @param req
   * @return List<CerticateWrapper> all certificates which remain to the certificate Path
   * @throws CertPathBuilderException
   */
  public static List<X509Certificate> buildCertPath(CPVRequest req)
        throws CertificatePathValidatorException
  {
    LOG.fine("(start) buildCertPath(???)");

    List<X509Certificate> certs = null;

    try
    {
      certs = CertificatePathValidatorHelper.getCertPath(req);
    }
    catch (GeneralSecurityException ex)
    {
      LOG.severe("Cannot extract certificates from request" + ex);

      CPVResponse resp =
            (ex instanceof CertificateException) ? CertificatePathValidatorHelper
                                                                                 .createErrorResponseCertificateNotValid(req)
                                                : CertificatePathValidatorHelper.createErrorResponse(req);
      throw new CertificatePathValidatorException(resp);
    }
    catch (CertPathBuilderException ex)
    {
      LOG.severe("Can not create certificatePath " + ex);
      if (ex.getDuplicateUserCert())
      {
        LOG.fine("Duplicate user cert or attribute cert found");
        throw new CertificatePathValidatorException(
                                                    CertificatePathValidatorHelper
                                                                                  .createErrorResponseUserCertificate(req));
      }
      if (!ex.getIllegalSignature())
      {
        throw new CertificatePathValidatorException(CertificatePathValidatorHelper.createErrorResponse(req));
      }

      throw new CertificatePathValidatorException(
                                                  CertificatePathValidatorHelper
                                                                                .createErrorResponseSignature(req));
    }
    catch (InvalidParameterException ex)
    {
      LOG.severe("Invalid parameter in buildCertPath" + ex);
      throw new CertificatePathValidatorException(CertificatePathValidatorHelper.createErrorResponse(req));
    }

    LOG.fine("(stop) buildCertPath(???)");

    return certs;
  }

  /**
   * @return the extracted certificates from the CPVRequest
   *
   */
  public static List<X509Certificate> getCertPath(final CPVRequest req)
        throws GeneralSecurityException, CertPathBuilderException
  {
    LOG.fine("(start) getCertPath(CPVRequest)");

    List<X509Certificate> respcerts = null;

    // das Antwort-Object erzeugen
    CPVResponse resp = new CPVResponse();
    X509Certificate[] certs = req.getCertificates();

    CertPathBuilder certbuilder = null;
    certbuilder = new CertPathBuilder();
    CertPath path = null;

    try
    {
      if ((certs == null) || (certs.length == 0))
      {
        LOG.fine("Certs are null in CertificatePatValidator.getCertPath");
      }
      BuilderParameters params = new BuilderParameters(certs, null);
      path = certbuilder.build(params).getCertPath();
      respcerts = path.getCertificates();

      for (int ti = 0; ti < (respcerts.size() - 1); ti++)
      {
        LOG.fine("Class of cert in getCertPath: " + respcerts.get(ti).getClass().getName());
        X509Certificate checkCert = respcerts.get(ti);

        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("CheckCert Subject: " + checkCert.getSubjectDN().getName());
          LOG.fine("CheckCert Issuer: " + checkCert.getIssuerDN().getName());
        }

        X509Certificate issuerCert = respcerts.get(ti + 1);

        if (LOG.isLoggable(Level.FINE))
        {
          LOG.fine("IssuerCert Subject: " + issuerCert.getSubjectDN().getName());
          LOG.fine("IssuerCert Issuer: " + issuerCert.getIssuerDN().getName());
        }

        try
        {
          checkCert.verify(issuerCert.getPublicKey());
        }
        catch (Exception ex3)
        {
          LOG.fine("SignatureException: " + ex3);
          throw new CertPathBuilderException(resp, true, false);
        }
      }
    }
    catch (java.security.cert.CertPathBuilderException ex)
    {
      LOG.log(Level.FINE, "CertPathBuilderException", ex);
      if (ex.getMessage().equals(CertPathBuilder.ERROR04))
      {
        throw new CertPathBuilderException(resp, false, true);
      }

      throw new CertPathBuilderException(resp, false, false);
    }
    catch (InvalidAlgorithmParameterException ex)
    {
      LOG.log(Level.SEVERE, "Error in CertificatePathValidator.getCertPath(): ", ex);
      throw ex;
    }

    return respcerts;
  }

  public static boolean checkForIndeterminate(CertificatevalidatorResult[] certs)
  {
    LOG.fine("(start) checkForIndterminate(???)");
    CertificatevalidatorResult usercert = certs[0];

    for (int ti = 1; ti < certs.length; ti++)
    {
      CertificatevalidatorResult cacert = certs[ti];
      if (cacert.getIndeterminateReason().size() > 0)
      {
        List<Integer> ir = cacert.getIndeterminateReason();

        if (LOG.isLoggable(Level.FINE))
        {
          for (int ta = 0; ta < ir.size(); ta++)
          {
            LOG.fine("Indeterminate Reason is CertificatePathValidator + #" + ta + " : " + TranslationTable.XKMS_REASON_TABLE.get(ir.get(ta)));
          }
        }
        if (cacert.getErrorCode() != null)
        {
          usercert.setErrorCode(cacert.getErrorCode());
        }
        if (ir.contains(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST)
            || ir.contains(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS))
        {
          usercert.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
          usercert.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
        }
      }
    }
    return (usercert.getIndeterminateReason().size() <= 0);
  }

}
