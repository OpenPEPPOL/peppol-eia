/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.requestcontroller;

import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3._2002._03.xkms.ValidateResultType;

import eu.peppol.lsp.xkmsresponder.certificatepathvalidator.CertificatePathValidatorBean;
import eu.peppol.lsp.xkmsresponder.common.CPVRequest;
import eu.peppol.lsp.xkmsresponder.common.CPVResponse;
import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;
import eu.peppol.lsp.xkmsresponder.webadmin.WebAdmin;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;

/*
 * This class receives the messages form the SOAP entry and
 * activate the process class RequestController
 * @author Ralf Lindemann
 * @author buengener
 * @see eu.peppol.lsp.xkmsresponder.requestcontroller.RequestController
 * 
*/
public class RequestControllerBean
{
  private static final long serialVersionUID = 5624716602070581335L;

  private static final Logger LOG = Logger.getLogger(RequestControllerBean.class.getName());

  public String process(String inpXkmsRequest) throws Exception
  {
    LOG.fine("Request in process.");

    RequestController requestController = null;
    List<CPVRequest> cpvRequests = null;

    requestController = new RequestController();
    LOG.fine("Request-Controller starts.");
    cpvRequests = requestController.getRequests(inpXkmsRequest);

    LOG.fine("count CPVRequests: " + cpvRequests.size());
    Hashtable<String, CPVResponse> errorResponses = new Hashtable<String, CPVResponse>();
    List<XKMSForwarding> xkmsFwds = new ArrayList<XKMSForwarding>();

    CPVRequest tmpCPVRequest = null;

    for (Iterator<CPVRequest> tmpRequestsIterator = cpvRequests.iterator(); tmpRequestsIterator.hasNext();)
    {
    	tmpCPVRequest = tmpRequestsIterator.next();

        try
        {
          tmpCPVRequest.checkCeritificates();
        }
        catch (CertificateException e)
        {
          CPVResponse tmpResponse = createErrorResponseCertificateNotValid(tmpCPVRequest);
          errorResponses.put(tmpCPVRequest.getRequestID(), tmpResponse);
          tmpRequestsIterator.remove();
          continue;
        }

        // check if request contains a certificate, which can not be validated locally

        IssuerDto tmpIssuerDto = null;
        X509Certificate tmpCert = tmpCPVRequest.getCertificates()[0];
        tmpIssuerDto = Configuration.getIssuerDtoByUserCertificate(tmpCert);
        if (tmpIssuerDto == null)
        {
        	LOG.warning("Issuer not found, trying to find XKMS responder by country code !");
        	try
        	{
        		String cc = MessageExtensionHandler.getCountry(tmpCert).value();
        		LOG.fine("Country code found: " + cc);
        		if (!XKMSSignature.getCountryCode().equals(cc)) // prevent forwarding for national issuers to avoid loops
        		{
        			tmpIssuerDto = Configuration.getIssuerDtoPPRS(cc);
        			if (tmpIssuerDto != null)
        				LOG.fine("Issuer for country code found: "+ tmpIssuerDto.getName());
        		}
        	}
        	catch (Exception e)
        	{
        		// No country code
        	}
        }

        if (tmpIssuerDto == null)
        	LOG.warning("Issuer not found !");
        else
        {
        	LOG.fine("Found issuer with name: " + tmpIssuerDto.getName());

        	if (tmpIssuerDto.getValMethod().containsXKMS())
        	{
        		LOG.fine("Forwarding XKMS-Response to another XKMS-Responder");

    			XKMSForwarding tmpForward = new XKMSForwarding(
    					tmpIssuerDto,
    					requestController
    					.getValidateRequestTypeByID(tmpCPVRequest
    							.getRequestID()));
//    					tmpForward.doForwardRequest( ResponderHelper.createCertificate(tmpIssuerDto.getValMethodXkmsDto().getSigCertificate()));
   				xkmsFwds.add(tmpForward);
   				tmpRequestsIterator.remove();
        	}
    	}
    }

    Hashtable<String, CPVResponse> cpvResponses = new Hashtable<String, CPVResponse>();
    Hashtable<String, ValidateResultType> xkmsResponses = new Hashtable<String, ValidateResultType>();

    execute(cpvRequests, xkmsFwds, cpvResponses, xkmsResponses);
    LOG.fine("count CPVresponses: " + cpvResponses.size());
    cpvResponses.putAll(errorResponses);

    // convert the Hashtable with CPVResponse to a Message
    String respMessage = requestController.createResponseMessage(cpvResponses, xkmsResponses);

    return respMessage;
  }

  private void execute(List<CPVRequest> inpRequests, List<XKMSForwarding> xkmsFwds, Hashtable<String, CPVResponse> cpvResponses, Hashtable<String, ValidateResultType> xkmsFwdResponses) throws Exception
  {
    CPVRequest[] cpvRequestMessage = inpRequests.toArray(new CPVRequest[inpRequests.size()]);

    try
    {
      CertificatePathValidatorBean[] cpvs = new CertificatePathValidatorBean[cpvRequestMessage.length];
      LOG.fine("Before sendAndReceive");
      synchronized (cpvRequestMessage)
      {
	      for (int i = 0; i < cpvRequestMessage.length; i++)
	      {
	    	  cpvs[i] = new CertificatePathValidatorBean(cpvRequestMessage, i);
	    	  LOG.fine("Starting thread " + cpvs[i].getName() + " for index " + i);
	    	  cpvs[i].start();
	      }

	      for (int i = 0; i < xkmsFwds.size(); i++)
	      {
	    	  xkmsFwds.get(i).setNotifyObject(cpvRequestMessage);
	    	  LOG.fine("Starting XKMS forward thread " + xkmsFwds.get(i).getName() + " for index " + i);
	    	  xkmsFwds.get(i).start();
	      }

	      CPVResponse rsp;
	      long start = System.currentTimeMillis();
	      while ((cpvResponses.size() < cpvRequestMessage.length
	    		  || xkmsFwdResponses.size() < xkmsFwds.size())
	    		  && (System.currentTimeMillis() - start) < Configuration.VALIDATION_TIMEOUT)
	      {
	    	  cpvRequestMessage.wait(Configuration.VALIDATION_TIMEOUT);
		      for (int i = 0; i < cpvRequestMessage.length; i++)
		      {
		    	  if (cpvResponses.get(cpvRequestMessage[i].getRequestID()) == null)
		    	  {
				      LOG.fine("NOTIFIED from CPV");
		    		  rsp = cpvs[i].getCPVResponse();
		    		  if (rsp != null)
		    			  cpvResponses.put(rsp.getRequestID(), rsp);
		    	  }
		      }

		      for (int i = 0; i < xkmsFwds.size(); i++)
		      {
		    	  XKMSForwarding xf = xkmsFwds.get(i);
		    	  if (xkmsFwdResponses.get(xf.getRequestID()) == null)
		    	  {
		    		  if (xf.getValidateResult() != null)
		    			  xkmsFwdResponses.put(xf.getRequestID(), xf.getValidateResult());
		    	  }
		      }
	      }

      }

      LOG.fine("After sendAndReceive");
    }
    catch (Exception ex1)
    {
      if (LOG.isLoggable(Level.FINE))
        LOG.log(Level.SEVERE, "Error while forwarding Message.", ex1);
    }

    if (LOG.isLoggable(Level.FINE))
      LOG.fine("Count cpvResults: " + cpvResponses.size() + "\n" + "Count xkmsFwdResponses: " + xkmsFwdResponses.size());

  }

  public CPVResponse createErrorResponseCertificateNotValid(CPVRequest req)
  {
    LOG.fine("(start) createErrorResponseCertificateNotValid(???)");

    CPVResponse resp = new CPVResponse();
    resp.setRequestID(req.getRequestID());

    CertificatevalidatorResult res = new CertificatevalidatorResult((String)null);
    res.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    res.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);

    try
    {
      res.setCertificate(req.getCertificates()[0]);
    }
    catch (Exception e)
    {
      res.setCertificateEncoded(req.getCertificatesBytes().get(0));
    }

    resp.addCertificateCheckList(res);
    resp.setErrorCode(XKMSConstants.ErrorExtension_WrongCertificateFormat);
    resp.setResult(Integer.valueOf(CertificatevalidatorResult.STATUS_INDETERMINATE));
    LOG.fine("Certificates in Request not valid. Generating Error-Response !!!");

    return resp;
  }
}
