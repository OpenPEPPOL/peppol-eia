 /*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.xkms;

import java.io.StringReader;
import java.security.SignatureException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;

import org.etsi.uri._02231.v2.TSPServiceInformationType;
import org.w3._2000._09.xmldsig.KeyInfoType;
import org.w3._2000._09.xmldsig.X509DataType;
import org.w3._2002._03.xkms.CompoundRequestType;
import org.w3._2002._03.xkms.CompoundResultType;
import org.w3._2002._03.xkms.LocateRequestType;
import org.w3._2002._03.xkms.LocateResultType;
import org.w3._2002._03.xkms.MessageExtensionAbstractType;
import org.w3._2002._03.xkms.OpaqueClientDataType;
import org.w3._2002._03.xkms.QueryKeyBindingType;
import org.w3._2002._03.xkms.RecoverRequestType;
import org.w3._2002._03.xkms.RecoverResultType;
import org.w3._2002._03.xkms.RegisterRequestType;
import org.w3._2002._03.xkms.RegisterResultType;
import org.w3._2002._03.xkms.ReissueRequestType;
import org.w3._2002._03.xkms.ReissueResultType;
import org.w3._2002._03.xkms.RequestAbstractType;
import org.w3._2002._03.xkms.ResultType;
import org.w3._2002._03.xkms.RevokeRequestType;
import org.w3._2002._03.xkms.RevokeResultType;
import org.w3._2002._03.xkms.UseKeyWithType;
import org.w3._2002._03.xkms.ValidateRequestType;
import org.w3._2002._03.xkms.ValidateResultType;

import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.entry.SimpleSoapServlet;
import eu.peppol.lsp.xkmsresponder.entry.SoapFaultException;
import eu.peppol.lsp.xkmsresponder.requestcontroller.XKMSForwarding;
import eu.peppol.uri.xkmsext.v2.EIDQualityType;
import eu.peppol.uri.xkmsext.v2.ErrorExtensionType;
import eu.peppol.uri.xkmsext.v2.ObjectFactory;
import eu.peppol.uri.xkmsext.v2.RequestingNodeChainType;
import eu.peppol.uri.xkmsext.v2.ResponderDetailsType;
import eu.peppol.uri.xkmsext.v2.ValidateRequestExtEUType;
import eu.peppol.uri.xkmsext.v2.ValidateResultExtEUType;
import eu.peppol.uri.xkmsext.v2.ValidationDetailsType;


/**
 * Handler for processing XKMS content.
 * @author tabrizi
 *
 * 
*/
public class XKMSContentHandler
{

  private String requestString;

  // To do Handling the Result as a Stream
  private RequestAbstractType requestObject = null;

  private CompoundResultType compoundResultObj = null;

  private final Map<String, List<String>> mapRespondWith = new Hashtable<String, List<String>>();

  //
  private final Map<String, List<byte[]>> mapX509Certificate = new Hashtable<String, List<byte[]>>();

  private final Map<String, ValidateResultType> validateResultByRequestId =
        new Hashtable<String, ValidateResultType>();

  private final List<String> validateRequestIDList = new ArrayList<String>();

  private List<ValidateRequestType> validateRequestObjects = new ArrayList<ValidateRequestType>();

  private final Map<String, GregorianCalendar> timeInstanceByRequestId =
        new Hashtable<String, GregorianCalendar>();

  //
  private final Map<String, List<String>> mapKeyUsage = new Hashtable<String, List<String>>();

  //
  private final Map<String, List<UseKeyWithType>> mapUseKeyWith =
        new Hashtable<String, List<UseKeyWithType>>();

  private final Map<String, RequestingNodeChainType> mapEUData = new Hashtable<String, RequestingNodeChainType>();

  private boolean compoundRequest = false;

  private final Stack<List<String>> respondWithStack = new Stack<List<String>>();

  private static Logger LOG = Logger.getLogger(XKMSContentHandler.class.getName());

  /**
   * Creates a new XKMSContentHandler object.
   *
   * @param pInputStream DOCUMENT ME!
   */
  public XKMSContentHandler(String in) throws SoapFaultException
  {
    try
    {
      LOG.fine("(start) XKMSContentHandler EU");
      requestString = in;
      XKMSContextHolder tmpXKMSContextHolder = XKMSContextHolder.getSingleton();
      Unmarshaller tmpUnmarshaller = tmpXKMSContextHolder.getUnmarshaller();
      Object tmpUnmarshal = null;
      try
      {
        tmpUnmarshal = tmpUnmarshaller.unmarshal(new StringReader(requestString));
      }
      finally
      {
        tmpXKMSContextHolder.recycle(tmpUnmarshaller);
      }

      @SuppressWarnings("unchecked")
      JAXBElement<RequestAbstractType> tmpJAXBElement = (JAXBElement<RequestAbstractType>) tmpUnmarshal;

      RequestAbstractType reqOb = tmpJAXBElement.getValue();

      doMessageProcessing(reqOb);
      LOG.fine("(stop) XKMSContentHandler EU");

    }
    catch (Exception e)
    {
      LOG.log(Level.SEVERE, "Error in Constructor while parsing Request: ", e);
      throw new SoapFaultException(SimpleSoapServlet.SOAP_FAULT_CODE_SENDER, "Unsupported message: " + e.getMessage());
    }
  }

  /**
   * Return true if the request is Compound Type
   */
  public boolean isCompoundRequest()
  {
    return compoundRequest;
  }

  /**
   * Returns a List which contains with all RequestIDs of ValidateRequests obtain from incoming message
   */
  public List<String> getValidateRequestIDs()
  {
    return validateRequestIDList;
  }

  /**
   * Creates a XKMSRequestValidator Object
   *
   * @return XKMSRequestValidator
   */
  public XKMSRequestValidator createXKMSRequestValidator()
  {
    return new XKMSRequestValidator();
  }

  /**
   * Returns the Map of X509Certificate Lists of all ValidateRequests
   *
   * @return Map
  public Map<String, List<byte[]>> getX509Certificates()
  {
    return mapX509Certificate;
  }
   */
  /**
   * Returns a List of X509Certificates for this Request Id
   *
   * @param pRequestId the Id of the Request Object
   * @return List
   */
  public List<byte[]> getX509CertificatesByRequestId(String pRequestId)
  {
    List<byte[]> arl = null;

    try
    {
      if (mapX509Certificate.size() > 0)
      {
        arl = mapX509Certificate.get(pRequestId);
      }

      return arl;
    }
    catch (Exception e)
    {
      return null;
    }
  }

  /**
   * Extracts X509Certificates and stores them to the Map
   *
   * @param pX509Data X509DataType
   * @param pId String
   * @return boolean false if this process failed
   */
  protected boolean extractX509Data(X509DataType pX509Data, String pId)
  {
    ArrayList<byte[]> cert = new ArrayList<byte[]>();

    try
    {
      for (Object tmpElement : pX509Data.getX509IssuerSerialOrX509SKIOrX509SubjectName())
      {
        @SuppressWarnings("unchecked")
        JAXBElement tmpJAXBElement = (JAXBElement) tmpElement;
        Object entry = tmpJAXBElement.getValue();

        if (entry != null && tmpJAXBElement.getName().getLocalPart().equals("X509Certificate"))
        {
          cert.add((byte[])entry);
        }
      }

      if (!cert.isEmpty())
      {
        mapX509Certificate.put(pId, cert);
      }

      return true;
    }
    catch (Exception e)
    {
      LOG.log(Level.SEVERE, "Error during the extracting of X509Data: ", e);

      return false;
    }
  }

  public static RequestingNodeChainType extractRequestingNodeChain(ValidateRequestType vrt)
  {
	    List<JAXBElement<? extends MessageExtensionAbstractType>> meatList = vrt.getMessageExtension();
	    for (JAXBElement<? extends MessageExtensionAbstractType> meat : meatList)
	    {
	    	if (meat.getValue() instanceof ValidateRequestExtEUType)
	    		return ((ValidateRequestExtEUType)meat.getValue()).getRequestingNodeChain();
	    }
	    return null;
  }


  /**
   * Extracts the X509DataType from the KeyInfo element
   *
   * @param pKeyInfo KeyInfo
   * @return List
   */
  protected List<Object> extractKeyInfo(KeyInfoType pKeyInfo)
  {
    List<Object> list = new ArrayList<Object>();

    // boolean passed = true;
    try
    {
      @SuppressWarnings("unchecked")
      List contentList = pKeyInfo.getContent();

      if ((contentList != null) && (contentList.size() > 0))
      {
        for (int i = 0; i < contentList.size(); i++)
        {
          @SuppressWarnings("unchecked")
          JAXBElement tmpJAXBElement = (JAXBElement) contentList.get(i);
          Object content = tmpJAXBElement.getValue();

          if (content instanceof X509DataType)
          {
            list.add(content);

            break;
          }
        }
      }

      return list;
    }
    catch (Exception e)
    {
      LOG.severe("Error during the exctracting KeyInfo: " + e);

      return null;
    }
  }


  /**
   * Returns the parsed RequestObject
   *
   * @return RequestAbstractType
   */
  public RequestAbstractType getRequestObject()
  {
    return requestObject;
  }

  /**
   * Returns a Map of all ValidateResults
   *
   * @return Map
   */
  public Map<String, ValidateResultType> getValidateResultObjects()
  {
    return validateResultByRequestId;
  }

  /**
   * Returns a List of all KeyUsage for this RequestId
   *
   * @param pRequestId String
   * @return List
   */
  public List<String> getKeyUsageByRequestId(String pRequestId)
  {
    try
    {
      return mapKeyUsage.get(pRequestId);
    }
    catch (Exception e)
    {
      return null;
    }
  }

  /**
   * Returns the EUData Object for this Request
   *
   * @param pRequestId String
   * @return EUDataType
   */
  public RequestingNodeChainType getEUDataByRequestId(String pRequestId)
  {
    try
    {
      return mapEUData.get(pRequestId);
    }
    catch (Exception e)
    {
      return null;
    }
  }

  /**
   * DOCUMENT ME!
   *
   * @param pRequestId DOCUMENT ME!
   * @return DOCUMENT ME! public boolean getOCSPNoCache(String pRequestId) { try { return
   *         getEUDataByRequestId(pRequestId).getEURequest().isOCSPNoCache().booleanValue(); } catch
   *         (Exception ex) { return false; } }
   */
  /**
   * Returns the ValidateResult Object for this RequestID
   *
   * @param pRequestId String
   * @return ValidateResultTyp
   */
  public ValidateResultType getValidateResultObjectByRequestId(String pRequestId)
  {
    try
    {
      return validateResultByRequestId.get(pRequestId);
    }
    catch (Exception e)
    {
      return null;
    }
  }

  /**
   * Returns the ValidateResult Object for this RequestID
   *
   * @param pRequestId String
   * @return ValidateResultTyp
   */
  public static ValidateResultExtEUType getValidateResultExtEU(ValidateResultType vrt)
  {
    try
    {
      List<JAXBElement<? extends MessageExtensionAbstractType>> list = vrt.getMessageExtension();
      for ( JAXBElement<? extends MessageExtensionAbstractType> element : list )
      {
        if (element.getValue() instanceof ValidateResultExtEUType)
          return (ValidateResultExtEUType)element.getValue();
      }
      return null;
    }
    catch (Exception e)
    {
      return null;
    }
  }

  /**
   * Returns the CompoundResult Object
   *
   * @return CompoundResultType
   */
  public CompoundResultType getCompoundResult()
  {
    return compoundResultObj;
  }

  /**
   * Creates a suitable ResultType Object
   *
   * @param pRequestAbstractType RequestAbstractType
   * @param pResultMajor QName
   * @param pResultMinor QName
   * @return ResultType
   */
  protected ResultType createResultObject(RequestAbstractType pRequestAbstractType, String pResultMajor,
                                          String pResultMinor)
  {
    String strId = XKMSResponseHelper.getMessageId();
    String requestId = pRequestAbstractType.getId();
    OpaqueClientDataType dOpaqueClientData = pRequestAbstractType.getOpaqueClientData();
    ResultType dummyRT = null;

    if (pRequestAbstractType instanceof CompoundRequestType)
    {
      dummyRT = new CompoundResultType();
    }
    else
    {
      if (pRequestAbstractType instanceof ValidateRequestType)
      {
        dummyRT = new ValidateResultType();
      }

      if (pRequestAbstractType instanceof LocateRequestType)
      {
        dummyRT = new LocateResultType();
      }

      if (pRequestAbstractType instanceof RegisterRequestType)
      {
        dummyRT = new RegisterResultType();
      }

      if (pRequestAbstractType instanceof ReissueRequestType)
      {
        dummyRT = new ReissueResultType();
      }

      if (pRequestAbstractType instanceof RecoverRequestType)
      {
        dummyRT = new RecoverResultType();
      }

      if (pRequestAbstractType instanceof RevokeRequestType)
      {
        dummyRT = new RevokeResultType();
      }
    }

    if (dummyRT != null)
    {
      dummyRT.setId(strId);
      dummyRT.setResultMajor(pResultMajor);

      if (pResultMinor != null)
      {
        dummyRT.setResultMinor(pResultMinor);
      }

      // takes over the OpaqueClientData from RequestObject
      if (dOpaqueClientData != null)
      {
        dummyRT.setOpaqueClientData(dOpaqueClientData);
      }

      dummyRT.setService(XKMSConstants.XKMS_ATTRIBUTE_Service);
      dummyRT.setRequestId(requestId);
    }

    return dummyRT;
  }

  /**
   * <p>
   * Extracting and storing of: - Timeinstances - X509Certificates - KeyUsage - UseKeyWith
   * </p>
   *
   * @param pRequestAbstractType RequestAbstractType
   * @return boolean false if this process failed
   */
  protected boolean extractQueryKeyBinding(RequestAbstractType pRequestAbstractType)
  {
    boolean passed = true;

    try
    {
      if (pRequestAbstractType instanceof ValidateRequestType)
      {
        ValidateRequestType vreq = (ValidateRequestType) pRequestAbstractType;

        // TimeInstance
        passed = setTimeInstance(vreq);

        if (passed)
        {
          QueryKeyBindingType qkb = vreq.getQueryKeyBinding();

          if (qkb != null)
          {
            // KeyInfo
            if (qkb.getKeyInfo() != null)
            {
              List<Object> dlist = extractKeyInfo(vreq.getQueryKeyBinding().getKeyInfo());

              if ((dlist != null) && !dlist.isEmpty())
              {
                for (int i = 0; i < dlist.size(); i++)
                {
                  Object content = dlist.get(i);

                  if (content instanceof X509DataType)
                  {
                    // X509Certificates
                    passed = extractX509Data((X509DataType) content, vreq.getId());

                    break;
                  }
                }
              }
            }

            if (passed)
            {
              // KeyUsage
              if (!qkb.getKeyUsage().isEmpty())
              {
                // log.info("Keyusage");
                mapKeyUsage.put(vreq.getId(), qkb.getKeyUsage());
              }

              // UseKeyWith
              if (!qkb.getUseKeyWith().isEmpty())
              {
                mapUseKeyWith.put(vreq.getId(), qkb.getUseKeyWith());
              }
            }
          }
        }
      }

      if (!passed)
      {
        LOG.severe("Error exctracting of QueryKeyBinding");
      }

      return passed;
    }
    catch (Exception e)
    {
      LOG.severe("Error exctracting of QueryKeyBinding: " + e);

      return false;
    }
  }

  /**
   * <p>
   * Extracting and dispatching of: - RespondWith - QueryKeyBinding - MessageExtension - EUData
   * </p>
   *
   * @param pRequestAbstractType RequestAbstractTyp
   * @return boolean
   */
  protected boolean extractRequestAbstractType(RequestAbstractType pRequestAbstractType)
  {
    boolean passed = true;

    try
    {
      if (pRequestAbstractType instanceof CompoundRequestType)
      {
        respondWithStack.push(((CompoundRequestType)pRequestAbstractType).getRespondWith());
        // this.compoundResultObj = (CompoundResultType) pRequestAbstractType;
      }
      else
      {
        if (pRequestAbstractType instanceof ValidateRequestType)
        {
          List<String> rwlist = null;

          if (!respondWithStack.isEmpty())
          {
            rwlist = respondWithStack.peek();
          }

          passed = setRespondWith(rwlist, pRequestAbstractType);

          if (passed)
          {
            passed = extractQueryKeyBinding(pRequestAbstractType);

            if (passed)
            {
              // EUData
              if (!pRequestAbstractType.getMessageExtension().isEmpty())
              {
                ValidateRequestType tmpValidateRequestType = (ValidateRequestType)pRequestAbstractType;
                List extList = tmpValidateRequestType.getMessageExtension();
                for ( Object o : extList )
                {
                  MessageExtensionAbstractType meat = ((JAXBElement<MessageExtensionAbstractType>)o).getValue();
                  if (o instanceof RequestingNodeChainType)
                    mapEUData.put(pRequestAbstractType.getId(), (RequestingNodeChainType)meat);
                }
              }
            }
          }
        }
      }

      if (!passed)
      {
        LOG.severe("Error during the Exctracting of RequestAbstractType");
      }

      return passed;
    }
    catch (Exception e)
    {
      LOG.severe("Error during the Exctracting of RequestAbstractType: " + e);

      return false;
    }
  }

  /**
   * <p>
   * This method processes the incoming Request as follow: - XML Schema Validation Check - XKMS requeset
   * Validation - Keeping the RequestObject for further treatments "getRequestObject" - The investigation of
   * the included Request Types - Extracting of Request informations for further needs "by getter methods" -
   * Creating of suitable Result Type Object. - extract Information from ValidateRequest for further needs
   * </p>
   *
   * @param pRequestAbstractType RequestAbstractType
   * @throws Exception
   */
  protected void doMessageProcessing(RequestAbstractType pRequestAbstractType) throws Exception
  {
    String minorResult;
    String majorResult;

      // -------XML Schema Validation Check-----
      // TODO: find other way to validate
      // jaxbContext.createValidator().validateRoot(pRequestAbstractType);
      // -------XKMS Requset Validation-----
      createXKMSRequestValidator().assertResponderCompliance(pRequestAbstractType);
      // keep the RequestObject for further needs
      requestObject = pRequestAbstractType;

      // looking for CompoundRequest Type
      if (pRequestAbstractType instanceof CompoundRequestType)
      {
        // extract CompoundRequest
        extractRequestAbstractType(pRequestAbstractType);

        // extract ResponseMechnism
        if (!pRequestAbstractType.getResponseMechanism().isEmpty())
        {
          minorResult = XKMSConstants.XKMS_RESULT_MINOR_MessageNotSupported;
          majorResult = XKMSConstants.XKMS_RESULT_MAJOR_Success;
        }
        else
        {
          minorResult = null;
          majorResult = XKMSConstants.XKMS_RESULT_MAJOR_Success;
        }

        // create a result type for this request
        compoundResultObj = (CompoundResultType)createResultObject(pRequestAbstractType,
                                                                   majorResult,
                                                                   minorResult);
        compoundRequest = true;

        // searching for included validate requests in CompoundRequest
        List<RequestAbstractType> dVRList = ((CompoundRequestType)pRequestAbstractType).getLocateRequestOrValidateRequestOrRegisterRequest();
        LOG.severe("count RequstObjects in doMessageProcessing: " + dVRList.size());
        if (!dVRList.isEmpty())
        {
          for ( int i = 0 ; i < dVRList.size() ; i++ )
          {
            prepareValidateResult((ValidateRequestType)dVRList.get(i));
          }
        }
      }
      else
      {
        LOG.fine("Add ValidateRequest");
        prepareValidateResult((ValidateRequestType)pRequestAbstractType);
      }
  }

  private void prepareValidateResult(ValidateRequestType vreq) throws Exception
  {
	  String minorResult;
	  String majorResult;

      validateRequestObjects.add(vreq);

      // Add the RequestID of this Request Type to the List
      // this.ValidateRequestIDList.add(vreq.getId());
      // extract Information from ValidateRequest for further needs
      extractRequestAbstractType(vreq);
      // Add the RequestID of this Request Type to the List
      validateRequestIDList.add(vreq.getId());

      // extract ResponseMechnism
      if (!vreq.getResponseMechanism().isEmpty())
      {
        minorResult = XKMSConstants.XKMS_RESULT_MINOR_MessageNotSupported;
        majorResult = XKMSConstants.XKMS_RESULT_MAJOR_Success;
      }
      else
      {
        minorResult = null;
        majorResult = XKMSConstants.XKMS_RESULT_MAJOR_Success;
      }

      // Create A ValidateResult Object
      ValidateResultType vres = (ValidateResultType)createResultObject(vreq, majorResult, minorResult);

      vres.setService(Configuration.service);

      XKMSForwarding.checkSignature(requestString, null, Configuration.acceptTAmessagesOnly);

      if (vreq.getRespondWith().contains(XKMSConstants.XKMS_RESPONDWITH_EU_EXTENSION))
      {
          ValidateResultExtEUType vrelt = new ValidateResultExtEUType();

          List<String> unknownRspWiths = XKMSRequestValidator.checkRespondWith(vreq);
          for (String urw : unknownRspWiths)
          {
            ErrorExtensionType tmpErrorExt = new ErrorExtensionType();
            tmpErrorExt.setReason(XKMSConstants.ERROR_EXTENSION_NOT_UNDERSTOOD);
            tmpErrorExt.setDetail(urw);
            vrelt.getErrorExtension().add(tmpErrorExt);
          }

          // Empty EIDQual object, will be filled at the end of processing
          if (vreq.getRespondWith().contains(XKMSConstants.XKMS_RESPONDWITH_EIDQUALITY))
            vrelt.setEIDQuality(new  EIDQualityType());

          // Empty TSPServiceInformationType object, will be replaced at the end of processing
          if (vreq.getRespondWith().contains(XKMSConstants.XKMS_RESPONDWITH_SERVICE_INFORMATION))
          {
            vrelt.setServiceInformation(new TSPServiceInformationType());
          }

          // Empty ValDetail object, will be filled at the end of processing
          if (vreq.getRespondWith().contains(XKMSConstants.XKMS_RESPONDWITH_VALIDATION_DETAILS))
            vrelt.setValidationDetails(new ValidationDetailsType());

          ResponderDetailsType rdt = new ResponderDetailsType();
          vrelt.getResponderDetails().add(rdt);

          // When forwarding, the spec prohibits changes of the returned
          // result. This leads to some strange handling.
          // Add a ResponderDetails with ChainingTo-attribute only for every node,
          // except for the first instance
          RequestingNodeChainType rnct = extractRequestingNodeChain(vreq);
          if (rnct != null && rnct.getRequestingNode().size() > 0)
          {
          	List<String> chain = rnct.getRequestingNode();
          	if (chain.size() > 1)
	            	for (int i=1; i<chain.size(); i++)
	            	{
	            		rdt = new ResponderDetailsType();
	            		rdt.setChainingTo(chain.get(i));
	            		vrelt.getResponderDetails().add(rdt);
	            	}
          	// add this instance, the last in chain has forwarded here
      		rdt = new ResponderDetailsType();
      		rdt.setChainingTo(Configuration.service);
      		vrelt.getResponderDetails().add(rdt);
          }

          vres.getMessageExtension().add(new ObjectFactory().createValidateResultExtEU(vrelt));
      }

      // Put the ValidateResult to the mapValidateResults
      validateResultByRequestId.put(vreq.getId(), vres);

  }

  public List<ValidateRequestType> getRequestObjects()
  {
    return validateRequestObjects;
  }


  public void setRequestObjects(List<ValidateRequestType> requestObjects)
  {
    this.validateRequestObjects = requestObjects;
  }

  /**
   * Stores the Timeinstance for this ValidateRequest to a Map
   *
   * @param pValidateRequest ValidateRequest
   * @return false if this process failed
   */
  protected boolean setTimeInstance(ValidateRequestType pValidateRequest)
  {
    GregorianCalendar time = null;
    boolean passed = true;

    try
    {
      if (pValidateRequest != null)
      {
        if ((pValidateRequest.getQueryKeyBinding() != null)
            && (pValidateRequest.getQueryKeyBinding().getTimeInstant() != null))
        {
          time = pValidateRequest.getQueryKeyBinding().getTimeInstant().getTime().toGregorianCalendar();

          if (LOG.isLoggable(Level.FINE))
          {
            LOG.fine("Time in setTimeInstance:" + time.getTime());
          }

          timeInstanceByRequestId.put(pValidateRequest.getId(), time);
        }
      }

      return passed;
    }
    catch (Exception e)
    {
      LOG.severe("Error while setting TimeInstance: " + e);

      return false;
    }
  }

  /**
   * Returns a map of all Timeinstances for all ValidateRequests. Each included Timeinstance is a Calendar
   *
   * @return Map
  public Map<String, GregorianCalendar> getTimeInstances()
  {
    return timeInstanceByRequestId;
  }
  */
  /* Returns the Timeinstance for this RequestId
  *
  * @param pRequestId String
  * @return Calendar
  */
  public GregorianCalendar getTimeInstanceByRequestId(String pRequestId)
  {
    try
    {
      GregorianCalendar cal = null;

      if (timeInstanceByRequestId.size() > 0)
      {
        cal = timeInstanceByRequestId.get(pRequestId);
      }

      return cal;
    }
    catch (Exception e)
    {
      LOG.severe("NO TimeInstances FOUND: " + e);

      return null;
    }
  }

  /**
   * Stores the RespondWith to a Map
   *
   * @param pRespondWithfromCompound List
   * @param pRequestAbstractType RequestAbstractType
   * @return boolean false if this process failed
    */
  protected boolean setRespondWith(List<String> pRespondWithfromCompound,
                                   RequestAbstractType pRequestAbstractType)
  {
    ArrayList<String> ar = new ArrayList<String>();
    boolean passed = true;

    try
    {
      if (pRespondWithfromCompound != null)
      {
        if (!pRespondWithfromCompound.isEmpty())
        {
          ar.addAll(pRespondWithfromCompound);
        }
      }

      if (pRequestAbstractType.getRespondWith().size() > 0)
      {
        ar.addAll(pRequestAbstractType.getRespondWith());
      }

      mapRespondWith.put(pRequestAbstractType.getId(), ar);

      return passed;
    }
    catch (Exception e)
    {
      LOG.severe("Error while setting RespondWith: " + e);

      return false;
    }
  }


  /**
   * A Map of all RespondWith lists for all ValidateRequests
   *
   * @return Map
  public Map<String, List<QName>> getAllRespondWith()
  {
    return mapRespondWith;
  }
   */
  /**
   * Returns a list of RespondWiths for this RequestId
   *
   * @param pRequestId String
   * @return List
   * */
  public List<String> getRespondWithByRequestId(String pRequestId)
  {
    List<String> arl = null;

    try
    {
      if (mapRespondWith.size() > 0)
      {
        arl = mapRespondWith.get(pRequestId);
      }

      return arl;
    }
    catch (Exception e)
    {
      LOG.severe("NO RespondWith FOUND: " + e);

      return null;
    }
  }

}
