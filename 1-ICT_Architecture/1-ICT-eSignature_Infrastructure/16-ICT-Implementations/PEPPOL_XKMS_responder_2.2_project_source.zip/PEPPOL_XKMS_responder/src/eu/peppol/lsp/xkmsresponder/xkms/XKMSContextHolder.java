/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.xkms;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;

import com.sun.xml.bind.IDResolver;

/**
 * Holder for JAXBContext obejcts, see {@link AbstractJaxbContextHolder}
 * @author an
 *
 * 
*/
public class XKMSContextHolder extends AbstractJaxbContextHolder
{
  private static Logger LOG = Logger.getLogger(XKMSContextHolder.class.getName());

  private static XKMSContextHolder sSingleton = null;

  private static Schema schema = null;

  static
  {
    schema = null;
    SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
    Source[] schemaSources = new Source[]{
            new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/xml.xsd")),
            new StreamSource(XKMSContentHandler.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/xmldsig-core-schema.xsd")),
            new StreamSource(XKMSContentHandler.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/xenc-schema.xsd")),
            new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/xkms.xsd")),
            new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/ts_102231v030102_xsd.xsd")),
            new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/ISOCountryCodeType-V2006.xsd")),
            new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/XKMSExtensions_EU_LSP.xsd")),
            new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/DSSC_draft.xsd")),
            new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/XAdES132.xsd"))};
    try
    {
      schema = sf.newSchema(schemaSources);
    }
    catch (SAXException e)
    {
      LOG.log(Level.SEVERE, "cannot create schema", e);
    }
  }

  /**
   * This is how you obtain an instance of this class. Having this
   * method will enable us to implement some caching here if needed.
   * @param _contextPath context path to create the JAXB context for
   * @throws JAXBException
   */
  public static XKMSContextHolder getSingleton() throws JAXBException
  {
    if (sSingleton == null)
    {
      sSingleton = new XKMSContextHolder();
    }
    return sSingleton;
  }

  /**
   * You have to call {@link #getSingleton()} to get an instance
   * @param classLoader
   * @throws JAXBException
   */
  private XKMSContextHolder() throws JAXBException
  {
	    super("org.w3._2002._03.xkms:eu.peppol.uri.xkmsext.v2:org.etsi.uri._01903.v1_3:org.etsi.uri._02231.v2",
	            XKMSContextHolder.class.getClassLoader());
  }

  @Override
  protected Marshaller createMarshaller() throws JAXBException
  {
    Marshaller tmpMarshaller = context.createMarshaller();
    tmpMarshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapperImpl());
    tmpMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.FALSE);
    tmpMarshaller.setSchema(schema);
    return tmpMarshaller;
  }

  @Override
  protected Unmarshaller createUnmarshaller() throws JAXBException
  {
    Unmarshaller retUnmarshaller = null;
    try
    {
      retUnmarshaller = context.createUnmarshaller();
      retUnmarshaller.setSchema(schema);
      retUnmarshaller.setProperty(IDResolver.class.getName(), new IDResolverPEPPOL());
    }
    catch (Exception ex)
    {
      LOG.log(Level.SEVERE, "cannot create unmarshaller", ex);
    }
    return retUnmarshaller;
  }

}
