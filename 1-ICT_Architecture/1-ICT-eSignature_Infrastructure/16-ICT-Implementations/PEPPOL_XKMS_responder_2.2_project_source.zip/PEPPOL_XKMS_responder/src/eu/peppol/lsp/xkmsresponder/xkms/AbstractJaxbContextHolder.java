/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.xkms;

import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 * Caches for a JAXB context and some marshaller/unmarshaller instances.
 * All cached objects are held by weak references so there is no danger of
 * using too much memory if this class is used too enthusiastically.
 * @author an, with inspirations from tt
 *
 * 
 */
public abstract class AbstractJaxbContextHolder
{
  protected final String contextPath;

  protected JAXBContext context;

  private List<SoftReference<Marshaller>> marshallers = new ArrayList<SoftReference<Marshaller>>();

  private List<SoftReference<Unmarshaller>> unmarshallers = new ArrayList<SoftReference<Unmarshaller>>();

  /**
   * Implementing classes might want to define some getInstance methods
   * instead of providing a public constructor.
   * @param _contextPath
   * @param classLoader
   * @throws JAXBException
   */
  protected AbstractJaxbContextHolder(String _contextPath, ClassLoader classLoader) throws JAXBException
  {
    contextPath = _contextPath;
    context = JAXBContext.newInstance(contextPath, classLoader);
  }

  protected abstract Marshaller createMarshaller() throws JAXBException;

  /**
   * Return a Marshaller object for the current context.
   * After using it, you should give it back by calling {@link #recycle(Marshaller)}
   * @throws JAXBException
   */
  public Marshaller getMarshaller() throws JAXBException
  {
    synchronized (marshallers)
    {
      while (!marshallers.isEmpty())
      {
        SoftReference<Marshaller> ref = marshallers.remove(0);
        if (ref.get() != null)
        {
          return ref.get();
        }
      }
    }
    return createMarshaller();
  }

  /**
   * Give a Marshaller object back to be re-used later.
   */
  public void recycle(Marshaller marshaller)
  {
    synchronized (marshallers)
    {
      SoftReference<Marshaller> ref = new SoftReference<Marshaller>(marshaller);
      marshallers.add(ref);
    }
  }

  /**
   * Return an Unmarshaller matching the JAXB context managed by this object.
   * This method is kept abstract to allow setting some attributes on all used
   * Unmarshaller objects.
   * @throws JAXBException
   */
  protected abstract Unmarshaller createUnmarshaller() throws JAXBException;

  public Unmarshaller getUnmarshaller() throws JAXBException
  {
    synchronized (unmarshallers)
    {
      while (!unmarshallers.isEmpty())
      {
        SoftReference<Unmarshaller> ref = unmarshallers.remove(0);
        if (ref.get() != null)
        {
          return ref.get();
        }
      }
    }
    return createUnmarshaller();
  }

  /**
   * Give an UnMarshaller object back to be re-used later.
   */
  public void recycle(Unmarshaller unmarshaller)
  {
    synchronized (unmarshallers)
    {
      SoftReference<Unmarshaller> ref = new SoftReference<Unmarshaller>(unmarshaller);
      unmarshallers.add(ref);
    }
  }

}
