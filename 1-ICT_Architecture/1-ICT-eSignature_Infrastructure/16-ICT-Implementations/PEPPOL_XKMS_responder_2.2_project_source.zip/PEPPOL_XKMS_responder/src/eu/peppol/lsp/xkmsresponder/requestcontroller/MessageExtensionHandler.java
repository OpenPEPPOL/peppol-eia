/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.requestcontroller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.etsi.uri._02231.v2.AnyType;
import org.etsi.uri._02231.v2.DigitalIdentityType;
import org.etsi.uri._02231.v2.NonEmptyURIListType;
import org.etsi.uri._02231.v2.OtherTSLPointerType;
import org.etsi.uri._02231.v2.TSPInformationType;
import org.etsi.uri._02231.v2.TSPServiceInformationType;
import org.etsi.uri._02231.v2.TSPServiceType;
import org.etsi.uri._02231.v2.TSPType;
import org.etsi.uri._02231.v2.TrustStatusListType;
import org.tm_xml.xmlschema.common.ISOCountryCodeType;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvOCSPResult;
import eu.peppol.lsp.xkmsresponder.common.ResponderHelper;
import eu.peppol.lsp.xkmsresponder.configuration.Configuration;
import eu.peppol.lsp.xkmsresponder.configuration.dto.CertificateDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ResponderTransport;
import eu.peppol.lsp.xkmsresponder.webadmin.WebAdmin;
import eu.peppol.lsp.xkmsresponder.xkms.TranslationTable;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSConstants;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSContentHandler;
import eu.peppol.lsp.xkmsresponder.xkms.XKMSContextHolder;
import eu.peppol.uri.xkmsext.v2.CertificateRevocationDetails;
import eu.peppol.uri.xkmsext.v2.ErrorExtensionType;
import eu.peppol.uri.xkmsext.v2.ResponderDetailsType;
import eu.peppol.uri.xkmsext.v2.ValidateResultExtEUType;
import eu.peppol.uri.xkmsext.v2.ValidationDetailsType;

/**
 * Helper class for processing message extensions.
 * @author buengener
 *
 * 
*/
public class MessageExtensionHandler
{
  private static Logger LOG = Logger.getLogger(MessageExtensionHandler.class.getName());

  private static final Hashtable<String, TSPInformationType> TSL_INF_TYPES = new Hashtable<String, TSPInformationType>();

  public static Hashtable<String, IssuerDto> loadPPRS_TSL()
  {
	  Hashtable<String, IssuerDto> ret = new Hashtable<String, IssuerDto>();

	  try
	  {
		  if (System.getProperty("peppol.xkmsresponder.pprs.url") == null)
		  {
			  LOG.warning("No URL for PPRS download specified in SysProp 'peppol.xkmsresponder.pprs.url', no PPRS support available !");
			  return ret;
		  }

		  Unmarshaller unmarshal = getUnmarshaller();

		  byte[] pprs_bytes = ResponderTransport.sendHTTPRequest(System.getProperty("peppol.xkmsresponder.pprs.url"), null, null);
		  XKMSForwarding.checkSignature(new InputSource(
				  new ByteArrayInputStream(pprs_bytes)), null, true); // PPRS signature certificate must be TA
		  JAXBElement<TrustStatusListType> trustStatusList =
			  (JAXBElement<TrustStatusListType>)unmarshal.unmarshal(
					  new InputSource(new ByteArrayInputStream(pprs_bytes)));
		  String countryCode = "";
		  String url = "";
		  List<TSPType> tspList = trustStatusList.getValue().getTrustServiceProviderList().getTrustServiceProvider();
		  for (TSPType tspType : tspList)
		  {
			  TSPInformationType tspInfo = tspType.getTSPInformation();
			  countryCode = tspInfo.getTSPName().getName().get(0).getValue();
			  countryCode = countryCode.substring(0, countryCode.indexOf(':'));
			  TSPServiceType tspService = tspType.getTSPServices().getTSPService().get(0);
			  url = tspService.getServiceInformation().getServiceSupplyPoints().getServiceSupplyPoint().get(0);
			  byte[] cert = tspService.getServiceInformation().getServiceDigitalIdentity().getDigitalId().get(0).getX509Certificate();
			  IssuerDto issdto = new IssuerDto(countryCode);
			  issdto.setValMethod(ValMethodType.XKMS);
			  issdto.getValMethodXkmsDto().setUrl(url);
			  issdto.getValMethodXkmsDto().setSigCertificate(cert);
			  ret.put(countryCode, issdto);
		  }
	  }
	  catch (Throwable t)
	  {
		  LOG.log(Level.SEVERE, "Failed to parse PPRS-TSLs.", t);
	  }

//	  System.err.println(ret);
	  return ret;
  }

  public static void loadTSLs()
  {
	  try
	  {
		  File tslDir = new File(Configuration.CONF_DIR + "/tsl");
		  if (!tslDir.exists() || !tslDir.isDirectory() || tslDir.listFiles().length == 0)
		  {
			  LOG.warning("No TSLs found !");
			  return;
		  }
		  File[] tsls = tslDir.listFiles();

		  Unmarshaller unmarshal = getUnmarshaller();

		  for (int i = 0; i < tsls.length; i++)
		  {
			  LOG.fine("Processing TSL " + tsls[i].getName());
			  try
			  {
				  JAXBElement<TrustStatusListType> trustStatusList = (JAXBElement<TrustStatusListType>)unmarshal.unmarshal(tsls[i]);
				  String tslID = "";
				  if (trustStatusList.getValue().getTrustServiceProviderList() == null)
					  continue;
				  List<TSPType> tspList = trustStatusList.getValue().getTrustServiceProviderList().getTrustServiceProvider();
				  for (TSPType tspType : tspList)
				  {
					  TSPInformationType tspInfo = tspType.getTSPInformation();
					  List<TSPServiceType> tspServices = tspType.getTSPServices().getTSPService();
					  for (TSPServiceType tspService : tspServices)
					  {
						  TSPServiceInformationType tspServiceInfo = tspService.getServiceInformation();
						  List<DigitalIdentityType> digIdList = tspServiceInfo.getServiceDigitalIdentity().getDigitalId();
						  List<X509Certificate> certList = new ArrayList<X509Certificate>();
						  // If we find a certificate matching a configured issuer,
						  // we have to check if all certificates of this issuer are listed in this TSL entry
						  for (DigitalIdentityType digId : digIdList)
						  {
							  if (digId.getX509Certificate() != null)
								  certList.add(ResponderHelper.createCertificate(digId.getX509Certificate()));
						  }
						  for (X509Certificate cert : certList)
						  {
							  Collection<CertificateDto> cdtos = Configuration.getIssuerCertificateBySubjectDNAndSubjectKeyIdentifier(
									  ResponderHelper.getSubjectDN(cert),
									  ResponderHelper.getSubjectKeyIdentifier(cert));

							  ArrayList<String[]> toBeRemoved = new ArrayList<String[]>();

							  for (CertificateDto cdto : cdtos)
							  {
								  if (cdto.getX509Certificate().equals(cert))
								  {
									LOG.fine("Matching certificate '" + cdto.getFriendlyName() + "' found in TSL, isuer " + cdto.getIssuerName());
									IssuerDto idto = Configuration.getIssuerDto(cdto.getIssuerName());
									for (CertificateDto c : idto.certificateMap.values())
										if (!certList.contains(c.getX509Certificate()))
										{
											LOG.warning("The TSL entry "
													+ " contains a certificate that matches a certificate configured in the issuer "
													+ idto.getName() + " but another certficate of this issuer (" + c.getFriendlyName()
													+ ") is not listed in the TSL. The certificate " + c.getFriendlyName()
													+ " should be removed from the configuration.");
											toBeRemoved.add(new String[]{idto.getName(), c.getFriendlyName()});
										}
// Removed
//									idto.setTSLIdentifier(tsls[i].getName());
									idto.setTSPInformation(tspInfo);
									idto.setTSPServiceInformation(tspServiceInfo);
								  }
							  }
//	@todo: activate ?
//							  for (String[] items : toBeRemoved)
//									Configuration.removeIssuerCertificateDto(items[0], items[1]);
						  }
					  }
				  }
			  }
			  catch (Exception e)
			  {
				  LOG.log(Level.WARNING, "Failed to parse TSL " + tsls[i].getAbsolutePath(), e);
			  }

		  }
	  }
	  catch (Throwable t)
	  {
		  LOG.log(Level.WARNING, "Failed to parse TSLs.", t);
	  }
  }

  public static void getTSLs()
  {
	  ArrayList<String> existingTSLs = new ArrayList<String>();
	  try
	  {
		  LOG.fine("Starting download " + System.getProperty("peppol.xkmsresponder.eu_tsl.url"));
		  byte[] eu_tsl_bytes = ResponderTransport.sendHTTPRequest(System.getProperty("peppol.xkmsresponder.eu_tsl.url"), null, null);

		  XKMSForwarding.checkSignature(new InputSource(
				  new ByteArrayInputStream(eu_tsl_bytes)), null, true); // EU-TSL signature certificate must be TA

		  JAXBElement<TrustStatusListType> trustStatusList = (JAXBElement<TrustStatusListType>)getUnmarshaller().unmarshal(new ByteArrayInputStream(eu_tsl_bytes));

		  File tslDir = new File(Configuration.CONF_DIR + "/tsl");
		  if (!tslDir.exists())
		  {
			  tslDir.mkdir();
		  }
		  else if (!tslDir.isDirectory())
		  {
			  LOG.warning("File " + tslDir.getAbsolutePath() + " is not a directory. Skipping TSL download.");
			  return;
		  }
		  File[] existingTSLfiles = tslDir.listFiles();

		  for (int i = 0; i < existingTSLfiles.length; i++)
			  existingTSLs.add(existingTSLfiles[i].getName());

		  List<OtherTSLPointerType> otslptrList = trustStatusList.getValue().getSchemeInformation().getPointersToOtherTSL().getOtherTSLPointer();
		  String url, mimeType, country;
		  for (OtherTSLPointerType otslptr : otslptrList)
		  {
			  try
			  {
				  url = mimeType = country = null;
				  X509Certificate x509 = ResponderHelper.createCertificate(otslptr.getServiceDigitalIdentities().getServiceDigitalIdentity().get(0).getDigitalId().get(0).getX509Certificate());
				  url = otslptr.getTSLLocation();
				  List<Serializable> infos = otslptr.getAdditionalInformation().getTextualInformationOrOtherInformation();
				  for (Serializable s : infos)
				  {
					  AnyType at = (AnyType)s;
					  List<Object>  l = at.getContent();

					  for (Iterator iterator = l.iterator(); iterator.hasNext(); )
					  {
						Object object = (Object) iterator.next();
		//				if (object instanceof MIMET)
						if (object instanceof JAXBElement)
						{
							if (((JAXBElement)object).getName().getLocalPart().equals("SchemeTerritory"))
								country = ((JAXBElement<String>)object).getValue();
						}
						else if (object instanceof Node)
						{
							if (((Node)object).getLocalName().equals("MimeType"))
								mimeType = ((Node)object).getTextContent();
						}
					  }

				  }
				  if (mimeType.equals("application/vnd.etsi.tsl+xml"))
				  {
					  LOG.fine("Starting download of " + country + "-TSL from " + url);
					  byte[] tsl_bytes = ResponderTransport.sendHTTPRequest(url, null, null);
					  XKMSForwarding.checkSignature(new InputSource(
								  new ByteArrayInputStream(tsl_bytes)), x509, true);
					  String toFile = Configuration.CONF_DIR + "/tsl/" + country + "_tsl.xml";
					  LOG.fine("Saving " + country + "-TSL to " + toFile);
					  FileOutputStream fos = new FileOutputStream(toFile);
					  fos.write(tsl_bytes);
					  fos.close();
					  existingTSLs.remove(country + "_tsl.xml");
				  }
			  }
			  catch (Exception e)
			  {
				  LOG.log(Level.WARNING, "Download failed: " + otslptr.getTSLLocation(), e);
			  }
		  }
	  }
	  catch (Exception e)
	  {
		  LOG.log(Level.WARNING, "Download of TSLs from EU-TSL failed !", e);
	  }
	  finally
	  {
		  for (int i = 0; i < existingTSLs.size(); i++)
			  LOG.warning("File "+  existingTSLs.get(i) + " exists in TSL directory and was not updated");
	  }

  }

  private static Unmarshaller getUnmarshaller() throws JAXBException, SAXException
  {
	  JAXBContext jaxbCon = JAXBContext.newInstance("org.etsi.uri._02231.v2");
	  Unmarshaller unmarshal = jaxbCon.createUnmarshaller();
	  SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
	  Source[] schemaSources = new Source[]
	          {
	            new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/xml.xsd")),
	            new StreamSource(XKMSContentHandler.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/xmldsig-core-schema.xsd")),
			  	new StreamSource(XKMSContextHolder.class.getResourceAsStream("/eu/peppol/lsp/xkmsresponder/xkms/ts_102231v030102_xsd.xsd"))
			  };
      Schema schema = sf.newSchema(schemaSources);
	  unmarshal.setSchema(schema);
	  return unmarshal;
  }

  public static void updateResultMessageExtension(ValidateResultExtEUType vrelspt,
                                                               CertificatevalidatorResult inpUserCertValidatorResult,
                                                               CertificatevalidatorResult inpIssuerCertValidatorResult)
  {
    try
    {
    	if (vrelspt.getEIDQuality() != null)
        {
      	  if (inpUserCertValidatorResult.getCertQuality() != null)
      	  {
  	          vrelspt.getEIDQuality().setCertificateQuality(TranslationTable.XKMS_CERTQUALITY_TABLE.get(inpUserCertValidatorResult.getCertQuality()));
  	          vrelspt.getEIDQuality().setCSPAssurance(TranslationTable.XKMS_CSPASSURANCE_TABLE.get(inpUserCertValidatorResult.getCSPAssurance()));
      	  }
      	  else
      		  vrelspt.setEIDQuality(null);
        }

        if (vrelspt.getServiceInformation() != null)
      		  vrelspt.setServiceInformation(inpUserCertValidatorResult.getTspServiceInformation());

        if(inpUserCertValidatorResult.getErrorMessage() != null)
        {
        	ErrorExtensionType tmpErrorExt = new ErrorExtensionType();
        	if (inpUserCertValidatorResult.getErrorCode() == null)
        		tmpErrorExt.setReason(XKMSConstants.ErrorExtension_Unknown);
        	else
        		tmpErrorExt.setReason(inpUserCertValidatorResult.getErrorCode());

        	if (inpUserCertValidatorResult.getErrorCode() != null
        			&& inpUserCertValidatorResult.getErrorMessage() != null)
        		tmpErrorExt.setDetail(inpUserCertValidatorResult.getErrorMessage());
        	vrelspt.getErrorExtension().add(tmpErrorExt);
        }

        if (vrelspt.getValidationDetails() != null
        		&& inpIssuerCertValidatorResult != null
        		&& inpIssuerCertValidatorResult.getCertificate() != null)
        {
        	try
        	{
        		ValidationDetailsType tmpValidationDetails = vrelspt.getValidationDetails();

        		GregorianCalendar tmpGCal = new GregorianCalendar();
        		XMLGregorianCalendar tmpXMLCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(tmpGCal);
        		tmpValidationDetails.setValidationTime(tmpXMLCal);

        		if(inpUserCertValidatorResult.getValidateScheme() != null)
        		{
        			if (inpUserCertValidatorResult.isValSchemeOCSPCommonPKI())
        				tmpValidationDetails.setValidateScheme(XKMSConstants.VALIDATESCHEME_OCSP_COMMON_PKI);
        			else
        				tmpValidationDetails.setValidateScheme(inpUserCertValidatorResult.getValidateScheme().getXKMSIdentifier());
        		}
        		else
        			tmpValidationDetails.setValidateScheme(ValMethodType.NONE.getXKMSIdentifier());

        		if(inpUserCertValidatorResult.getValidationModel() != null)
        			tmpValidationDetails.setValidateModel(TranslationTable.XKMS_VALIDATIONMODEL_TABLE.get(inpUserCertValidatorResult.getValidationModel()));

        		if (inpUserCertValidatorResult.getValidationTimeQueried() != null)
        			tmpValidationDetails.setValidationTimeQueried(DatatypeFactory.newInstance().
		                                                        newXMLGregorianCalendar((GregorianCalendar)inpUserCertValidatorResult.getValidationTimeQueried()));
        		else
        			tmpValidationDetails.setValidationTimeQueried(DatatypeFactory.newInstance().newXMLGregorianCalendar((new GregorianCalendar())));

        		tmpValidationDetails.setValidationTime(DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar()));
        		ISOCountryCodeType countryCode = null;

        		countryCode = getCountry(inpIssuerCertValidatorResult.getCertificate());
        		tmpValidationDetails.setCertIssuingCountry(countryCode);

        		if(inpUserCertValidatorResult instanceof CvOCSPResult)
        			tmpValidationDetails.setOCSPNoCache(((CvOCSPResult)inpUserCertValidatorResult).isOCSPNoCache());

        	      //RevocationReason
        	      Integer reasonNr = Integer.valueOf(inpUserCertValidatorResult.getRevokationReason());
        	      LOG.fine("RevocationReason(1) :" + inpUserCertValidatorResult.getRevokationReason());
        	      if (reasonNr < 11)
        	      {
        	        String obj = TranslationTable.XKMS_REVOCATIONREASON_TABLE.get(reasonNr);
        	        LOG.fine("RevocationReason(2): " + obj);
        	        if (obj != null)
        	        {
        	          CertificateRevocationDetails crd = new CertificateRevocationDetails();
        	          crd.setRevocationReason(obj);
        	          tmpGCal = new GregorianCalendar();
        	          tmpGCal.setTime(inpUserCertValidatorResult.getRevokationTime());
        	          LOG.fine("RevocationTime: " + inpUserCertValidatorResult.getRevokationTime());
        	          tmpXMLCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(tmpGCal);
        	          crd.setRevocationTimeInstant(tmpXMLCal);
        	          tmpValidationDetails.setCertificateRevocationDetails(crd);
        	        }
        	      }


        		vrelspt.setValidationDetails(tmpValidationDetails);
        	}
        	catch (Throwable ex)
        	{
        		LOG.log(Level.SEVERE, "Error while generating ValidationDetails" , ex);
        		vrelspt.setValidationDetails(null);
        		ErrorExtensionType tmpErrorExt = new ErrorExtensionType();
        		tmpErrorExt.setReason(XKMSConstants.ErrorExtension_Unknown);
        		tmpErrorExt.setDetail(ex.getMessage());
        		vrelspt.getErrorExtension().add(tmpErrorExt);
        	}
        }
        else
        	vrelspt.setValidationDetails(null);

        // First ResponderDetailsType in List is for this instance
        ResponderDetailsType tmpResponderDetails = vrelspt.getResponderDetails().get(0);

        tmpResponderDetails.setConfigurationVersion(Configuration.CONF_FILENAME
				  + "_" + Configuration.configDate.toString());

        if(inpUserCertValidatorResult instanceof CvOCSPResult && !((CvOCSPResult)inpUserCertValidatorResult).isOCSPNoCache())
        {
        	Duration tmpCacheInterval= DatatypeFactory.newInstance().newDuration((((CvOCSPResult) inpUserCertValidatorResult).getOcspCacheInterval()) * 1000);

        	tmpResponderDetails.setOCSPCacheingInterval(tmpCacheInterval);
        }

//        tmpResponderDetails.setPolicyIdentifier(inpUserCertValidatorResult.getolicyIdentifier());

        tmpResponderDetails.setAlgPolicyIdentifier(inpUserCertValidatorResult.getAlgPolicyIdentifier());

        tmpResponderDetails.setTSLIdentifier(inpUserCertValidatorResult.getTslIdentifier());

    }
    catch (Throwable ex)
    {
      LOG.log(Level.SEVERE, "Error while generateMessageExtension" , ex);
      ErrorExtensionType tmpErrorExt = new ErrorExtensionType();
      tmpErrorExt.setReason(XKMSConstants.ErrorExtension_Unknown);
      tmpErrorExt.setDetail(ex.getMessage());
      vrelspt.getErrorExtension().add(tmpErrorExt);
    }
  }

  public static ISOCountryCodeType getCountry(X509Certificate inpCert)
  {

    String dnString = inpCert.getIssuerDN().toString();
    int begin = dnString.indexOf("c=");
    if(begin < 0) begin = dnString.indexOf("C=");
    if(begin > -1)
    {
      begin = begin + 2;
    }
    else
    {
      throw new IllegalArgumentException("No country code found in issuer certificate");
    }
    LOG.fine("Start: " + begin);

    int stop = dnString.indexOf(",", begin);
    if(stop < 0) stop = dnString.length();
    LOG.fine("Stop" + stop);
    return ISOCountryCodeType.fromValue(dnString.substring(begin, stop));
  }


  private static void handleException(Exception e)
  {
    LOG.log(Level.SEVERE, "Fehler in getResultMessageExtension:", e);
  }

  public static ResponderDetailsType createResponderDetails()
  {
	  ResponderDetailsType tmpResponderDetails = new ResponderDetailsType();

//	  tmpResponderDetails.setTSPInformation(createTSPspInformationType());
	  tmpResponderDetails.setTSLIdentifier(XKMSConstants.XKMS_EU_ISSUER_NOT_IN_TSL);
	  tmpResponderDetails.setConfigurationVersion(Configuration.CONF_FILENAME
			  + "_" + Configuration.configDate.toString());
	  return tmpResponderDetails;
  }
}
