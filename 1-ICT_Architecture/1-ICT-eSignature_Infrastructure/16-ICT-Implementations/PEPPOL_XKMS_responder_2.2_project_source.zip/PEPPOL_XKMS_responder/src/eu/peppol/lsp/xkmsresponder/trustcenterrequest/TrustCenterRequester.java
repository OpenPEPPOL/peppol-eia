/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.trustcenterrequest;

import java.security.NoSuchProviderException;
import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;

import eu.peppol.lsp.xkmsresponder.common.CertificatevalidatorResult;
import eu.peppol.lsp.xkmsresponder.common.CvCRLLDAPResult;
import eu.peppol.lsp.xkmsresponder.common.CvCRLResult;
import eu.peppol.lsp.xkmsresponder.common.CvLDAPResult;
import eu.peppol.lsp.xkmsresponder.common.CvLOCALResult;
import eu.peppol.lsp.xkmsresponder.common.CvNONEResult;
import eu.peppol.lsp.xkmsresponder.common.CvOCSPResult;
import eu.peppol.lsp.xkmsresponder.configuration.dto.IssuerDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodCrlDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodLdapDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodOcspDto;
import eu.peppol.lsp.xkmsresponder.configuration.dto.ValMethodType;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.crl.CRLRequester;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ldap.LDAPRequester;
import eu.peppol.lsp.xkmsresponder.trustcenterrequest.ocsp.OCSPRequester;


/**
 * The base class for online or CRL validation requests. It delegates requests to
 * {@link CRLRequester}, {@link LDAPRequester} or {@link OCSPRequester}.
 * @author jens
 * 
*/

public class TrustCenterRequester
{
  private static final Logger LOG = Logger.getLogger(TrustCenterRequester.class.getName());

  private static final String ERROR01 = "ValidateMethod not Supported : ";

  private TrustCenterRequester()
  {
    // just to make the constructor private
  }

  public static CertificatevalidatorResult processRequest(final X509Certificate issuer,
                                                          final X509Certificate user,
                                                          final IssuerDto inpIssuerDto,
                                                          final boolean ocspNoCache, final Long _requestID)
        throws IllegalArgumentException, NoSuchProviderException
  {
    if (user == null)
    {
      throw new IllegalArgumentException("UserCertificate is null");
    }

    if (issuer == null)
    {
      throw new IllegalArgumentException("IssuerCertificate is null");
    }

    if (inpIssuerDto == null)
    {
      throw new IllegalArgumentException("Issuer is null");
    }

    ValMethodType tmpValMethodType = inpIssuerDto.getValMethod();

    if (issuer.equals(user))
    {
    	LOG.fine("A self signed Certificate was found. Setting valMethod to LOCAL");
    	tmpValMethodType = ValMethodType.LOCAL;
    }

    try
    {
      if (LOG.isLoggable(Level.FINE))
      {
        LOG.fine("(start) processRequest(" + issuer.getSubjectDN().getName() + ","
                  + user.getSubjectDN().getName() + ", __) " + tmpValMethodType);
      }

      if (tmpValMethodType.ordinal() == ValMethodType.OCSP.ordinal())
      {
        return doOCSP(issuer, user, ocspNoCache, inpIssuerDto, _requestID);
      }

      if (tmpValMethodType.ordinal() == ValMethodType.CRL.ordinal())
      {
        return doCRL(issuer, user, inpIssuerDto);
      }

      if (tmpValMethodType.ordinal() == ValMethodType.LDAP.ordinal())
      {
        return doLDAP(issuer, user, inpIssuerDto);
      }

      if (tmpValMethodType.ordinal() == ValMethodType.CRL_LDAP.ordinal())
      {
        return doCRLLDAP(issuer, user, inpIssuerDto);
      }

      if (tmpValMethodType.ordinal() == ValMethodType.NONE.ordinal())
      {
        return doNONE(user);
      }

      if (tmpValMethodType.ordinal() == ValMethodType.LOCAL.ordinal())
      {
        return doLOCAL(user);
      }

      throw new NoSuchProviderException(ERROR01 + "?" + tmpValMethodType);
    }
    catch (Exception e)
    {
      if (LOG.isLoggable(Level.SEVERE))
      {
        LOG.log(Level.SEVERE, "processRequest() ", e);
      }

      throw new IllegalArgumentException("ValMethod for Issuer " + inpIssuerDto.getName() + " not found");
    }
  }

  /**
   * Perform OCSP request by delegating it to {@link OCSPRequester}.
   *
   * @param issuer Issuer certificate
   * @param user User certificate
   * @param ocspNoCache Use of cache not allowed
   * @param inpIssuerDto Issuer dto object
   * @param _requestID Request ID
   * @return validation result
   */
  private static CvOCSPResult doOCSP(final X509Certificate issuer, final X509Certificate user,
                                     final boolean ocspNoCache, final IssuerDto inpIssuerDto,
                                     Long _requestID) throws Exception
  {
    ValMethodOcspDto tmpValMethodOcspDto = inpIssuerDto.getValMethodOcspDto();

    CvOCSPResult result =
          OCSPRequester.doRequest(issuer, user, tmpValMethodOcspDto, ocspNoCache, _requestID);
    result.setValSchemeOCSPCommonPKI(tmpValMethodOcspDto.getSubType().equals(ValMethodOcspDto.SUBTYPE_COMMON_PKI));
    result.setValidateScheme(ValMethodType.OCSP);
    result.setOcspCacheInterval(tmpValMethodOcspDto.getCacheTimeout());
    result.setAlgPolicyIdentifier(inpIssuerDto.getAlgPolicyIdentifier());
    result.setTslIdentifier(inpIssuerDto.getTSLIdentifier());
    result.setCSPAssurance(inpIssuerDto.getCSPAssurance());
    result.setValidationModel(inpIssuerDto.getValidateModel());
    result.setOCSPNoCache(ocspNoCache);
    result.setOcspCacheInterval(inpIssuerDto.getValMethodOcspDto().getCacheTimeout());

    checkOCSPSignature(result, tmpValMethodOcspDto);

    return result;
  }

  /**
   * Perform CRL check by delegating it to {@link CRLRequester}.
   *
   * @param issuer Issuer certificate
   * @param user User certificate
   * @param inpIssuerDto Issuer dto object
   * @return validation result
   */
  private static CvCRLResult doCRL(final X509Certificate issuer, final X509Certificate user,
                                   final IssuerDto inpIssuerDto) throws Exception
  {
    ValMethodCrlDto tmpValMethodCrlDto = inpIssuerDto.getValMethodCrlDto();

    return CRLRequester.doRequest(issuer, user, tmpValMethodCrlDto);
  }

  private static CvCRLLDAPResult doCRLLDAP(final X509Certificate issuer, final X509Certificate user,
                                           final IssuerDto inpIssuerDto) throws Exception
  {
    ValMethodCrlDto tmpValMethodCrlDto = inpIssuerDto.getValMethodCrlDto();
    CvCRLResult crlresult = CRLRequester.doRequest(issuer, user, tmpValMethodCrlDto);

    if (crlresult.getInvalidReason().size() > 0)
    {
      return createCvCRLLDAPResult(crlresult, null, inpIssuerDto);
    }

    ValMethodLdapDto tmpValMethodLdapDto = inpIssuerDto.getValMethodLdapDto();
    CvLDAPResult ldapresult = LDAPRequester.doRequest(issuer, user, tmpValMethodLdapDto);

    return createCvCRLLDAPResult(crlresult, ldapresult, inpIssuerDto);
  }

  /**
   * Perform LDAP check by delegating it to {@link LDAPRequester}.
   *
   * @param issuer Issuer certificate
   * @param user User certificate
   * @param inpIssuerDto Issuer dto object
   * @return validation result
   */
  private static CvLDAPResult doLDAP(final X509Certificate issuer, final X509Certificate user,
                                     final IssuerDto inpIssuerDto) throws Exception
  {
    ValMethodLdapDto tmpValMethodLdapDto = inpIssuerDto.getValMethodLdapDto();

    return LDAPRequester.doRequest(issuer, user, tmpValMethodLdapDto);
  }

  /**
   * Does no validation, always returns indeterminate
   * @param user User certificate
   * @return validation result
   * @throws IllegalArgumentException
   */
  private static CvNONEResult doNONE(final X509Certificate user) throws IllegalArgumentException
  {
    CvNONEResult result = new CvNONEResult(user);
    result.setValidateScheme(ValMethodType.NONE);
    result.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
    result.setStatus(CertificatevalidatorResult.STATUS_INDETERMINATE);

    return result;
  }

 /**
  *  Does no online validation, only checks signature, validity interval,
  * always returns valid. This validation method is only used internally
  * for self-signed certificates like configured trusted anchors or root
  * certificates.
  * @param user User certificate
  * @return validation result
  * @throws IllegalArgumentException
  */
 private static CvLOCALResult doLOCAL(final X509Certificate user) throws IllegalArgumentException
 {
   CvLOCALResult result = new CvLOCALResult(user);
   result.setValidateScheme(ValMethodType.LOCAL);
// @todo: check if removal causes any problems
//   result.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
   result.setStatus(CertificatevalidatorResult.STATUS_VALID);

   return result;
 }

  private static void checkOCSPSignature(CvOCSPResult result, ValMethodOcspDto pruefmethode)
  {
    if ((result.getOcspRespSignature() == CvOCSPResult.OCSPResp_INVALID)
        || (result.getOcspRespSignature() == CvOCSPResult.OCSPResp_INDETERMINATE))
    {
      LOG.fine("OCSPSignature not valid. Set Indeterminate Reason.");
      result.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
      result.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    }

    if (pruefmethode.getCheckRespSignature().booleanValue()
        && (CvOCSPResult.OCSPResp_UNCHECKED == result.getOcspRespSignature()))
    {
      LOG.fine("OCSPSignature not checked. Set Indeterminate Reason.");
      result.addIndeterminateReason(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
      result.getValidReason().remove(CertificatevalidatorResult.XKMSREASONS_ISSUER_TRUST);
    }
  }

  private static CvCRLLDAPResult createCvCRLLDAPResult(CvCRLResult crlresult, CvLDAPResult ldapresult,
                                                       IssuerDto inpIssuerDto)
  {
    CvCRLLDAPResult result = new CvCRLLDAPResult(crlresult.getCertificate());
    result.setValidateScheme(ValMethodType.CRL_LDAP);
    result.setChainpos(crlresult.getChainpos());

    if (ldapresult == null)
    {
      result.setCaRating(crlresult.getCaRating());
      result.setErrorCode(crlresult.getErrorCode());
      result.setRevokationReason(crlresult.getRevokationReason());
      result.setRevokationTime(crlresult.getRevokationTime());
      result.addInvalidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);
      result.setStatus(crlresult.getStatus());
      result.setX509Crl(crlresult.getX509Crl());
      result.setAlgPolicyIdentifier(inpIssuerDto.getAlgPolicyIdentifier());
      result.setTslIdentifier(inpIssuerDto.getTSLIdentifier());
      result.setCSPAssurance(inpIssuerDto.getCSPAssurance());
      result.setValidationModel(inpIssuerDto.getValidateModel());

      for (int ti = 0; ti < crlresult.getValidReason().size(); ti++)
      {
        result.addValidReason(crlresult.getValidReason().get(ti));
      }

      for (int ti = 0; ti < crlresult.getIndeterminateReason().size(); ti++)
      {
        result.addIndeterminateReason(crlresult.getIndeterminateReason().get(ti));
      }

      for (int ti = 0; ti < crlresult.getInvalidReason().size(); ti++)
      {
        result.addInvalidReason(crlresult.getInvalidReason().get(ti));
      }

      return result;
    }

    switch (ldapresult.getStatus())
    {
      case CertificatevalidatorResult.STATUS_VALID:

        switch (crlresult.getStatus())
        {
          case CertificatevalidatorResult.STATUS_VALID:
            result.setStatus(CertificatevalidatorResult.STATUS_VALID);
            result.addValidReason(CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS);

            break;

          case CertificatevalidatorResult.STATUS_INDETERMINATE:
            fillCrlLdapResult(result, CertificatevalidatorResult.STATUS_INDETERMINATE,
                              CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS,
                              crlresult.getErrorCode());

            break;

          case CertificatevalidatorResult.STATUS_INVALID:
            fillCrlLdapResult(result, CertificatevalidatorResult.STATUS_INVALID,
                              CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS,
                              crlresult.getErrorCode());

            break;

          default:
            throw new IllegalArgumentException("crlresult.getStatus()");
        }

        break;

      case CertificatevalidatorResult.STATUS_INDETERMINATE:

        switch (crlresult.getStatus())
        {
          case CertificatevalidatorResult.STATUS_VALID:
            fillCrlLdapResult(result, CertificatevalidatorResult.STATUS_INDETERMINATE,
                              CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS,
                              ldapresult.getErrorCode());

            break;

          case CertificatevalidatorResult.STATUS_INDETERMINATE:
            fillCrlLdapResult(result, CertificatevalidatorResult.STATUS_INDETERMINATE,
                              CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS,
                              ldapresult.getErrorCode());

            break;

          case CertificatevalidatorResult.STATUS_INVALID:
            fillCrlLdapResult(result, CertificatevalidatorResult.STATUS_INVALID,
                              CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS,
                              crlresult.getErrorCode());

            break;

          default:
            throw new IllegalArgumentException("crlresult.getStatus()");
        }

        break;

      case CertificatevalidatorResult.STATUS_INVALID:
        fillCrlLdapResult(result, CertificatevalidatorResult.STATUS_INVALID,
                          CertificatevalidatorResult.XKMSREASONS_REVOCATION_STATUS, crlresult.getErrorCode());

        break;

      default:
        throw new IllegalArgumentException("ldapresult.getStatus()");
    }

    return result;
  }

  private static void fillCrlLdapResult(CvCRLLDAPResult result, int status, Integer indeterminateReason,
                                        String errorCode)
  {
    result.setStatus(status);

    if (status == CertificatevalidatorResult.STATUS_INVALID)
    {
      result.addInvalidReason(indeterminateReason);
    }
    else
    {
      result.addIndeterminateReason(indeterminateReason);
    }

    result.setErrorCode(errorCode);
  }
}
