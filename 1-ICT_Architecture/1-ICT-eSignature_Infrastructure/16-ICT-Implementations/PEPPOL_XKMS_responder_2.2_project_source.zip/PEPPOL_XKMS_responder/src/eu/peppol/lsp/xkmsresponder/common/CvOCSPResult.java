/*
 * Version: MPL 1.1/EUPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Copyright The PEPPOL project (http://www.peppol.eu)
 *
 * Alternatively, the contents of this file may be used under the
 * terms of the EUPL, Version 1.1 or - as soon they will be approved
 * by the European Commission - subsequent versions of the EUPL
 * (the "Licence"); You may not use this work except in compliance
 * with the Licence.
 * You may obtain a copy of the Licence at:
 * http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * If you wish to allow use of your version of this file only
 * under the terms of the EUPL License and not to allow others to use
 * your version of this file under the MPL, indicate your decision by
 * deleting the provisions above and replace them with the notice and
 * other provisions required by the EUPL License. If you do not delete
 * the provisions above, a recipient may use your version of this file
 * under either the MPL or the EUPL License.
 *
 */

package eu.peppol.lsp.xkmsresponder.common;

import java.security.cert.X509Certificate;


/**
 * Represents the result of an OCSP certificate validation
 * @author buengener
 *
 * 
*/

public class CvOCSPResult extends CertificatevalidatorResult
{
  /**
   *
   */
  private static final long serialVersionUID = -6527878424481678119L;

  public static final String OCSPResp_SUCCESSFUL = "OCSPResp_SUCCESSFUL";

  public static final String OCSPResp_MALFORMED_REQUEST = "OCSPResp_MALFORMED_REQUEST";

  public static final String OCSPResp_INTERNAL_ERROR = "OCSPResp_INTERNAL_ERROR";

  public static final String OCSPResp_TRY_LATER = "OCSPResp_TRY_LATER";

  public static final String OCSPResp_SIGREQUIRED = "OCSPResp_SIGREQUIRED";

  public static final String OCSPResp_UNAUTHORIZED = "OCSPResp_UNAUTHORIZED";

  //Values for OCSP-Response Signature
  public static final int OCSPResp_VALID = 0;

  public static final int OCSPResp_INVALID = 1;

  public static final int OCSPResp_INDETERMINATE = 2;

  public static final int OCSPResp_UNCHECKED = 3;

  public static final int OCSPResp_NOT_SIGNED = 4;

  private int ocspRespStatus;

  private int ocspRespSignature = OCSPResp_UNCHECKED;

  private String producedAt;

  private byte[] ocspResp;

  private boolean ocspNoCache;

  private int ocspCacheInterval = -1;

  private boolean isCommonPKIIndeterminate = false;

  /**
   * Creates a new CvOCSPResult object.
   * @param certificate checked certificate
   */
  public CvOCSPResult(X509Certificate certificate)
  {
    super(certificate);
  }

  /**
   * Returns the status of the OCSP response.
   * @return Status
   */
  public int getOcspRespStatus()
  {
    return ocspRespStatus;
  }

  /**
   * Sets the status of the OCSP response.
   * @param ocspRespStatus Status
   */
  public void setOcspRespStatus(int ocspRespStatus)
  {
    this.ocspRespStatus = ocspRespStatus;
  }

  /**
   * Returns the status of the OCSP signature.
   * @return Status
   */
  public int getOcspRespSignature()
  {
    return ocspRespSignature;
  }

  /**
   * Sets the status of the OCSP signature.
   * @param ocspRespSignature Status
   */
  public void setOcspRespSignature(int ocspRespSignature)
  {
    this.ocspRespSignature = ocspRespSignature;
  }

  /**
   * Returns the date of generation.
   * @return Date of production as string
   */
  public String getProducedAt()
  {
    return producedAt;
  }

  /**
   * Sets the date of generation.
   * @param producedAt Date of production as string
   */
  public void setProducedAt(String producedAt)
  {
    this.producedAt = producedAt;
  }

  /**
   * Returns the OCSP response.
   * @return OCSP response
   */
  public byte[] getOcspResp()
  {
    return ocspResp;
  }

  /**
   * Sets the OCSP response.
   * @param ocspResp OCSP response
   */
  public void setOcspResp(byte[] ocspResp)
  {
    this.ocspResp = ocspResp;
  }

  /**
   * Returns if the certificate is indeterminate according to the CommonPKI specification..
   * @return Is indeterminate
   */
  public boolean isCommonPKIIndeterminate()
  {
    return isCommonPKIIndeterminate;
  }

  /**
   * Sets if the certificate is indeterminate according to the CommonPKI specification..
   * @param inpCommonPKIIndeterminate Is indeterminate
   */
  public void setCommonPKIIndeterminate(boolean inpCommonPKIIndeterminate)
  {
    isCommonPKIIndeterminate = inpCommonPKIIndeterminate;
  }

  /**
   * Sets the flag that determines if the response cache may be used.
   * @param inpOCSPNoCache true -> do not use cache
   */
  public void setOCSPNoCache(boolean inpOCSPNoCache)
  {
    ocspNoCache = inpOCSPNoCache;
  }

  /**
   * Returns if the response cache may <b>not</b> been used.
   * @return true -> use of cache prohibited
   */
  public boolean isOCSPNoCache()
  {
    return ocspNoCache;
  }

  public int getOcspCacheInterval()
  {
    return ocspCacheInterval;
  }

  public void setOcspCacheInterval(int ocspCacheInterval)
  {
    this.ocspCacheInterval = ocspCacheInterval;
  }

}
