
package eu.peppol.lsp.xkms.jaxb.xkms;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import eu.peppol.lsp.xkms.jaxb.peppol.RequestingNodeChainType;
import eu.peppol.lsp.xkms.jaxb.peppol.ValidateRequestExtEUType;
import eu.peppol.lsp.xkms.jaxb.peppol.ValidateResultExtEUType;


/**
 * <p>Java class for MessageExtensionAbstractType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageExtensionAbstractType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageExtensionAbstractType")
@XmlSeeAlso({
    ValidateResultExtEUType.class,
    RequestingNodeChainType.class,
    ValidateRequestExtEUType.class
})
public abstract class MessageExtensionAbstractType {


}
