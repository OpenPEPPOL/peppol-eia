/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 13 oct. 2010
 * Time: 17:05:19
 */
package eu.peppol.lsp.xkms.extensions;


public enum CertificateQuality
{
	/**
	 * Certificate quality can't be determined.
	 */
	UNKNOWN (PEPPOLConstants.CERT_QUALITY_URI + "Unknown"),
	
	/**
	 * Low confidence in certificate but certificate policy exists or quality
	 * assessment is possible by other means.
	 */
	LOW (PEPPOLConstants.CERT_QUALITY_URI + "Low"),
	
	/**
	 * Certificate governed by a Certificate Policy in compliance with the
	 * ETSI TS 102 042 standard for LCP or a similar standard.
	 */
	LCP (PEPPOLConstants.CERT_QUALITY_URI + "LCP"),
	
	/**
	 * Certificate governed by a Certificate Policy in compliance with the
	 * ETSI TS 102 042 standard for NCP or a similar standard.
	 */
	NCP (PEPPOLConstants.CERT_QUALITY_URI + "NCP"),
	
	/**
	 * Certificates governed by a Certificate Policy in compliance with the
	 * ETSI TS 102 042 standard for NCP+ or a similar standard (Use of a SSCD
	 * is mandated in the CP).
	 */
	NCP_PLUS (PEPPOLConstants.CERT_QUALITY_URI + "NCPPLUS"),
	
	/**
	 * Certificates governed by a Certificate Policy in compliance with the
	 * ETSI TS 101 456 standard for QCP or a similar standard.
	 */
	QCP (PEPPOLConstants.CERT_QUALITY_URI + "QCP"),
	
	/**
	 * Certificates governed by a Certificate Policy in compliance with the
	 * ETSI TS 101 456 standard for QCP+ or a similar standard.
	 * (Use of a SSCD is mandated in the CP).
	 */
	QCP_PLUS (PEPPOLConstants.CERT_QUALITY_URI + "QCPPLUS");
	
	
	private final String value;
	
	CertificateQuality(String v) 
	{
        value = v;
    }

    public String value() 
    {
        return value;
    }

    public static CertificateQuality fromValue(String v) 
    {
    	if (v == null)
    	{
    		return null;
    	}
    	
        for (CertificateQuality c: CertificateQuality.values()) 
        {
            if (c.value.equals(v)) 
            {
                return c;
            }
        }
        throw new IllegalArgumentException(v.toString());
    }
}
