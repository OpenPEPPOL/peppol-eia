
package eu.peppol.lsp.xkms.jaxb.peppol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.Duration;
import eu.peppol.lsp.xkms.jaxb.tsl.TSPInformationType;


/**
 * <p>Java class for ResponderDetailsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ResponderDetailsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://uri.etsi.org/02231/v2#}TSPInformation" minOccurs="0"/>
 *         &lt;element name="ConfigurationVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OCSPCacheingInterval" type="{http://www.w3.org/2001/XMLSchema}duration" minOccurs="0"/>
 *         &lt;element name="TSLIdentifier" type="{http://uri.etsi.org/02231/v2#}NonEmptyURIType" minOccurs="0"/>
 *         &lt;element name="PolicyIdentifier" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/>
 *         &lt;element name="AlgPolicyIdentifier" type="{http://uri.etsi.org/02231/v2#}NonEmptyURIType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="ChainingTo" type="{http://uri.etsi.org/02231/v2#}NonEmptyURIType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ResponderDetailsType", propOrder = {
    "tspInformation",
    "configurationVersion",
    "ocspCacheingInterval",
    "tslIdentifier",
    "policyIdentifier",
    "algPolicyIdentifier"
})
public class ResponderDetailsType {

    @XmlElement(name = "TSPInformation", namespace = "http://uri.etsi.org/02231/v2#")
    protected TSPInformationType tspInformation;
    @XmlElement(name = "ConfigurationVersion")
    protected String configurationVersion;
    @XmlElement(name = "OCSPCacheingInterval")
    protected Duration ocspCacheingInterval;
    @XmlElement(name = "TSLIdentifier")
    protected String tslIdentifier;
    @XmlElement(name = "PolicyIdentifier")
    @XmlSchemaType(name = "anyURI")
    protected String policyIdentifier;
    @XmlElement(name = "AlgPolicyIdentifier")
    protected String algPolicyIdentifier;
    @XmlAttribute(name = "ChainingTo")
    protected String chainingTo;

    /**
     * Gets the value of the tspInformation property.
     * 
     * @return
     *     possible object is
     *     {@link TSPInformationType }
     *     
     */
    public TSPInformationType getTSPInformation() {
        return tspInformation;
    }

    /**
     * Sets the value of the tspInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link TSPInformationType }
     *     
     */
    public void setTSPInformation(TSPInformationType value) {
        this.tspInformation = value;
    }

    /**
     * Gets the value of the configurationVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigurationVersion() {
        return configurationVersion;
    }

    /**
     * Sets the value of the configurationVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigurationVersion(String value) {
        this.configurationVersion = value;
    }

    /**
     * Gets the value of the ocspCacheingInterval property.
     * 
     * @return
     *     possible object is
     *     {@link Duration }
     *     
     */
    public Duration getOCSPCacheingInterval() {
        return ocspCacheingInterval;
    }

    /**
     * Sets the value of the ocspCacheingInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link Duration }
     *     
     */
    public void setOCSPCacheingInterval(Duration value) {
        this.ocspCacheingInterval = value;
    }

    /**
     * Gets the value of the tslIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTSLIdentifier() {
        return tslIdentifier;
    }

    /**
     * Sets the value of the tslIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTSLIdentifier(String value) {
        this.tslIdentifier = value;
    }

    /**
     * Gets the value of the policyIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyIdentifier() {
        return policyIdentifier;
    }

    /**
     * Sets the value of the policyIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyIdentifier(String value) {
        this.policyIdentifier = value;
    }

    /**
     * Gets the value of the algPolicyIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlgPolicyIdentifier() {
        return algPolicyIdentifier;
    }

    /**
     * Sets the value of the algPolicyIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlgPolicyIdentifier(String value) {
        this.algPolicyIdentifier = value;
    }

    /**
     * Gets the value of the chainingTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChainingTo() {
        return chainingTo;
    }

    /**
     * Sets the value of the chainingTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChainingTo(String value) {
        this.chainingTo = value;
    }

}
