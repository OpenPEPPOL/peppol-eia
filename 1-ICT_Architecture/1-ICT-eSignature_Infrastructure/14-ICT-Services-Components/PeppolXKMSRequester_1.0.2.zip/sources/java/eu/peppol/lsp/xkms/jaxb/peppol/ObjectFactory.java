
package eu.peppol.lsp.xkms.jaxb.peppol;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the eu.peppol.lsp.xkms.jaxb.peppol package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RequestingNodeChain_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "RequestingNodeChain");
    private final static QName _RevocationReason_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "RevocationReason");
    private final static QName _ValidationTimeQueried_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ValidationTimeQueried");
    private final static QName _ValidateModel_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ValidateModel");
    private final static QName _CertificateQuality_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "CertificateQuality");
    private final static QName _ValidateResultExtEU_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ValidateResultExtEU");
    private final static QName _ValidateScheme_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ValidateScheme");
    private final static QName _CSPAssurance_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "CSPAssurance");
    private final static QName _ErrorExtension_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ErrorExtension");
    private final static QName _OCSPNoCache_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "OCSPNoCache");
    private final static QName _ValidationDetails_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ValidationDetails");
    private final static QName _EIDQuality_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "eIDQuality");
    private final static QName _ValidationTime_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ValidationTime");
    private final static QName _ValidateRequestExtEU_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ValidateRequestExtEU");
    private final static QName _ResponderDetails_QNAME = new QName("http://uri.peppol.eu/xkmsExt/v2#", "ResponderDetails");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: eu.peppol.lsp.xkms.jaxb.peppol
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CertificateRevocationDetails }
     * 
     */
    public CertificateRevocationDetails createCertificateRevocationDetails() {
        return new CertificateRevocationDetails();
    }

    /**
     * Create an instance of {@link ResponderDetailsType }
     * 
     */
    public ResponderDetailsType createResponderDetailsType() {
        return new ResponderDetailsType();
    }

    /**
     * Create an instance of {@link ValidationDetailsType }
     * 
     */
    public ValidationDetailsType createValidationDetailsType() {
        return new ValidationDetailsType();
    }

    /**
     * Create an instance of {@link RequestingNodeChainType }
     * 
     */
    public RequestingNodeChainType createRequestingNodeChainType() {
        return new RequestingNodeChainType();
    }

    /**
     * Create an instance of {@link ValidateRequestExtEUType }
     * 
     */
    public ValidateRequestExtEUType createValidateRequestExtEUType() {
        return new ValidateRequestExtEUType();
    }

    /**
     * Create an instance of {@link EIDQualityType }
     * 
     */
    public EIDQualityType createEIDQualityType() {
        return new EIDQualityType();
    }

    /**
     * Create an instance of {@link ValidateResultExtEUType }
     * 
     */
    public ValidateResultExtEUType createValidateResultExtEUType() {
        return new ValidateResultExtEUType();
    }

    /**
     * Create an instance of {@link ErrorExtensionType }
     * 
     */
    public ErrorExtensionType createErrorExtensionType() {
        return new ErrorExtensionType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequestingNodeChainType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "RequestingNodeChain", substitutionHeadNamespace = "http://www.w3.org/2002/03/xkms#", substitutionHeadName = "MessageExtension")
    public JAXBElement<RequestingNodeChainType> createRequestingNodeChain(RequestingNodeChainType value) {
        return new JAXBElement<RequestingNodeChainType>(_RequestingNodeChain_QNAME, RequestingNodeChainType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "RevocationReason")
    public JAXBElement<String> createRevocationReason(String value) {
        return new JAXBElement<String>(_RevocationReason_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ValidationTimeQueried")
    public JAXBElement<XMLGregorianCalendar> createValidationTimeQueried(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ValidationTimeQueried_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ValidateModel")
    public JAXBElement<String> createValidateModel(String value) {
        return new JAXBElement<String>(_ValidateModel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "CertificateQuality")
    public JAXBElement<String> createCertificateQuality(String value) {
        return new JAXBElement<String>(_CertificateQuality_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateResultExtEUType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ValidateResultExtEU", substitutionHeadNamespace = "http://www.w3.org/2002/03/xkms#", substitutionHeadName = "MessageExtension")
    public JAXBElement<ValidateResultExtEUType> createValidateResultExtEU(ValidateResultExtEUType value) {
        return new JAXBElement<ValidateResultExtEUType>(_ValidateResultExtEU_QNAME, ValidateResultExtEUType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ValidateScheme")
    public JAXBElement<String> createValidateScheme(String value) {
        return new JAXBElement<String>(_ValidateScheme_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "CSPAssurance")
    public JAXBElement<String> createCSPAssurance(String value) {
        return new JAXBElement<String>(_CSPAssurance_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ErrorExtensionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ErrorExtension")
    public JAXBElement<ErrorExtensionType> createErrorExtension(ErrorExtensionType value) {
        return new JAXBElement<ErrorExtensionType>(_ErrorExtension_QNAME, ErrorExtensionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "OCSPNoCache")
    public JAXBElement<Boolean> createOCSPNoCache(Boolean value) {
        return new JAXBElement<Boolean>(_OCSPNoCache_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidationDetailsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ValidationDetails")
    public JAXBElement<ValidationDetailsType> createValidationDetails(ValidationDetailsType value) {
        return new JAXBElement<ValidationDetailsType>(_ValidationDetails_QNAME, ValidationDetailsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EIDQualityType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "eIDQuality")
    public JAXBElement<EIDQualityType> createEIDQuality(EIDQualityType value) {
        return new JAXBElement<EIDQualityType>(_EIDQuality_QNAME, EIDQualityType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ValidationTime")
    public JAXBElement<XMLGregorianCalendar> createValidationTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ValidationTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateRequestExtEUType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ValidateRequestExtEU", substitutionHeadNamespace = "http://www.w3.org/2002/03/xkms#", substitutionHeadName = "MessageExtension")
    public JAXBElement<ValidateRequestExtEUType> createValidateRequestExtEU(ValidateRequestExtEUType value) {
        return new JAXBElement<ValidateRequestExtEUType>(_ValidateRequestExtEU_QNAME, ValidateRequestExtEUType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResponderDetailsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://uri.peppol.eu/xkmsExt/v2#", name = "ResponderDetails")
    public JAXBElement<ResponderDetailsType> createResponderDetails(ResponderDetailsType value) {
        return new JAXBElement<ResponderDetailsType>(_ResponderDetails_QNAME, ResponderDetailsType.class, null, value);
    }

}
