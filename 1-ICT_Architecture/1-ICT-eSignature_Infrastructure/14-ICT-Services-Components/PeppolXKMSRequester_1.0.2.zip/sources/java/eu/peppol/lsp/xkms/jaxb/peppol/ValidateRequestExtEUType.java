
package eu.peppol.lsp.xkms.jaxb.peppol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import eu.peppol.lsp.xkms.jaxb.xkms.MessageExtensionAbstractType;


/**
 * <p>Java class for ValidateRequestExtEUType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValidateRequestExtEUType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.w3.org/2002/03/xkms#}MessageExtensionAbstractType">
 *       &lt;sequence>
 *         &lt;element ref="{http://uri.peppol.eu/xkmsExt/v2#}RequestingNodeChain"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidateRequestExtEUType", propOrder = {
    "requestingNodeChain"
})
public class ValidateRequestExtEUType
    extends MessageExtensionAbstractType
{

    @XmlElement(name = "RequestingNodeChain", required = true)
    protected RequestingNodeChainType requestingNodeChain;

    /**
     * Gets the value of the requestingNodeChain property.
     * 
     * @return
     *     possible object is
     *     {@link RequestingNodeChainType }
     *     
     */
    public RequestingNodeChainType getRequestingNodeChain() {
        return requestingNodeChain;
    }

    /**
     * Sets the value of the requestingNodeChain property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestingNodeChainType }
     *     
     */
    public void setRequestingNodeChain(RequestingNodeChainType value) {
        this.requestingNodeChain = value;
    }

}
