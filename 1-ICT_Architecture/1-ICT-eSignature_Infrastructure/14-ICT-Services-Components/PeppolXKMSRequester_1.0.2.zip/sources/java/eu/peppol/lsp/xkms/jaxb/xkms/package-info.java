@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.w3.org/2002/03/xkms#", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package eu.peppol.lsp.xkms.jaxb.xkms;
