/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 13 oct. 2010
 * Time: 17:05:19
 */
package eu.peppol.lsp.xkms.extensions;

public enum ErrorExtensionReason
{
	/**
	 * Length of value of /xkms:OpaqueClientData exceeds 256 bytes.		
	 */
	OPAQUE_CLIENT_DATE_TOO_LONG (PEPPOLConstants.REASON_URI + "OpaqueClientDataTooLong"),
	
	/**
	 * Responder of certificate issuer CA not reached - time-out limit reached
	 * or other technical reasons.
	 */
	TRUST_CENTER_NOT_REACHABLE (PEPPOLConstants.REASON_URI + "TrustCenterNotReachable"),
	
	/**
	 * Certificate defect or wrong coded.
	 */
	WRONG_CERTIFICATE_FORMAT (PEPPOLConstants.REASON_URI + "WrongCertificateFormat"),
	
	/**
	 * Validation time instant not recognizable or in future.
	 */
	WRONG_TIME_INSTANT (PEPPOLConstants.REASON_URI + "WrongTimeInstant"),
	
	/**
	 * Certificate issuer not known.
	 */
	UNKNOWN_CA (PEPPOLConstants.REASON_URI + "UnkownCA"),
	
	/**
	 * Key length of signature certificate is too short.
	 */
	SIGNATURE_KEY_TOO_SHORT (PEPPOLConstants.REASON_URI + "SignatureKeyTooShort"),
	
	/**
	 * While chaining a request, the addressed next responder could not be
	 * reached or did not respond in time.
	 */
	NEXT_RESPONDER_IN_CHAIN_NOT_REACHED (PEPPOLConstants.REASON_URI + "NextResponderInChainNotReached"),
	
	/**
	 * While chaining a request, a loop in the responder chain was detected.
	 */
	RESPONDER_CHAIN_LOOP (PEPPOLConstants.REASON_URI + "ResponderChainLoop"),
	
	/**
	 * Error reason could not be determined.
	 */
	UNKNOWN (PEPPOLConstants.REASON_URI + "Unknown"),
	
	/**
	 * Certificate issuer no longer offers CRL or OCSP services (e.g. because
	 * of closing down business).
	 */
	REVOCATION_STATUS_NO_LONGER_PROVIDED (PEPPOLConstants.REASON_URI + "RevocationStatusNoLongerProvided"),
	
	/**
	 * Different quality levels detected in the certificate chain
	 */
	CERT_QUALITY_NOT_CONSISTENT (PEPPOLConstants.REASON_URI + "CertQualityNotConsistent"),
	
	/**
	 * A request parameter could not be understood, but processing was
	 * (partially) possible. The indicated parameter SHOULD be outlined
	 * in the xkmsEU:Detail element of this xkmsEU:ErrorExtension entry.
	 */
	NOT_UNDERSTOOD (PEPPOLConstants.REASON_URI + "NotUnderstood");
	
	
	private final String value;
	
	ErrorExtensionReason(String v) 
	{
        value = v;
    }

    public String value() 
    {
        return value;
    }

    public static ErrorExtensionReason fromValue(String v) 
    {
    	if (v == null)
    	{
    		return null;
    	}
    	
        for (ErrorExtensionReason c: ErrorExtensionReason.values()) 
        {
            if (c.value.equals(v)) 
            {
                return c;
            }
        }
        throw new IllegalArgumentException(v.toString());
    }
}
