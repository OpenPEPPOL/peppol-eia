/*
 * ====================================================================
 *
 * The Lex Persona Software Disclaimer
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LEX PERSONA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * The Lex Persona Source Code License, Version 1.0
 *
 * Copyright (c) 2005 Lex Persona.  All rights reserved.
 *
 * THIS SOURCE CODE IS PROVIDED FOR THE SOLE PURPOSE OF THE APPLICATION
 * FOR WHICH IT HAS BEEN DEVELOPED. ALSO THIS SOURCE CODE IS PROVIDED FOR
 * UNLIMITED USE BY THE CLIENT FOR WHOM IT HAS BEEN DEVELOPED. CLIENT MAY
 * ADD, MODIFY OR DELETE ANY PARTS OF THIS SOURCE CODE UNDER ITS OWN
 * RESPONSABILITY, FOR THE SOLE PURPOSE OF MAINTENANCE, CORRECTIONS,
 * BUG FIXING, AND ENHANCEMENTS. UNDER NO CIRCUMSTANCES WHATSOEVER
 * SHOULD THE CLIENT TRANSFER, COMMUNICATE, GIVE, SHARE OR SELL THE
 * SOFTWARE TO OTHER CLIENTS, COMPANIES, BUSINESSES, ADMINISTRATIONS OR
 * INDIVIDUALS WITHOUT A SIGNED AUTHORIZATION FROM LEX PERSONA.
 * ====================================================================
 *
 * For more information on Lex Persona , please see
 * <http://www.lex-persona.com/>.
 *
 * Copyright Lex Persona.
 * Author: Julien
 * Date: 14 oct. 2010
 * Time: 08:23:12
 */
package eu.peppol.lsp.xkms.extensions;

import java.util.Date;

import eu.peppol.lsp.xkms.jaxb.isocc.ISOCountryCodeType;
import eu.peppol.lsp.xkms.jaxb.peppol.CertificateRevocationDetails;
import eu.peppol.lsp.xkms.jaxb.peppol.ValidationDetailsType;


public class ValidationDetails
{
	private ValidateScheme validateScheme;
	private ValidateModel validateModel;
	private Date validationTimeQueried;
	private Date validationTime;
	private ISOCountryCodeType certIssuingCountry;
	private Boolean isOCSPNoCache;
	private Date revocationTimeInstant;
	private RevocationReason revocationReason;
	
	/**
	 * Creates a new <code>ValidationDetails</code>.
	 * 
	 * @param  validateDetailsType
	 *         The JAXB object.
	 */
	public ValidationDetails(ValidationDetailsType validateDetailsType)
	{
		this.validateScheme = ValidateScheme.fromValue(validateDetailsType.getValidateScheme());
		
		String validateModelValue = validateDetailsType.getValidateModel();
		if (validateModelValue != null)
		{
			validateModel = ValidateModel.fromValue(validateModelValue);
		}
		
		this.validationTimeQueried = validateDetailsType.getValidationTimeQueried().toGregorianCalendar().getTime();

		this.validationTime = validateDetailsType.getValidationTime().toGregorianCalendar().getTime();
		
		this.certIssuingCountry = validateDetailsType.getCertIssuingCountry();
		
		this.isOCSPNoCache = validateDetailsType.isOCSPNoCache();
		
		CertificateRevocationDetails certRevDetails = validateDetailsType.getCertificateRevocationDetails();
		if (certRevDetails != null)
		{
			this.revocationTimeInstant = certRevDetails.getRevocationTimeInstant().toGregorianCalendar().getTime();
			this.revocationReason = RevocationReason.fromValue(certRevDetails.getRevocationReason()); 
		}
	}

	/**
	 * Returns the validation scheme used to validate the certificate.
	 * 
	 * @return the validation scheme used to validate the certificate.
	 */
	public ValidateScheme getValidateScheme()
	{
		return validateScheme;
	}

	/**
	 * Returns the validation model used to validate the certificate.
	 * 
	 * @return the validation model used to validate the certificate.
	 */
	public ValidateModel getValidateModel()
	{
		return validateModel;
	}

	/**
	 * Returns the requested time of validation processing.
	 * 
	 * @return the requested time of validation processing.
	 */
	public Date getValidationTimeQueried()
	{
		return validationTimeQueried;
	}

	/**
	 * Returns the time of validation processing.
	 * 
	 * @return the time of validation processing.
	 */
	public Date getValidationTime()
	{
		return validationTime;
	}

	/**
	 * Returns the code of the country the certificate was issued.
	 * 
	 * @return the code of the country the certificate was issued.
	 */
	public ISOCountryCodeType getCertIssuingCountry()
	{
		return certIssuingCountry;
	}

	/**
	 * Returns <code>true</code> if the OSCP response was not taken from the
	 * cache or <code>false</code> otherwise. 
	 * <p>
	 * Returns <code>null</code> if this flag is not specified.
	 * 
	 * @return <code>true</code> if the OSCP response was not taken from the
	 * cache or <code>false</code> otherwise (or <code>null</code> if this
	 * flag is not specified).
	 */
	public Boolean getOCSPNoCache()
	{
		return isOCSPNoCache;
	}

	/**
	 * Returns the time of revocation or <code>null</code> if the certificate
	 * is not revoked.
	 * 
	 * @return the time of revocation or <code>null</code> if the certificate
	 * is not revoked.
	 */
	public Date getRevocationTimeInstant()
	{
		return revocationTimeInstant;
	}

	/**
	 * Returns the reason of revocation or <code>null</code> if the certificate
	 * is not revoked.
	 * 
	 * @return the reason of revocation or <code>null</code> if the certificate
	 * is not revoked.
	 */
	public RevocationReason getRevocationReason()
	{
		return revocationReason;
	}
}
