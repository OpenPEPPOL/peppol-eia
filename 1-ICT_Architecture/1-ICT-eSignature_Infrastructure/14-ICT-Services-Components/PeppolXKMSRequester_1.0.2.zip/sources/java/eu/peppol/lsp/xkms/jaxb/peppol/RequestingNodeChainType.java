
package eu.peppol.lsp.xkms.jaxb.peppol;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import eu.peppol.lsp.xkms.jaxb.xkms.MessageExtensionAbstractType;


/**
 * <p>Java class for RequestingNodeChainType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RequestingNodeChainType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.w3.org/2002/03/xkms#}MessageExtensionAbstractType">
 *       &lt;sequence>
 *         &lt;element name="RequestingNode" type="{http://uri.etsi.org/02231/v2#}NonEmptyURIType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestingNodeChainType", propOrder = {
    "requestingNode"
})
public class RequestingNodeChainType
    extends MessageExtensionAbstractType
{

    @XmlElement(name = "RequestingNode")
    protected List<String> requestingNode;

    /**
     * Gets the value of the requestingNode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestingNode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestingNode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getRequestingNode() {
        if (requestingNode == null) {
            requestingNode = new ArrayList<String>();
        }
        return this.requestingNode;
    }

}
