/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.service.esp;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

import javax.servlet.ServletContext;
import javax.xml.ws.WebServiceContext;

import at.m2n.IntelligenceManagement.peppol.service.reasoner.PeppolOWLDLReasonerService;
import at.m2n.IntelligenceManagement.peppol.service.reasoner.PeppolStep1ReasonerService;
import at.m2n.IntelligenceManagement.peppol.service.reasoner.PeppolStep2ReasonerService;
import at.m2n.IntelligenceManagement.peppol.service.reasoner.ReasonerService;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant.Name;

import com.hp.hpl.jena.ontology.OntDocumentManager;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.util.FileManager;

public class ESPInterfaceContext {
	private static final String KEY_SERVLET_CONTEXT = "javax.xml.ws.servlet.context";
	private static final String KEY_INIT_VHOSTS_PATH = "at.m2n.peppol.service.esp.vhosts";
	private static final String DEFAULT_VHOSTS_PATH = "vhosts/";

	private final VcdSchemaVariant TENDERER_SKELETON;
	private final VcdSchemaVariant TENDERER_CRITERION_SUGGESTED_SKELETON;
	private final VcdSchemaVariant TENDERER_CRITERION_SELECTED_SKELETON;
	private final VcdSchemaVariant TENDERER_CRITERION_EVIDENCE_SKELETON;

	private final Model schemaModel;																						

	private PeppolOWLDLReasonerService	rsOWL																	= new PeppolOWLDLReasonerService();
	private PeppolStep1ReasonerService	rsStep1																= new PeppolStep1ReasonerService();
	private PeppolStep2ReasonerService	rsStep2																= new PeppolStep2ReasonerService();


	public ESPInterfaceContext() throws IOException, MalformedURLException { // thrown in initializers for the schema variants
		OntDocumentManager.getInstance().getFileManager().setModelCaching(false);
		FileManager.get().setModelCaching(false);
		
		String schemaPath = "/schema/VCDSchema1.3.1/xsd/";
		
		
		TENDERER_SKELETON						= VcdSchemaVariant.newInstance(schemaPath, Name.TENDERER_SKELETON);
		TENDERER_CRITERION_SUGGESTED_SKELETON	= VcdSchemaVariant.newInstance(schemaPath, Name.TENDERER_CRITERION_SKELETON);
		TENDERER_CRITERION_SELECTED_SKELETON	= VcdSchemaVariant.newInstance(schemaPath, Name.TENDERER_CRITERION_SKELETON);
		TENDERER_CRITERION_EVIDENCE_SKELETON	= VcdSchemaVariant.newInstance(schemaPath, Name.TENDERER_CRITERION_EVIDENCE_SKELETON);

		schemaModel = createSchemaModel();
	}



	private Model createSchemaModel() throws IOException {
		OntModel retVal = ModelFactory.createOntologyModel();

		read(retVal, "/ontology/schema/ossso/collector-schema.n3");
		read(retVal, "/ontology/schema/ossso/common.n3");
		read(retVal, "/ontology/schema/ossso/criterion-schema.n3");
		read(retVal, "/ontology/schema/ossso/fri_tenderer-schema_party.n3");
		read(retVal, "/ontology/schema/ossso/m2n-compatibility.n3");
		read(retVal, "/ontology/schema/ossso/tenderer-criterion-schema.n3");
		read(retVal, "/ontology/schema/ossso/tenderer-schema.n3");

		read(retVal, "/ontology/mappings/countries.n3");
		read(retVal, "/ontology/mappings/eu.n3");

		read(retVal, "/ontology/mappings/at.n3");
		read(retVal, "/ontology/mappings/de_vol.n3");
		read(retVal, "/ontology/mappings/de_vob.n3");
		read(retVal, "/ontology/mappings/fr.n3");
		read(retVal, "/ontology/mappings/it.n3");
		read(retVal, "/ontology/mappings/no.n3");
		read(retVal, "/ontology/mappings/gr_sp.n3");

		read(retVal, "/ontology/mappings/other.n3");

		Model m = ModelFactory.createDefaultModel();
		m.add(retVal);
		return m;
	}


	private void read(Model m, String url) throws IOException {
		InputStream in = getClass().getResourceAsStream(url);
		try {
		  m.read(in, "", "N3");
		} finally {
		  in.close();
		}
	}



	public VcdSchemaVariant getVariantTendererSkeleton() {
		return TENDERER_SKELETON;
	}



	public VcdSchemaVariant getVariantTendererCriterionSuggestedSkeleton() {
		return TENDERER_CRITERION_SUGGESTED_SKELETON;
	}



	public VcdSchemaVariant getVariantTendererCriterionSelectedSkeleton() {
		return TENDERER_CRITERION_SELECTED_SKELETON;
	}



	public VcdSchemaVariant getVariantTendererCriterionEvidenceSkeleton() {
		return TENDERER_CRITERION_EVIDENCE_SKELETON;

	}



	public ReasonerService getReasonerOWL() {
		return rsOWL;
	}



	public ReasonerService getReasonerStep1() {
		return rsStep1;
	}



	public ReasonerService getReasonerStep2() {
		return rsStep2;
	}



	public Model getSchemaModel() {
		return schemaModel;
	}
	
	
	
	
}
