/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.service.compoundVCD;

import javax.activation.DataHandler;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.xml.bind.annotation.XmlMimeType;

import at.m2n.peppol.service.FileFormatFault;
import at.m2n.peppol.service.InternalErrorFault;
import at.m2n.peppol.service.TokenFault;

@WebService(targetNamespace = "http://service.peppol.m2n.at/CompoundVCD/DNVS/")
@SOAPBinding(style = Style.RPC)
public class DNVSInterface {

    
    @WebMethod
    @WebResult(name="ProcessID")
  public String completeVCD(                                 
                                     @XmlMimeType("application/zip")
                                     @WebParam(partName="tceSkeleton")
                                     DataHandler tceSkeleton,

                                     @WebParam(partName="vcdUUID")
                                     String vcdUUID,

                                     @WebParam(partName="delegateUserEMail")
                                     String email,

                                     @WebParam(partName="authenticationToken")
                                     String authenticationToken
                                     
  
  ) throws InternalErrorFault, FileFormatFault, TokenFault {
        return "";
  }

    
    @WebMethod
  public void cancelVCDCompletion(                                 
                                     @WebParam(partName="processID")
                                     String processID,

                                     @WebParam(partName="authenticationToken")
                                     String authenticationToken
                                     
  
  ) throws InternalErrorFault, TokenFault {
  }
    
}
