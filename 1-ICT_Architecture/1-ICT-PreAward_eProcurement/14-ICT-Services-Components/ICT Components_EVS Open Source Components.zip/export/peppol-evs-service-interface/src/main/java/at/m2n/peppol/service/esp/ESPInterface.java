/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.service.esp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.soap.MTOM;

import org.apache.log4j.Logger;
import org.apache.log4j.lf5.util.StreamUtils;

import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;
import at.m2n.IntelligenceManagement.osSso.service.ServiceResult;
import at.m2n.IntelligenceManagement.peppol.service.reasoner.ReasonerService;
import at.m2n.IntelligenceManagement.vcd.packing.VcdZipWriter;
import at.m2n.IntelligenceManagement.vcd.saver.TransformerSupport;
import at.m2n.IntelligenceManagement.vcd.saver.XmlSaver;
import at.m2n.IntelligenceManagement.vcd.transformer.Owl2XmlTransform;
import at.m2n.IntelligenceManagement.vcd.transformer.Xml2OwlTransform;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;
import at.m2n.peppol.service.FileFormatFault;
import at.m2n.peppol.service.InternalErrorFault;
import at.m2n.peppol.service.TokenFault;

import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;
import com.hp.hpl.jena.rdf.model.impl.StatementImpl;
import com.hp.hpl.jena.vocabulary.RDF;

@WebService(targetNamespace = "http://service.peppol.m2n.at")
@SOAPBinding(style = Style.RPC)
@MTOM
public class ESPInterface {
    @javax.annotation.Resource
    private WebServiceContext serviceContext;

	ESPInterfaceContext ctx;

    private Logger log = Logger.getLogger(getClass());

    private synchronized void initContext() throws InternalErrorFault {
        try {
            if (ctx == null)
                ctx = new ESPInterfaceContext();
        } catch (MalformedURLException mue) {
            throw new InternalErrorFault("Configuration problem: " + mue);
        } catch (IOException ioe) {
        	throw new InternalErrorFault("IO problem: " + ioe);
        }
  	}



	/** Suggest criteria for the given Tenderer Structure.
   * @parameter tSkeleton A Tenderer-Skeleton (a VCD Package Container containing only tenderer structure but no criterion/evidence info)
     * @parameter authenticationToken A Token authenticating the caller.
   * @return A Tenderer-Criterion-Skeleton (a VCD Package Container containing the tenderer structure and all the suggested criteria for each TSE) 
   * TODO: an alternative would be to have ALL criteria in the TC-Skeleton and use the RequestedIndicator element to mark suggestions. 
     */
    @WebMethod
    @XmlMimeType("application/zip")
  public DataHandler suggestCriteria(                                  
                                     @XmlMimeType("application/octet-stream")
                                     @WebParam(partName="tSkeleton")
                                     DataHandler tSkeleton,

                                     @WebParam(partName="authenticationToken")
                                     String authenticationToken) throws InternalErrorFault, FileFormatFault, TokenFault {

        initContext();

        File savedPreSkeleton = null;

        try {
            // save the tskel
            savedPreSkeleton = saveSkeletonContainer(tSkeleton);

			File exportedSkeleton = doSuggestCriteria(savedPreSkeleton);

			// return the tcskel
			DataHandler ret = new DataHandler(new FileDataSource(exportedSkeleton));

            if (!savedPreSkeleton.delete())
                savedPreSkeleton.deleteOnExit();

			return ret;
			
  	} catch (Exception e) {
  		errorlog("suggestCriteria Error", savedPreSkeleton, e);
      return failInternal(e, savedPreSkeleton);
		} finally {
			infolog("suggestCriteria finished", savedPreSkeleton);
    }
  }



    /** 
     * @param savedPreSkeleton the pre-skeleton package XML file or the ZIP container 
     **/
	File doSuggestCriteria(File savedPreSkeleton) throws InternalErrorFault,
			FileFormatFault, InterruptedException {
            infolog("suggestCriteria called", savedPreSkeleton);

		Model schemaModel = ctx.getSchemaModel();
		OntModel schemaOntModel = ModelFactory.createOntologyModel(OntModelSpec.RDFS_MEM, schemaModel);
		
            // import it into a model
		Model m = importSkeleton(savedPreSkeleton, ctx.getVariantTendererSkeleton(), schemaOntModel);

		infolog("suggestCriteria imported "+m.size()+" statements", savedPreSkeleton);

//		System.out.println("\n\nmodel dump!");
//		m.write(System.out, "N3", "");
//		System.out.println("\n\n");

	  	OsssoModel model = setupOsssoModel(m, schemaModel);

	  	try {
            // services: OWL DL, peppol-step-1
            // call ossso (or only the relevant services)
			Model m2 = doTheOsssoWorkSuggestCriteria(model, savedPreSkeleton);

            infolog("suggestCriteria reasoned to " + m2.size() + " statements", savedPreSkeleton);

//			System.out.println("\n\nmodel dump!");
//			m2.write(System.out, "N3", ""); 
//			System.out.println("\n\n");
			
			

            // export the model into a tcskel (suggested)
			File exportedSkeleton = exportSkeleton(m2, ctx.getVariantTendererCriterionSuggestedSkeleton(), TransformerSupport.TS_ESP, savedPreSkeleton);

            infolog("suggestCriteria exported to " + exportedSkeleton, savedPreSkeleton);
			return exportedSkeleton;
	  	} finally {
	  		model.close();
	  	}
    }


    private void infolog(String message, File f) {
        log.info(message + " [" + f + "]");
    }

    private void errorlog(String message, File f, Throwable t) {
        log.error(message + " [" + f + "]", t);
        t.printStackTrace();
    }


	/** Suggest possible evidences for the given Tenderer Structure.
   * @parameter tcSkeleton A Tenderer-Criterion-Skeleton (a VCD Package Container containing only tenderer structure and selected criteria for each TSE but no evidences)
     * @parameter authenticationToken A Token authenticating the caller.
   * @return A Tenderer-Criterion-Evidence-Skeleton (a VCD Package Container containing only tenderer structure, the selected criteria for each TSE, and suggested evidences for each criterion of each TSE)
     */
    @WebMethod
    @XmlMimeType("application/zip")
  public DataHandler suggestEvidences(                                  
                                     @XmlMimeType("application/octet-stream")
                                     @WebParam(partName="tcSkeleton")
                                     DataHandler tcSkeleton,

                                     @WebParam(partName="authenticationToken")
                                     String authenticationToken) throws InternalErrorFault, FileFormatFault, TokenFault {

        initContext();
        File saved = null;
        try {
            // save the tcskel(selected)
            saved = saveSkeletonContainer(tcSkeleton);

            infolog("suggestEvidences called", saved);

			File exportedSkeleton = doSuggestEvidences(saved);

            infolog("suggestEvidences exported as " + exportedSkeleton, saved);

            // return the tceskel
            DataHandler ret = new DataHandler(new FileDataSource(exportedSkeleton));
            
            if (!saved.delete())
                saved.deleteOnExit();
            
            return ret;

		} catch (Exception e) {
            errorlog("suggestEvidences Error", saved, e);
            return failInternal(e, saved);
		} finally {
            infolog("suggestEvidences finished", saved);
        }
    }

    
  
	File doSuggestEvidences(File saved) throws InternalErrorFault,
			FileFormatFault, InterruptedException {
		
		Model schemaModel = ctx.getSchemaModel();
		OntModel schemaOntModel = ModelFactory.createOntologyModel(OntModelSpec.RDFS_MEM, schemaModel); 
		
		// import it into a model (no need to build collectors, just set the wantsToProve for the included criteria)
		Model m = importSkeleton(saved, ctx.getVariantTendererCriterionSelectedSkeleton(), schemaOntModel);
		
		infolog("suggestEvidences imported "+m.size()+" statements", saved);

		// services: OWL DL (needed for all the steps), peppol-step-1 (so we know what was suggested), peppol-step-2, peppol-step-3
		// call ossso (or only the relevant services)
		OsssoModel model = setupOsssoModel(m, schemaModel);

		try {
			Model m2 = doTheOsssoWorkSuggestEvidences(model, saved);

			infolog("suggestEvidences reasoned to "+m2.size()+" statements", saved);

		// export the model into a tceskel (suggested)
		File exportedSkeleton = exportSkeleton(m2, ctx.getVariantTendererCriterionEvidenceSkeleton(), TransformerSupport.TS_ESP, saved);
		return exportedSkeleton;
		} finally {
			model.close();
	}
	}

    
  

  
  
  
  
  
  
  

  private DataHandler failInternal(Exception e, File skeleton) throws InternalErrorFault {
  	log.error("Internal Error Fault", e);
		throw new InternalErrorFault(e.getMessage() + " ["+(skeleton==null?"no file":skeleton.getPath())+"]");
	}

    private DataHandler failFileFormat(Exception e) throws FileFormatFault {
        log.error("File Format Fault", e);
        e.printStackTrace();
        throw new FileFormatFault(e.getMessage());
    }

    private static final String PEPPOL = "http://m2n.at/2009/05/peppol/";
    private static final Property P_SUGGESTED = new PropertyImpl(PEPPOL + "suggestedCANC");
    private static final Property P_POSSIBLE = new PropertyImpl(PEPPOL + "possibleCANC");
    private static final Property P_WANTS = new PropertyImpl(PEPPOL + "wantsToProveCANC");

  private Model doTheOsssoWorkSuggestCriteria(OsssoModel model, File f) throws InterruptedException {

  	  	reason(model, ctx.getReasonerOWL(), f);
  	  	reason(model, ctx.getReasonerStep1(), f);

  	  	Model m = model.getOperatingModelWithoutBase();

        List<Statement> addMe = new ArrayList<Statement>();
        convertSuggestions(m, P_SUGGESTED, addMe);
        convertSuggestions(m, P_POSSIBLE, addMe);
        m.add(addMe);
  	
  	  	reason(model, ctx.getReasonerStep2(), f);

  	  	//This is a workaround because for some reason, bidding consortia ended up having type SingleTenderer as well, leading to the xml-export getting confused. Only happened in SOAP Interface, not in GUI.. for whatever reason..
  	  	List<Statement> delete = new LinkedList<Statement>();
  	  	StmtIterator iter = m.listStatements(null, RDF.type, new ResourceImpl(PEPPOL+"BiddingConsortium"));
  	  	while (iter.hasNext()) {
  	  		Resource rBC = iter.nextStatement().getSubject();
  	 		delete.add(new StatementImpl(rBC, RDF.type, new ResourceImpl(PEPPOL+"SingleTenderer")));
  	  	}  
  	  	iter.close();
  	  	m.remove(delete); 
  	  	
  	  	
  		return m;
    }



    private void convertSuggestions(Model m, Property pSugg, List<Statement> addMe) {
        StmtIterator iter = m.listStatements(null, pSugg, (RDFNode) null);
        while (iter.hasNext()) {
            Statement stmt = iter.nextStatement();
            addMe.add(m.createStatement(stmt.getSubject(), P_WANTS, stmt.getObject()));
        }
        iter.close();
    }





	private Model doTheOsssoWorkSuggestEvidences(OsssoModel model, File f) throws InterruptedException {
			reason(model, ctx.getReasonerOWL(), f);
			reason(model, ctx.getReasonerStep2(), f); // builds collectors from wantstoprove

        return model.getOperatingModelWithoutBase();
    }

  
  
  
  private OsssoModel setupOsssoModel(Model m, Model schemaModel) {
  	OsssoModel model = new OsssoModel(schemaModel);
        model.getOperatingModelWithoutBase().add(m);
        return model;
    }


	private void reason(OsssoModel model, ReasonerService rs, File f) throws InterruptedException {
		try {
			long start = System.currentTimeMillis();
        ServiceExecution se = rs.call(Collections.<Node_Variable, Node_Concrete> emptyMap(), null, null, model);
        ServiceResult sr = se.getResultBlocking();
        sr.applyToModel(model);
		  	
		  	long end = System.currentTimeMillis();
		  	long diff = end-start;
		  	float diffs = ((float)diff)/1000f;
		  	infolog(String.format("reasoning %s took %.2f s", rs, diffs), f);
		  	
		  	Exception e = sr.getException();
		  	if (e != null) {
		  		log.error("Reasoning failure:", e);
    }
		} catch (Throwable t) {
			log.error("Reasoning failure 2:", t);
		}
	}





  
  


    private File saveSkeletonContainer(DataHandler skeletonContainer) throws IOException {
        File f = File.createTempFile("SkeletonContainer", ".zip");
        try {
            InputStream is = skeletonContainer.getInputStream();
            OutputStream os = new FileOutputStream(f);
            StreamUtils.copyThenClose(is, os);
    } catch (IOException ioe) {
            log.error("IOE copying stream", ioe);
        }

        return f;
    }

  private Model importSkeleton(File savedPreSkeleton, VcdSchemaVariant variant, OntModel schemaOntModel) throws InternalErrorFault, FileFormatFault {
        try {
      Model m = new Xml2OwlTransform().transform(schemaOntModel, savedPreSkeleton.toURL().toString(), variant);

            postprocess(m);

            return m;

    } catch (ParserConfigurationException pce) {
            failInternal(pce, savedPreSkeleton);
            return null;
    } catch (Exception se) {
    	log.error("Error importing skeleton.", se);
    	failFileFormat(se);
    	return null;
    }
    }

    private void postprocess(Model m) {

    }


	private File exportSkeleton(Model model, VcdSchemaVariant variant, TransformerSupport transformerSupport, File saved) throws InternalErrorFault {
		File validateMe = null; 
        try {
            XmlSaver saver = new Owl2XmlTransform().transform(ctx.getSchemaModel(), model, variant, transformerSupport, null);

            validateMe = new VcdZipWriter().pack(saver, "");
            String validationErrors = saver.validate();   // must be called explicitly if needed
            return validateMe;
        } catch (Exception e) {
            failInternal(e, validateMe != null ? validateMe : saved);
            return null;
		} finally {

        }
    }

	
	
	
	
}
