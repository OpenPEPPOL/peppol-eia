/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.xml.parsers.ParserConfigurationException;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.loader.XmlLoader;
import at.m2n.IntelligenceManagement.vcd.mapping.MapperVariant;
import at.m2n.IntelligenceManagement.vcd.mapping.Xml2OwlMapper;
import at.m2n.IntelligenceManagement.vcd.transformer.xml2owl.Xml2OwlIterator;
import at.m2n.IntelligenceManagement.vcd.transformer.xmladjust.XmlAdjusterChain;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.Model;

/**
 * Facade class for the XML->RDF transformation direction.
 * Transforms passed XML document(s) (with some data from schema model)
 * into a VCD-specified RDF representation.
 * 
 * @author Fritz Ritzberger  17.06.2010
 */
public class Xml2OwlTransform {

    /**
     * Transform passed VCDPackage and VCD XML referenced from there into RDF.
     * @param schemaModel the RDF model containing meta-data for the data to extract from XML.
     * @param vcdPackageXmlFileUrl the URL of the VCDPackage.xml file.
     * @return the model containing the RDF instance data extracted from XML input.
     * @throws IOException when some input/output operation fails.
     * @throws JDOMException when some XML editing action fails.
     * @throws SAXException when XML reading or validation fails.
     * @throws ParserConfigurationException 
     */
    public Model transform(
            OntModel schemaModel,
            String vcdPackageXmlFileUrl,
            VcdSchemaVariant schemaVariant)
    throws JDOMException, IOException, ParserConfigurationException, SAXException    {
        
        Xml2OwlMapper mapper = newMapper(schemaVariant);
        
        Document preSkeleton = new XmlLoader(schemaVariant).load(vcdPackageXmlFileUrl, shouldValidate());
        preSkeleton = new XmlAdjusterChain(mapper).preProcessXml2Rdf(preSkeleton);
        
        return new Xml2OwlIterator(mapper).transform(preSkeleton, schemaModel, null);
    }

    /**
     * Made this overridable for use in unit tests.
     * @param vhostDirectory TODO
     * @return a Mapper instance.
     * @throws MalformedURLException 
     */
    protected Xml2OwlMapper newMapper(VcdSchemaVariant schemaVariant) throws MalformedURLException    {
        return new Xml2OwlMapper(schemaVariant, MapperVariant.Get.get(schemaVariant));
    }

    /** @return true if this transformer should validate XML input. Default is true. */
    protected boolean shouldValidate()  {
        return true;
    }
}
