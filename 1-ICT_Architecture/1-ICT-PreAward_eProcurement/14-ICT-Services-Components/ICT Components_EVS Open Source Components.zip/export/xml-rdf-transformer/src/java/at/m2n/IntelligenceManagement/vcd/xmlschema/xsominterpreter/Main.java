/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.mapping.CommonMappingNames;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;
import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.util.PrintXmlIterator;

/**
 * Demo main class for the XSOM interpreter, outputting XML descriptions of all schema
 * variants into sub-directory "xmloutput".
 * 
 * @author Fritz Ritzberger 05.07.2010
 */
public class Main {
    
    /** Test main. */
    public static void main(String[] args) throws Exception {
        System.err.println("Standing in "+System.getProperty("user.dir"));
        final File vhostDirectory = new File("../runner-server/vhosts/ossso_uis/");

        VcdSchemaVariant.Name [] schemaVariantNames = new VcdSchemaVariant.Name [] {
                VcdSchemaVariant.Name.PRESKELETON,
                VcdSchemaVariant.Name.SKELETON,
                VcdSchemaVariant.Name.FULL,
        };
        
        final String pkgFilename = "vcdpackage.template.xml";
        final VcdSchemaVariant pkgSchemaVariant = VcdSchemaVariant.newInstance(vhostDirectory, VcdSchemaVariant.Name.FULL);
        printSchemaInfo(pkgSchemaVariant.vcdPackageSchemaUrl, CommonMappingNames.XML_VCDPACKAGE_ROOT_ELEMENT, pkgFilename);
        
        for (VcdSchemaVariant.Name variant : schemaVariantNames)    {
            final String filename = "vcd"+variant.toString().toLowerCase()+".template.xml";
            VcdSchemaVariant schemaVariant = VcdSchemaVariant.newInstance(vhostDirectory, variant);
            printSchemaInfo(schemaVariant.vcdSchemaUrl, CommonMappingNames.XML_VCD_ROOT_ELEMENT, filename);
        }
    }

    private static void printSchemaInfo(String schemaUrl, String rootElementName, String filename) throws SAXException, IOException   {
        XsomInterpreter interpreter = new XsomInterpreter(schemaUrl);
        Element descr = interpreter.getTopLevelElementDescriptor(rootElementName, null);
        
        File outputFile = new File(getPackagePath(), filename);
        PrintStream ps = new PrintStream(new BufferedOutputStream(new FileOutputStream(outputFile)));
        new PrintXmlIterator(ps).print(descr);
        ps.close();
    }
    
    private static String getPackagePath()  {
        String clazz = Main.class.getName();
        clazz = clazz.substring(0, clazz.lastIndexOf('.')).replace('.', '/');
        return "src/java/" + clazz + "/xmloutputs/";
    }
    
}

