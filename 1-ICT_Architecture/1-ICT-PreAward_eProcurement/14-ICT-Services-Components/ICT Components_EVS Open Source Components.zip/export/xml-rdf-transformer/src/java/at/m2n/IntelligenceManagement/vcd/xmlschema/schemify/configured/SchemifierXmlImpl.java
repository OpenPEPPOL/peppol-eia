/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.schemify.configured;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import at.m2n.IntelligenceManagement.vcd.util.JdomXmlUtil;
import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.xmlschema.Schemifier;

/**
 * Schemifier implementation that works with original schema files and XSOM library.
 * 
 * @author Fritz Ritzberger  07.07.2010
 */
public class SchemifierXmlImpl implements Schemifier.Impl {
    
    private static final Logger log = Logger.getLogger(SchemifierXmlImpl.class);
    
    private final Document vcdTemplate;
    private final Document vcdPackageTemplate;
    private final Map<Path.Part,Boolean> isFolderMap = new Hashtable<Path.Part,Boolean>();
    
    public SchemifierXmlImpl(boolean isFullPackageTransform) throws JDOMException, IOException {
        SAXBuilder builder = new SAXBuilder();
        InputStream in = null;
        try {
            in = getClass().getResourceAsStream("vcdpackage.template.xml");
            this.vcdPackageTemplate = builder.build(in);
            in.close();
            
            in = getClass().getResourceAsStream(isFullPackageTransform ? "vcdfull.template.xml" : "vcdskeleton.template.xml");
            this.vcdTemplate = builder.build(in);
            
            buildIsFolderMap();
        }
        finally {
            try { in.close(); } catch (Exception e) { /* Gracefully ignore this. */ }
        }
    }
    
    /**
     * @param element the element for which it should be decided if it is a folder or leaf.
     * @return true when passed element is a folder element and not a leaf element.
     */
    @Override
    public boolean isFolderElement(Path.Part element) {
        return isFolderMap.get(element) != null;
    }
    
    /**
     * Adds required and missing elements,
     * then sorts all elements according to schema information.
     * @param document the XML document to rectify.
     */
    @Override
    public void schemify(Document document) {
        Element root = document.getRootElement();
        Element compareElement;
        if (root.getName().equals(vcdPackageTemplate.getRootElement().getName()) &&
                root.getNamespace().getURI().equals(vcdPackageTemplate.getRootElement().getNamespaceURI()))   {
            compareElement = vcdPackageTemplate.getRootElement();
        }
        else if (root.getName().equals(vcdTemplate.getRootElement().getName()) &&
                    root.getNamespace().getURI().equals(vcdTemplate.getRootElement().getNamespaceURI()))   {
            compareElement = vcdTemplate.getRootElement();
        }
        else
            throw new IllegalArgumentException("Unkown root element in document: "+root.getName()+", namespace: "+root.getNamespaceURI());
        
        addRequiredElements(root, compareElement);
        sortElements(root, compareElement);
    }

    private void addRequiredElements(final Element element, final Element compareElement)    {
        assert compareElement != null : "Element found that is not in XML template: name="+JdomXmlUtil.xpath(element);
        final Element resolvedCompareElement = resolveRecursiveElement(compareElement);
        
        List children = element.getChildren();  // this is a JDOM "live" List
        List compareChildren = resolvedCompareElement.getChildren();

        for (Object o : compareChildren)   {
            Element compareChild = (Element) o;
            String minOccursString = compareChild.getAttributeValue("minOccurs");
            assert minOccursString != null : "No minOccurs attribute found in template element "+compareChild.getName()+", please add one";
            
            int minOccurs = Integer.parseInt(minOccursString);
            if (minOccurs > 0 && element.getChild(compareChild.getName(), compareChild.getNamespace()) == null)   {
                log.info("Found missing element "+xpath(compareChild)+", adding "+minOccurs);
                
                for (int i = 0; i < minOccurs; i++) {
                    Element missingElement = new Element(compareChild.getName(), compareChild.getNamespace());
                    children.add(missingElement);
                }
            }
        }
        
        for (Object o : children)   {   // continue recursively
            Element child = (Element) o;
            addRequiredElements(child, getCompareChild(resolvedCompareElement, child));
        }
    }

    private void sortElements(final Element element, final Element compareElement)    {
        final Element resolvedCompareElement = resolveRecursiveElement(compareElement);
        
        List children = element.getChildren();  // this is a JDOM "live" List
        final List compareChildren = resolvedCompareElement.getChildren();

        Comparator comparator = new Comparator()    {
            @Override
            public int compare(Object o1, Object o2) {
                Element e1 = (Element) o1;  // provoke ClassCastException
                Element e2 = (Element) o2;
                Element parallelChild1 = resolvedCompareElement.getChild(e1.getName(), e1.getNamespace());  // provoke NullPointerException
                assert parallelChild1 != null : "Element found that is not in XML template: name="+e1.getName()+", namespace="+e1.getNamespaceURI();
                Element parallelChild2 = resolvedCompareElement.getChild(e2.getName(), e2.getNamespace());
                assert parallelChild2 != null : "Element found that is not in XML template: name="+e2.getName()+", namespace="+e2.getNamespaceURI();
                return compareChildren.indexOf(parallelChild1) - compareChildren.indexOf(parallelChild2);
            }
        };
        
        // JDOM problem on sorting, so sort a clone and renew the list after
        // org.jdom.IllegalAddException: The Content already has an existing parent "vcdp:VCDPackage"
        final List clone = new ArrayList(children);
        Collections.sort(clone, comparator);
        children.clear();   // remove all curent children
        for (Object o : clone)  // add the sorted list of children
            children.add((Element) o);
        
        for (Object o : children)   {   // continue recursively
            Element child = (Element) o;
            sortElements(child, getCompareChild(resolvedCompareElement, child));
        }
    }

    private void buildIsFolderMap() {
        buildIsFolderMap(vcdPackageTemplate.getRootElement());
        buildIsFolderMap(vcdTemplate.getRootElement());
    }

    private void buildIsFolderMap(Element element) {
        List children = element.getChildren();
        if (element.getChildren().size() > 0)
            isFolderMap.put(new Path.Part(element.getNamespaceURI(), element.getName()), Boolean.TRUE);
        for (Object o : children)
            buildIsFolderMap((Element) o);
    }

    private Element getCompareChild(Element compareElementParent, Element child)   {
        return compareElementParent.getChild(child.getName(), child.getNamespace());
    }
    
    private Element resolveRecursiveElement(Element compareElement) {
        String unresolved = compareElement.getAttributeValue("unresolved");
        if (unresolved == null || unresolved.equalsIgnoreCase("true") == false)
            return compareElement;
        
        return resolveRecursiveElement(compareElement.getName(), compareElement.getNamespaceURI(), compareElement.getDocument().getRootElement());
    }

    private Element resolveRecursiveElement(String name, String namespace, Element element) {
        String unresolved = element.getAttributeValue("unresolved");
        if ((unresolved == null || unresolved.equalsIgnoreCase("true") == false) && // if not unresolved
                name.equals(element.getName()) && namespace.equals(element.getNamespaceURI()))
            return element;
        
        for (Object o : element.getChildren())   {
            Element found = resolveRecursiveElement(name, namespace, (Element) o);
            if (found != null)
                return found;
        }
        
        return null;
    }

    /** Debug helper */
    private String xpath(Element e) {
        return JdomXmlUtil.xpath(e);
    }

}
