/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xmladjust;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.jdom.Document;

import at.m2n.IntelligenceManagement.vcd.mapping.Mapper;

/**
 * The <i>XmlAdjuster</i> facade class.
 * This copies, moves and removes XML elements as an XML->RDF pre-processing
 * and an RDF->XML post-processing.
 * The chain consists of 1-n XmlAdjuster interface implementations, and it
 * is processed from head to tail for XML->RDF and from tail to head for RDF->XML.
 * 
 * @author Fritz Ritzberger  07.06.2010
 */
public class XmlAdjusterChain {
    
    private List<AbstractXmlAdjuster> chain = new ArrayList<AbstractXmlAdjuster>();
    
    /**
     * Creates a adjuster chain that already contains XmlAdjuster instances for VCD.
     */
    public XmlAdjusterChain(Mapper mapper) {
        // Add adjusters in order to be processed for XML->RDF.
        // For RDF->XML they will run in reverse order.
    	
    	chain.add(new LanguageTagsAdjuster());
        chain.add(new EvidenceTitle2OntologyDefinitionRegulationAdjuster());
        chain.add(new RequestedIndicatorAdjuster());
        chain.add(new EconomicOperatorNaturalPersonAdjuster());
        chain.add(new EvidenceAdjuster());
        
        for (AbstractXmlAdjuster adjuster : chain)
            adjuster.setMapper(mapper);
    }
    
    /**
     * Processes the chain from head to tail to create XML transformable to RDF.
     * @param document the input document to process.
     * @return the adjusted document (is the same as input document, just a for convenience).
     */
    public Document preProcessXml2Rdf(Document document)   {
        for (AbstractXmlAdjuster adjuster : chain)
            document = adjuster.xml2Rdf(document);

        return document;
    }
    
    /**
     * Processes the chain from head to tail to create XML transformable to RDF.
     * @param document the input document to process.
     * @return the adjusted document (is the same as input document, just a for convenience).
     */
    public Document postProcessRdf2Xml(Document document)   {
        List<AbstractXmlAdjuster> reverseChain = new ArrayList<AbstractXmlAdjuster>(chain);
        Collections.reverse(reverseChain);
        
        for (AbstractXmlAdjuster adjuster : reverseChain)
            document = adjuster.rdf2Xml(document);

        return document;
    }

}
