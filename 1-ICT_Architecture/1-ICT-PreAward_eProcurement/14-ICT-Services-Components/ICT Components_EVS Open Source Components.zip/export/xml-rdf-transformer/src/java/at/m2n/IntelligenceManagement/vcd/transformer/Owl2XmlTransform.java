/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer;

import java.io.IOException;
import java.net.MalformedURLException;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.mapping.MapperVariant;
import at.m2n.IntelligenceManagement.vcd.mapping.Owl2XmlMapper;
import at.m2n.IntelligenceManagement.vcd.mapping.SaverXmlLogicImpl;
import at.m2n.IntelligenceManagement.vcd.saver.BlobDocumentResolver;
import at.m2n.IntelligenceManagement.vcd.saver.TransformerSupport;
import at.m2n.IntelligenceManagement.vcd.saver.TransformerSupportAppliance;
import at.m2n.IntelligenceManagement.vcd.saver.XmlSaver;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.Owl2XmlIterator;
import at.m2n.IntelligenceManagement.vcd.transformer.xmladjust.XmlAdjusterChain;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

import com.hp.hpl.jena.rdf.model.Model;

/**
 * Facade class for the RDF->XML transformation direction.
 * Transforms passed RDF instance model (with some data from schema model)
 * into a VCD-specified XML representation that conforms to the VCD XMLSchema.
 * 
 * @author Fritz Ritzberger  11.06.2010
 */
public class Owl2XmlTransform {

    private static final Logger log = Logger.getLogger(Owl2XmlTransform.class);
    
    /**
     * Transforms passed RDF. This is a facade for the transformer processing chain.
     * @param schemaModel the RDF schema for the transformation.
     * @param instancesModel the RDF individuals data for transformation.
     * @param isFullPackageTransformation true when this is a full-package transform (includes documents).
     * @param tansformerSupport provides IssuingService data and others.
     * @return a saver object ready to pack the transformation results e.g. into the file-system.
     * @throws SAXException 
     * @throws MalformedURLException 
     * @throws IOException when some input/output operation fails.
     * @throws JDOMException when some XML editing action fails.
     */
    public XmlSaver transform(
            Model schemaModel,
            Model instancesModel,
            VcdSchemaVariant schemaVariant,
            TransformerSupport transformerSupport,
            BlobDocumentResolver blobResolver) throws MalformedURLException, SAXException {
        

        
        // basic transformation
        Owl2XmlMapper mapper = newMapper(schemaVariant);
        Owl2XmlIterator transformer = new Owl2XmlIterator(schemaModel, mapper);
        Document skeleton = transformer.transform(instancesModel);
        
        log.debug(new XMLOutputter(Format.getPrettyFormat()).outputString(skeleton));

        // doing specific XML editing tasks like creating ids and idrefs
        skeleton = new XmlAdjusterChain(mapper).postProcessRdf2Xml(skeleton);
        new TransformerSupportAppliance(transformerSupport, skeleton, mapper, schemaVariant);

        // splitting, schemifying, further processings
        return new XmlSaver(
                skeleton,
                schemaVariant,
                newSaverLogic(),
                blobResolver);
    }

    /**
     * Made this overridable for use in unit tests.
     * @param isFullPackageTransformation see transform() parameter
     * @param vhostDirectory TODO
     * @return a Mapper instance.
     */
    protected Owl2XmlMapper newMapper(VcdSchemaVariant schemaVariant)    {
        return new Owl2XmlMapper(schemaVariant, MapperVariant.Get.get(schemaVariant));
    }

    /**
     * Made this overridable for use in unit tests.
     * @return a SaverLogic instance.
     */
    protected XmlSaver.SaverXmlLogic newSaverLogic()    {
        return new SaverXmlLogicImpl();
    }

}
