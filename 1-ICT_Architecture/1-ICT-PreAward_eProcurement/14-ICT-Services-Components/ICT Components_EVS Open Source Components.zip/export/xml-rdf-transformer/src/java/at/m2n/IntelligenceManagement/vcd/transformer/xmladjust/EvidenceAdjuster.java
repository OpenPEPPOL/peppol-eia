/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xmladjust;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;

import at.m2n.IntelligenceManagement.vcd.util.JdomXmlUtil;
import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

/**
 * This was made for the VCD case of RDF "evidenceCollector" that contains the
 * "tnCriterion" Property (comes from XML "EconomicOperatorNationalRegulation" XML child),
 * and the "suggestedPrimaryEvidence" (comes from XML "Evidence" element(s) referenced by
 * "ProvingEvidenceID"(s) in XML "Criterion" element).
 * 
 * @author Fritz Ritzberger  07.06.2010
 */
class EvidenceAdjuster extends AbstractXmlAdjuster {
    
    private static final Logger log = Logger.getLogger(EvidenceAdjuster.class);

    /**
     * Moves XML "Evidence" elements into the "Criterion" to where they are referenced,
     * into a transformer-temporary Criterion sub-folder named "EvidenceCollector".
     * Also moves the ECONOMIC_OPERATOR_NATIONAL_REGULATION element (child of Criterion)
     * into that collector.
     */
    @Override
    public Document xml2Rdf(Document document) {
        // in all Criterion elements, find referenced Evidence elements and copy them to
        // an EvidenceCollector sub-element (to create a structure similar to VCD ontology)
        // remove any ID elements that are used for chaining, these will not be mapped
        for (Element criterion :    // for all XML Criterion elements
                findByName(document.getRootElement(), getMapper().getCriterionDescr()))    {
            
            final Element criterionID =
                findSingleDirectChild(criterion, getMapper().getIdDescr());
            final Element economicOperatorNationalRegulation =
                findSingleDirectChild(criterion, getMapper().getEconomicOperatorNationalReglationDescr());
            
            // search every referenced Evidence
            for (Element provingEvidenceID :
                    findDirectChildren(criterion, getMapper().geProvingEvidenceIdDescr()))  {
                
                // find the evidence by Evidence.DocumentGroupID == Criterion.ProvingEvidenceID
                Element evidence = findEvidence(document, criterion, criterionID, provingEvidenceID.getText());

                final Element evidenceCollector = getMapper().newEvidenceCollector();
                criterion.addContent(evidenceCollector);
                final Element evidenceClone = copyElement(evidence, evidenceCollector);
                
                removeElement(provingEvidenceID);
                removeElement(findSingleDirectChild(evidenceClone, getMapper().getDocumentGroupIdDescr()));
                removeElements(findDirectChildren(evidenceClone, getMapper().getProvesCriterionIdDescr()));
                // do not remove original provesCriterionID as VCD-level Evidences will be removed after
                
                if (economicOperatorNationalRegulation != null)
                    copyElement(economicOperatorNationalRegulation, evidenceCollector);
            }
            
            removeElement(criterionID);
            removeElement(economicOperatorNationalRegulation);
        }

        // after all Evidences have been copied to their Criterion/EvidenceCollector, 
        // remove them from VCD root element
        for (Element evidence :    // for all XML Evidence elements
                findByName(document.getRootElement(), getMapper().getEvidenceDescr()))    {
            
            if (getMapper().isVcdElement(evidence.getParentElement()))
                removeElement(evidence);
        }
        
        return document;
    }
    
    private Element findEvidence(Document document, Element criterion, Element criterionID, String provingEvidId) {
        assert provingEvidId != null && provingEvidId.length() > 0 : "Empty ProvingEvidenceID found!";
        List<Element> documentGroupIDs = findByNameAndText(document.getRootElement(), getMapper().getDocumentGroupIdDescr(), provingEvidId);
        assert documentGroupIDs.size() == 1 : "Ambiguous ProvingEvidenceID found: "+provingEvidId+" in "+JdomXmlUtil.xpath(criterion);

        final Element evidence = ((Element) documentGroupIDs.get(0)).getParentElement();
        
        // check if reverse IDs are pointing to each other: Evidence.ProvesCriterionID == Criterion.ID
        checkForeignIds(criterionID, evidence);
        
        return evidence;
    }

    private void checkForeignIds(Element criterionID, Element evidence) {
        List<Element> provesCritIDs = findDirectChildren(evidence, getMapper().getProvesCriterionIdDescr());
        boolean found = false;
        for (Element e : provesCritIDs)
            if (e.getText().equals(criterionID.getText()))
                found = true;
        assert found : "The double chaining of criterion and evidence is wrong in "+JdomXmlUtil.xpath(criterionID);
    }

    /**
     * Moves the "Evidence" elements in "EvidenceCollector" (child of "Criterion")
     * to their enclosing VCD element at end, and chains them to their origin by IDs
     * (Evidence.ProvesCriterionID == Criterion.ID,
     * Criterion.ProvingEvidenceID == Evidence.DocumentGroupID).
     * 
     * TODO refactor big method
     */
    @Override
    public Document rdf2Xml(Document document) {
    	VcdSchemaVariant variant = getMapper().getSchemaVariant();
    	
    	if (variant.hasEvidenceDocuments())
    		return rdf2XmlFull(document);
    	else
    		return rdf2XmlSkeleton(document);
    }
    
    private Document rdf2XmlSkeleton(Document document) {
      makeOneCriterionForOneEvidenceCollector(document);
      // now there are all Criterions with just a single EvidenceCollector child
      
      // move EconomicOperatorNationalRegulaton from EvidenceCollector to its Criterion parent
      for (Element criterion :    // for all Criterion, and those that might have been added
              findByName(document.getRootElement(), getMapper().getCriterionDescr()))    {
          
          final Element evidenceCollector = findSingleDirectChild(criterion, getMapper().getEvidenceCollectorDescr(), false);
          
          final List<Element> evidences; 
          if (evidenceCollector != null) {
            // move the EconomicOperatorNationalRegulation to parent Criterion
            Element economicOperatorNationalRegulation = findSingleDirectChild(evidenceCollector, getMapper().getEconomicOperatorNationalReglationDescr(), false);
            if (economicOperatorNationalRegulation != null)
              moveElement(economicOperatorNationalRegulation, criterion);
            
            evidences = findDirectChildren(evidenceCollector, getMapper().getEvidenceDescr());
          } else {
          	evidences = null;
          }


          
          establishIdReferencesSkeleton(criterion, evidenceCollector,  evidences);
      }
      
      return document;
  }
    private Document rdf2XmlFull(Document document) {
        makeOneCriterionForOneEvidenceCollector(document);
        // now there are all Criterions with just a single EvidenceCollector child
        
        Map<String, String> serviceCollectorURIsToEvidenceIDs = new HashMap<String, String>();

        // move EconomicOperatorNationalRegulaton from EvidenceCollector to its Criterion parent
        for (Element criterion :    // for all Criterion, and those that might have been added
                findByName(document.getRootElement(), getMapper().getCriterionDescr()))    {
            
            final Element evidenceCollector = findSingleDirectChild(criterion, getMapper().getEvidenceCollectorDescr(), false);
          	final Set<Element> evidences = new HashSet<Element>();

            if (evidenceCollector != null) {
            	final List<Element> serviceCollectors = findDirectChildren(evidenceCollector, getMapper().getServiceCollectorDescr());
            	for (Element serviceCollector : serviceCollectors) {
            		String serviceCollectorURI = getOntologyUriFromElement(serviceCollector);
            		final Element evidence = findOrMakeEvidenceElement(document.getRootElement(), serviceCollector, serviceCollectorURI, serviceCollectorURIsToEvidenceIDs);
            	
            	
            		evidences.add(evidence);
            	}

              // move the EconomicOperatorNationalRegulation to parent Criterion
              Element economicOperatorNationalRegulation = findSingleDirectChild(evidenceCollector, getMapper().getEconomicOperatorNationalReglationDescr(), false);
              if (economicOperatorNationalRegulation != null)
                moveElement(economicOperatorNationalRegulation, criterion);
            } else {
            	log.warn("Criterion without EvidenceCollector discovered: "+criterion);
            }


            
            establishIdReferencesFull(criterion, evidenceCollector, null, new ArrayList<Element>(evidences));
            
        }
        
        //remove all service collectors
        removeElements(findByName(document.getRootElement(), getMapper().getServiceCollectorDescr()));
        removeElements(findDirectChildren(document.getRootElement(), getMapper().getEvidenceDescr()));
        
        generateDocumentIDs(findByName(document.getRootElement(), getMapper().getDocumentReferenceDescr()));
        
        return document;
    }



		private void generateDocumentIDs(List<Element> documentRefs) {
			for (Element documentRef : documentRefs) {
				String docId = getMapper().generateUuid4Xml();
				Element id = getMapper().newId();
				id.setText(docId);
				documentRef.addContent(id);
			}
		}

		private Element findOrMakeEvidenceElement(Element root, Element serviceCollector, String serviceCollectorURI, Map<String, String> serviceCollectorURIsToEvidenceIDs) {
			String evidenceId = findOrAllocateEvidenceId(serviceCollectorURI, serviceCollectorURIsToEvidenceIDs);

			//look through all evidences and try to find it
			List<Element> allEvidences = findDirectChildren(root, getMapper().getEvidenceDescr());
			for (Element evidence : allEvidences) {
				Element eId = findSingleDirectChild(evidence, getMapper().getDocumentGroupIdDescr());
				String id = eId.getText();
				
				if (id.equals(evidenceId)) {
					return evidence;
				}
			}

			//none found => create it!
			Element evidenceOrig = findSingleDirectChild(serviceCollector, getMapper().getEvidenceDescr());

			Element evidenceCopy = copyDeep(evidenceOrig);
			Element docGroupId = getMapper().newDocumentGroupId();
			docGroupId.setText(evidenceId);
			evidenceCopy.addContent(docGroupId);
			
			List<Element> docRefs = findDirectChildren(serviceCollector, getMapper().getDocumentReferenceDescr());
			for (Element docRef : docRefs) {
				evidenceCopy.addContent(copyDeep(docRef));
			}
			
			root.addContent(evidenceCopy);
			return evidenceCopy;
		}

		private String findOrAllocateEvidenceId(String serviceCollectorURI, Map<String, String> serviceCollectorURIsToEvidenceIDs) {
			String id = serviceCollectorURIsToEvidenceIDs.get(serviceCollectorURI);
			
			if (id == null) {
				id = getMapper().generateUuid4Xml();
				serviceCollectorURIsToEvidenceIDs.put(serviceCollectorURI, id);
				
			}

			return id;
		}

		private void makeOneCriterionForOneEvidenceCollector(Document document) {
        // Check if there are Criterion with more than one EvidenceCollector sub-elements
        // (this is a special case that originates from the RDF structure).
        // Resolve the multiple EvidenceCollectors by creating Criterion parent
        // clones in enclosing EconomicOperator, and putting each of them in one.
        for (Element criterion :    // for all XML Criterion elements
                findByName(document.getRootElement(), getMapper().getCriterionDescr()))    {
            
            List<Element> evidenceCollectors =
                findDirectChildren(criterion, getMapper().getEvidenceCollectorDescr());
            
            // leave evidence 0 here and move other evidences to
            // newly created Criterion clones 
            if (evidenceCollectors.size() > 1)  {
                evidenceCollectors.get(0);
                
                Element insertionParent = criterion.getParentElement();
                int index = insertionParent.getChildren().indexOf(criterion);
                
                // make a move-list to avoid concurrent modification exception of JDOM children list
                List<Element> movingList = new ArrayList<Element>();
                for (Element evidenceCollector : evidenceCollectors.subList(1, evidenceCollectors.size()))  {
                    evidenceCollector.getParentElement().removeContent(evidenceCollector);
                    movingList.add(evidenceCollector);
                }
                
                for (Element evidenceCollector : movingList)  {
                    Element newCriterion = copyDeep(criterion);
                    getMapper().removeEvidenceCollectorFrom(newCriterion);
                    newCriterion.addContent(evidenceCollector);
                    
                    int length = insertionParent.getChildren().size();
                    index++;
                    if (index < length)
                        insertionParent.addContent(index, newCriterion);
                    else
                        insertionParent.addContent(newCriterion);
                }
            }
        }
    }

    private void establishIdReferencesFull(Element criterion, Element evidenceCollector, Element serviceCollector, List<Element> evidences) {
    	if (evidences == null)
    		evidences = Collections.emptyList();
    	
        // find the enclosing VCD element
        final Element vcd = findParent(criterion, getMapper().getVcdDescr());
        assert vcd != null : "Could not find enclosing VCD element to move evidences to!";

        //find the owner of the criterion (the TSE)
        final Element criterionOwner = criterion.getParentElement();

        // assign an ID to Criterion
        final Element criterionID = getMapper().newId();
        final String critID = getMapper().generateUuid4Xml();
        criterionID.setText(critID);
        criterion.addContent(criterionID);
        
        
        // move EvidenceCollector Evidences from Criterion to VCD ancestor, create and chain IDs on both sides
        for (Element evidence : evidences)  {   // for all Evidence children of Criterion/EvidenceCollector
            final Element provesCriterionID = getMapper().newProvesCriterionId();
            provesCriterionID.setText(critID);
            
            final Element provingEvidenceID = getMapper().newProvingEvidenceId();

            // ID chaining:
            // Evidence.ProvesCriterionID == Criterion.ID
            // Criterion.ProvingEvidenceID == Evidence.DocumentGroupID
            Element existingEvidence = findEvidenceOnVcdLevel(vcd, evidence, criterionOwner);
            if (existingEvidence == null)   {   // there is an evidence with same ontology-URI on VCD level
              moveElement(evidence, vcd);
              existingEvidence = evidence;
            }
             
            final Element evidenceID = findSingleDirectChild(existingEvidence, getMapper().getDocumentGroupIdDescr());
            assert evidenceID.getText().length() > 0 : "Empty Evidence/DocumentGroupID element found in "+JdomXmlUtil.xpath(evidence); 
                
            provingEvidenceID.setText(evidenceID.getText());
            
            criterion.addContent(provingEvidenceID);
            existingEvidence.addContent(provesCriterionID);
            
            // copy any DocumentReference from EvidenceCollector to that Evidence
            if (serviceCollector != null) {
              List<Element> documentReferences = findDirectChildren(serviceCollector, getMapper().getDocumentReferenceDescr());
              for (Element documentReference : documentReferences)    {
                  copyElement(documentReference, existingEvidence);
              }
            }
        }
        
        // finally remove the EvidenceCollector, this is just an artificial element
        removeElement(evidenceCollector);
        
        if (serviceCollector != null)
        	removeElement(serviceCollector);
    }
    
    private void establishIdReferencesSkeleton(Element criterion, Element evidenceCollector, List<Element> evidences) {
    	if (evidences == null)
    		evidences = Collections.emptyList();
    	
        // find the enclosing VCD element
        final Element vcd = findParent(criterion, getMapper().getVcdDescr());
        assert vcd != null : "Could not find enclosing VCD element to move evidences to!";

        //find the owner of the criterion (the TSE)
        final Element criterionOwner = criterion.getParentElement();

        // assign an ID to Criterion
        final Element criterionID = getMapper().newId();
        final String critID = getMapper().generateUuid4Xml();
        criterionID.setText(critID);
        criterion.addContent(criterionID);
        
        // move EvidenceCollector Evidences from Criterion to VCD ancestor, create and chain IDs on both sides
        for (Element evidence : evidences)  {   // for all Evidence children of Criterion/EvidenceCollector
            final Element provesCriterionID = getMapper().newProvesCriterionId();
            provesCriterionID.setText(critID);
            
            final Element provingEvidenceID = getMapper().newProvingEvidenceId();

            // ID chaining:
            // Evidence.ProvesCriterionID == Criterion.ID
            // Criterion.ProvingEvidenceID == Evidence.DocumentGroupID
            Element existingEvidence = findEvidenceOnVcdLevel(vcd, evidence, criterionOwner);
            if (existingEvidence != null)   {   // there is an evidence with same ontology-URI on VCD level
                final Element evidenceID = findSingleDirectChild(existingEvidence, getMapper().getDocumentGroupIdDescr());
                assert evidenceID.getText().length() > 0 : "Empty Evidence/DocumentGroupID element found in "+JdomXmlUtil.xpath(evidence); 
                
                provingEvidenceID.setText(evidenceID.getText());
            }
            else    {   // no evidence with the same ontolog<-URI found on VCD level
                moveElement(evidence, vcd);
                existingEvidence = evidence;
                
                final String evidID = getMapper().generateUuid4Xml();
                provingEvidenceID.setText(evidID);
                final Element documentGroupID = getMapper().newDocumentGroupId();
                documentGroupID.setText(evidID);
                evidence.addContent(documentGroupID);
            }
            
            criterion.addContent(provingEvidenceID);
            existingEvidence.addContent(provesCriterionID);
            
        }
        
        // finally remove the EvidenceCollector, this is just an artificial element
        removeElement(evidenceCollector);
    }

    private Element findEvidenceOnVcdLevel(Element vcd, Element evidence, Element mustHaveOwner) {
        final String searchedOntUri = getOntologyUriFromEvidence(evidence);
        
        for (Element existingEvidence :    // for all Evidences at first level in passed VCD
                findDirectChildren(vcd, getMapper().getEvidenceDescr()))    {
            
            String foundOntUri = getOntologyUriFromEvidence(existingEvidence);
            if (searchedOntUri.equals(foundOntUri)) {
            	
            	Element owner = findOwner(existingEvidence);
            	if (mustHaveOwner.equals(owner)) {
                log.debug("Subsuming to existing Evidence "+foundOntUri);
                checkAttachments(evidence, existingEvidence, foundOntUri);
                return existingEvidence;
            	}
            }
        }
        return null;
    }

    private Element findOwner(Element evidence) {
      List<Element> provenCrits = findDirectChildren(evidence, getMapper().getProvesCriterionIdDescr());
      

      for (Element provenCrit : provenCrits) {
        String critId = provenCrit.getTextTrim();
        List<Element> critIdCandidates = findByNameAndText(evidence.getDocument().getRootElement(), getMapper().getIdDescr(), critId);
        for (Element critIdCandidate : critIdCandidates) {
        	Element critCandidate = critIdCandidate.getParentElement();
        	if (critCandidate.getName().equals("Criterion")) 
        		return critCandidate.getParentElement();
        }

      }
      
			return null;
		}

		private String getOntologyUriFromEvidence(Element evidence) {
        Element ontologyDefReg = findSingleDirectChild(evidence, getMapper().getOntologyDefinitionRegulationDescr());
        return getOntologyUriFromElement(ontologyDefReg);
    }
    
    private String getOntologyUriFromElement(Element element) {
        Element ontologyUri = findSingleDirectChild(element, getMapper().getOntlogyUriDescr());
        return ontologyUri.getText();
    }
    
    private void checkAttachments(Element evidence1, Element evidence2, String foundOntUri) {
        Path.Part path = getMapper().getDocumentReferenceDescr();
        List<Element> documentReferences1 = findDirectChildren(evidence1, path);
        List<Element> documentReferences2 = findDirectChildren(evidence2, path);
        if (equals(documentReferences1, documentReferences2) == false)
            log.warn("Attachments seem to be different for Evidences with same OntologyUri: "+foundOntUri);
    }
    
    private boolean equals(Object o1, Object o2)   {
        return o1 == o2 ? true : o1 == null || o2 == null ? false : o1.equals(o2);
    }

}
