/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xmladjust;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.jdom.Document;
import org.jdom.Element;

import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.util.Path.Part;

public class LanguageTagsAdjuster extends AbstractXmlAdjuster {
	private enum Language {
		ENGLISH {
			@Override
			String getLanguage(String caLanguage, String tendererLanguage) {
				return "en";
			}
		},
		TENDERER {
			@Override
			String getLanguage(String caLanguage, String tendererLanguage) {
				return tendererLanguage;
			}
		}
		,
		CONTRACTING_AUTHORITY {
			@Override
			String getLanguage(String caLanguage, String tendererLanguage) {
				return caLanguage;
			}
		};
		
		abstract String getLanguage(String caLanguage, String tendererLanguage);
	}
	
	private static final class LanguageTagSetting {
		Part parentElement;
		Part fakeElement;
		Part realElement;
		String languageAttribute;
		Language language;
		
		public LanguageTagSetting(String ns, String fakeElement, String realElement, String languageAttribute, Language language) {
			this(null, ns, fakeElement, realElement, languageAttribute, language);
		}
		
		public LanguageTagSetting(Part parentElement, String ns, String fakeElement, String realElement, String languageAttribute, Language language) {
			this.parentElement = parentElement;
			this.fakeElement = new Path.Part(ns, fakeElement);
			this.realElement = new Path.Part(ns, realElement);
			this.languageAttribute = languageAttribute;
			this.language = language;
		}

	}
	
	private Set<LanguageTagSetting> languageTagSettingsCriteria = new HashSet<LanguageTagSetting>();
	private Set<LanguageTagSetting> languageTagSettingsEvidences = new HashSet<LanguageTagSetting>();
	{
	    String cac = "urn:peppol:wp2:schema:xsd:CommonAggregateComponents-2";
	    String cbc = "urn:peppol:wp2:schema:xsd:CommonBasicComponents-2";
	    String lid = "languageID";
	
		Part P_EONR = new Part(cac, "EconomicOperatorNationalRegulation");
		Part P_CANR = new Part(cac, "ContractingAuthorityNationalRegulation");

		languageTagSettingsCriteria.add(new LanguageTagSetting(cbc, "NameEnglish", "Name", lid, Language.ENGLISH));
		languageTagSettingsCriteria.add(new LanguageTagSetting(cbc, "LegalTextEnglish", "LegalText", lid, Language.ENGLISH));
		languageTagSettingsCriteria.add(new LanguageTagSetting(cbc, "FurtherInformationEnglish", "FurtherInformation", lid, Language.ENGLISH));
		
		languageTagSettingsCriteria.add(new LanguageTagSetting(P_EONR, cbc, "NameNational", "Name", lid, Language.TENDERER)); 
		languageTagSettingsCriteria.add(new LanguageTagSetting(P_CANR, cbc, "NameNational", "Name", lid, Language.CONTRACTING_AUTHORITY)); 
		languageTagSettingsCriteria.add(new LanguageTagSetting(P_EONR, cbc, "LegalTextNational", "LegalText", lid, Language.TENDERER)); 
		languageTagSettingsCriteria.add(new LanguageTagSetting(P_CANR, cbc, "LegalTextNational", "LegalText", lid, Language.CONTRACTING_AUTHORITY)); 
		languageTagSettingsCriteria.add(new LanguageTagSetting(P_EONR, cbc, "FurtherInformationNational", "FurtherInformation", lid, Language.TENDERER)); 
		languageTagSettingsCriteria.add(new LanguageTagSetting(P_CANR, cbc, "FurtherInformationNational", "FurtherInformation", lid, Language.CONTRACTING_AUTHORITY)); 

		languageTagSettingsEvidences.add(new LanguageTagSetting(cbc, "TitleEnglish", "Title", lid, Language.ENGLISH));
		languageTagSettingsEvidences.add(new LanguageTagSetting(cbc, "TitleNational", "Title", lid, Language.TENDERER));
	}
	

	@Override
	public Document xml2Rdf(Document document) {
		// this is a NOP because we don't import criterion data into the ontology!
		return document;
	}

	private static final Part P_ODC = new Part("urn:peppol:wp2:schema:xsd:CommonBasicComponents-2", "OntologyDomainCode");
	private static final Part P_VCD = new Part("urn:peppol:wp2:schema:xsd:VirtualCompanyDossier-1", "VCD");

	private static final Part P_EO= new Part("urn:peppol:wp2:schema:xsd:CommonAggregateComponents-2", "EconomicOperator");
	private static final Part P_RVP = new Part("urn:peppol:wp2:schema:xsd:CommonAggregateComponents-2", "RelevantVCDPerson");
	
		
	private static final Map<String, String> ODC_TO_LANG = new HashMap<String, String>();
	static {
		ODC_TO_LANG.put("http://m2n.at/2009/05/peppol/Country/11d1def534ea1be0%3A7c8d0dbf%3A129a6fc4a67%3A-7d48", "gr");
		ODC_TO_LANG.put("http://m2n.at/duplicate/1eda6f281fe7bee1%3A-e252900%3A12c1b5e521c%3A-7d80", "de");
		ODC_TO_LANG.put("http://m2n.at/duplicate/583c10bfdbd326ba%3Af50f82c%3A124dd339f4c%3A-6cbf", "de");
		ODC_TO_LANG.put("http://m2n.at/2009/05/peppol/Country583c10bfdbd326ba%3A-176bf4a8%3A124c3087c4e%3A-6361", "de");
		ODC_TO_LANG.put("http://m2n.at/2009/05/peppol/Country583c10bfdbd326ba%3A173f24f5%3A124c372bee6%3A-683f", "fr");
		ODC_TO_LANG.put("http://m2n.at/2009/05/peppol/Country583c10bfdbd326ba%3A173f24f5%3A124c372bee6%3A-6d3c", "it");
		ODC_TO_LANG.put("http://m2n.at/2009/05/peppol/Country583c10bfdbd326ba%3A-57527b26%3A1258bedc41f%3A-6aec", "no");
	}
	
	@Override
	public Document rdf2Xml(Document document) {
		//first we need to find out the CA language
		Element eVCDP = document.getRootElement();
		String caLanguage = getLanguage(eVCDP);
		
		//then we find all affected tags for criteria and unify them correctly
        fixCriteria(document, caLanguage);
        
        //next, we do the same for evidences
        fixEvidences(document, caLanguage);

		return document;
	}

	private void fixCriteria(Document document, String caLanguage) {
		for (Element vcd : findEOsAndPersons(document.getRootElement()))    {
        	String tendererLanguage = getLanguage(vcd);
        	
    		for (LanguageTagSetting lts : languageTagSettingsCriteria) {
    			Iterable<Element> parents = lts.parentElement == null ? Collections.singleton(vcd) : findByName(vcd, lts.parentElement);
    			for (Element p : parents) {
        	        for (Element fake : findByName(p, lts.fakeElement))    {
        	        	fake.setName(lts.realElement.name);
        	        	String language = lts.language.getLanguage(caLanguage, tendererLanguage);
        	        	fake.setAttribute(lts.languageAttribute, language);
        	        }
    			}
    		}
        }
	}

	private void fixEvidences(Document document, String caLanguage) {
		Map<String, String> evidencesToLanguages = new HashMap<String, String>();
		Part evidence = new Part("urn:peppol:wp2:schema:xsd:CommonAggregateComponents-2", "Evidence");
		Part provingEvidence = new Part("urn:peppol:wp2:schema:xsd:CommonBasicComponents-2", "ProvingEvidenceID");
		Part dgid = new Part("urn:peppol:wp2:schema:xsd:CommonBasicComponents-2", "DocumentGroupID");
		
		for (Element vcd : findEOsAndPersons(document.getRootElement()))    {
        	String tendererLanguage = getLanguage(vcd);
        	
	        for (Element eid : findByName(vcd, provingEvidence)) {
	        	String id = eid.getText();
	        	evidencesToLanguages.put(id, tendererLanguage);
	        }
        }
		
		for (LanguageTagSetting lts : languageTagSettingsEvidences) {
			Iterable<Element> evs = findByName(document.getRootElement(), evidence);
			for (Element ev : evs) {
	        	Element eid = findSingleDirectChild(ev, dgid);
	        	String tendererLanguage = evidencesToLanguages.get(eid.getText());
	        	
    	        for (Element fake : findByName(ev, lts.fakeElement))    {
    	        	fake.setName(lts.realElement.name);
    	        	String language = lts.language.getLanguage(caLanguage, tendererLanguage);
    	        	fake.setAttribute(lts.languageAttribute, language);
    	        }
			}
		}
	}

	private Iterable<Element> findEOsAndPersons(Element root) {
		Set<Element> retVal = new HashSet<Element>();
		retVal.addAll(findByName(root, P_EO));
		retVal.addAll(findByName(root, P_RVP));
		return retVal;
	}

	private String getLanguage(Element eVCDP) {
		Element eODC = findSingleDirectChild(eVCDP, P_ODC, false);
		if (eODC == null)
			return "unknown";
		
		String odc = eODC.getTextTrim();
		if (odc == null)
			return "unknown";
		
		String lang = ODC_TO_LANG.get(odc);
		if (lang == null)
			return "unknown";
		
		return lang;
	}

}
