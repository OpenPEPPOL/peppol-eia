/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.saver;

import org.jdom.Document;
import org.jdom.Element;

import at.m2n.IntelligenceManagement.vcd.mapping.Owl2XmlMapper;
import at.m2n.IntelligenceManagement.vcd.util.JdomXmlUtil;
import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

/**
 * Puts all values the TransformerSupport holds into the XML document.
 * Can be applied upon the intermediate XML or upon the final VCD/VCDPackage files.
 * 
 * @author Fritz Ritzberger 25.06.2010
 */
public class TransformerSupportAppliance {

    private Owl2XmlMapper mapper;
    private VcdSchemaVariant schemaVariant;
    
    private Document document;

    /**
     * @param support the TransformerSupport that provides additional XML contents, can be null.
     * @param schemaVariant 
     */
    public TransformerSupportAppliance(TransformerSupport support, Document document, Owl2XmlMapper mapper, VcdSchemaVariant schemaVariant)  {
        this.mapper = mapper;
        this.document = document;
        this.schemaVariant = schemaVariant;
        setSupportedValues(support, document.getRootElement());
    }

    private void setSupportedValues(TransformerSupport support, Element rootElement) {
        if (support == null)
            return;
        
        setTextInDirectChild(rootElement, mapper.getCompilationDateDescr(), support.getCompilationDate());
        setTextInDirectChild(rootElement, mapper.getCompilationTimeDescr(), support.getCompilationTime());
        setTextInDirectChild(rootElement, mapper.getOntologyVersionIdDescr(), support.getOntologyVersionID());
        setTextInDirectChild(rootElement, mapper.getVcdSchemaVersionDescr(), support.getVCDSchemaVersionID());
        setTextInDirectChild(rootElement, mapper.getVcdTypeCodeDescr(), schemaVariant.getName().getVCDTypeCode());

        fillIssuingService(
            rootElement, support.getIssuingService(), mapper.getIssuingServiceDescr());

        for (Element vcd : JdomXmlUtil.findByName(rootElement, mapper.getVcdDescr()))  {
            setTextInDirectChild(vcd, mapper.getCompilationDateDescr(), support.getCompilationDate());
            setTextInDirectChild(vcd, mapper.getCompilationTimeDescr(), support.getCompilationTime());
            setTextInDirectChild(vcd, mapper.getOntologyVersionIdDescr(), support.getOntologyVersionID());
            setTextInDirectChild(vcd, mapper.getVcdTypeCodeDescr(), schemaVariant.getName().getVCDTypeCode());
            
            fillIssuingService(
                vcd, support.getVcdIssuingService(), mapper.getVcdIssuingServiceDescr());
        }
    }

    private void setTextInDirectChild(Element parent, Path.Part part, String text) {
        if (text == null || text.length() <= 0)
            return;
        
        Element e = JdomXmlUtil.findSingleDirectChild(parent, part, false);
        if (e == null)  {
            e = newElement(part);
            parent.addContent(e);
        }
        e.setText(text);
    }
    
    private void fillIssuingService(Element parent, TransformerSupport.IssuingService issuingService, Path.Part part)   {
        if (issuingService == null)
            return;
        
        Element issuing = JdomXmlUtil.findSingleDirectChild(parent, part, false);
        if (issuing == null)   {
            issuing = newElement(part);
            parent.addContent(issuing);
        }
        
        String endpointID = issuingService.getEndpointID();
        setTextInDirectChild(issuing, mapper.getEndpointIdDescr(), endpointID);
        
        String name = issuingService.getName();
        setTextInDirectChild(issuing, mapper.getNameDescr(), name);
        
        String providingPartyName = issuingService.getProvidingPartyName();
        Path path = new Path();
        path.add(mapper.getProvidingPartyDescr());
        path.add(mapper.getPartyNameDescr());
        path.add(mapper.getNameDescr());
        setTextInPath(issuing, path, providingPartyName);
    }
    
    // creates every path part when not found, sets text at last path part
    private void setTextInPath(Element element, Path path, String text)   {
        Element parent = element;
        Element found = null;
        for (Path.Part part : path) {
            found = null;
            for (Object o : parent.getChildren()) {
                Element child = (Element) o;
                if (JdomXmlUtil.matches(child, part))    {
                    found = child;
                    break;
                }
            }
            if (found == null)  {
                found = newElement(part);
                parent.addContent(found);
            }
            parent = found;
        }
        found.setText(text);
    }
    
    private Element newElement(Path.Part part)   {
        return mapper.newElementForInsertion(part, document.getRootElement());
    }

}
