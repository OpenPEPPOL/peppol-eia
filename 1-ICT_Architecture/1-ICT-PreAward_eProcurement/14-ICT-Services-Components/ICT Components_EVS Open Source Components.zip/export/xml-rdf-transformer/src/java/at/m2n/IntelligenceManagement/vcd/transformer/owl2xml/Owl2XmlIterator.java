/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.owl2xml;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.jena.util.OntUtil;
import at.m2n.util.multimap.DefaultMultiMap;
import at.m2n.util.multimap.MultiMap;

import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;

/**
 * VCD Transformer that converts from RDF to XML (skeleton).
 * Looks for an single instance of the defined OWL root type (VCDRequest)
 * and iterates this node by its properties, whereby only mapped properties
 * are regarded. Knows the context of RDF nodes by the XML path subsequently
 * built during iteration.
 * <p />
 * fri_2010-06-14 Review:<br />
 * The conversion RDF->XML is done using the same Mapper as the XML->RDF conversion.
 * The XML mapping side can use pathes, but the RDF side not. This seems to be a
 * weakness at first glance, but in fact it is a strength, as it avoids redundancy:
 * every RDF node always is processed in context of its XML element parent, and thus
 * has a well-defined processing context.
 * Imagine a RDF NaturalPerson that occurs in different contexts. If that NaturalPerson
 * is mapped to e.g VCD/EconomicOperator/Party/Person, the Transformer will build
 * into that XML parent, and thus have the correct context without duplicating mapping
 * information on RDF side.
 * 
 * @author Fritz Ritzberger  31.05.2010
 */
public class Owl2XmlIterator {
    
    private static final Logger log = Logger.getLogger(Owl2XmlIterator.class);

    private final Model rdfSchemaModel;
    private final Owl2XmlIterationLogic mapper;
    private final String defaultLanguage = "en";
    private final String noLanguage = "";
    private String targetLanguage;
    private Document resultDocument;
    
    public Owl2XmlIterator(Model rdfSchemaModel, Owl2XmlIterationLogic mapper) {
        assert mapper != null && rdfSchemaModel != null : "Need a Mapper and a RDF schema to transform to XML!";
        
        this.rdfSchemaModel = rdfSchemaModel;
        this.mapper = mapper;
    }

    /**
     * Transform passed Model to XML.
     * @param rdfInstancesModel the OWL model containing RDF instances to convert.
     * @return the XML document that resulted from transformation (intermediate XML).
     * @throws SAXException 
     * @throws MalformedURLException 
     */
    public Document transform(Model rdfInstancesModel) throws MalformedURLException, SAXException {
        assert rdfInstancesModel != null : "Need a RDF model to transform to XML!";
        
        mapper.preprocessRDF(rdfInstancesModel);
        
        // build a XML root element, its namespace and a containing document
        Element rootElement = mapper.newXmlRootElement();
        this.resultDocument = new Document(rootElement);   // UTF-8 is default encoding
        
        Resource rdfRoot = findRoot(rdfInstancesModel);
        transform(rdfRoot, mapper.newXmlRootPath(), rootElement);
        
        return resultDocument;
    }
    
    private Resource findRoot(Model rdfInstancesModel)   {
        String className = mapper.getRdfRootClassname();
        Resource vcdRequestClass = rdfSchemaModel.getResource(className);
        StmtIterator rootFinder = rdfInstancesModel.listStatements(null, RDF.type, vcdRequestClass);
        Resource root = null;
        try {
            while (rootFinder.hasNext())    {   // there must be just one root, check this
                Statement statement = rootFinder.nextStatement();
                log.info("Found "+className+" root in RDF graph: "+statement.getSubject());
                assert root == null : "Multiple instances of RDF class "+className+" found in RDF graph!";
                root = statement.getSubject();
                
                setTargetLanguage(statement);
                //debugModel.add(statement);
            }
        }
        finally {
            rootFinder.close();
        }
        return root;
    }
    
    private void setTargetLanguage(Statement rootStatement) {
        StmtIterator it = rootStatement.getSubject().listProperties();
        try {
            while (it.hasNext())    {
                Statement stmt = it.nextStatement();
                if (mapper.isTargetLanguagePredicate(stmt.getPredicate().getNameSpace(), stmt.getPredicate().getLocalName())) {
                    RDFNode targetLanguageNode = stmt.getObject();
                    String locale;
                    if (targetLanguageNode.isResource())
                        locale = ((Resource) targetLanguageNode.as(Resource.class)).getLocalName();
                    else
                        locale = ((Literal) targetLanguageNode.as(Literal.class)).getLexicalForm();
                    
                    assert targetLanguage == null : "There are more than one targeLanguage statements in VCDRequest!";
    
                    if (locale != null && locale.length() > 0)  {
                        log.info("Found targetLanguage "+locale);
                        if (locale.equals("dummyLanguage") == false)    // is from test phase, remove this
                            targetLanguage = locale;
                    }
                }
            }
        }
        finally {
            it.close();
        }
    }

    private Element transform(Resource rdfResource, Path xmlPath, Element element) throws MalformedURLException, SAXException   {
        if (mapper.isFolder(xmlPath.getLastPart()))   {
            // retrieve all properties from resource and resolve them by language tags
            List<Statement> statements = retrievePropertiesResolveLanguage(rdfResource);
            
            // check all statements if they are relevant for XML
            List<Statement> mappedStatements = new ArrayList<Statement>();
            List<Path> pathes = new ArrayList<Path>();
            filterMappedStatementsAndCollectPathes(statements, xmlPath, mappedStatements, pathes);
            
            // folder, but empty - search data in RDF schema that may be not present in instance graph
            if (mappedStatements.size() <= 0 && rdfResource.getModel().equals(rdfSchemaModel) == false) {
                Resource schemaData = rdfSchemaModel.getResource(rdfResource.getURI());
                if (schemaData != null) {
                    statements = retrievePropertiesResolveLanguage(schemaData);
                    filterMappedStatementsAndCollectPathes(statements, xmlPath, mappedStatements, pathes);
                }
            }
            
            return mappedStatements.size() > 0
                ? transformFolder(rdfResource, xmlPath, element, mappedStatements, pathes)
                : null; // empty, do not create XML element for this
        }
        else    {
            return transformLeaf(rdfResource, xmlPath); // e.g. caCountry goes here
        }
    }
    
    /** Loops all statements and recurses into properties. @return the created XML folder element. 
     * @throws SAXException 
     * @throws MalformedURLException */
    private Element transformFolder(Resource rdfResource, Path xmlPath, Element element, List<Statement> mappedPropertyStatements, List<Path> pathes) throws MalformedURLException, SAXException {
        Element folderElement = (element == null) ? newXmlElement(xmlPath) : element;

        int i = 0;
        for (Statement statement : mappedPropertyStatements)   {
            Path nextXmlPath = pathes.get(i);
            i++;
            
            Element realParent = createIntermediateElements(folderElement, xmlPath, nextXmlPath);
            addFolderChild(realParent, statement, nextXmlPath);
        }
        
        // sometimes we must write properties of a resource, and ALSO its URI,
        // like with Criterion/OntologyUri - let the mapper check this special case
        mapper.processResourceUri(folderElement, rdfResource.getURI());

        return folderElement;
    }
    
    private Element createIntermediateElements(Element parentElement, Path xmlParentPath, Path xmlChildPath) {
        int base = xmlParentPath.size();
        int diff = xmlChildPath.size() - base;
        assert diff > 0 : "The parent path is longer than the child path! "+xmlChildPath;
        
        // create or reuse intermediate elements from left to right
        Path currentPath = xmlParentPath.copy();
        for (int i = base; i < base + diff - 1; i++)  {
            Path.Part xmlPathPart = xmlChildPath.get(i);
            currentPath.add(xmlPathPart);    // creates new Path with Part appended to end
            
            Element e = mapper.reuseExistingIntermediateParentElement(parentElement, xmlPathPart)
                ? findExistingIntermediateElement(parentElement, xmlPathPart)
                : null;
                
            if (e != null)  {
                parentElement = e;
            }
            else    {
                e = newXmlElement(currentPath);
                parentElement.addContent(e);
                parentElement = e;
            }
        }
        return parentElement;
    }

    private Element findExistingIntermediateElement(Element parentElement, Path.Part xmlPathPart) {
        for (Object o : parentElement.getChildren())   {
            Element child = (Element) o;
            if (child.getName().equals(xmlPathPart.name) && child.getNamespaceURI().equals(xmlPathPart.namespace))    {
                return child;
            }
        }
        return null;
    }

    private void addFolderChild(Element folderElement, Statement statement, Path xmlChildPath) throws MalformedURLException, SAXException{
        // Find out if predicate points to a resource or a literal
        // Mind that the "is folder" decision implemented here must be in
        // sync with PreSkeleton2OwlTransformer.createProperty() !
        
        Property predicateDefinition = rdfSchemaModel.getProperty(statement.getPredicate().getURI());
        boolean isObjectProperty = predicateDefinition.hasProperty(RDF.type, OWL.ObjectProperty);
        RDFNode object = statement.getObject();
        Element subElement;
        
        if (object.isResource() != isObjectProperty)  {
            log.warn("Predicate "+predicateDefinition.getLocalName()+" points to resource but Object is not a resource: "+object+" (happens when the RDF schema was not completely loaded?)");
            subElement = transformLeaf(object, xmlChildPath);
        }
        else if (isObjectProperty) {  // folder: both caParty (has sub-elements) and caCountry (has no sub-elements) must go here
            Resource folder = (Resource) object.as(Resource.class);
            subElement = transform(folder, xmlChildPath, (Element) null);
        }
        else    {   // leaf: throw exception if not
            if (object.canAs(Literal.class))    {
                Literal literal = (Literal) object.as(Literal.class);
                subElement = transformLeaf(literal, xmlChildPath);
            }
            else    {
                log.error("Found no literal where literal was expected: "+object);
                subElement = transformLeaf(object, xmlChildPath);
            }
        }
        
        if (subElement != null) {
            folderElement.addContent(subElement);
            //debugModel.add(statement);
        }
    }

    private Element transformLeaf(Literal literal, Path xmlPath)   {
        return transformLeaf(literal.getLexicalForm(), literal.getLanguage(), xmlPath);
    }

    private Element transformLeaf(RDFNode object, Path xmlPath)   {
        return transformLeaf(object.toString(), null, xmlPath);
    }

    private Element transformLeaf(Resource resource, Path xmlPath)   {
        String text = (resource.isAnon() == false && resource.isURIResource()) ? resource.getURI() : null;
        return transformLeaf(text, null, xmlPath);
    }

    private Element transformLeaf(String text, String lang, Path xmlPath)   {
        Element element = newXmlElement(xmlPath);
        if (text != null)
            element.setText(text);
        
        if (lang != null && !lang.isEmpty())
        	element.setAttribute("languageID", lang);
        
        return element;
    }

    private Element newXmlElement(Path xmlPath)    {
        Path.Part p = xmlPath.getLastPart();
        return mapper.newElementForInsertion(p, resultDocument.getRootElement());
    }
    
    /**
     * Returns a list of statements that contains statements from one (or none) language only.
     * First the Properties of the Resource get bundled by their name.
     * Then all bundles are looped, for every bundle look if there are languages in them.
     * When so, apply the language filter and remove all wrong languages.
     * When there are more than one left, remove the one without language.
     * When there are no languages in a bundle, further process the bundle as separate statements!
     * 
     * @param resource the resource to retrieve properties from.
     * @return list filled with one-language-only statements.
     */
    private List<Statement> retrievePropertiesResolveLanguage(Resource resource)   {
        MultiMap<Property,Statement> bundles = new DefaultMultiMap<Property,Statement>();
        StmtIterator propertiesIterator = resource.listProperties();
        try {
            while (propertiesIterator.hasNext())    {
                Statement statement = propertiesIterator.nextStatement();
                bundles.put(statement.getPredicate(), statement);
            }
        }
        finally {
            propertiesIterator.close();
        }
        
        List<Statement> statements = new ArrayList<Statement>();
        
        for (Property predicate : bundles.keySet())   {
            Set<Statement> stmts = bundles.get(predicate);
            
            if (hasLanguage(predicate, stmts))  {  // reduce the statements to one
                Statement languageStatement = getLanguageStatement(stmts, resource, targetLanguage);
                if (languageStatement == null)
                    languageStatement = getLanguageStatement(stmts, resource, defaultLanguage);
                if (languageStatement == null)
                    languageStatement = getLanguageStatement(stmts, resource, noLanguage);
                
                if (languageStatement != null)
                    statements.add(languageStatement);
            }
            else    {   // add all statements to result list
                for (Statement stmt : stmts)
                    statements.add(stmt);
            }
        }
        
        return statements;
    }
    
    /** @return true when maxCardinality exists and maxCardinality == 1. */
    private boolean hasLanguage(Property predicate, Set<Statement> statements)   {
        return
            predicate.hasProperty(OWL.maxCardinality) &&
            predicate.getProperty(OWL.maxCardinality).getInt() == 1 &&
            statements.iterator().next().getObject().canAs(Literal.class);
    }
    
    private Statement getLanguageStatement(Set<Statement> stmts, Resource resource, String desiredLanguage)   {
        Statement languageStatement = null;   // the statement with default language
        for (Statement stmt : stmts)    {
            String language = getLanguage(stmt);
            if (matchesLanguage(language, desiredLanguage))   {
                if (languageStatement == null)
                    languageStatement = stmt;
                else
                    log.warn("WARNING: found more than one values for language "+desiredLanguage+" in property bundle at: "+resource.getURI());
            }
        }
        return languageStatement;
    }
    
    private String getLanguage(Statement statement) {
        String language = statement.getLanguage();
        if (language == null || language.trim().length() < 0)
            language = noLanguage;
        return language;
    }
    
    private boolean matchesLanguage(String language, String compareLanguage)  {
        return language.equalsIgnoreCase(compareLanguage);
    }

    /**
     * Filters passed statements and puts only those into filteredStatements
     * that are mapped by the Mapper.
     * 
     * @param statements the incoming statements to filter.
     * @param xmlPath the XML path about to be filled with sub-elements from RDF properties.
     * @param filteredStatements the outgoing list of filtered statements, initially empty.
     * @param pathes the outgoing list of XML paths to create, in parallel to filteredStatements, initially empty.
     */
    private void filterMappedStatementsAndCollectPathes(List<Statement> statements, Path xmlPath, List<Statement> filteredStatements, List<Path> pathes)   {
        for (Statement statement : statements)    {
            String predicateNamespace = statement.getPredicate().getNameSpace();
            String predicateName = statement.getPredicate().getLocalName();
            Path childPath = mapper.getXmlElement4RdfPredicate(predicateNamespace, predicateName, xmlPath, statement);
            // returns the to-element path
            
            if (childPath != null)    {
                filteredStatements.add(statement);
                Path clone = xmlPath.copy();
                clone.addAll(childPath);
                pathes.add(clone);
            }
        }
    }
}
