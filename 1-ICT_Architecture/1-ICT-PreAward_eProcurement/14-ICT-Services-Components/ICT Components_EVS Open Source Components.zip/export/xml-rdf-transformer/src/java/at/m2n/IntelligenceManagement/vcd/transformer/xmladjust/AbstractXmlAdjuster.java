/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xmladjust;

import java.util.ArrayList;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

import at.m2n.IntelligenceManagement.vcd.mapping.Mapper;
import at.m2n.IntelligenceManagement.vcd.util.JdomXmlUtil;
import at.m2n.IntelligenceManagement.vcd.util.Path;

/**
 * Each chain member implements XmlAdjuster (to be chainable).
 * This class contains common JDOM utilities to edit XML documents.
 * <p />
 * XmlAdjusters have the freedom to create, rename and delete elements without
 * regard to the XMLSchema. The Schemifier will establish order after.
 * <p />
 * This class is package-visible, force all subclasses to be in the same package.
 * 
 * @author Fritz Ritzberger  07.06.2010
 */
abstract class AbstractXmlAdjuster {

    private Mapper mapper;
    
    /**
     * Subclasses edit the passed XML document to achieve adjustment from XML to RDF.
     * @param document the document to edit.
     * @return the modified document.
     */
    public abstract Document xml2Rdf(Document document);
    
    /**
     * Subclasses edit the passed XML document to achieve adjustment from RDF to XML.
     * @param document the document to edit.
     * @return the modified document.
     */
    public abstract Document rdf2Xml(Document document);
    
    /** Instead of passing mapper to each constructor, it is set to each instance in a loop. */
    void setMapper(Mapper mapper) {
        this.mapper = mapper;
    }

    /** Subclasses call this to use the mapper. */
    protected Mapper getMapper()    {
        return mapper;
    }
    
    // common JDOM service methods
    
    /**
     * @param element the XML element to match.
     * @param part the path part to check.
     * @return true if the element name and its namespace both equal the passed path part.
     */
    protected boolean matches(Element element, Path.Part part) {
        return JdomXmlUtil.matches(element, part);
    }
    
    /**
     * Finds all direct XML children that match the passed path, starting the
     * search from passed parent element, excluding the parent itself.
     * @param startSearchElement the element on which to start the hierarchical search.
     * @param path the path to find in startSearchElement.
     */
    protected List<Element> findDirectChildren(Element parent, Path.Part part) {
        return JdomXmlUtil.findDirectChildren(parent, part);
    }
    
    /**
     * @param parent the parent element.
     * @param part the namespace:name to find.
     * @return the single child with passed namespace:name, assert when not found or ambiguous.
     */
    protected Element findSingleDirectChild(Element parent, Path.Part part) {
        return JdomXmlUtil.findSingleDirectChild(parent, part);
    }
    
    /**
     * @param throwExceptionWhenNotFound when true an exception is thrown when the result is ambiguous or not existent.
     */
    protected Element findSingleDirectChild(Element parent, Path.Part part, boolean throwExceptionWhenNotFound) {
        return JdomXmlUtil.findSingleDirectChild(parent, part, throwExceptionWhenNotFound);
    }
    
    /**
     * @param element the start point of search for parent, exclusive.
     * @param name the namespace:name of the parent to find.
     * @return the parent of passed name, of null if not found.
     */
    protected Element findParent(Element element, Path.Part name) {
        assert element != null : "Can not find parent of null element!";
        do  {
            element = element.getParentElement();
        }
        while (element != null && matches(element, name) == false);
        return element;
    }
    
    /**
     * Finds any XML element that matches the passed path, starting the
     * search from passed parent element, including the startSearchElement itself.
     * @param startSearchElement the element on which to start the hierarchical search.
     * @param part the namespace:name to find in startSearchElement.
     * @return list of all elements that match.
     */
    protected List<Element> findByName(Element startSearchElement, Path.Part part) {
        return JdomXmlUtil.findByName(startSearchElement, part);
    }
    
    /**
     * Finds any XML element that matches the passed path and has passed content text,
     * starting the search from passed parent element, including the startSearchElement itself.
     * @param startSearchElement the element on which to start the hierarchical search.
     * @param part the namespace:name to find in startSearchElement.
     * @param text the text content the element must have to be in found-list.
     * @return list of all elements that match.
     */
    protected List<Element> findByNameAndText(Element startSearchElement, Path.Part part, String text) {
        List<Element> list = findByName(startSearchElement, part);
        List<Element> returnList = new ArrayList<Element>();
        for (Element e : list)  {
            if (text.equals(e.getText()))   {
                returnList.add(e);
            }
        }
        return returnList;
    }
    
    /**
     * Replaces an XML element by another one.
     * @param toReplace the element to be replaced.
     * @param substitute the new element to insert instead of toReplace.
     */
    protected void replaceElementBy(Element toReplace, Element substitute)    {
        JdomXmlUtil.replaceElementBy(toReplace, substitute);
    }
    
    /**
     * Removes an XML element from its current parent.
     * @param toRemove the element to be deleted.
     */
    protected void removeElement(Element toRemove)    {
        if (toRemove == null)
            return;
        assert toRemove.getParent() != null : "Can not remove element without parent: "+JdomXmlUtil.xpath(toRemove);
        toRemove.getParent().removeContent(toRemove);
    }
    
    /**
     * Removes XML elements from their current parent.
     * @param toRemove the list of elements to be deleted.
     */
    protected void removeElements(List<Element> toRemove)    {
        if (toRemove == null)
            return;
        for (Element e : toRemove)
            removeElement(e);
    }
    
    /**
     * Copies an XML element and all its children recursively.
     * @param toCopy the element to be copied.
     * @return the copied element, which has not yet a parent element.
     */
    protected Element copyDeep(Element toCopy)    {
        return (Element) toCopy.clone();
    }
    
    /**
     * Moves passed element to end of the child list of passed target element.
     * @param toMove the element to move.
     * @param targetParent the move action target element.
     */
    protected void moveElement(Element toMove, Element targetParent) {
        removeElement(toMove);
        targetParent.addContent(toMove);
    }

    /**
     * Copies passed element to end of the child list of passed target element.
     * @param toCopy the element to move.
     * @param targetParent the move action target element.
     * @return the new (copied) element.
     */
    protected Element copyElement(Element toCopy, Element targetParent) {
        Element clone = copyDeep(toCopy);
        targetParent.addContent(clone);
        return clone;
    }

}
