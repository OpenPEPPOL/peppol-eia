/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.owl2xml;

import java.net.MalformedURLException;

import org.jdom.Element;
import org.xml.sax.SAXException;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Statement;

import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.util.Path.Part;

/**
 * The responsibilities of the Mapper against the RDF->XML Iterator.
 * 
 * @author Fritz Ritzberger 01.07.2010
 */
public interface Owl2XmlIterationLogic
{
    /** @return a XML document root element. */
    Element newXmlRootElement();
    
    /** @return the Path valid for the XML document root element. */
    Path newXmlRootPath();
    
    /** @return the RDF Class name of the RDF instance to treat as root node. */
    String getRdfRootClassname();
    
    /** @return true if the passed predicate is the predicate that holds the target language to filter statements for. */
    boolean isTargetLanguagePredicate(String predicateNameSpace, String predicateLocalName);
    
    /** @return true if the passed XML element can have sub-elements, false if it is empty or has text content. 
     * @throws SAXException 
     * @throws MalformedURLException */
    boolean isFolder(Path.Part elementIdentification) throws MalformedURLException, SAXException;
    
    /** Offers the Mapper an opportunity to process the RDF URI of the just-processed XML folder element. */
    void processResourceUri(Element xmlFolderElement, String rdfResourceURI);
    
    /** @return true if the pending element represented by xmlPathPart should be inserted into an existing parent element.
     * On false it will be inserted into its own newly generated parent element. */
    boolean reuseExistingIntermediateParentElement(Element parent, Path.Part xmlPathPart);
    
    /** @return a newly created XML element with passed identification. The root element is needed for namespace updating. */
    Element newElementForInsertion(Path.Part elementIdentification, Element documentRootElement);
    
    /** @param statement 
     * @return the XML element that represents passed predicate in context of xmlPath. */
    Path getXmlElement4RdfPredicate(String predicateNamespace, String predicateName, Path xmlPath, Statement statement);

	void preprocessRDF(Model rdfInstancesModel);
}