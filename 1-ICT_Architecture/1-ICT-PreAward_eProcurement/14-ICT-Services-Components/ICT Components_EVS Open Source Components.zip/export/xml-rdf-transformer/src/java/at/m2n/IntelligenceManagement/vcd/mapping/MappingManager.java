/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.mapping;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.jdom.Element;

import at.m2n.IntelligenceManagement.vcd.util.JdomXmlUtil;
import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.util.Pair;
import at.m2n.util.multimap.DefaultMultiMap;
import at.m2n.util.multimap.MultiMap;

import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;
import com.hp.hpl.jena.vocabulary.RDF;

/**
 * Structures to map XML info to OWL graph and vice versa.
 * Encapsulates the search algorithms and maps for the Mapper class.
 * This currently consists of following major maps:
 * <ul>
 *  <li>XML element to OWL Classes</li>
 *  <li>XML element relation to OWL property</li>
 * </ul>
 * The search algorithm in these maps is as follows:
 * <pre>
 *   Assuming an XML element has xpath /a/b/c/d,
 *   first search with a/b/c/d, second with b/c/d, then c/d, finally d.
 * </pre>
 * This ensures that the longest possible match wins.
 * 
 * @author Fritz Ritzberger  25.05.2010
 */
abstract class MappingManager {
    
    /**
     * Bind together the "to" XML element ("from"-"to" relation)
     * and a RDF property URI for that relation.
     */
    private static class ToXmlElementRdfProperty  {
        final String toElementPath;
        final String propertyUri;
        final String objectClassURI;
        
        public ToXmlElementRdfProperty(String toElementPath, String propertyUri, String objectClassURI) {
            assert toElementPath != null && propertyUri != null : "Null values do not make sense here!";
            this.toElementPath = toElementPath;
            this.propertyUri = propertyUri;
            this.objectClassURI = objectClassURI;
        }
        @Override
        public String toString() {
            return "RDF property "+propertyUri+", XML element = "+toElementPath;
        }
				public boolean isApplicableFor(Statement statement) {
					if (objectClassURI != null) {
						Resource object = statement.getResource();
						
						if (object == null)
							return false;
						
						Resource type = new ResourceImpl(objectClassURI);
						
						if (!object.hasProperty(RDF.type, type))
							return false;
					}


					return true;
				}
    }
    
    
    /**
     * Mapping XML element identities to 1-n OWL classes (types).
     */
    private final MultiMap<String,String> owlTypes = new DefaultMultiMap<String,String>();
    
    /**
     * Mapping hierarchic XML element relations to OWL properties.
     */
    private final MultiMap<String,ToXmlElementRdfProperty> owlRelationProperties = new DefaultMultiMap<String,ToXmlElementRdfProperty>();

    /**
     * Ignoring several elements (TODO remove this as soon as all XML informations are mapped to RDF).
     */
    private final Set<String> ignored = new HashSet<String>();
    
    /**
     * The "deterministic" elements should be represented only once in RDF,
     * even when they are duplicated in XML. For that purpose a String is returned
     * from the Mapper that should be used instead of an URIGenerator IRI part,
     * inserting such nodes into RDF graph would then do nothing.
     * The returned string is retrieved from the XML by pointng to a certain
     * element whose content should be used as RDF IRI part.
     */
    private final Map<String,Path> deterministicElements = new Hashtable<String,Path>();


    // map-put methods
    
    /**
     * Registers an OWL class for the passed XML element.
     * @param xmlElement the XML element.
     * @param rdfType the RDF type (class).
     */
    protected final void xml2OwlType(Path.Part xmlElement, Path.Part rdfType) {
        xml2OwlType(path(xmlElement), rdfType);
    }
    
    /**
     * Registers an OWL class for the passed XML element path.
     * @param xmlElement the XML element.
     * @param rdfType the RDF type (class).
     */
    protected final void xml2OwlType(Path xmlElement, Path.Part rdfType) {
        String pathMapId = path2MapId(xmlElement);
        owlTypes.put(pathMapId, rdfUri(rdfType.namespace, rdfType.name));
    }
    
    /**
     * Registers an OWL property URI for an XML relation.
     * @param xmlFromElement the source XML element of the relation.
     * @param xmlToElement the target XML element of the relation.
     */
    protected final void xmlRelation2OwlProperty(Path.Part xmlFromElement, Path.Part xmlToElement, Path.Part rdfPropertyUri)   {
    	xmlRelation2OwlProperty(xmlFromElement, xmlToElement, rdfPropertyUri, null);
    }
   /**
     * Registers an OWL property URI for an XML relation.
     * @param xmlFromElement the source XML element of the relation.
     * @param xmlToElement the target XML element of the relation.
     * @param objectClassURI the URI of the required rdf:type of the object of the statement
     */
    protected final void xmlRelation2OwlProperty(Path.Part xmlFromElement, Path.Part xmlToElement, Path.Part rdfPropertyUri, String objectClassURI)   {
        xmlRelation2OwlProperty(path(xmlFromElement), path(xmlToElement), rdfPropertyUri, objectClassURI);
    }

    protected final void xmlRelation2OwlProperty(Path.Part xmlFromElement, Path xmlToElement, Path.Part rdfPropertyUri)   {
    	xmlRelation2OwlProperty(xmlFromElement, xmlToElement, rdfPropertyUri, null);
    }
    /**
     * Registers an OWL property URI for an XML relation.
     * @param xmlFromElement the source XML element of the relation.
     * @param xmlToElement a (relative) path of the target XML element of the relation.
     * @param rdfType the RDF type (class).
     */
    protected final void xmlRelation2OwlProperty(Path.Part xmlFromElement, Path xmlToElement, Path.Part rdfPropertyUri, String objectClassURI)   {
        xmlRelation2OwlProperty(path(xmlFromElement), xmlToElement, rdfPropertyUri, objectClassURI);
    }

    /**
     * Registers an OWL property URI for an XML relation.
     * @param xmlFromElement a (relative) path of the source XML element of the relation.
     * @param xmlToElement a (relative) path of the target XML element of the relation.
     * @param rdfType the RDF type (class).
     */
    protected final void xmlRelation2OwlProperty(Path xmlFromElement, Path xmlToElement, Path.Part rdfProperty, String objectClassURI) {
        String fromPathMapId = path2MapId(xmlFromElement);
        String toPathMapId = path2MapId(xmlToElement);
        owlRelationProperties.put(
            fromPathMapId,
            new ToXmlElementRdfProperty(
                toPathMapId,
                rdfUri(rdfProperty.namespace, rdfProperty.name),
                objectClassURI));
    }
    
    /** Registers passed XML element to be ignored. */
    protected final void xmlIgnore(Path.Part xmlElement)   {
        xmlIgnore(path(xmlElement));
    }
    
    /** Registers passed XML element to be ignored. */
    protected final void xmlIgnore(Path xmlElement)   {
        String pathMapId = path2MapId(xmlElement);
        ignored.add(pathMapId);
    }
    
    /** Registers passed XML element to be mapped by content of passed relative xpath expression. */
    protected final void xmlDeterministicElement(Path.Part xmlElement, Path deterministicIdLocation)   {
        xmlDeterministicElement(path(xmlElement), deterministicIdLocation);
    }
    
    /** Registers passed XML element to be mapped by content of passed relative xpath expression. */
    protected final void xmlDeterministicElement(Path xmlElement, Path deterministicIdLocation)   {
        String pathMapId = path2MapId(xmlElement);
        deterministicElements.put(pathMapId, deterministicIdLocation);
    }
    
    
    // map-get methods

    /**
     * Finds RDF class(es) for an XML element.
     * @param xmlElement the element to search types for.
     * @return the matched RDF property for passed relation, or null if none found.
     */
    public Set<String> getOwlTypes(Element xmlElement) {
        List<Element> path = makePath(xmlElement);
        // try to match the element, with decrementing path length
        for (int startIndex = 0; startIndex < path.size(); startIndex++)  {
            String mapId = getSearchPathNr(startIndex, path);
            Set<String> value = owlTypes.get(mapId);
            
            if (value != null)  // match the longest possible path!
                return value;
        }
        return null;
    }

    /**
     * Finds an RDF property for a (hierarchical) XML element relation.
     * @param fromElement the start of the XML relation edge (parent node).
     * @param toElement the end of the XML relation edge (child node).
     * @return the matched RDF property for passed relation, or null if none found.
     */
    public String getOwlProperty4XmlRelation(Element fromElement, Element toElement) {
        List<Element> path = makePath(fromElement);
        
        // first match the "from" element, with decrementing path length
        for (int startIndex = 0; startIndex < path.size(); startIndex++)  {
            String mapId = getSearchPathNr(startIndex, path);
            Set<ToXmlElementRdfProperty> targets = owlRelationProperties.get(mapId);
            
            // when "from" found, try to match the "to" element, with decrementing path length
            if (targets != null)  {
                for (ToXmlElementRdfProperty target : targets) {
                    if (match(toElement, target.toElementPath))  {
                        return target.propertyUri;
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Finds the XML element relation for passed property name.
     * TODO this is complex and not very performant, improve it.
     * 
     * @param rdfPropertyNamespace the (expanded) RDF prefix
     * @param rdfPropertyName the local name of the RDF property.
     * @return null when property not found, else the XML "to"-element of its associated XML relation.
     */
    protected Path getXmlRelation4OwlProperty(String rdfPropertyNamespace, String rdfPropertyName, Path xmlPath, Statement statement) {
    	
        // make search key
        String rdfFullPropertyName = rdfUri(rdfPropertyNamespace, rdfPropertyName);
        List<Pair<String,ToXmlElementRdfProperty>> equalToElements = new ArrayList<Pair<String,ToXmlElementRdfProperty>>();
        
        // iterate XML relationship map and collect all relations that point to passed property
        for (String key : owlRelationProperties.keySet()) {
            Set<ToXmlElementRdfProperty> values = owlRelationProperties.get(key);
            
            for (ToXmlElementRdfProperty toElementProperty : values)  {
                if (toElementProperty.propertyUri.equals(rdfFullPropertyName))    {
                	if (toElementProperty.isApplicableFor(statement))
                    equalToElements.add(new Pair<String,ToXmlElementRdfProperty>(key, toElementProperty));
                }
            }
        }
        ToXmlElementRdfProperty bestToElementProperty = findLongestPath(equalToElements, xmlPath);
        return bestToElementProperty != null ? path(bestToElementProperty.toElementPath) : null;
    }
    
    /**
     * Find best match of those relations that equaled the property name.
     * This is done by trying to match the passed xmlPath against the from-element (left/key part of the Pair),
     * starting from tail. The longest match wins.
     * 
     * TODO integrate also the fromElement part into path finding for a safer match
     */
    private ToXmlElementRdfProperty findLongestPath(List<Pair<String,ToXmlElementRdfProperty>> keyAndToElements, Path xmlPath) {
        int max = 0;
        ToXmlElementRdfProperty best = null;
        
        for (Pair<String,ToXmlElementRdfProperty> keyAndToElement : keyAndToElements) {
            String key = keyAndToElement.left();
            Path keyPath = path(key);
            
            int count = 0;
            int xs = xmlPath.size();
            int ks = keyPath.size();
            boolean isEqual = true;
            for (int i = 0; isEqual && i < Math.min(xs, ks); i++)  {
                isEqual = xmlPath.get(xs - i - 1).equals(keyPath.get(ks - i - 1));
                if (isEqual)
                    count++;
            }
            
            if (count > max) {
                best = keyAndToElement.right();
                max = count;
            }
        }
        return best;
    }


    // business logic XML->RDF

    /**
     * @param xmlElement the element to be checked if it is ignored.
     * @return true when the passed element was registered to be ignored.
     */
    //@Override
    public boolean shouldIgnoreXmlRecursively(Element xmlElement) {
        List<Element> path = makePath(xmlElement);
        for (int startIndex = 0; startIndex < path.size(); startIndex++)  {
            String mapId = getSearchPathNr(startIndex, path);
            if (ignored.contains(mapId))
                return true;
        }
        return false;
    }
    
    /**
     * Returns an identifier to write as RDF URI part behind "http://m2n.at/".
     * This identifier describes a certain XML element instance that should not
     * be duplicated in RDF graph.
     * 
     * @param xmlElement the XML element to check if it is mapped to a deterministic identifier.
     * @return the identifier, or null if the element should be mapped to a generated URI.
     */
    public String getDeterministicOwlIdentifier4XmlElement(Element xmlElement)  {
        List<Element> path = makePath(xmlElement);
        for (int startIndex = 0; startIndex < path.size(); startIndex++)  {
            String mapId = getSearchPathNr(startIndex, path);
            Path idpath = deterministicElements.get(mapId);
            if (idpath != null)  {
                String uriPart = readPathValue(idpath, xmlElement);
                if (uriPart != null)
                    return uriPart;
            }
        }
        return null;
    }



    // internal XML path methods
    
    /** Reads the child element described by path from xmlElement. */
    private String readPathValue(Path path, Element xmlElement) {
        for (Path.Part p : path)    {
            Element found = null;
            for (Object o : xmlElement.getChildren())  {
                Element child = (Element) o;
                if (child.getName().equals(p.name) && child.getNamespaceURI().equals(p.namespace))  {
                    found = child;
                    break;
                }
            }
            assert found != null : "Path not found in element "+JdomXmlUtil.xpath(xmlElement)+": "+path;
            xmlElement = found;
        }
        String content = xmlElement.getText();
        assert content != null && content.trim().length() > 0 : "Deterministic ID in "+xmlElement+" is empty!";
        return makeUri(content);
    }

    /** Builds a "ns:root/ns:elem1/ns:elem2" path String to be used as map key. */
    private String path2MapId(Path xmlElement) {
        String pathMapId = "";
        for (Path.Part p : xmlElement)    {
            pathMapId = catenizeMapIds(pathMapId, xmlMapId(p.namespace, p.name));
        }
        return pathMapId;
    }

    /**
     * @return true when one of the possible search pathes of passed element is equal to path pattern.
     */
    private boolean match(Element toElement, String pathPattern) {
        List<Element> path = makePath(toElement);
        for (int startIndex = 0; startIndex < path.size(); startIndex++)  {
            String mapId = getSearchPathNr(startIndex, path);
            if (mapId.equals(pathPattern))  {
                return true;
            }
        }
        return false;
    }

    /**
     * Creates a String path, going from tail (index = 0) to head with (index = max).
     * @return the i-th search path: for 0 it's a/b/c, for 1 it's b/c, for 2 it's c.
     */
    private String getSearchPathNr(int i, List<Element> path) {
        String mapId = "";
        for (int pathIndex = i; pathIndex < path.size(); pathIndex++)  {
            String p = xmlMapId(path.get(pathIndex));
            mapId = catenizeMapIds(mapId, p);
        }
        return mapId;
    }
    
    /** @return a List path of the passed element, root is index 0, element at last index. */
    private List<Element> makePath(Element xmlElement)  {
        List<Element> path = new ArrayList<Element>();
        while (xmlElement != null)  {
            path.add(0, xmlElement);
            xmlElement = xmlElement.getParentElement();
        }
        return path;
    }


    // Path utility methods
    
    /** Utility to build a Pair from passed XML prefix and element name. */
    public final Path.Part xml(String nameSpace, String name)  {
        return new Path.Part(nameSpace, name);
    }
    
    /** Utility to build a Pair from passed RDF prefix and name. */
    public final Path.Part rdf(String nameSpace, String name)  {
        return xml(nameSpace, name);
    }
    
    /** Utility to build a Path from passed slash-separated string like a/b/c. */
    public final Path path(String slashedPath)  {
        Path path = new Path();
        for (StringTokenizer stok = new StringTokenizer(slashedPath, "/"); stok.hasMoreTokens(); )   {
            String namespaceAndName = stok.nextToken();
            int i = namespaceAndName.lastIndexOf(":");
            assert i >= 0 : "Unexpected XML name without prefix: "+slashedPath;
            
            String nameSpace = namespaceAndName.substring(0, i);
            String name = namespaceAndName.substring(i + 1);
            path.add(new Path.Part(nameSpace, name));
        }
        return path;
    }

    /** Utility to build a Path from passed pair. */
    public final Path path(Path.Part part)  {
        Path path = new Path();
        if (part != null)
            path.add(part);
        return path;
    }

    /** Utility to build a Path from passed 1-n pairs, left to right means root to element. */
    public final Path path(Path.Part... parts)  {
        Path path = new Path();
        if (parts != null)
            for (Path.Part p : parts)
                path.add(p);
        return path;
    }

    /** Utility to build a new Path from a parent path and a tail element. */
    public final Path path(Path parentPath, Path.Part tail)  {
        Path returnList = new Path(); 
        if (parentPath != null)
            returnList.addAll(parentPath);
        if (tail != null)
            returnList.add(tail);
        return returnList;
    }

    /** Utility to build a new Path from a parent path and a tail element. */
    public final Path path(Path headPath, Path tailPath)  {
        Path returnList = new Path(); 
        if (headPath != null)
            returnList.addAll(headPath);
        if (tailPath != null)
            returnList.addAll(tailPath);
        return returnList;
    }

    /**
     * @param xmlElement the element to build a namespace-unspecific XML name from
     * @return namespace+":"name
     */
    private String xmlMapId(Element xmlElement) {
        return xmlMapId(xmlElement.getNamespaceURI(), xmlElement.getName());
    }
    
    /**
     * @param namespace the namespace of the element to build
     * @param elementName the element to build a namespace-unspecific XML name from
     * @return namespace-unspecific XML name, namespace+":"name
     */
    private String xmlMapId(String namespace, String elementName) {
        return namespace+":"+elementName;
    }
    
    /**
     * @param mapId1 the leading id for the path to build.
     * @param mapId2 the trailing id for the path to build.
     * @return mapId1+"/"+mapId2
     */
    private String catenizeMapIds(String mapId1, String mapId2) {
        assert mapId1 != null && mapId2 != null;
        if (mapId1.length() <= 0)
            return mapId2;
        if (mapId2.length() <= 0)
            return mapId1;
        String separator = mapId1.endsWith("/") || mapId2.startsWith("/") ? "" : "/";
        return mapId1 + separator + mapId2;
    }

    private String rdfUri(String rdfPrefix, String rdfName){
        if (rdfPrefix.endsWith("/") == false && rdfPrefix.endsWith("#") == false &&
                rdfName.startsWith("/") == false && rdfName.startsWith("#") == false)   {
            return rdfPrefix + "/" + rdfName;
        }
        return rdfPrefix + rdfName;
    }

    /**
     * Makes a Java identifier from passed string, replacing invalid chars by '_'.
     * The returned string does not contain non-Java-identifier characters anymore.
     * This is for building "deterministic" URIs.
     */
    private static String makeUri(String src) {
        if (src == null)
            return null;
        
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < src.length(); i++) {
            char c = src.charAt(i);
            if (i == 0 && (c == '$' || !Character.isJavaIdentifierStart(c)) || i != 0 && (c == '$' || !Character.isJavaIdentifierPart(c))) {
                c = '_';
            }
            sb.append(c);
        }
        return sb.toString();
    }
}
