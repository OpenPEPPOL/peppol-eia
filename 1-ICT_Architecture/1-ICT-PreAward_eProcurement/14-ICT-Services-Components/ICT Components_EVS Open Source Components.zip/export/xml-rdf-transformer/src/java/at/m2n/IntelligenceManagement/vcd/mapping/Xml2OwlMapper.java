/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.mapping;

import java.net.MalformedURLException;

import org.jdom.Element;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.transformer.xml2owl.Xml2OwlIterationLogic;
import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;
import at.m2n.jena.util.URIGenerator;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;

/**
 * Contains XML/RDF mappings for the VCD case.
 * 
 * @author Fritz Ritzberger  18.05.2010
 */
public class Xml2OwlMapper extends Mapper implements
    Xml2OwlIterationLogic
{
	
	private MapperVariant variant;
	
    /**
     * Constructs a Mapper for a XML->RDF transformation.
     * TODO make different classes for XML->RDF and RDF->XML!
     * @throws MalformedURLException 
     */
    public Xml2OwlMapper(VcdSchemaVariant schemaVariant, MapperVariant variant) {
        super(schemaVariant);
        initXml2Rdf();
        variant.initXml2Rdf(this);
        this.variant = variant;
    }
    
    private final void initXml2Rdf()    {
        // TODO separate XML->RF and RDF->XML, following is for RDF->XML
        
        xmlRelation2OwlProperty(xml(cac, XML_CRITERION),
            path(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION), xml(cbc, XML_URI)), 
            rdf(peppol, "canCriterion"));

        xmlRelation2OwlProperty(xml(cac, XML_CRITERION),
            path(xml(cac, XML_EUROPEAN_REGULATION), xml(cbc, XML_URI)), 
            rdf(peppol, "euCriterion"));
    
        xmlRelation2OwlProperty(xml(cac, XML_CRITERION),
            xml(tmp, XML_EVIDENCE_COLLECTOR),
            rdf(peppol, "evidenceCollector"));
        
        xmlRelation2OwlProperty(xml(tmp, XML_EVIDENCE_COLLECTOR),
            path(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION), xml(cbc, XML_URI)), 
            rdf(peppol, "tnCriterion"));
        
        // Wolfgang 2010-06-07: "a VCD import creates no evidences".
        // For XML->RDF we must express that only the OntologyURI value should
        // be written instead of the whole Evidence XML element
        xmlRelation2OwlProperty(xml(tmp, XML_EVIDENCE_COLLECTOR),
            path(xml(cac, XML_EVIDENCE), xml(cac, XML_ONTOLOGY_DEFINITION_REGULATION), xml(cbc, XML_URI)),
            rdf(peppol, "suggestedPrimaryEvidence"));
        /*
         * TODO when is Evidence mapping to primaryEvidence, when to secondaryEvidence,
         * when to suggestedPrimaryEvidence, when to suggestedSecondaryEvidence?
         * 
        xmlRelation2OwlProperty(xml(tmp, XML_EVIDENCE_COLLECTOR),
            path(xml(cac, XML_EVIDENCE), xml(cac, XML_ONTOLOGY_DEFINITION_REGULATION), xml(cbc, XML_ONTOLOGY_URI)),
            rdf(peppol, "primaryEvidence"));
        xmlRelation2OwlProperty(xml(tmp, XML_EVIDENCE_COLLECTOR),
            path(xml(cac, XML_EVIDENCE), xml(cac, XML_ONTOLOGY_DEFINITION_REGULATION), xml(cbc, XML_ONTOLOGY_URI)),
            rdf(peppol, "secondaryEvidence"));
        xmlRelation2OwlProperty(xml(tmp, XML_EVIDENCE_COLLECTOR),
            path(xml(cac, XML_EVIDENCE), xml(cac, XML_ONTOLOGY_DEFINITION_REGULATION), xml(cbc, XML_ONTOLOGY_URI)),
            rdf(peppol, "suggestedSecondaryEvidence"));
         */

        
        // fri_tenderer-schema_party.n3
        xmlRelation2OwlProperty(xml(cac, XML_ISSUING_SERVICE),
            xml(cac, XML_PROVIDING_PARTY),
            rdf(peppol, "issuingServiceParty"));
        xmlRelation2OwlProperty(xml(cac, XML_ISSUING_SERVICE),
            xml(cbc, XML_ENDPOINT_ID),
            rdf(peppol, "issuingServiceEndpointID"));
        xmlRelation2OwlProperty(xml(cac, XML_ISSUING_SERVICE),
            xml(cbc, XML_NAME), 
            rdf(peppol, "issuingServiceName"));
        xmlRelation2OwlProperty(xml(cac, XML_VCD_ISSUING_SERVICE),
            xml(cac, XML_PROVIDING_PARTY),
            rdf(peppol, "issuingServiceParty"));
        xmlRelation2OwlProperty(xml(cac, XML_VCD_ISSUING_SERVICE),
            xml(cbc, XML_ENDPOINT_ID),
            rdf(peppol, "issuingServiceEndpointID"));
        xmlRelation2OwlProperty(xml(cac, XML_VCD_ISSUING_SERVICE),
            xml(cbc, XML_NAME), 
            rdf(peppol, "issuingServiceName"));
        
        mapEvidenceDocumentAttachments();
        
        
        // XML elements to OWL Classes mapping
        // ===================================
        // key = fully qualified XML element name,
        // value = List of 1-n OWL Class URIs
        // example: the XML element "VCDPackage" is "VCDRequest" in RDF
        // when no type is defined for an XML element, it will not be present
        // as RDF node, but its children may

        xml2OwlType(xml(XML_VCDPACKAGE_ROOT_NAMESPACE, XML_VCDPACKAGE_ROOT_ELEMENT), rdf(RDF_ROOT_PREFIX, RDF_ROOT_CLASS));

        xml2OwlType(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY), rdf(peppol, "Party"));
        xml2OwlType(xml(cac, XML_REQUESTER_PARTY), rdf(peppol, "Party"));
        xml2OwlType(xml(cac, XML_PROVIDING_PARTY), rdf(peppol, "Party"));
        
        xml2OwlType(xml(cac, XML_SINGLE_TENDERER), rdf(peppol, "SingleContractor"));
        xml2OwlType(xml(cac, XML_SINGLE_TENDERER), rdf(peppol, "LegalEntity"));
        
        xml2OwlType(xml(cac, XML_BIDDING_CONSORTIUM), rdf(peppol, "BiddingConsortium"));
        
        xml2OwlType(xml(cac, XML_BIDDING_CONSORTIUM_LEADER), rdf(peppol, "SingleContractor"));
        xml2OwlType(xml(cac, XML_BIDDING_CONSORTIUM_MEMBER), rdf(peppol, "LegalEntity"));
        //Distinction SP/LE is done in MapperVariant.postprocessRDF!
        
        // fri_2010-06-08: is no longer in simple_vps:
        // xml2OwlType(xml(cac, SINGLE_TENDERER), rdf(peppol, PARTY));
        
        xml2OwlType(xml(cac, XML_SUBCONTRACTOR_SINGLE_TENDERER), rdf(peppol, "LegalEntity"));
        xml2OwlType(xml(cac, XML_SUBCONTRACTOR_SINGLE_TENDERER), rdf(peppol, "Subcontractor"));

        // by Adrian, don't know if these are correct
        xml2OwlType(xml(cac, XML_BIDDING_CONSORTIUM), rdf(peppol, "LegalEntity"));
        xml2OwlType(xml(cac, XML_BIDDING_CONSORTIUM), rdf(peppol, "BiddingConsortium"));

        xml2OwlType(path(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY), xml(cac, XML_PERSON)), rdf(peppol, "Person"));
        xml2OwlType(path(xml(cac, XML_REQUESTER_PARTY), xml(cac, XML_PERSON)), rdf(peppol, "Person"));
        xml2OwlType(path(xml(cac, XML_PROVIDING_PARTY), xml(cac, XML_PERSON)), rdf(peppol, "Person"));
        xml2OwlType(path(xml(cac, XML_SIGNATORY_PARTY), xml(cac, XML_PERSON)), rdf(peppol, "Person"));
        xml2OwlType(path(xml(cac, XML_ISSUER_PARTY), xml(cac, XML_PERSON)), rdf(peppol, "Person"));
        xml2OwlType(path(xml(cac, XML_PARTY), xml(cac, XML_PERSON)), rdf(peppol, "Person"));

        xml2OwlType(path(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY), xml(cac, XML_POSTAL_ADDRESS)), rdf(peppol, "PostalAddress"));
        xml2OwlType(path(xml(cac, XML_REQUESTER_PARTY), xml(cac, XML_POSTAL_ADDRESS)), rdf(peppol, "PostalAddress"));
        xml2OwlType(path(xml(cac, XML_PROVIDING_PARTY), xml(cac, XML_POSTAL_ADDRESS)), rdf(peppol, "PostalAddress"));
        xml2OwlType(path(xml(cac, XML_SIGNATORY_PARTY), xml(cac, XML_POSTAL_ADDRESS)), rdf(peppol, "PostalAddress"));
        xml2OwlType(path(xml(cac, XML_ISSUER_PARTY), xml(cac, XML_POSTAL_ADDRESS)), rdf(peppol, "PostalAddress"));
        xml2OwlType(path(xml(cac, XML_PARTY), xml(cac, XML_POSTAL_ADDRESS)), rdf(peppol, "PostalAddress"));

        xml2OwlType(path(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY), xml(cac, XML_CONTACT)), rdf(peppol, "Contact"));
        xml2OwlType(path(xml(cac, XML_REQUESTER_PARTY), xml(cac, XML_CONTACT)), rdf(peppol, "Contact"));
        xml2OwlType(path(xml(cac, XML_PROVIDING_PARTY), xml(cac, XML_CONTACT)), rdf(peppol, "Contact"));
        xml2OwlType(path(xml(cac, XML_SIGNATORY_PARTY), xml(cac, XML_CONTACT)), rdf(peppol, "Contact"));
        xml2OwlType(path(xml(cac, XML_ISSUER_PARTY), xml(cac, XML_CONTACT)), rdf(peppol, "Contact"));
        xml2OwlType(path(xml(cac, XML_PARTY), xml(cac, XML_CONTACT)), rdf(peppol, "Contact"));
        
        
        xml2OwlType(path(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY), xml(cac, XML_POSTAL_ADDRESS), xml(cac, XML_COUNTRY)), rdf(peppol, "PACountry"));
        xml2OwlType(path(xml(cac, XML_REQUESTER_PARTY), xml(cac, XML_POSTAL_ADDRESS), xml(cac, XML_COUNTRY)), rdf(peppol, "PACountry"));
        xml2OwlType(path(xml(cac, XML_PROVIDING_PARTY), xml(cac, XML_POSTAL_ADDRESS), xml(cac, XML_COUNTRY)), rdf(peppol, "PACountry"));
        xml2OwlType(path(xml(cac, XML_SIGNATORY_PARTY), xml(cac, XML_POSTAL_ADDRESS), xml(cac, XML_COUNTRY)), rdf(peppol, "PACountry"));
        xml2OwlType(path(xml(cac, XML_ISSUER_PARTY), xml(cac, XML_POSTAL_ADDRESS), xml(cac, XML_COUNTRY)), rdf(peppol, "PACountry"));
        xml2OwlType(path(xml(cac, XML_PARTY), xml(cac, XML_POSTAL_ADDRESS), xml(cac, XML_COUNTRY)), rdf(peppol, "PACountry"));
        
        xml2OwlType(xml(cac, XML_CITIZENSHIP_COUNTRY), rdf(peppol, "PACountry"));
        xml2OwlType(xml(cac, XML_RESIDENCE_ADDRESS), rdf(peppol, "PostalAddress"));

        xml2OwlType(path(xml(cac, XML_COUNTRY)), rdf(peppol, "PACountry"));
 
        
        // can't do this like that:
        //xml2OwlType(xml(cac, XML_PERSON), rdf(peppol, "Person"));
        // because the Person of RelevantVCDPerson is mapped otherwise
        
        xml2OwlType(xml(cac, XML_ISSUING_SERVICE), rdf(peppol, "IssuingService"));
        xml2OwlType(xml(cac, XML_VCD_ISSUING_SERVICE), rdf(peppol, "IssuingService"));
        
        xml2OwlType(xml(cac, XML_RELEVANT_VCD_PERSON), rdf(peppol, "NaturalPerson"));
        xml2OwlType(xml(cac, XML_CRITERION), rdf(peppol, "CriterionCollector"));
        
        /* this is not written into RDF
        xml2OwlType(xml(cac, XML_EUROPEAN_REGULATION), rdf(peppol, "EUCriterion"));
        xml2OwlType(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION), rdf(peppol, "NationalAtomicCriterion"));
        xml2OwlType(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION), rdf(peppol, "NationalAtomicCriterion"));
        */
        
        xml2OwlType(xml(tmp, XML_EVIDENCE_COLLECTOR), rdf(peppol, "EvidenceCollector"));
        
        
        // continue this - all types to be transformed MUST be here!
        
        // XML Elements that should be mapped to IRIs generated from XML content
        // ===================================
        // key = element, value = xpath expression describng the content to use as ID
        // which is the ID the RDF URI is generated from (instead of calling URIGenerator)
        
        // following is for demo/test on simple_vpps
        //xmlDeterministicElement(xml(cac, "RequesterParty"), path(xml(cac, "PartyName"), xml(cbc, "Name")));
        
        
        // Ignored XML element names
        // ===================================
        // for now here are names that are not yet in RDF schema,
        // but finally here should be only names that are really ignored
        
        xmlIgnore(xml(cbc, XML_VCD_SCHEMA_VERSION_ID));
        xmlIgnore(xml(cbc, XML_ONTOLOGY_VERSION_ID));
        xmlIgnore(xml(cbc, XML_COMPILATION_DATE));
        xmlIgnore(xml(cbc, XML_VCD_TYPE_CODE));
        
        xmlIgnore(path(xml(vcdp, XML_VCD_PACKAGE), xml(cbc, XML_VCD_TYPE_CODE)));
        xmlIgnore(path(xml(vcd, XML_VCD), xml(cbc, XML_VCD_TYPE_CODE)));

        // there are some remnants of trying to import issuing service data strewn around, but they led to a superfluous SingleTenderer being created at export-time for bidding consortia, so we'll disable this import and just stamp our own mark on the VCD/Package.
        xmlIgnore(xml(cac, XML_ISSUING_SERVICE));
        xmlIgnore(xml(cac, XML_VCD_ISSUING_SERVICE));
        
        xmlIgnore(xml(cbc, "CompilationTime"));
        // TODO where to put these informations?

        // ignored by Adrian, don't know how to map these
        xmlIgnore(path(xml(cac, XML_ONTOLOGY_DEFINITION_REGULATION), xml(cbc, XML_NAME)));
        xmlIgnore(path(xml(tmp, XML_EVIDENCE_COLLECTOR), xml(cac, XML_EVIDENCE), xml(cac, XML_DOCUMENT_REFERENCE), xml(cac, XML_ATTACHMENT)));

        // Wolfgang 2010-06-07: "a VCD import creates no evidences".
        xmlIgnore(path(xml(cac, XML_EVIDENCE), xml(cbc, XML_TITLE)));
        xmlIgnore(path(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION), xml(cbc, XML_NAME)));
        xmlIgnore(path(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION), xml(cbc, XML_LEGAL_REFERENCE)));
        xmlIgnore(path(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION), xml(cbc, XML_NAME)));
        xmlIgnore(path(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION), xml(cbc, XML_LEGAL_REFERENCE)));
        xmlIgnore(path(xml(cac, XML_EUROPEAN_REGULATION), xml(cbc, XML_NAME)));
        xmlIgnore(path(xml(cac, XML_EUROPEAN_REGULATION), xml(cbc, XML_LEGAL_REFERENCE)));
        xmlIgnore(path(xml(cac, XML_DOCUMENT_REFERENCE), xml(cbc, XML_ID)));
        
        
        
        xmlIgnore(path(xml(cac, XML_CRITERION), xml(cac, XML_CRITERION_GROUP_REGULATION)));
        xmlIgnore(path(xml(cbc, XML_LEGAL_TEXT)));
        xmlIgnore(path(xml(cbc, XML_REQUIREMENT_DESCRIPTION)));
        xmlIgnore(path(xml(cbc, XML_FURTHER_INFORMATION)));
        xmlIgnore(path(xml(cbc, XML_SUBSTITUTE_EVIDENCE_MINIMUM_LEVEL_CODE)));
        xmlIgnore(path(xml(cbc, XML_SUBSTITUTE_EVIDENCE_DESCRIPTION)));
        
    }


    // start interface Xml2OwlIterationLogic

    /**
     * Creates an empty model with needed prefixes.
     * @return the created and configured model.
     */
    @Override
    public OntModel createXml2RdfResultModel()    {
        OntModel resultModel = ModelFactory.createOntologyModel();
        resultModel.setNsPrefix(peppolprefix, peppol);
        return resultModel;
    }
    
    /** @return true if the passed element is a VCDPackage root. */
    @Override
    public boolean isVcdPackageRootElement(Element element) {
        return element.getName().equals(XML_VCDPACKAGE_ROOT_ELEMENT) && element.getNamespaceURI().equals(XML_VCDPACKAGE_ROOT_NAMESPACE);
    }
    
    /**
     * Delegates to isFolder(Path.Part pathPart)
     * @throws SAXException 
     * @throws MalformedURLException 
     */
    @Override
    public boolean isFolder(Element xmlElement) throws MalformedURLException, SAXException {
        return isFolder(new Path.Part(xmlElement.getNamespaceURI(), xmlElement.getName()));
    }

    /**
     * @param xmlElement the XML element for whose contents a unique RDF URI should be generated.
     * @return a M2N base URI, appended referencedTypeName, appended random identifier.
     */
    @Override
    public final String generateUri(Element xmlElement)    {
        String referencedTypeName = xmlElement.getName();
        String id;
        if ((id = getDeterministicOwlIdentifier4XmlElement(xmlElement)) != null)  {
            return t + id;
        }
        return generateUri4Rdf(t + referencedTypeName);
    }
    
    /** Returns a new globally unique URI. Overridden by unit tests. */
    protected String generateUri4Rdf(String base)  {
        return URIGenerator.getForURI(base);
    }

    /**
     * @param xmlElement the empty element, containing nothing or just spaces.
     * @return true when such elements should be ignored.
     */
    @Override
    public boolean shouldIgnoreEmptyElement(Element xmlElement) {
        return true;
    }

		@Override
		public void postprocessRDF(OntModel resultModel) {
			variant.postprocessRDF(resultModel);
		}

    // end interface Xml2OwlIterationLogic

}
