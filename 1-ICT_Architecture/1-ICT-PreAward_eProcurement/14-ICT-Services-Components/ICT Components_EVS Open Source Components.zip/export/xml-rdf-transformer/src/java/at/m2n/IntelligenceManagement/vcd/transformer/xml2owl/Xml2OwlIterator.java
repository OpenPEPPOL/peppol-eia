/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xml2owl;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.jdom.Document;
import org.jdom.Element;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.util.JdomXmlUtil;

import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import com.hp.hpl.jena.ontology.Individual;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;

/**
 * Iterates an XML document and maps its contents to an Jena OWL graph.
 * The behaviour of this class is controlled by the Mapper object.
 * <p />
 * Leaf XML elements are always converted, to ignore them add an ignore
 * in Mapper. Folder XML elements are converted to RDF only when they have
 * an type assigned in Mapper. When there is no type for them, their children
 * are iterated anyway, because they might be present in RDF.
 * To ignore a folder XML element recursively, add an ignore in Mapper.
 * <p />
 * This class is not thread-safe!
 * Make transform() synchronized to achieve this.
 * 
 * @author Fritz Ritzberger  18.05.2010
 */
public class Xml2OwlIterator {

    private final Xml2OwlIterationLogic mapper;
    private OntModel rdfSchemaModel;
    private OntModel resultModel;
    
    /**
     * Creates a Transformer that works with passed Mapper.
     * @param mapper the Mapper to use for XML->RDF node mapping.
     */
    public Xml2OwlIterator(Xml2OwlIterationLogic mapper) {
        assert mapper != null : "Can not transform without a Mapper!";
        this.mapper = mapper;
    }

    /**
     * Transforms the passed document to an ontology, resolving VCDReferenceID elements.
     * @param xmlDocument the XML pre-skeleton document to transform
     * @param rdfSchemaModel the ontology holding classes and properties (meta-info) the Mapper refers to.
     * @param resultModel the ontology where to put resulting individuals into, can be null, then a new Model will be generated.
     * @return the ontolgy model with individuals created from XML
     * @throws SAXException 
     * @throws MalformedURLException 
     */
    public OntModel transform(Document xmlDocument, OntModel rdfSchemaModel, OntModel resultModel) throws MalformedURLException, SAXException {
        assert rdfSchemaModel != null : "Can not transform without a RDF schema!";
        
        if (resultModel == null)    {
            resultModel = mapper.createXml2RdfResultModel();
        }
        this.rdfSchemaModel = rdfSchemaModel;
        this.resultModel = resultModel;
        
        Element root = xmlDocument.getRootElement();
        assert mapper.isVcdPackageRootElement(root) : "This is not a VCD Package: "+xpath(root);

        transformElement(root);
        mapper.postprocessRDF(resultModel);
        
        return resultModel;
    }

    /** Type switch, distinguishing folders and leafs. 
     * @throws SAXException 
     * @throws MalformedURLException */
    private List<Xml2RdfMappedNode> transformElement(Element element) throws MalformedURLException, SAXException {
        if (mapper.shouldIgnoreXmlRecursively(element)) {
            return null;
        }
        else if (mapper.isFolder(element))   {
            return transformFolderElement(element);
        }
        else    {    // has no sub-elements: empty or simple content
            return transformLeafElement(element);
        }
    }

    /**
     * Transform an XML folder element.
     * @return the List of IndividualWrapper representing this folder element.
     *  When the passed folder is "vaporized" (ignored) by the transformation, this
     *  method will return its children in a List. When not, it will return a List
     *  of size 1 with the passed folder's representation as the only item.
     * @throws SAXException 
     * @throws MalformedURLException 
     */
    private List<Xml2RdfMappedNode> transformFolderElement(Element xmlElement) throws MalformedURLException, SAXException {
        // create the individual for this folder (when it has at least one type)
        // transform all child-elements to OWL and collect their created resources
        List<Element> xmlChildren = xmlElement.getChildren();
        List<Xml2RdfMappedNode> rdfChildren = new ArrayList<Xml2RdfMappedNode>();
        
        for (Element xmlChild : xmlChildren)  {
            List<Xml2RdfMappedNode> individuals = transformElement(xmlChild);
            if (individuals != null) {
                rdfChildren.addAll(individuals);
            }
        }
        
        List<OntClass> types = getTypesForElement(xmlElement);
        Individual individual = null;
        if (types != null && (rdfChildren.size() > 0 || false == mapper.shouldIgnoreEmptyElement(xmlElement)))  {
            individual = createIndividual(xmlElement, types);
        }   // else this folder element will not be present in RDF graph at all
        
        if (individual != null) {   // create predicates pointing to the collected children
            createProperties(xmlElement, individual, rdfChildren);
            return Arrays.asList(new Xml2RdfMappedNode [] { new Xml2RdfMappedNode(xmlElement, individual) });
        }
        else    {   // individual is null when all children are going to the parent of this node
            return rdfChildren;
        }
    }

    /**
     * Transform an XML leaf element.
     * The calling parent will use the Object returned from here as property value.
     * This method will always return a single object, the List is just a programming convenience.
     */
    private List<Xml2RdfMappedNode> transformLeafElement(Element xmlElement)  {
        String content = xmlElement.getText();
        
        String lang = xmlElement.getAttributeValue("languageID");
        
        if ((content == null || content.trim().length() <= 0) && mapper.shouldIgnoreEmptyElement(xmlElement))
            return null;    // empty element
        
        return Collections.singletonList(new Xml2RdfMappedNode(xmlElement, content, lang));
    }



    private Individual createIndividual(Element element, List<OntClass> types) {
        assert types != null && types.size() > 0 : "Can not create individual without type: "+element;
        
        // provide the new individual with all of its types
        String individualUri = mapper.generateUri(element);
        OntClass type = types.get(0);   // create with first type
        Individual individual = resultModel.createIndividual(individualUri, type);
        for (int i = 1; i < types.size(); i++)  {   // add optional other types
            individual.addRDFType(types.get(i));
        }
        return individual;
    }

    private void createProperties(Element xmlParent, Individual rdfParent, List<Xml2RdfMappedNode> children) {
        // add all related child resources to it
        if (children != null)    {
            for (Xml2RdfMappedNode child : children)   {
                createProperty(xmlParent, rdfParent, child);
            }
        }
    }

    private void createProperty(Element xmlParent, Individual rdfParent, Xml2RdfMappedNode propertyValue)    {
        // Mind that the "is folder" decision implemented here must be in
        // sync with Owl2SkeletonTransformer.addFolderChild() ! TODO
        
        String relationUri = mapper.getOwlProperty4XmlRelation(xmlParent, propertyValue.xmlOriginator);
        
        if (relationUri == null) {
        	throw new RuntimeException("Please map the RDF property for the XML relation from "+
            xpath(xmlParent)+" to "+xpath(propertyValue.xmlOriginator)+
            ", or add an ignore for "+xpath(propertyValue.xmlOriginator));
        }
        
        Property property = rdfSchemaModel.getProperty(relationUri);  // hopefully does not create the Property ...
        assert property != null :
            "Predicate property not found in RDF graph: "+relationUri+ ", XML relation from "+
            xpath(xmlParent)+" to "+xpath(propertyValue.xmlOriginator);
        
        RDFNode rdfValue;
        if (propertyValue.individual != null)   {   // property target is an ObjectProperty
            rdfValue = propertyValue.individual;
        }
        else    {
            assert propertyValue.xmlContentText != null : "Invalid property value: "+propertyValue;

            boolean isResource = property.hasProperty(RDF.type, OWL.ObjectProperty);
            if (isResource) {   // things like caCountry go here
                rdfValue = resultModel.createResource(propertyValue.xmlContentText);
            }
            else    {   // all primitive types go here
                StmtIterator it = property.listProperties(RDFS.range);
                String dataTypeUri = (it.hasNext() == false)
                    ? XSDDatatype.XSDstring.getURI()    // no data-type available, assume string
                    : it.nextStatement().getResource().getURI();
                it.close();
                
                String lang = propertyValue.lang;
                rdfValue = lang == null ? resultModel.createTypedLiteral(propertyValue.xmlContentText, dataTypeUri) : resultModel.createLiteral(propertyValue.xmlContentText, lang);
            }
        }
        
        rdfParent.addProperty(property, rdfValue);
    }
    
    private List<OntClass> getTypesForElement(Element element) {
        Set<String> types = mapper.getOwlTypes(element);
        
        if (types != null && types.size() > 0)  {
            List<OntClass> ontClasses = new ArrayList<OntClass>(types.size());
            
            for (String type : types)   {
                OntClass clazz = rdfSchemaModel.getOntClass(type);
                assert clazz != null :
                    "When a type was specified in Mapper, it must exist in the ontology schema, but there is no OntClass "+
                    type+" for XML element "+xpath(element);

                ontClasses.add(clazz);
            }
            return ontClasses;
        }
        return null;
    }

    /** Debug helper */
    private String xpath(Element e) {
        return JdomXmlUtil.xpath(e);
    }

    
    /**
     * Binds together an XML element and its corresponding RDF individual or literal content.
     * This is needed to know the XML originator of some RDF node when creating its Properties .
     */
    private static class Xml2RdfMappedNode
    {
        final Element xmlOriginator;    // never null
        final String xmlContentText;    // variant 1
        final String lang;				// variant 1
        final Individual individual;    // variant 2
        
        Xml2RdfMappedNode(Element xmlOriginator, String xmlContentText, String lang) {
            assert xmlOriginator != null && xmlContentText != null : "Null values do not make sense here!";
            this.xmlOriginator = xmlOriginator;
            this.xmlContentText = xmlContentText;
            this.lang = lang;
            this.individual = null;
        }
        Xml2RdfMappedNode(Element xmlOriginator, Individual individual) {
            assert xmlOriginator != null && individual != null : "Null values do not make sense here!";
            this.xmlOriginator = xmlOriginator;
            this.individual = individual;
            this.xmlContentText = null;
            this.lang = null;
        }
    }
    
}
