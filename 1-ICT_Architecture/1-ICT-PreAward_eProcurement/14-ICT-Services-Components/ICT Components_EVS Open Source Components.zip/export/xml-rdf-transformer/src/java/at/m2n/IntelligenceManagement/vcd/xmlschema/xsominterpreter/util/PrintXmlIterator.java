/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.util;

import java.io.PrintStream;
import java.util.Map;
import java.util.Stack;

import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.ComplexElement;
import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.Element;
import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.PrefixGenerator;
import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.SimpleElement;

public class PrintXmlIterator extends PrintTextIterator
{
    private Stack<String> currentElement = new Stack<String>();
    private Map<String,String> namespaceMap;
    
    public PrintXmlIterator(PrintStream out) {
        super(out);
        out.println("<?xml version='1.0'?>");
    }
    
    @Override
    public void print(Element d)    {
        if (namespaceMap == null)  {
            namespaceMap = new PrefixGenerator(d).getNamespaceMap();
        }
        super.print(d);
    }
    
    @Override
    protected void printIt(Element d)   {
        String prefix = (d.getPrefix() != null ? d.getPrefix()+":" : "");
        String baseOutput = prefix+d.name+
            " minOccurs='"+(d.getMinOccurs() == null ? "1" : d.getMinOccurs())+
            "' maxOccurs='"+(d.getMaxOccurs() == null ? "1" : d.getMaxOccurs())+"'";

        if (isComplexElement(d))   {
            currentElement.push(prefix+d.name);
            
            ComplexElement ce = (ComplexElement) d;
            String baseOutput2 = baseOutput+" type='"+ce.type+"'"+" childListType='"+ce.getChildListType()+"'";
            if (namespaceMap != null)  {
                out.println("<"+baseOutput2+printNamespacesAttributes(namespaceMap)+">");
            }
            else    {
                out.println("<"+baseOutput2+">");
            }
        }
        else if (d instanceof SimpleElement)   {
            SimpleElement se = (SimpleElement) d;
            out.println("<"+baseOutput+" xsdType='xsd:"+se.xsdDataType+"' />");
        }
        else    {
            out.println("<"+baseOutput+" unresolved='true' />");
        }
    }
        
    @Override
    protected void decrement(Element d)    {
        super.decrement(d);
        indent();
        out.println("</"+currentElement.pop()+">");
    }
    
    private String printNamespacesAttributes(Map<String, String> namespaceMap) {
        StringBuffer sb = new StringBuffer();
        for (Map.Entry<String,String> e : namespaceMap.entrySet())  {
            sb.append(" xmlns:"+e.getValue()+"='"+e.getKey()+"'");
        }
        return sb.toString();
    }

}
