/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xmladjust;

import org.jdom.Document;
import org.jdom.Element;

/**
 * The TendererRootResource->NaturalPerson* properties in RDF have to be written
 * to some XML elements, but there are none except the Person in EconomicOperator,
 * but that XML Person has no place for other RDF NaturalPerson data like birthplace etc.
 * <p />
 * Currently three of the RDF NaturalPerson properties are mapped to XML EconomicOperator/Party/Person.
 * <p />
 * NaturalPerson in TendererRootResource occurs when tenderer is a SoleProprietor.
 * 
 * TODO Is this a pending issue for VCD Task-Force?
 * 
 * @author Fritz Ritzberger  11.06.2010
 */
public class EconomicOperatorNaturalPersonAdjuster extends AbstractXmlAdjuster {

    /**
     * This adjuster takes the Person values of FirstName, MiddleName and FamilyName and
     * puts them, concatenated, to the Party/PartyName/Name element if this is empty.
     * 
     * This is a convenience for SoleProprietor that has no name there but must have one.
     */
    @Override
    public Document rdf2Xml(Document document) {
        for (Element economicOperator :
                findByName(document.getRootElement(), getMapper().getEconomicOperatorDescr()))  {
            
            Element party = findSingleDirectChild(economicOperator, getMapper().getPartyDescr(), false);
            Element partyName = party != null ? findSingleDirectChild(party,  getMapper().getPartyNameDescr(), false) : null;
            Element name = partyName != null ? findSingleDirectChild(partyName, getMapper().getNameDescr(), false) : null;
            
            Element person = party != null ? findSingleDirectChild(party, getMapper().getPersonDescr(), false) : null;
            Element personFirstName = person != null ? findSingleDirectChild(person,  getMapper().getFirstNameDescr(), false) : null;
            Element personMiddleName = person != null ? findSingleDirectChild(person,  getMapper().getMiddleNameDescr(), false) : null;
            Element personFamilyName = person != null ? findSingleDirectChild(person,  getMapper().getFamilyNameDescr(), false) : null;
            String somePersonName = 
                (personFirstName != null && personFirstName.getText().length() > 0 ? personFirstName.getText() : "")+" "+
                (personMiddleName != null && personMiddleName.getText().length() > 0 ? personMiddleName.getText() : "")+" "+
                (personFamilyName != null && personFamilyName.getText().length() > 0 ? personFamilyName.getText() : "");
            somePersonName = somePersonName.trim();
            
            if ((name == null || name.getTextTrim().length() <= 0) && somePersonName.length() > 0)  {
                if (party == null)  {
                    party = getMapper().newParty();
                    economicOperator.addContent(party);
                }
                if (partyName == null)  {
                    partyName = getMapper().newPartyName();
                    party.addContent(partyName);
                }
                if (name == null)  {
                    name = getMapper().newName();
                    partyName.addContent(name);
                }
                
                name.setText(somePersonName);
            }
        }
        return document;
    }

    /** Does nothing. */
    @Override
    public Document xml2Rdf(Document document) {
        return document;
    }

}
