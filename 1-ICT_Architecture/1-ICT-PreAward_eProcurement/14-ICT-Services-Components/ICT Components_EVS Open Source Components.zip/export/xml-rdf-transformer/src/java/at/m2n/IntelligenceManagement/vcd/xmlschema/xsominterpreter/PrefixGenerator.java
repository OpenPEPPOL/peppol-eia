/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter;

import java.util.Hashtable;
import java.util.Map;


/**
 * Writes prefixes into the passed tree of Elements.
 * The prefixes are created from uppercase letters of the namespace.
 * Prefixes are written directly into the Elements, and collected
 * into a Map that can be retrieved after.
 * 
 * @author Fritz Ritzberger 05.07.2010
 */
public class PrefixGenerator {
    private Map<String,String> namespaceMap;
    
    public PrefixGenerator(Element root)   {
        namespaceMap = addNamespaces(root);
    }
    
    /**
     * @return a map containing key = namespace and value = prefix.
     */
    public Map<String,String> getNamespaceMap() {
        return namespaceMap;
    }
    
    private Map<String,String> addNamespaces(Element d) {
        Map<String,String> namespaceMap = new Hashtable<String,String>();
        collectNamespaces(d, namespaceMap);
        return namespaceMap;
    }
    
    private void collectNamespaces(Element d, Map<String,String> namespaceMap) {
        if (d.getPrefix() == null)   {
            d.setPrefix(namespaceMap.get(d.nameSpace));
            if (d.getPrefix() == null){
                String prefix = generatePrefix(d.nameSpace, namespaceMap);
                namespaceMap.put(d.nameSpace, prefix);
                d.setPrefix(prefix);
            }
        }
        
        for (Element desc : d.getChildren())
            collectNamespaces(desc, namespaceMap);
    }
    
    private String generatePrefix(String nameSpace, Map<String,String> namespaceMap) {
        StringBuffer sb = new StringBuffer();
        for (char c : nameSpace.toCharArray())  {
            if (Character.isDigit(c) == false && Character.isUpperCase(c))
                sb.append(Character.toLowerCase(c));
        }
        
        String p = sb.toString();
        if (p.length() <= 0)
            p = "n";
        else if (namespaceMap.containsValue(p) == false)
            return p;
        
        int count = 1;
        String pc;
        do  {
            pc = p + count;
            count++;
        }
        while (namespaceMap.containsValue(pc));
        return pc;
    }

}
