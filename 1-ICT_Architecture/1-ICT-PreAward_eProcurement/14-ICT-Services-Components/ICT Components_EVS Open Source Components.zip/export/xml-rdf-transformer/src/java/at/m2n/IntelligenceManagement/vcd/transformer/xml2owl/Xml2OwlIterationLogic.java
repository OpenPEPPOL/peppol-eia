/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xml2owl;

import java.net.MalformedURLException;
import java.util.Set;

import org.jdom.Element;
import org.xml.sax.SAXException;

import com.hp.hpl.jena.ontology.OntModel;

/**
 * The responsibilities of the Mapper against the XML->RDF Iterator.
 * 
 * @author Fritz Ritzberger 01.07.2010
 */
public interface Xml2OwlIterationLogic
{
    /** @return a newly created result model for RDF instances created. */
    OntModel createXml2RdfResultModel();
    
    /** @return true if the passed element is the root element of the XML to create. This is a sanity check. */
    boolean isVcdPackageRootElement(Element root);
    
    /** @return true if the passed element should be ignored recursively. */
    boolean shouldIgnoreXmlRecursively(Element element);
    
    /** @return true if passed element can have sub-elements, false if it has text content. 
     * @throws SAXException 
     * @throws MalformedURLException */
    boolean isFolder(Element element) throws MalformedURLException, SAXException;
    
    /** @return true if the passed empty element should be ignored, false if it should be written anyway.
     * Empty means no text content or no sub-elements. */
    boolean shouldIgnoreEmptyElement(Element emptyXmlElement);
    
    /** @return a generated URI for passed XML element that should reflect the XML element a little. */
    String generateUri(Element element);
    
    /** @return the name of the RDF Property that represents the passed XML parent-child relation in XML. */
    String getOwlProperty4XmlRelation(Element xmlParent, Element xmlChild);
    
    /** @return RDF/OWL Class names that the RDF resource representing passed XML element will be type of.
     * This is called for "Folder" elements only. */
    Set<String> getOwlTypes(Element element);

		void postprocessRDF(OntModel resultModel);
}