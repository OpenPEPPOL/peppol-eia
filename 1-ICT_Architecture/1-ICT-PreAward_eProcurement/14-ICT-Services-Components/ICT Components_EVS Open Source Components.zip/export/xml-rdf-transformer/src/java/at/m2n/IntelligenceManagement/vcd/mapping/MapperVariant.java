/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.mapping;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;
import at.m2n.jena.util.OntUtil;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;
import com.hp.hpl.jena.vocabulary.RDF;




public interface MapperVariant {
	void initRdf2Xml(Mapper mapper);
	void initXml2Rdf(Mapper mapper);

	/** preprocess for rdf->xml*/
	void preprocessRDF(Model rdfInstancesModel);
	
	/** postprocess for xml->rdf*/
	void postprocessRDF(Model m);
	
	public class Get {
		public static MapperVariant get(VcdSchemaVariant sv) {
			switch (sv.getName()) {
				case FULL:
					return FULL;
					
				case SKELETON:
				case TENDERER_CRITERION_EVIDENCE_SKELETON:
					return TENDERER_CRITERION_EVIDENCE_SKELETON;
				
				case TENDERER_CRITERION_SKELETON:
					return TENDERER_CRITERION_SKELETON;
					
				case PRESKELETON:
				case TENDERER_SKELETON:
					return TENDERER_SKELETON;
					
				default:
					throw new IllegalArgumentException("No such mapper variant: "+sv);
			}
		}
	}
	
	abstract class AbstractMapperVariant implements MapperVariant, MappingNames {
		private Logger logger = Logger.getLogger(getClass());
		private MapperVariant base;
		
		public AbstractMapperVariant(MapperVariant base) {
			super();
			this.base = base == null ? NULL : base;
		}

		@Override
		public void initRdf2Xml(Mapper mapper) {
			base.initRdf2Xml(mapper);
			initCommon(mapper);
		}

		@Override
		public void initXml2Rdf(Mapper mapper) {
			base.initXml2Rdf(mapper);
			initCommon(mapper);
		}
		
		@Override
		public void postprocessRDF(Model m) {
			Resource R_LEGAL_ENTITY = new ResourceImpl("http://m2n.at/2009/05/peppol/LegalEntity");
			
			Set<Resource> tenderers = new HashSet<Resource>();
			
			StmtIterator iTenderers = m.listStatements(null, RDF.type, R_LEGAL_ENTITY);
			try {
				while (iTenderers.hasNext()) {
				  Resource rTenderer = iTenderers.nextStatement().getSubject();
				  tenderers.add(rTenderer);
				}
			} finally {
				iTenderers.close();
			}
			
			Property P_PERSON = new PropertyImpl("http://m2n.at/2009/05/peppol/person");
			Resource R_SOLE_PROPRIETOR = new ResourceImpl("http://m2n.at/2009/05/peppol/SoleProprietor");
			
			Property P_SPI = new PropertyImpl("http://m2n.at/2009/05/peppol/soleProprietorshipIndicator");
			
			

			for (Resource tenderer : tenderers) {
				boolean soleProprietor = false;
				
				Statement stmtSPI = tenderer.getProperty(P_SPI);
				if (stmtSPI != null) {
					String sSoleProprietor = stmtSPI.getLiteral().getString();
					if ("true".equalsIgnoreCase(sSoleProprietor))
						soleProprietor = true;
				}
				
				if (soleProprietor) {
						m.remove(tenderer, RDF.type, R_LEGAL_ENTITY);
						m.add(tenderer, RDF.type, R_SOLE_PROPRIETOR);
					}

			}
			
		}
			
		@Override
		public void preprocessRDF(Model m) {
//			Resource R_SOLE_PROPRIETOR = new ResourceImpl("http://m2n.at/2009/05/peppol/SoleProprietor");
//			
//			Set<Resource> soleprops = new HashSet<Resource>();
//			
//			StmtIterator iTenderers = m.listStatements(null, RDF.type, R_SOLE_PROPRIETOR);
//			try {
//				while (iTenderers.hasNext()) {
//				  Resource rTenderer = iTenderers.nextStatement().getSubject();
//				  soleprops.add(rTenderer);
//				}
//			} finally {
//				iTenderers.close();
//			}
//			
//			Property P_PERSON = new PropertyImpl("http://m2n.at/2009/05/peppol/person");
//
//			for (Resource soleprop : soleprops) {
//				soleprop.addProperty(P_PERSON, soleprop);
//			}
//			
		}
		
		void initCommon(Mapper mapper) {
			
		}
	}
	
	public static MapperVariant NULL = new MapperVariant() {

		@Override
		public void initRdf2Xml(Mapper mapper) {}

		@Override
		public void initXml2Rdf(Mapper mapper) {}

		@Override
		public void postprocessRDF(Model m) {}

		@Override
		public void preprocessRDF(Model rdfInstancesModel) {}
		
		
		
	};
	
	public static MapperVariant TENDERER_SKELETON = new AbstractMapperVariant(null) {
		
	};

	public static MapperVariant TENDERER_CRITERION_SKELETON = new AbstractMapperVariant(TENDERER_SKELETON) {
		@Override
		public void initCommon(Mapper m) {
      for (String aSingleTenderer : new String [] { XML_SINGLE_TENDERER, XML_SUBCONTRACTOR_SINGLE_TENDERER, XML_BIDDING_CONSORTIUM_LEADER, XML_BIDDING_CONSORTIUM_MEMBER, XML_BIDDING_CONSORTIUM })   {
      	m.xmlRelation2OwlProperty(m.xml(cac, aSingleTenderer),
      	                          m.path(m.xml(vcd, XML_VCD), m.xml(cac, XML_ECONOMIC_OPERATOR), m.xml(cac, XML_CRITERION)),
      	                          m.rdf(peppol, "criterionCollector"));
      }
                          
      m.xmlRelation2OwlProperty(m.xml(cac, XML_RELEVANT_VCD_PERSON),
                                m.xml(cac, XML_CRITERION),
                                m.rdf(peppol, "criterionCollector"));
    }
		
		
		private static final String PEPPOL = "http://m2n.at/2009/05/peppol/";
		private final Property P_CRIT_COLL = new PropertyImpl(PEPPOL+"criterionCollector");
		private final Property P_COLL_CANC = new PropertyImpl(PEPPOL+"canCriterion");
		private final Property P_WANTS = new PropertyImpl(PEPPOL+"wantsToProveCANC");
		private final Property P_REQUESTED = new PropertyImpl(PEPPOL+"requestedIndicator");
		private final Property P_SUGGESTED = new PropertyImpl(PEPPOL+"suggestedCANC");

		
		public void postprocessRDF(Model m) {
			super.postprocessRDF(m);
			
			List<Statement> add = new LinkedList<Statement>();
			List<Resource> remove = new LinkedList<Resource>();
			
			StmtIterator iCCs = m.listStatements(null, P_CRIT_COLL, (RDFNode)null);
			while (iCCs.hasNext()) {
				Statement stmtCC = iCCs.nextStatement();
				Resource rOwner = stmtCC.getSubject();
				Resource rCC = stmtCC.getResource();
				
				if (rCC == null)
					continue;
				
				remove.add(rCC);
				
				StmtIterator iCANCs = rCC.listProperties(P_COLL_CANC);
				while (iCANCs.hasNext()) {
					Statement stmtCANC = iCANCs.nextStatement();
					Resource rCANC = stmtCANC.getResource();
					
					if (rCANC == null)
						continue;

					add.add(m.createStatement(rOwner, P_WANTS, rCANC));

                    if (rCC.hasProperty(P_REQUESTED) && rCC.getProperty(P_REQUESTED).getLiteral().getBoolean()) {
						add.add(m.createStatement(rOwner, P_SUGGESTED, rCANC));
					}
					
				}
				iCANCs.close();
				
			} 
			iCCs.close();
			
			m.add(add);
			for (Resource r : remove) {
				m.removeAll(r, null, null);
				m.removeAll(null, null, r);
			}
			
		}
		

	};

	public static MapperVariant TENDERER_CRITERION_EVIDENCE_SKELETON = new AbstractMapperVariant(TENDERER_CRITERION_SKELETON) {

		@Override
		public void initCommon(Mapper m) {
			
      for (String aSingleTenderer : new String [] { XML_SINGLE_TENDERER, XML_SUBCONTRACTOR_SINGLE_TENDERER, XML_BIDDING_CONSORTIUM_LEADER, XML_BIDDING_CONSORTIUM_MEMBER, XML_BIDDING_CONSORTIUM })   {
      	m.xmlRelation2OwlProperty(m.xml(cac, aSingleTenderer),
      	                          m.path(m.xml(vcd, XML_VCD), m.xml(cac, XML_ECONOMIC_OPERATOR), m.xml(cac, XML_CRITERION)),
      	                          m.rdf(peppol, "criterionCollector"));
      }
                          
      m.xmlRelation2OwlProperty(m.xml(cac, XML_RELEVANT_VCD_PERSON),
                                m.xml(cac, XML_CRITERION),
                                m.rdf(peppol, "criterionCollector"));
                          

          // Wolfgang 2010-06-07:
          // Wird ein transformer als "full package" angeworfen, sollen die suggested* evidences NICHT
          // von RDF->XML geschrieben werden, sondern nur die tatsächlich gewählten (primary/secondary) evidences.
          // Im anderen Falle sollen aber alle evidences geschrieben werden.
          m.xmlRelation2OwlProperty(m.xml(tmp, XML_EVIDENCE_COLLECTOR),
              m.xml(cac, XML_EVIDENCE), 
              m.rdf(peppol, "suggestedPrimaryEvidence"));
          m.xmlRelation2OwlProperty(m.xml(tmp, XML_EVIDENCE_COLLECTOR),
              m.xml(cac, XML_EVIDENCE), 
              m.rdf(peppol, "suggestedSecondaryEvidence"));
		}
		
	};
	
	public static MapperVariant FULL = new AbstractMapperVariant(TENDERER_CRITERION_EVIDENCE_SKELETON) {

		@Override
		public void initCommon(Mapper m) {
        m.mapEvidenceDocumentAttachments();
        
        // transport the blob RDF resource URI for later resolution in XML
        m.xmlRelation2OwlProperty(m.xml(cac, XML_DOCUMENT_REFERENCE),
                                  m.path(m.xml(cac, XML_ATTACHMENT), m.xml(cac, XML_EXTERNAL_REFERENCE), m.xml(tmp, XML_SERVICE_DOCUMENT_BLOB_URI)),
                                  m.rdf(m2n, "blob"));

		}
		
	};


	
}
