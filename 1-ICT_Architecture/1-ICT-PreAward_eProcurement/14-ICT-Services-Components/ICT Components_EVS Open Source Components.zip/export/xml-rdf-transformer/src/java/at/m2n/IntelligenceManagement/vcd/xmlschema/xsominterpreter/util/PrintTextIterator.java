/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.util;

import java.io.PrintStream;

import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.ComplexElement;
import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.Element;

public class PrintTextIterator
{
    protected final PrintStream out;
    private int indent;
    
    public PrintTextIterator(PrintStream out) {
        this.out = out;
    }
    
    public void print(Element descriptor)    {
        indent();
        printIt(descriptor);
        
        if (isComplexElement(descriptor))    {
            increment(descriptor);
            for (Element d : descriptor.getChildren())    {
                print(d);
            }
            decrement(descriptor);
        }
    }
    
    protected boolean isComplexElement(Element e)   {
        return e instanceof ComplexElement;
    }
    
    protected void indent() {
        for (int i = 0; i < indent; i++)
            out.print(" ");
    }
    
    protected void decrement(Element descriptor)    {
        indent -= 4;
    }
    
    protected void increment(Element descriptor)    {
        indent += 4;
    }
    
    protected void printIt(Element d) {
        out.println(d);
    }

}
