/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xmladjust;

import org.jdom.Document;
import org.jdom.Element;

/**
 * Goes to every XML "Criterion" element and checks if there is a RequestedIndicator,
 * puts one there with value false, when not.
 * 
 * @author Fritz Ritzberger  07.06.2010
 */
class RequestedIndicatorAdjuster extends AbstractXmlAdjuster {
    
    /**
     * Adds RequestedIndicator with value false wherever not present.
     */
    @Override
    public Document rdf2Xml(Document document) {
        for (Element criterion :    // for all XML Criterion elements
                findByName(document.getRootElement(), getMapper().getCriterionDescr()))    {
            
            Element requestedIndicator = findSingleDirectChild(criterion, getMapper().getRequestedIndicatorDescr(), false);
            if (requestedIndicator == null) {
                requestedIndicator = getMapper().newRequestedIndicator();
                criterion.addContent(requestedIndicator);
            }
            if (requestedIndicator.getText().length() <= 0) {
                requestedIndicator.setText("false");
            }
        }
        return document;
    }
    
    /**
     * Does nothing.
     */
    @Override
    public Document xml2Rdf(Document document) {
        return document;
    }

}
