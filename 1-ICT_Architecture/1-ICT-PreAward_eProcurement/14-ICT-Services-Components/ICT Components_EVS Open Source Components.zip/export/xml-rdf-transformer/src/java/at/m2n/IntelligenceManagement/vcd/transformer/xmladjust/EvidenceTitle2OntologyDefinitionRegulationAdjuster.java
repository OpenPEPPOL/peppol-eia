/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xmladjust;

import org.jdom.Document;
import org.jdom.Element;

/**
 * Goes to every XML "Criterion" element and checks if there is a RequestedIndicator,
 * puts one there with value false, when not.
 * 
 * @author Fritz Ritzberger  07.06.2010
 */
class EvidenceTitle2OntologyDefinitionRegulationAdjuster extends AbstractXmlAdjuster {
    
    /**
     * Adds ontologydefinitionregulation-text from evidence-title, if not set
     */
    @Override
    public Document rdf2Xml(Document document) {
        for (Element evidence :    // for all XML Criterion elements
                findByName(document.getRootElement(), getMapper().getEvidenceDescr()))    {
            
        	//TODO: we now have MULTIPLE titles!! what do we do?
            Element title = findSingleDirectChild(evidence, getMapper().getTitleDescr(), false);
            if (title != null) {
                Element ontDefReg = findSingleDirectChild(evidence, getMapper().getOntologyDefinitionRegulationDescr(), false);
                if (ontDefReg != null)  {
                    Element name = findSingleDirectChild(ontDefReg, getMapper().getNameDescr(), false);
                    if (name == null)   {
                        name = getMapper().newName();
                        ontDefReg.addContent(name);
                    }
                    if (name.getText().length() <= 0) {
                        name.setText(title.getText());
                    }
                }
            }
        }
        return document;
    }
    
    /**
     * Does nothing.
     */
    @Override
    public Document xml2Rdf(Document document) {
        return document;
    }

}
