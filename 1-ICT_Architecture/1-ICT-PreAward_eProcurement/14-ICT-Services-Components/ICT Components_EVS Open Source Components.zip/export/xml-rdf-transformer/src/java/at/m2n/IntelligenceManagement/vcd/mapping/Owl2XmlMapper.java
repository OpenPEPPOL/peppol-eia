/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.mapping;

import java.util.List;

import org.jdom.Element;
import org.jdom.Namespace;

import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.Owl2XmlIterationLogic;
import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.vocabulary.RDF;

/**
 * Contains XML/RDF mappings for the VCD case.
 * 
 * @author Fritz Ritzberger  18.05.2010
 */
public class Owl2XmlMapper extends Mapper implements
    Owl2XmlIterationLogic
{
    /**
     * Constructs a Mapper for a RDF->XML normal or "full-package" transformation.
     * TODO make different classes for XML->RDF and RDF->XML!
     * @param isFullPackageTransformation when true this transformation is a "full package" transformation.
     */
    public Owl2XmlMapper(VcdSchemaVariant schemaVariant, MapperVariant variant)    {
        super(schemaVariant);
        initRdf2Xml();
        variant.initRdf2Xml(this);
    }

    /** Initializes mappings that are used for RDF->XML only. */
    private final void initRdf2Xml()    {
        xmlRelation2OwlProperty(xml(cac, XML_CRITERION),
            xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION), 
            rdf(peppol, "canCriterion"));

        xmlRelation2OwlProperty(xml(cac, XML_CRITERION),
            xml(cac, XML_EUROPEAN_REGULATION),
            rdf(peppol, "euCriterion"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CRITERION),
                xml(cac, XML_CRITERION_GROUP_REGULATION),
                rdf(peppol, "euGroup"));        
    
        xmlRelation2OwlProperty(xml(cac, XML_CRITERION),
            xml(tmp, XML_EVIDENCE_COLLECTOR), 
            rdf(peppol, "evidenceCollector"));
        
        
        for (String aSingleTenderer : new String [] { XML_ECONOMIC_OPERATOR, XML_RELEVANT_VCD_PERSON, XML_SINGLE_TENDERER, XML_BIDDING_CONSORTIUM_LEADER, XML_BIDDING_CONSORTIUM_MEMBER, XML_SUBCONTRACTOR_SINGLE_TENDERER, XML_BIDDING_CONSORTIUM})   {
          xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                                  path(xml(vcd, XML_VCD), xml(tmp, XML_SERVICE_COLLECTOR)), 
                                  rdf(peppol, "serviceCollector"));
        }

        xmlRelation2OwlProperty(xml(tmp, XML_EVIDENCE_COLLECTOR),
            xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION), 
            rdf(peppol, "tnCriterion"));
        
        xmlRelation2OwlProperty(xml(tmp, XML_EVIDENCE_COLLECTOR),
                                xml(tmp, XML_SERVICE_COLLECTOR), 
                                rdf(peppol, "ecServiceCollector"));
        
        xmlRelation2OwlProperty(xml(tmp, XML_SERVICE_COLLECTOR),
            xml(cac, XML_EVIDENCE), 
            rdf(peppol, "evidence"));
        
        xmlRelation2OwlProperty(xml(tmp, XML_SERVICE_COLLECTOR),
                                xml(cac, XML_DOCUMENT_REFERENCE), 
                                rdf(peppol, "evidenceDocument"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
            xml(cbc, XML_NAME_ENGLISH),
            rdf(peppol, "Name"));
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
                xml(cbc, XML_NAME_NATIONAL),
                rdf(peppol, "nationalName"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
            xml(cbc, XML_LEGAL_REFERENCE),
            rdf(peppol, "legalReference"));

        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
                xml(cbc, XML_LEGAL_TEXT_ENGLISH),
                rdf(peppol, "LegalText"));

        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
                xml(cbc, XML_LEGAL_TEXT_NATIONAL),
                rdf(peppol, "nationalLegalText"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
                xml(cbc, XML_FURTHER_INFORMATION_ENGLISH),
                rdf(peppol, "LegalExplanation"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
                xml(cbc, XML_FURTHER_INFORMATION_NATIONAL),
                rdf(peppol, "nationalLegalExplanation"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
                xml(cbc, XML_REQUIREMENT_DESCRIPTION),
                rdf(peppol, "criterionRequirementHint"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
                xml(cbc, XML_SUBSTITUTE_EVIDENCE_DESCRIPTION),
                rdf(peppol, "selfEvidenceHint"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION),
                xml(cbc, XML_SUBSTITUTE_EVIDENCE_MINIMUM_LEVEL_CODE),
                rdf(peppol, "minimumSubstitutionLevel"));
        
        

        xmlRelation2OwlProperty(xml(cac, XML_EUROPEAN_REGULATION),
            xml(cbc, XML_NAME_ENGLISH),
            rdf(peppol, "Name"));
        xmlRelation2OwlProperty(xml(cac, XML_EUROPEAN_REGULATION),
                xml(cbc, XML_NAME_NATIONAL),
                rdf(peppol, "nationalName")); //a rather theoretic (= impossible) case.

        xmlRelation2OwlProperty(xml(cac, XML_EUROPEAN_REGULATION),
            xml(cbc, XML_LEGAL_REFERENCE),
            rdf(peppol, "legalReference"));
  
        xmlRelation2OwlProperty(xml(cac, XML_EUROPEAN_REGULATION),
                xml(cbc, XML_LEGAL_TEXT_ENGLISH),
                rdf(peppol, "LegalText"));
        
        xmlRelation2OwlProperty(xml(cac, XML_EUROPEAN_REGULATION),
                xml(cbc, XML_FURTHER_INFORMATION_ENGLISH),
                rdf(peppol, "LegalExplanation"));
        
        
        
        xmlRelation2OwlProperty(xml(cac, XML_CRITERION_GROUP_REGULATION),
                xml(cbc, XML_NAME_ENGLISH),
                rdf(peppol, "Name"));
        xmlRelation2OwlProperty(xml(cac, XML_CRITERION_GROUP_REGULATION),
                xml(cbc, XML_NAME_NATIONAL),
                rdf(peppol, "nationalName")); //also impossible (european group!)
            xmlRelation2OwlProperty(xml(cac, XML_CRITERION_GROUP_REGULATION),
                xml(cbc, XML_LEGAL_REFERENCE),
                rdf(peppol, "legalReference"));        

        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
            xml(cbc, XML_NAME_ENGLISH),
            rdf(peppol, "Name"));
        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
                xml(cbc, XML_NAME_NATIONAL),
                rdf(peppol, "nationalName"));
        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
            xml(cbc, XML_LEGAL_REFERENCE),
            rdf(peppol, "legalReference"));
        
        
        
        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
                xml(cbc, XML_LEGAL_TEXT_ENGLISH),
                rdf(peppol, "LegalText"));

        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
                xml(cbc, XML_LEGAL_TEXT_NATIONAL),
                rdf(peppol, "nationalLegalText"));
        
        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
                xml(cbc, XML_FURTHER_INFORMATION_ENGLISH),
                rdf(peppol, "LegalExplanation"));
        
        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
                xml(cbc, XML_FURTHER_INFORMATION_NATIONAL),
                rdf(peppol, "nationalLegalExplanation"));
        
        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
                xml(cbc, XML_REQUIREMENT_DESCRIPTION),
                rdf(peppol, "criterionRequirementHint"));
        
        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
                xml(cbc, XML_SUBSTITUTE_EVIDENCE_DESCRIPTION),
                rdf(peppol, "selfEvidenceHint"));
        
        xmlRelation2OwlProperty(xml(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION),
                xml(cbc, XML_SUBSTITUTE_EVIDENCE_MINIMUM_LEVEL_CODE),
                rdf(peppol, "minimumSubstitutionLevel"));
        
        

        xmlRelation2OwlProperty(xml(cac, XML_EVIDENCE),
            xml(cbc, XML_TITLE_ENGLISH),
            rdf(peppol, "Name"));
        xmlRelation2OwlProperty(xml(cac, XML_EVIDENCE),
                xml(cbc, XML_TITLE_NATIONAL),
                rdf(peppol, "nationalName"));
    }

    

    // start interface Owl2XmlIterationLogic
    
    /**
     * Checks if the passed element contains a sub-element "OntologyURI",
     * i.e. this element carries a resource URI that must be written on RDF->XML.
     * These sub-elements are created on RDF->XML only.
     * Adds the passed OntologyUri and creates any necessary sub-element.
     * 
     * @param folderElement the element to check.
     * @param resourceUri the RDF resource URI to insert when necessary.
     */
    @Override
    public void processResourceUri(Element folderElement, String resourceUri) {
        String name = folderElement.getName();
        String ns = folderElement.getNamespaceURI();
        boolean needsOntologyUri =
            name.equals(XML_CRITERION_GROUP_REGULATION) && ns.equals(cac) ||
            name.equals(XML_EUROPEAN_REGULATION) && ns.equals(cac) ||
            name.equals(XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION) && ns.equals(cac) ||
            name.equals(XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION) && ns.equals(cac) ||
            name.equals(XML_EVIDENCE) && ns.equals(cac) ||
            
            name.equals(XML_SERVICE_COLLECTOR) && ns.equals(tmp);

        
        if (needsOntologyUri) {
            Element e = new Element(XML_URI, Namespace.getNamespace(cbcPrefix, cbc));
            e.setText(resourceUri);
            
            if (folderElement.getName().equals(XML_EVIDENCE) && folderElement.getNamespaceURI().equals(cac))   {
                Element wrapper = new Element(XML_ONTOLOGY_DEFINITION_REGULATION, Namespace.getNamespace(cacPrefix, cac));
                wrapper.addContent(e);
                e = wrapper;
            }
            
            folderElement.addContent(e);
        }
    }

    /**
     * Intermediate elements are those that were left out in RDF graph (e.g. "PartyName")
     * and have to be recreated by the transformer. There are two possible
     * strategies: reuse parents that have been created by previous child,
     * or generate a new parent for each new child.
     * TODO make a Map for this!
     */
    @Override
    public boolean reuseExistingIntermediateParentElement(Element parentElement, Path.Part childPathPart) {
        boolean isParentParty = parentElement.getNamespace().getURI().equals(cac) && parentElement.getName().equals(XML_PARTY);
        boolean isChildPartyID = childPathPart.namespace.equals(cac) && childPathPart.name.equals(XML_PARTY_IDENTIFICATION);
        if (isParentParty && isChildPartyID)
            return false;

        
        boolean isParentPartyIdentification = parentElement.getNamespace().getURI().equals(cac) && parentElement.getName().equals(XML_PARTY_IDENTIFICATION);
        boolean isChildID = childPathPart.namespace.equals(cbc) && childPathPart.name.equals(XML_ID);
        if (isChildID && isParentPartyIdentification)
            return false;
        
        boolean isParentPartyName = parentElement.getNamespace().getURI().equals(cac) && parentElement.getName().equals(XML_PARTY_NAME);
        boolean isChildName = childPathPart.namespace.equals(cbc) && childPathPart.name.equals(XML_NAME);
        if (isChildName && isParentPartyName)
            return false;
        
        boolean isChildPartyName = childPathPart.namespace.equals(cac) && childPathPart.name.equals(XML_PARTY_NAME);
        if (isChildPartyName)
            return false;

        boolean isParentDocumentRef = parentElement.getNamespace().getURI().equals(cac) && parentElement.getName().equals(XML_DOCUMENT_REFERENCE);
        boolean isChildLanguage = childPathPart.namespace.equals(cac) && childPathPart.name.equals(XML_LANGUAGE);
        if (isChildLanguage && isParentDocumentRef)
            return false;
                
        return true;
    }
    
    /**
     * @return null when the passed RDF property (predicate) is not mapped to any XML relation.
     *  Returns the Path (or namespace/name pair) that was stored for the passed property
     *  in conjunction with the reverse mapping from XML to RDF.
     */
    @Override
    public Path getXmlElement4RdfPredicate(String nameSpace, String localName, Path xmlPath, Statement statement) {
        if (localName.equals(RDF.type.getLocalName()) && nameSpace.equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#"))
            return null;
        return getXmlRelation4OwlProperty(nameSpace, localName, xmlPath, statement);
    }
    
    /** @return the URI for the OWL resource that is the VCDRequest resource's class. */
    @Override
    public String getRdfRootClassname() {
        return RDF_ROOT_PREFIX + RDF_ROOT_CLASS;
    }

    /**
     * @param nameSpace the namespace of the predicate in quest.
     * @param localName the name of the predicate in quest.
     * @return true if the passed predicate (property) is the targetLanguage property of VCDRequest.
     */
    @Override
    public boolean isTargetLanguagePredicate(String nameSpace, String localName) {
        return localName.equals(RDF_TARGET_LANGUAGE) && nameSpace.equals(RDF_ROOT_PREFIX);
    }

    @Override
    public Path newXmlRootPath() {
        return path(xml(XML_VCDPACKAGE_ROOT_NAMESPACE, XML_VCDPACKAGE_ROOT_ELEMENT));
    }

    @Override
    public Element newXmlRootElement() {
        Path.Part p = newXmlRootPath().getLastPart();
        Namespace rootElementNamespace = Namespace.getNamespace(vcdpPrefix, p.namespace);
        Element rootElement = new Element(p.name, rootElementNamespace);
        rootElement.addNamespaceDeclaration(rootElementNamespace);
        return rootElement;
    }

    @Override
    public Element newElementForInsertion(Path.Part part, Element documentRootElement) {
        Namespace namespace = ensureNamespace(part.namespace, documentRootElement);
        assert namespace != null : "Need namespace for "+part.namespace+":"+part.name;
        return new Element(part.name, namespace);
    }

    private Namespace ensureNamespace(String nameSpaceUri, Element rootElement)    {
        assert rootElement != null : "No root element seems to be in document!";
        
        List list = rootElement.getAdditionalNamespaces();
        for (Object o : list)   {
            Namespace namespace = (Namespace) o;
            if (namespace.getURI().equals(nameSpaceUri)) {
                return namespace;
            }
        }
        
        String prefix = namespace2Prefix.get(nameSpaceUri);
        assert prefix != null : "Prefix not found for namespace URI: "+nameSpaceUri;
        
        Namespace namespace = Namespace.getNamespace(prefix, nameSpaceUri);  // a JDOM global impl
        rootElement.addNamespaceDeclaration(namespace);
        
        return namespace;
    }

	@Override
	public void preprocessRDF(Model rdfInstancesModel) {
		MapperVariant mv = MapperVariant.Get.get(schemaVariant);
		mv.preprocessRDF(rdfInstancesModel);
	}
    
    // end interface Owl2XmlIterationLogic
    
}
