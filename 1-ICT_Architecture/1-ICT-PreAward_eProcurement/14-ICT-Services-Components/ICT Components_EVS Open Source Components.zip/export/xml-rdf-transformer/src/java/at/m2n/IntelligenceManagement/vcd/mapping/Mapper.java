/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.mapping;

import java.net.MalformedURLException;
import java.util.Hashtable;
import java.util.Map;

import org.jdom.Element;
import org.jdom.Namespace;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.util.Path.Part;
import at.m2n.IntelligenceManagement.vcd.xmlschema.Schemifier;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

/**
 * Contains XML/RDF mappings for the VCD case.
 * 
 * @author Fritz Ritzberger  18.05.2010
 */
public abstract class Mapper extends MappingManager implements
    MappingNames,
    CommonMappingNames
{
    // fully-qualified-namespace to prefix map
    protected static final Map<String,String> namespace2Prefix = new Hashtable<String,String>();

    static  {
        namespace2Prefix.put(cac, cacPrefix);
        namespace2Prefix.put(cbc, cbcPrefix);
        namespace2Prefix.put(cec, cecPrefix);
        namespace2Prefix.put(clm54217, clm54217Prefix);
        namespace2Prefix.put(clm66411, clm66411Prefix);
        namespace2Prefix.put(clmIANAMIMEMediaType, clmIANAMIMEMediaTypePrefix);
        namespace2Prefix.put(udt, udtPrefix);
        namespace2Prefix.put(vcd, vcdPrefix);
        namespace2Prefix.put(vcdp, vcdpPrefix);
        namespace2Prefix.put(xsd, xsdPrefix);
        
        namespace2Prefix.put(tmp, tmpPrefix);
    }
    
    
    protected final VcdSchemaVariant schemaVariant;

    protected Mapper(VcdSchemaVariant schemaVariant)    {
        assert schemaVariant != null : "Need a schema variant for RDF->XML conversion!";
        this.schemaVariant = schemaVariant;
        init();
    }
    
    public VcdSchemaVariant getSchemaVariant() {
			return schemaVariant;
		}

		private void init()    {
        // XML elements relations to OWL properties mapping
        // ===================================
        // key = "from"-element,
        // value = List of [tuples of "to"-element and OWL-Property-URI]
        // example: the XML relation of "VCDPackage" to "OntologyDomainCode" is mapped by
        //          the RDF property "caCountry"
        // relations are normally given by XML parent name -> XML child name, but, in case
        // of XML elements not present in RDF, the child XML element might be given as path, in
        // which also those elements not present in RDF must be present
        
	    xmlRelation2OwlProperty((Path.Part)null, xml(cbc, XML_ID),rdf(peppol, "cbcID"));			

	    //TODO: we currently IGNORE non-evidence documents but they should probably survive?
        xmlIgnore(xml(cac, XML_POLICY_DOCUMENT));
        xmlIgnore(xml(cac, XML_ADDITIONAL_DOCUMENT)); 

	    xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE), xml(cbc, XML_UUID),rdf(peppol, "cbcUUID"));			
	    
        xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
            xml(cbc, XML_ONTOLOGY_DOMAIN_CODE),
            rdf(peppol, "caCountry"));
        xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
            xml(cac, XML_CONTRACTING_AUTHORITY_PARTY),
            rdf(peppol, "caParty"));
        
        xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
            xml(cac, XML_SINGLE_TENDERER),
            rdf(peppol, "tendererIs"),
            peppol+"SingleTenderer"); 


        xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
            xml(cac, XML_BIDDING_CONSORTIUM),
            rdf(peppol, "tendererIs"),
            peppol+"BiddingConsortium");
        
        xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
            xml(cac, XML_REQUESTER_PARTY),
            rdf(peppol, "vcdPackageRequesterParty"));
       
        xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
                xml(cbc, XML_VCD_PACKAGE_NAME),
                rdf(peppol, "vcdPackageName"));

        xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
            xml(cbc, XML_CALL_FOR_TENDER_ID),
            rdf(peppol, "tenderID"));
        
        xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
                xml(cbc, XML_PROCUREMENT_LOT_ID),
                rdf(peppol, "procurementLotID"));

        // fri_tenderer-schema_party.n3
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY),
            path(xml(cac, XML_PARTY_NAME), xml(cbc, XML_NAME)),
            rdf(peppol, "partyName"));
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY),
            xml(cac, XML_PERSON),
            rdf(peppol, "person"));
        xmlRelation2OwlProperty(
            xml(cac, XML_CONTRACTING_AUTHORITY_PARTY), xml(cbc, XML_ENDPOINT_ID),
            rdf(peppol, "endpointID"));
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY),
                path(xml(cac, XML_PARTY_IDENTIFICATION), xml(cbc, XML_ID)),
                rdf(peppol, "partyIdentification"));
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY),
                xml(cac, XML_POSTAL_ADDRESS),
                rdf(peppol, "postalAddress"));
        xmlRelation2OwlProperty(xml(cac, XML_CONTRACTING_AUTHORITY_PARTY),
                xml(cac, XML_CONTACT),
                rdf(peppol, "partyContact"));
        
        xmlRelation2OwlProperty(xml(cac, XML_PERSON),
            xml(cbc, XML_FIRST_NAME),
            rdf(peppol, "firstName"));
        xmlRelation2OwlProperty(xml(cac, XML_PERSON),
                xml(cbc, XML_MIDDLE_NAME),
                rdf(peppol, "middleName"));        
        xmlRelation2OwlProperty(xml(cac, XML_PERSON),
            xml(cbc, XML_FAMILY_NAME),
            rdf(peppol, "lastName"));
        xmlRelation2OwlProperty(xml(cac, XML_PERSON),
                xml(cbc, XML_JOB_TITLE),
                rdf(peppol, "jobTitle"));        

        
        String[] pas = new String[] {XML_POSTAL_ADDRESS, XML_RESIDENCE_ADDRESS };
        for (String pa : pas) {
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_ADDRESS_TYPE_CODE),
                    rdf(peppol, "addressTypeCode"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_ROOM),
                    rdf(peppol, "room"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_STREET_NAME),
                    rdf(peppol, "streetName"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_BUILDING_NAME),
                    rdf(peppol, "buildingName"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_BUILDING_NUMBER),
                    rdf(peppol, "buildingNumber"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_CITY_NAME),
                    rdf(peppol, "cityName"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_POSTAL_ZONE),
                    rdf(peppol, "postalZone"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_COUNTRY_SUBENTITY),
                    rdf(peppol, "countrySubentity"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_COUNTRY_SUBENTITY_CODE),
                    rdf(peppol, "countrySubentityCode"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cbc, XML_ADDRESS_LINE),
                    rdf(peppol, "addressLine"));
            xmlRelation2OwlProperty(xml(cac, pa),
                    xml(cac, XML_COUNTRY),
                    rdf(peppol, "paCountry"));
        }

        
        
        xmlRelation2OwlProperty(xml(cac, XML_COUNTRY),
                xml(cbc, XML_COUNTRY_IDENTIFICATION_CODE),
                rdf(peppol, "countryIdentificationCode"));
        
        xmlRelation2OwlProperty(xml(cac, XML_COUNTRY),
                xml(cbc, XML_COUNTRY_NAME),
                rdf(peppol, "countryName"));

        
        xmlRelation2OwlProperty(xml(cac, XML_CITIZENSHIP_COUNTRY),
                xml(cbc, XML_COUNTRY_IDENTIFICATION_CODE),
                rdf(peppol, "countryIdentificationCode"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CITIZENSHIP_COUNTRY),
                xml(cbc, XML_COUNTRY_NAME),
                rdf(peppol, "countryName"));


        
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTACT),
                xml(cbc, XML_CONTACT_NAME),
                rdf(peppol, "contactName"));

        xmlRelation2OwlProperty(xml(cac, XML_CONTACT),
                xml(cbc, XML_CONTACT_TELEPHONE),
                rdf(peppol, "contactTelephone"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTACT),
                xml(cbc, XML_CONTACT_TELEFAX),
                rdf(peppol, "contactTelefax"));
        
        xmlRelation2OwlProperty(xml(cac, XML_CONTACT),
                xml(cbc, XML_CONTACT_ELECTRONIC_MAIL),
                rdf(peppol, "contactElectronicMail"));

        xmlRelation2OwlProperty(xml(cac, XML_CONTACT),
                xml(cbc, XML_CONTACT_NOTE),
                rdf(peppol, "contactNote"));

        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON), xml(cbc, XML_ONTOLOGY_DOMAIN_CODE),
                                rdf(peppol, "tssCountry"));

	    xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON), xml(cbc, XML_UUID),rdf(peppol, "cbcUUID"));			

                            
       for (String aSingleTenderer : new String [] { XML_SINGLE_TENDERER, XML_SUBCONTRACTOR_SINGLE_TENDERER, XML_BIDDING_CONSORTIUM_LEADER, XML_BIDDING_CONSORTIUM_MEMBER, XML_BIDDING_CONSORTIUM })   {
    	   
    	    xmlIgnore(path(xml(cac, aSingleTenderer), xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cbc, XML_DESCRIPTIVE_DOCUMENT)));
    	    
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cbc, XML_SOLE_PROPRIETORSHIP_INDICATOR)),
                    rdf(peppol, "soleProprietorshipIndicator"));
    	    
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cbc, XML_ONTOLOGY_DOMAIN_CODE)),
                rdf(peppol, "tssCountry"));
            
        	xmlRelation2OwlProperty(xml(cac, aSingleTenderer), 
					path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PERSON)),
					rdf(peppol, "person"));
        	
    	    xmlRelation2OwlProperty(xml(cac, aSingleTenderer), path( xml(vcd, XML_VCD), xml(cbc, XML_UUID)) ,rdf(peppol, "cbcUUID"));			

            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cbc, XML_ONTOLOGY_DOMAIN_CODE)),
                    rdf(peppol, "tssCountry"));
      
            
            
            
            
//            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
//                path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PERSON), xml(cbc, XML_FIRST_NAME)),
//                rdf(peppol, "NaturalPersonFirstName"));
//            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
//                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PERSON), xml(cbc, XML_MIDDLE_NAME)),
//                    rdf(peppol, "NaturalPersonMiddleName"));            
//            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
//                path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PERSON), xml(cbc, XML_FAMILY_NAME)),
//                rdf(peppol, "NaturalPersonLastName"));
//            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
//                path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PERSON), xml(cbc, XML_JOB_TITLE)),
//                rdf(peppol, "NaturalPersonJobTitle"));
//            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
//                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PERSON), xml(cbc, XML_PROFESSION)),
//                    rdf(peppol, "NaturalPersonProfession"));
//            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PARTY_NAME), xml(cbc, XML_NAME)),
                rdf(peppol, "LegalEntityName"));
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PARTY_NAME), xml(cbc, XML_NAME)),
                rdf(peppol, "BiddingConsortiumName"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_PARTY_IDENTIFICATION), xml(cbc, XML_ID)),
                rdf(peppol, "partyIdentification"));     
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cbc, XML_ENDPOINT_ID)),
                    rdf(peppol, "endpointID"));     
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_POSTAL_ADDRESS)),
                    rdf(peppol, "postalAddress"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
            		path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PARTY), xml(cac, XML_CONTACT)),
                    rdf(peppol, "partyContact"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                path(xml(vcd, XML_VCD), xml(cac, XML_REQUESTER_PARTY)),
                rdf(peppol, "vcdRequesterParty"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                path(xml(vcd, XML_VCD), xml(cac, XML_RELEVANT_VCD_PERSON)),
                rdf(peppol, "hasRepresentative"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                xml(cac, XML_SUBCONTRACTOR_SINGLE_TENDERER),
                rdf(peppol, "hasSubcontractor"));
            
        

            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                path(xml(vcd, XML_VCD), xml(cac, XML_VCD_ISSUING_SERVICE)),
                rdf(peppol, "issuingService"));
            
            xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
                    path(xml(cac, aSingleTenderer), xml(vcd, XML_VCD), xml(cac, XML_VCD_ISSUING_SERVICE)),
                    rdf(peppol, "issuingService"));            
            
            
            
            
            
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR), xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_ID)),
                rdf(peppol, "PersonID"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR),xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_BIRTH_DATE)),
                rdf(peppol, "NaturalPersonBirthDate"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR),xml(cac, XML_PERSON_DETAILS),xml(cbc, XML_PLACE_OF_BIRTH)),
                    rdf(peppol, "NaturalPersonBirthPlace"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR),xml(cac, XML_PERSON_DETAILS), xml(cac, XML_CITIZENSHIP_COUNTRY)),
                    rdf(peppol, "citizenshipCountry"));

            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR),xml(cac, XML_PERSON_DETAILS), xml(cac, XML_RESIDENCE_ADDRESS)),
                    rdf(peppol, "residenceAddress"));

            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR),xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_FIRST_NAME)),
                rdf(peppol, "NaturalPersonFirstName"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR),xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_MIDDLE_NAME)),
                    rdf(peppol, "NaturalPersonMiddleName"));        
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR),xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_FAMILY_NAME)),
                rdf(peppol, "NaturalPersonLastName"));
            
            xmlRelation2OwlProperty(xml(cac, aSingleTenderer),
                    path(xml(vcd, XML_VCD), xml(cac, XML_ECONOMIC_OPERATOR),xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_JOB_TITLE)),
                    rdf(peppol, "NaturalPersonJobTitle"));        

            
        }
       
       xmlRelation2OwlProperty(xml(cac, XML_BIDDING_CONSORTIUM),
               xml(cac, XML_BIDDING_CONSORTIUM_LEADER),
               rdf(peppol, "bcLeader"));            

       xmlRelation2OwlProperty(xml(cac, XML_BIDDING_CONSORTIUM),
               xml(cac, XML_BIDDING_CONSORTIUM_MEMBER),
               rdf(peppol, "bcMember"));    

       xmlRelation2OwlProperty(xml(vcdp, XML_VCD_PACKAGE),
           xml(cac, XML_ISSUING_SERVICE),
           rdf(peppol, "issuingService"));
       
    
       
       xmlRelation2OwlProperty(xml(cac, XML_CRITERION),
            xml(cbc, XML_REQUESTED_INDICATOR),
            rdf(peppol, "requestedIndicator"));
        
        xmlRelation2OwlProperty(xml(cac, XML_REQUESTER_PARTY),
            path(xml(cac, XML_PARTY_NAME), xml(cbc, XML_NAME)),
            rdf(peppol, "partyName"));
        
        xmlRelation2OwlProperty(xml(cac, XML_REQUESTER_PARTY),
                xml(cac, XML_PERSON),
                rdf(peppol, "person"));
        
        xmlRelation2OwlProperty(xml(cac, XML_REQUESTER_PARTY),
                path(xml(cac, XML_PARTY_IDENTIFICATION), xml(cbc, XML_ID)),
                rdf(peppol, "partyIdentification"));

        xmlRelation2OwlProperty(xml(cac, XML_REQUESTER_PARTY),
                xml(cbc, XML_ENDPOINT_ID),
                rdf(peppol, "endpointID"));

        
        xmlRelation2OwlProperty(xml(cac, XML_REQUESTER_PARTY),
                xml(cac, XML_POSTAL_ADDRESS),
                rdf(peppol, "postalAddress"));
        xmlRelation2OwlProperty(xml(cac, XML_REQUESTER_PARTY),
                xml(cac, XML_CONTACT),
                rdf(peppol, "partyContact"));

        
        xmlRelation2OwlProperty(xml(cac, XML_PROVIDING_PARTY),
            path(xml(cac, XML_PARTY_NAME), xml(cbc, XML_NAME)),
            rdf(peppol, "partyName"));

        xmlRelation2OwlProperty(xml(cac, XML_PROVIDING_PARTY),
                xml(cac, XML_PERSON),
                rdf(peppol, "person"));

        xmlRelation2OwlProperty(xml(cac, XML_PROVIDING_PARTY),
                path(xml(cac, XML_PARTY_IDENTIFICATION), xml(cbc, XML_ID)),
                rdf(peppol, "partyIdentification"));
        
        xmlRelation2OwlProperty(xml(cac, XML_PROVIDING_PARTY),
                xml(cbc, XML_ENDPOINT_ID),
                rdf(peppol, "endpointID"));
        
        
        xmlRelation2OwlProperty(xml(cac, XML_PROVIDING_PARTY),
                xml(cac, XML_POSTAL_ADDRESS),
                rdf(peppol, "postalAddress"));
        xmlRelation2OwlProperty(xml(cac, XML_PROVIDING_PARTY),
                xml(cac, XML_CONTACT),
                rdf(peppol, "partyContact"));
        

        
        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
        		path(xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_ID)),
            rdf(peppol, "PersonID"));
        
        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
        		 path(xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_BIRTH_DATE)),
            rdf(peppol, "NaturalPersonBirthDate"));
        
        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
        		 path(xml(cac, XML_PERSON_DETAILS),xml(cbc, XML_PLACE_OF_BIRTH)),
                rdf(peppol, "NaturalPersonBirthPlace"));
        
        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
                xml(cbc, XML_PROFESSION),
                rdf(peppol, "NaturalPersonProfession"));

        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
        		 path(xml(cac, XML_PERSON_DETAILS), xml(cac, XML_CITIZENSHIP_COUNTRY)),
                rdf(peppol, "citizenshipCountry"));

        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
        		 path(xml(cac, XML_PERSON_DETAILS), xml(cac, XML_RESIDENCE_ADDRESS)),
                rdf(peppol, "residenceAddress"));

        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
            path(xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_FIRST_NAME)),
            rdf(peppol, "NaturalPersonFirstName"));
        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
                path(xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_MIDDLE_NAME)),
                rdf(peppol, "NaturalPersonMiddleName"));        
        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
            path(xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_FAMILY_NAME)),
            rdf(peppol, "NaturalPersonLastName"));
        xmlRelation2OwlProperty(xml(cac, XML_RELEVANT_VCD_PERSON),
                path(xml(cac, XML_PERSON_DETAILS), xml(cbc, XML_JOB_TITLE)),
                rdf(peppol, "NaturalPersonJobTitle"));        

        // continue this - all relations to be transformed MUST be here!
    }

    /** To be used by subclasses that handle DocumentReference elements. */
    protected final void mapEvidenceDocumentAttachments() {
//      xmlRelation2OwlProperty(xml(tmp, XML_EVIDENCE_COLLECTOR),
//                              xml(tmp, XML_SERVICE_COLLECTOR),
//                              rdf(peppol, "ecServiceCollector"));
      
        xmlRelation2OwlProperty(xml(tmp, XML_SERVICE_COLLECTOR),
            xml(cac, XML_DOCUMENT_REFERENCE),
            rdf(peppol, "evidenceDocument"));
        
        xmlRelation2OwlProperty(xml(cac, XML_DOCUMENT_REFERENCE),
            path(xml(cac, XML_LANGUAGE), xml(cbc, XML_LOCALE_CODE)),
            rdf(peppol, "documentLanguage"));
        xmlRelation2OwlProperty(xml(cac, XML_DOCUMENT_REFERENCE),
            path(xml(cac, XML_ATTACHMENT), xml(cac, XML_EXTERNAL_REFERENCE), xml(cbc, XML_FILENAME)),
            rdf(m2n, "fileName")); //this is mapped to cbc:FileName but in postprocessing in XmlSaver gets transformed to the correct format!
    }


    /** Delegates to new SaverLogicImpl().generateUuid4Xml(). To be overridden by unit tests. */
    public String generateUuid4Xml()  {
        return new SaverXmlLogicImpl().generateUuid4Xml();
    }
    
    /**
     * This delegates to Schemifier to find out if passed element has sub-elements.
     * @param pathPart the description of the element to check.
     * @return true when the passed element is a container node and thus.
     *  must be converted into an RDF node with ObjectProperties that point to child nodes.
     * @throws SAXException 
     * @throws MalformedURLException 
     */
    public boolean isFolder(Path.Part pathPart) throws MalformedURLException, SAXException   {
        return
            Schemifier.getInstance(schemaVariant).isFolderElement(pathPart) ||
            pathPart.name.equals(XML_EVIDENCE_COLLECTOR) && pathPart.namespace.equals(tmp) ||
            pathPart.name.equals(XML_SERVICE_COLLECTOR) && pathPart.namespace.equals(tmp);
    }
    
    /** @return true if passed element is a VCD element. */
    public final boolean isVcdElement(Element element) {
        return element.getName().equals(XML_VCD) && element.getNamespaceURI().equals(vcd);
    }

    // other XML service methods
    
    public final Path.Part getEconomicOperatorDescr() {
        return new Path.Part(cac, XML_ECONOMIC_OPERATOR);
    }

    public final Path.Part getPartyDescr() {
        return new Path.Part(cac, XML_PARTY);
    }

    public final Path.Part getPersonDescr() {
        return new Path.Part(cac, XML_PERSON);
    }

    public final Path.Part getFirstNameDescr() {
        return new Path.Part(cbc, XML_FIRST_NAME);
    }

    public final Path.Part getMiddleNameDescr() {
        return new Path.Part(cbc, XML_MIDDLE_NAME);
    }

    public final Path.Part getFamilyNameDescr() {
        return new Path.Part(cbc, XML_FAMILY_NAME);
    }

    public final Path.Part getCriterionDescr() {
        return new Path.Part(cac, XML_CRITERION);
    }

    public final Path.Part getIdDescr() {
        return new Path.Part(cbc, XML_ID);
    }

    public final Path.Part getEconomicOperatorNationalReglationDescr() {
        return new Path.Part(cac, XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION);
    }

    public final Path.Part getEvidenceDescr() {
        return new Path.Part(cac, XML_EVIDENCE);
    }

    public final Path.Part getEvidenceCollectorDescr() {
        return new Path.Part(tmp, XML_EVIDENCE_COLLECTOR);
    }
    
    public final Path.Part getServiceCollectorDescr() {
      return new Path.Part(tmp, XML_SERVICE_COLLECTOR);
  }    

    public final Path.Part geProvingEvidenceIdDescr() {
        return new Path.Part(cbc, XML_PROVING_EVIDENCE_ID);
    }

    public final Path.Part getProvesCriterionIdDescr() {
        return new Path.Part(cbc, XML_PROVES_CRITERION_ID);
    }

    public final Path.Part getDocumentGroupIdDescr() {
        return new Path.Part(cbc, XML_DOCUMENT_GROUP_ID);
    }

    public final Path.Part getOntologyDefinitionRegulationDescr() {
        return new Path.Part(cac, XML_ONTOLOGY_DEFINITION_REGULATION);
    }

    public final Path.Part getDocumentReferenceDescr() {
        return new Path.Part(cac, XML_DOCUMENT_REFERENCE);
    }

    public final Path.Part getOntlogyUriDescr() {
        return new Path.Part(cbc, XML_URI);
    }

    public final Path.Part getRequestedIndicatorDescr() {
        return new Path.Part(cbc, XML_REQUESTED_INDICATOR);
    }

    // XML factory methods
    
    public Element newRequestedIndicator() {
        return new Element(XML_REQUESTED_INDICATOR, Namespace.getNamespace(cbcPrefix, cbc));
    }

    public Element newParty() {
        return new Element(XML_PARTY, Namespace.getNamespace(cacPrefix, cac));
    }

    public Element newPartyName() {
        return new Element(XML_PARTY_NAME, Namespace.getNamespace(cacPrefix, cac));
    }

    public Element newName() {
        return new Element(XML_NAME, Namespace.getNamespace(cbcPrefix, cbc));
    }

    public Element newEvidenceCollector() {
        return new Element(XML_EVIDENCE_COLLECTOR, Namespace.getNamespace(tmpPrefix, tmp));
    }

    public Element newProvesCriterionId() {
        return new Element(XML_PROVES_CRITERION_ID, Namespace.getNamespace(cbcPrefix, cbc));
    }

    public Element newProvingEvidenceId() {
        return new Element(XML_PROVING_EVIDENCE_ID, Namespace.getNamespace(cbcPrefix, cbc));
    }

    public Element newId() {
        return new Element(XML_ID, Namespace.getNamespace(cbcPrefix, cbc));
    }

    public Element newDocumentGroupId() {
        return new Element(XML_DOCUMENT_GROUP_ID, Namespace.getNamespace(cbcPrefix, cbc));
    }

    public void removeEvidenceCollectorFrom(Element newCriterion) {
        newCriterion.removeChild(XML_EVIDENCE_COLLECTOR, Namespace.getNamespace(tmpPrefix, tmp));
    }

    // TransformerSupport
    
    public Path.Part getPartyNameDescr() {
        return new Path.Part(cac, XML_PARTY_NAME);
    }

    public Path.Part getNameDescr() {
        return new Path.Part(cbc, XML_NAME);
    }

    public Path.Part getVcdDescr() {
        return new Path.Part(vcd, XML_VCD);
    }

    public Path.Part getCompilationDateDescr() {
        return new Path.Part(cbc, XML_COMPILATION_DATE);
    }

    public Path.Part getCompilationTimeDescr() {
        return new Path.Part(cbc, XML_COMPILATION_TIME);
    }

    public Path.Part getOntologyVersionIdDescr() {
        return new Path.Part(cbc, XML_ONTOLOGY_VERSION_ID);
    }

    public Path.Part getVcdSchemaVersionDescr() {
        return new Path.Part(cbc, XML_VCD_SCHEMA_VERSION_ID);
    }

    public Path.Part getVcdTypeCodeDescr() {
        return new Path.Part(cbc, XML_VCD_TYPE_CODE);
    }

    public Path.Part getIssuingServiceDescr() {
        return new Path.Part(cac, XML_ISSUING_SERVICE);
    }

    public Path.Part getVcdIssuingServiceDescr() {
        return new Path.Part(cac, XML_VCD_ISSUING_SERVICE);
    }

    public Path.Part getEndpointIdDescr() {
        return new Path.Part(cbc, XML_ENDPOINT_ID);
    }

    public Path.Part getProvidingPartyDescr() {
        return new Path.Part(cac, XML_PROVIDING_PARTY);
    }

    public Part getTitleDescr() {
        return new Path.Part(cbc, XML_TITLE);
    }

}
