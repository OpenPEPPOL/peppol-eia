/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xml2owl;

import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

/**
 * Tests a XML->RDF import. Same directory/file structure as with RDF->XML.
 * 
 * @author Fritz Ritzberger  27.05.2010
 */
public class Xml2OwlTransformerTest extends AbstractXml2OwlTestCase {
    
    /** As we have evidences in the XML test file this runs as "full-package" transformation. */
    @Override
    protected boolean isFullPackageTransform() {
        return true;
    }
    
    /** Tests a "full-package" import. */
    public void testTransformation() throws Exception {
        checkTransform("VCDPackage.xml", "resultdata/created_instances.n3", VcdSchemaVariant.newInstance(vhostDirectory, VcdSchemaVariant.Name.FULL));
    }

}
