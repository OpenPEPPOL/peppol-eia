/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer;

import junit.framework.TestCase;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.util.FileUtils;

/**
 * Logging iniializaton and basic N3 file names.
 * 
 * @author Fritz Ritzberger  18.06.2010
 */
public abstract class AbstractVcdTestCase extends TestCase {

    private OntModel schemaModel;
    
    @Override
    protected void setUp() throws Exception {
        BasicConfigurator.configure();
    }

    /** Override this to set "full package" creation. */
    protected boolean isFullPackageTransform()   {
        return false;
    }
    
    protected OntModel getRdfSchemaModel()    {
        if (schemaModel != null)
            return schemaModel;
        
        schemaModel = ModelFactory.createOntologyModel();
        final String [] SCHEMA_URLS = new String [] {
            "file:../runner-server/vhosts/ossso/schema/ossso/tenderer-schema.n3",
            "file:../runner-server/vhosts/ossso/schema/ossso/common.n3",
            "file:../runner-server/vhosts/ossso/schema/ossso/collector-schema.n3",
            "file:../runner-server/vhosts/ossso/schema/ossso/criterion-schema.n3",
            "file:../runner-server/vhosts/ossso/schema/ossso/tenderer-criterion-schema.n3",
            "file:../runner-server/vhosts/ossso/schema/ossso/fri_tenderer-schema_party.n3",
        };
        for (String url : SCHEMA_URLS)
            schemaModel.read(url, "", FileUtils.langN3);
        
        return schemaModel;
    }
    

}
