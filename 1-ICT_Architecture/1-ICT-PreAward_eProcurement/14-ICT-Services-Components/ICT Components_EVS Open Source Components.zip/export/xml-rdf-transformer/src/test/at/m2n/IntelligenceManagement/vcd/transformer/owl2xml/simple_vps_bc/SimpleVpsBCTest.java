/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.simple_vps_bc;

import at.m2n.IntelligenceManagement.vcd.saver.XmlSaver;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.AbstractOwl2XmlTestCase;
import at.m2n.IntelligenceManagement.vcd.util.FileTestUtil;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class SimpleVpsBCTest extends AbstractOwl2XmlTestCase {

    public void testTransformation() throws Exception {
        Model instancesModel = ModelFactory.createDefaultModel();
        FileTestUtil.readN3AsClassRelativePath(getClass(), "simple_vps_bc.n3", instancesModel);
        
        XmlSaver saver = transform.transform(
            getRdfSchemaModel(),
            instancesModel,
            VcdSchemaVariant.newInstance(vhostRootDirectory, VcdSchemaVariant.Name.SKELETON),
            transformerSupport,
            null);
        
        checkSkeletonSaver(saver);
    }

}
