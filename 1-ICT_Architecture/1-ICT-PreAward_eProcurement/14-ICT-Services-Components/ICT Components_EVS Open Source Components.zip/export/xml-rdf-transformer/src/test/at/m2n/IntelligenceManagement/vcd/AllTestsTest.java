/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd;

import junit.framework.Test;
import junit.framework.TestSuite;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.Owl2XmlTransformerTest;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.same_ev_bug.SameEvBugTest;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.simple_vp.SimpleVpTest;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.simple_vps.SimpleVpsTest;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.simple_vps_bc.SimpleVpsBCTest;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.soleproprietor.SoleProprietorTest;
import at.m2n.IntelligenceManagement.vcd.transformer.xml2owl.Xml2OwlTransformerTest;
import at.m2n.IntelligenceManagement.vcd.transformer.xml2owl.simple_tc.SimpleTCTest;
import at.m2n.IntelligenceManagement.vcd.transformer.xml2owl.simple_vpps.SimpleVppsTest;

public class AllTestsTest extends TestSuite {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for at.m2n.IntelligenceManagement.vcd");
		//$JUnit-BEGIN$
		suite.addTestSuite(Owl2XmlTransformerTest.class);
		suite.addTestSuite(SimpleVpTest.class);
		suite.addTestSuite(SimpleVpsTest.class);
		suite.addTestSuite(SimpleVpsBCTest.class);
		suite.addTestSuite(SoleProprietorTest.class);
		suite.addTestSuite(SameEvBugTest.class);
		
		suite.addTestSuite(Xml2OwlTransformerTest.class);
		suite.addTestSuite(SimpleTCTest.class);
		suite.addTestSuite(SimpleVppsTest.class);
		suite.addTestSuite(Xml2OwlTransformerTest.class);

		//$JUnit-END$
		return suite;
	}

}
