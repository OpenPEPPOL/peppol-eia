/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.owl2xml;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.Difference;
import org.w3c.dom.Document;

import at.m2n.IntelligenceManagement.vcd.AbstractFileTestUtil;
import at.m2n.IntelligenceManagement.vcd.mapping.MapperVariant;
import at.m2n.IntelligenceManagement.vcd.mapping.Owl2XmlMapper;
import at.m2n.IntelligenceManagement.vcd.mapping.SaverXmlLogicImpl;
import at.m2n.IntelligenceManagement.vcd.saver.PathAndDocument;
import at.m2n.IntelligenceManagement.vcd.saver.TransformerSupport;
import at.m2n.IntelligenceManagement.vcd.saver.XmlSaver;
import at.m2n.IntelligenceManagement.vcd.transformer.AbstractVcdTestCase;
import at.m2n.IntelligenceManagement.vcd.transformer.Owl2XmlTransform;
import at.m2n.IntelligenceManagement.vcd.transformer.PrimitiveCounterIdGenerator;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

/**
 * Common functionality when testing conversion RDF->XML,
 * e.g. this configures a deterministic ID / UUID generator in a custom Mapper.
 * 
 * @author Fritz Ritzberger  17.06.2010
 */
public abstract class AbstractOwl2XmlTestCase extends AbstractVcdTestCase {
    
    protected Owl2XmlTransform transform;
    protected TransformerSupport transformerSupport;
    protected VcdSchemaVariant schemaVariant;
    protected File vhostRootDirectory;
    private Owl2XmlMapper mapper;
    private PrimitiveCounterIdGenerator primitiveCounterIdGenerator;
    private DocumentBuilder builder;
    
    private DocumentBuilder getDocumentBuilder() throws ParserConfigurationException  {
      if (builder == null)
          builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
      return builder;
   }
    
    private InputStream getXmlInputStream(PathAndDocument pathAndDocument) throws IOException  {
        OutputStream out = new ByteArrayOutputStream();
        pathAndDocument.writeDocument(out, false);
        out.close();
        String vcdPackageXml = out.toString();
        return new ByteArrayInputStream(vcdPackageXml.getBytes());
    }
    
    /** Checks if the created VCD package files are valid and conform to naming conventions. */
    protected void checkSkeletonSaver(XmlSaver saver) throws Exception {
        // validate against XML schema
        String errors = saver.validate();
        
        // control output
        System.out.println("\n"+saver.getVcdPackage().relativePathWithFileName+"\n");
        saver.getVcdPackage().writeDocument(System.out, false);
        for (PathAndDocument sd : saver.getVcdList())    {
            System.out.println("\n"+sd.relativePathWithFileName+"\n");
            sd.writeDocument(System.out, false);
        }
        
        System.out.println("Validation errors are:\n"+errors);
        
        // check the result XML against stored control XML
        System.err.println("Checking VCDPackage document "+saver.getVcdPackage().relativePathWithFileName);

        org.w3c.dom.Document testDoc = getDocumentBuilder().parse(getXmlInputStream(saver.getVcdPackage()));
        String controlData = AbstractFileTestUtil.urlStringAsClassRelativePath(getClass(), "resultdata/"+saver.getVcdPackage().relativePathWithFileName);
        controlData = removeUUIDs(controlData);
        
        org.w3c.dom.Document controlDoc = getDocumentBuilder().parse(controlData);
        
        Map<String, String> outputToControlMismapping = assertDiff(controlDoc, testDoc);
        
        for (PathAndDocument sd : saver.getVcdList())    {
        	  String outputName = sd.relativePathWithFileName;
        	  String outputUUID = getUUID(outputName);
            String controlName = outputToControlMismapping.get(outputUUID);
            if (controlName == null)
            	controlName = outputName;
            
            System.err.println("Checking VCD document "+outputName+ " against control "+controlName);
            
            testDoc = getDocumentBuilder().parse(getXmlInputStream(sd));
            String vcdControlData = AbstractFileTestUtil.urlStringAsClassRelativePath(getClass(), "resultdata/"+controlName);
            controlDoc = getDocumentBuilder().parse(vcdControlData);
            
            assertDiff(controlDoc, testDoc);
        }
        
        assertNull(errors);
    }
    
    private static final Pattern P_EXTRACT_UUID = Pattern.compile("VCD_([A-Za-z0-9\\-]+)/VCD_.*");
    
		private String getUUID(String outputName) {
			Matcher m =  P_EXTRACT_UUID.matcher(outputName);
			m.matches();
			return m.group(1);
		}

		protected String removeUUIDs(String controlData) {
			int lastUnderscore = controlData.lastIndexOf("_");
			int lastDot = controlData.lastIndexOf(".");
			controlData = controlData.substring(0, lastUnderscore) + controlData.substring(lastDot);
			return controlData;
		}
    
    private Map<String, String> assertDiff(Document controlDoc, Document testDoc) {
    	final Map<String, String> retVal = new HashMap<String, String>();
    	
    	Diff d = new Diff(controlDoc, testDoc) {
    		boolean evilDiffs = false;

				@Override
				public boolean haltComparison(Difference afterDifference) {
					if (isVCDRelocationIssue(afterDifference)) {
						noteVCDRelocation(afterDifference, retVal);
					} else {
						System.err.println(afterDifference);
						evilDiffs = true;
					}
					
					return false;
				}

				@Override
				public boolean identical() {
					return !evilDiffs;
				}
    		
    	};
    	
    	System.out.println(d);

    	assertTrue(d.identical());
    	
    	return retVal;
		}
		
    private static final Pattern P_RELOCATE = Pattern.compile("Expected text value '([^']+)' but was '([^']+)'.*");
		
		private void noteVCDRelocation(Difference afterDifference, Map<String, String> retVal) {
			Matcher m = P_RELOCATE.matcher(afterDifference.toString());
			
			if (m.matches()) {
				String from = m.group(1);
				String to = m.group(2);
				
				if (from != null && to != null) {
					retVal.put(to, from);
				}
			}
		}

		private boolean isVCDRelocationIssue(Difference afterDifference) {
			return P_RELOCATE.matcher(afterDifference.toString()).matches();
		}

		@Override
    protected void setUp() throws Exception {
        super.setUp();
        
        primitiveCounterIdGenerator = new PrimitiveCounterIdGenerator();
        
        vhostRootDirectory = new File("../runner-server/vhosts/ossso_uis");
        
        schemaVariant = VcdSchemaVariant.newInstance(vhostRootDirectory, isFullPackageTransform() ? VcdSchemaVariant.Name.FULL : VcdSchemaVariant.Name.SKELETON);
        mapper = new Owl2XmlMapper(schemaVariant, MapperVariant.Get.get(schemaVariant))    {
            @Override
            public String generateUuid4Xml()  {
                return primitiveCounterIdGenerator.generate();
            }
        };
        
        transform = new Owl2XmlTransform()    {
            /** Overridden to use a Mapper with "deterministic" ID and UUID generator. */
            @Override
            protected Owl2XmlMapper newMapper(VcdSchemaVariant schemaVariant) {
                return AbstractOwl2XmlTestCase.this.mapper;
            }
            /** Overridden to use a SaverLogic with "deterministic" UUID generator. */
            @Override
            protected XmlSaver.SaverXmlLogic newSaverLogic()    {
                return new SaverXmlLogicImpl() {
                    @Override
                    public String generateUuid4Xml() {
                        return AbstractOwl2XmlTestCase.this.mapper.generateUuid4Xml();
                    }
                };
            }
        };
        
        transformerSupport = new TransformerSupport() {
            @Override
            public String getVCDSchemaVersionID() {
                return "Test VCD XmlSchema Version 1.0";
            }
            @Override
            public String getCompilationDate() {
                return "2010-06-08";
            }
            public String getCompilationTime() {
                return "13:37:00Z";
            }            
            @Override
            public String getOntologyVersionID() {
                return "Test VCD Ontology Version 1.0";
            }
            @Override
            public IssuingService getVcdIssuingService() {
                return new IssuingService()    {
                    @Override
                   public String getEndpointID() {
                       return "Test VCD Issuing Service Endpoint ID";
                   }
                    @Override
                   public String getName() {
                       return "Test VCD Issuing Service Name";
                   }
                    @Override
                   public String getProvidingPartyName() {
                       return "Test VCD Issuing Service Providing Party Name";
                   }
                };
            }
            @Override
            public IssuingService getIssuingService() {
                return new IssuingService()    {
                    @Override
                   public String getEndpointID() {
                       return "Test Issuing Service Endpoint ID";
                   }
                    @Override
                   public String getName() {
                       return "Test Issuing Service Name";
                   }
                    @Override
                   public String getProvidingPartyName() {
                       return "Test Issuing Service Providing Party Name";
                   }
                };
            }
        };
    }
    
}
