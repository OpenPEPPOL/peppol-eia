/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.owl2xml;

import at.m2n.IntelligenceManagement.vcd.saver.XmlSaver;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

/**
 * Tests the transformation RDF->XML with the instance data in instances.n3,
 * compares the result with VCDPackage.xml and referenced vcd[n] subdirs.
 * 
 * @author Fritz Ritzberger  27.05.2010
 */
public class Owl2XmlTransformerTest extends AbstractOwl2XmlTestCase {
    
    private OntModel schemaModel;
    private Model instancesModel;
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        
        schemaModel = ModelFactory.createOntologyModel();
//        FileTestUtil.readN3AsClassRelativePath(getClass(), "schema.n3", schemaModel);
        
        instancesModel = ModelFactory.createDefaultModel();
//        FileTestUtil.readN3AsClassRelativePath(getClass(), "instances.n3", instancesModel);
    }
    
    public void testTransform() throws Exception {
        // transform from RDF to XML
        XmlSaver saver = transform.transform(
                schemaModel,
                instancesModel,
                VcdSchemaVariant.newInstance(vhostRootDirectory, VcdSchemaVariant.Name.SKELETON), 
                transformerSupport,
                null); // do not optimize XML
        
        checkSkeletonSaver(saver);
    }

}
