/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.same_ev_bug;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import at.m2n.IntelligenceManagement.vcd.saver.BlobDocumentResolver;
import at.m2n.IntelligenceManagement.vcd.saver.PathAndDocument;
import at.m2n.IntelligenceManagement.vcd.saver.XmlSaver;
import at.m2n.IntelligenceManagement.vcd.transformer.owl2xml.AbstractOwl2XmlTestCase;
import at.m2n.IntelligenceManagement.vcd.util.FileTestUtil;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

/** Regression test for an unnumbered bug where the evidences would get mixed up (and evidence docs dropped!) when a representative used the same evidence (type, not document) as its legal entity. 
 */
public class SameEvBugTest extends AbstractOwl2XmlTestCase {

    /** Must be a "full package" transformation to allow document references that are tested here. */
    @Override
    protected boolean isFullPackageTransform() {
        return true;
    }
    
    public void testFullPackageTransformation() throws Exception {
        Model instancesModel = ModelFactory.createDefaultModel();
        FileTestUtil.readN3AsClassRelativePath(getClass(), "same_ev_bug.n3", instancesModel);
        
        final String [] blobUris = new String []  {
            "http://eine/verflucht/lange/URI/m2ndok",
            "http://eine/verflucht/lange/URI/dorisdok",
        };
        final String [] documentFileNames = new String []  {
            "Bilanzauszug_m2n.pdf",
            "Bilanzauszug_doris.pdf",
        };
            
        BlobDocumentResolver blobDocumentResolver = new BlobDocumentResolver()  {
            @Override
            public InputStream resolveBlob(String documentResourceUri) throws IOException {
                if (find(blobUris, documentResourceUri) == null)
                    return null;    // will cause exception
                return new ByteArrayInputStream(("foobie bar baz "+documentResourceUri).getBytes());
            }
        };
        
        XmlSaver saver = transform.transform(
            getRdfSchemaModel(),
            instancesModel,
            VcdSchemaVariant.newInstance(vhostRootDirectory, VcdSchemaVariant.Name.FULL),
            transformerSupport,
            blobDocumentResolver);
        
        checkSkeletonSaver(saver);
        
        for (PathAndDocument pathAndDocument : saver.getVcdList())  {
            int counter = 0;
            for (PathAndDocument attachment : pathAndDocument.getAttachments()) {
                System.out.println("Attachment path is: "+attachment.relativePathWithFileName);
                attachment.writeDocument(System.out, false);
                System.out.println();
                
                String s = find(documentFileNames, attachment.relativePathWithFileName);
                if (s != null)
                    counter++;
                
                assertNotNull("Missing "+attachment.relativePathWithFileName, s);
            }
            assertEquals(pathAndDocument.getAttachments().size(), counter);
        }
    }
    
    private String find(String [] array, String toSearch){
        for (String s : array)
            if (toSearch.endsWith(s))
                return s;
        return null;
    }
}
