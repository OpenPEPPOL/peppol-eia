/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.util;

import java.io.IOException;
import java.io.InputStream;

import at.m2n.IntelligenceManagement.vcd.AbstractFileTestUtil;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.util.FileUtils;

/**
 * Utilities in conjunction with unit-test files reading and writing.
 * <p />
 * The filename must be given as path relative to the location of the passed class.
 * So if you have a.b.c.SomeClass in directory a/b/c/, and a resource a/b/c/some.n3,
 * you can load this resource by passing
 * <pre>
 *   (Some.class, "some.n3", model);
 * </pre>
 * to this method.
 * <p />
 * This was made for Eclipse users: Eclipse sometimes does not copy resources into
 * the "target/test-classes" folder (its compile- and run-directory).
 * 
 * @author Fritz Ritzberger, Wolfgang Groiss, Bernhard Stiftner 27.05.2010
 */
public abstract class FileTestUtil extends AbstractFileTestUtil {
    
    /**
     * Read an N3 file into a model.
     * @param model the model the N3 should be read into.
     */
    public static void readN3AsClassRelativePath(Class clazz, String relativePath, Model model)
            throws IOException {

        InputStream in = at.m2n.IntelligenceManagement.vcd.AbstractFileTestUtil.inputStreamAsClassRelativePath(clazz, relativePath);
        model.read(in, "", FileUtils.langN3);
    }

    private FileTestUtil()  {}
}
