/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.transformer.xml2owl;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.jdom.JDOMException;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.mapping.MapperVariant;
import at.m2n.IntelligenceManagement.vcd.mapping.Xml2OwlMapper;
import at.m2n.IntelligenceManagement.vcd.transformer.AbstractVcdTestCase;
import at.m2n.IntelligenceManagement.vcd.transformer.PrimitiveCounterIdGenerator;
import at.m2n.IntelligenceManagement.vcd.transformer.Xml2OwlTransform;
import at.m2n.IntelligenceManagement.vcd.util.FileTestUtil;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;
import at.m2n.jena.util.OntUtil;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.util.FileUtils;

/**
 * Encapsulates the RDF schema files to use when converting XML->RDF,
 * and configures a deterministic URI generator in a custom Mapper.
 * 
 * @author Fritz Ritzberger  17.06.2010
 */
public abstract class AbstractXml2OwlTestCase extends AbstractVcdTestCase {
    
    protected File vhostDirectory;
    private PrimitiveCounterIdGenerator primitiveCounterIdGenerator;
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        primitiveCounterIdGenerator = new PrimitiveCounterIdGenerator();
        
        vhostDirectory = new File("../runner-server/vhosts/ossso_uis");
        
    }

	public Xml2OwlMapper createMapper(VcdSchemaVariant schemaVariant) {
		return new Xml2OwlMapper(schemaVariant, MapperVariant.Get.get(schemaVariant)) {
			@Override
			protected String generateUri4Rdf(String base) {
				return base + "/" + primitiveCounterIdGenerator.generate();
			}
		};

	}
	
	

    private Model transform(String urlString, VcdSchemaVariant variant) throws JDOMException, IOException, ParserConfigurationException, SAXException   {
        Xml2OwlTransform transform = new Xml2OwlTransform()    {
            /** Overridden to use a Mapper with "deterministic" URI generator. */
            @Override
            protected Xml2OwlMapper newMapper(VcdSchemaVariant schemaVariant) {
                return createMapper(schemaVariant);
            }
            /** Overridden to use local shouldValidate) method. */
            @Override
            protected boolean shouldValidate()  {
                return AbstractXml2OwlTestCase.this.shouldValidate();
            }
        };
        
        return transform.transform(getRdfSchemaModel(), urlString, variant);
    }

    /** Override this to turn on/off XML validation. */
    protected boolean shouldValidate() {
        return true;
    }

    /** Call this to transform XML (given by testPath) to N3 (given by comparePath). */
    protected final void checkTransform(String testPath, String comparePath, VcdSchemaVariant variant) throws JDOMException, IOException, ParserConfigurationException, SAXException   {
        String urlString = FileTestUtil.urlStringAsClassRelativePath(getClass(), testPath);
        Model testModel = transform(urlString, variant);

        testModel.write(System.out, FileUtils.langN3);
        
        Model compareModel = ModelFactory.createOntologyModel();
//        FileTestUtil.readN3AsClassRelativePath(getClass(), comparePath, compareModel);
        
        Model tooMuch = testModel.difference(compareModel);
        if (!tooMuch.isEmpty()) {
        	System.out.println("too much:");
        	OntUtil.dumpModel(tooMuch);
        }
        
        Model tooLittle = compareModel.difference(testModel);
      	System.out.println("too little");
        if (!tooLittle.isEmpty()) {
        	OntUtil.dumpModel(tooLittle);
        }

        assertTrue(tooMuch.isEmpty());
        assertTrue(tooLittle.isEmpty());
    }

}
