/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

import java.io.File;

public class PeppolStep3RulesTest extends AbstractReasonerTest {
	  String[] testcases = { "virtualPS3" , "simplePS3" , "simplePS3DirectMappedCombined" ,"mafiaPS3", "ecertis-multimapPS3"};
  
  public void testRuleBasedReasoner() throws Exception {
    File baseDir = new File("src/java/"+getClass().getPackage().getName().replaceAll("\\.", "/").replaceAll("\\/", "\\"+File.separator));
    
    Reasoner reasoner3 = new RuleBasedReasoner(new File(baseDir, "peppol-step-3.rules"));
    Reasoner reasoner3b = new RuleBasedReasoner(new File(baseDir,"peppol-step-3b-fix-unmapped-criteria.rules"));
    Reasoner reasoner3b2 = new RuleBasedReasoner(new File(baseDir,"peppol-step-3b2-fix-unmatched-criteria.rules"));
    Reasoner reasoner3c = new RuleBasedReasoner(new File(baseDir,"peppol-step-3c-add-eu-groups.rules"));
    Reasoner reasoner3d = new RuleBasedReasoner(new File(baseDir,"peppol-step-3d-suggest-evidences.rules"));
    
    Reasoner chain = new ChainReasoner(reasoner3, reasoner3b, reasoner3b2, reasoner3c, reasoner3d);
    
    doTest(testcases, chain);
  }
  
  
}
