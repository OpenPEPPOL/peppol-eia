/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;
import com.hp.hpl.jena.vocabulary.RDF;

public class OfficialOWLTest extends TestSuite {
  public static final String TEST_NAMESPACE = "http://www.w3.org/2002/03owlt/testOntology#";
  public static final String RTEST_NAMESPACE = "http://www.w3.org/2000/10/rdf-tests/rdfcore/testSchema#";
  
  public static final Resource R_ENTAILMENT_TEST = new ResourceImpl(TEST_NAMESPACE + "PositiveEntailmentTest");
  public static final Resource R_NEGATIVE_ENTAILMENT_TEST = new ResourceImpl(TEST_NAMESPACE + "NegativeEntailmentTest");
  
  public static final Property LEVEL = new PropertyImpl(TEST_NAMESPACE + "level");
  public static final Property FULL = new PropertyImpl(TEST_NAMESPACE + "Full");
  public static final Property LITE = new PropertyImpl(TEST_NAMESPACE + "Lite");
  public static final Property DL = new PropertyImpl(TEST_NAMESPACE + "DL");

  public static final Property SIZE = new PropertyImpl(TEST_NAMESPACE + "size");
  public static final Resource LARGE = new ResourceImpl(TEST_NAMESPACE + "Large");

  public static final Property PREMISE = new PropertyImpl(RTEST_NAMESPACE + "premiseDocument");
  public static final Property CONCLUSION = new PropertyImpl(RTEST_NAMESPACE + "conclusionDocument");

  private static final Set<String> testWhitelist = new HashSet<String>();
  static {
//    testWhitelist.add("http://www.w3.org/2002/03owlt/Class/Manifest005#test"); //not very meaningful IMO
  }
  
  private static final Set<String> testBlacklist = new HashSet<String>();
  static {
    testBlacklist.add("http://www.w3.org/2002/03owlt/I5.8/Manifest004#test"); //not very meaningful IMO
    testBlacklist.add("http://www.w3.org/2002/03owlt/I5.5/Manifest005#test"); //not very meaningful IMO (strange list thing)

    testBlacklist.add("http://www.w3.org/2002/03owlt/TransitiveProperty/Manifest002#test"); //not very meaningful IMO
    testBlacklist.add("http://www.w3.org/2002/03owlt/equivalentClass/Manifest006#test"); //automatic creation of complement and intersection classes
    testBlacklist.add("http://www.w3.org/2002/03owlt/I5.2/Manifest002#test"); //all classes that can't have instances are equivalent to owl:Nothing
  
    testBlacklist.add("http://www.w3.org/2002/03owlt/unionOf/Manifest003#test"); //automatisch union-of aus one-of wenn die mengen verwandt sind
    testBlacklist.add("http://www.w3.org/2002/03owlt/unionOf/Manifest004#test"); //automatisch one-of aus union-of von zwei one-ofs

    testBlacklist.add("http://www.w3.org/2002/03owlt/I5.26/Manifest010#test"); //for every object property there exists a restriction with mincard 1 
    testBlacklist.add("http://www.w3.org/2002/03owlt/I5.26/Manifest009#test"); //same as 010? 


    
    testBlacklist.add("http://www.w3.org/2002/03owlt/miscellaneous/Manifest010#test"); //OOME TODO: make run?
    testBlacklist.add("http://www.w3.org/2002/03owlt/miscellaneous/Manifest011#test"); //OOME TODO: make run?
    

    
    testBlacklist.add("http://www.w3.org/2002/03owlt/description-logic/Manifest901#test"); //i don't understand it 
    testBlacklist.add("http://www.w3.org/2002/03owlt/description-logic/Manifest903#test"); //i don't understand it 

    
    //TODO: u.u. interessant?
    testBlacklist.add("http://www.w3.org/2002/03owlt/cardinality/Manifest003#test"); //min-max -> cardinality
    testBlacklist.add("http://www.w3.org/2002/03owlt/cardinality/Manifest004#test"); //cardinality -> min-max
    testBlacklist.add("http://www.w3.org/2002/03owlt/disjointWith/Manifest001#test"); //disjoint classes -> different members

    testBlacklist.add("http://www.w3.org/2002/03owlt/SymmetricProperty/Manifest002#test"); //inverseFunctional->symmetric, plus (actual use of a propert) -> domain
    testBlacklist.add("http://www.w3.org/2002/03owlt/I5.21/Manifest002#test"); //mutual class disjointness from has-value restrictions with different values
  }
  
  
  public static Test suite() throws Exception {
    TestSuite suite = new TestSuite();
    
    addOWLTests(suite);
    
    return suite;
  }
  
  public void testDontRedbarInEclipse() {}

  private static void addOWLTests(TestSuite suite) throws Exception {
    File base = new File("./src/test/at/m2n/IntelligenceManagement/reasoning/w3c");
    
    for (File dir : base.listFiles()) {
      for (File mc : dir.listFiles()) {
        if (mc.getName().startsWith("Manifest")) {
          addOWLTest(mc, dir, suite);
        }
      }
    }
  }

  private static void addOWLTest(File mc, File dir, TestSuite suite) throws Exception {
    Model mManifest = modelFromFile(mc);
    addOWLTests(mManifest, R_ENTAILMENT_TEST, dir, suite);
    addOWLTests(mManifest, R_NEGATIVE_ENTAILMENT_TEST, dir, suite);
    
  }

  private static void addOWLTests(Model mManifest, Resource rTestType, File dir, TestSuite suite) throws Exception {
    StmtIterator iter = mManifest.listStatements(null, RDF.type, rTestType);
    while (iter.hasNext()) {
      Resource rTestCase = iter.nextStatement().getSubject();
      if (! testWhitelist.isEmpty()) {
        if (!testWhitelist.contains(rTestCase.getURI())) {
          continue;
        }
      }

      
      if (! testBlacklist.contains(rTestCase.getURI())) {
        if (rTestCase.hasProperty(LEVEL, DL)) { //TODO: also lite?
          if (!rTestCase.hasProperty(SIZE, LARGE)) {
            addOWLTests(rTestCase, rTestType, dir, suite);
          }
        }
      }
    }
    iter.close();
  }

  private static void addOWLTests(Resource rTestCase, Resource rTestType, File dir, TestSuite suite) throws Exception {
    StmtIterator iPremises = rTestCase.listProperties(PREMISE);
    while (iPremises.hasNext()) {
      Resource rPremise = iPremises.nextStatement().getResource();
      StmtIterator iConclusions = rTestCase.listProperties(CONCLUSION);
      while (iConclusions.hasNext()) {
        Resource rConclusion = iConclusions.nextStatement().getResource();
        addOWLTest(rTestCase, rTestType, dir, rPremise, rConclusion, suite);
      }
      iConclusions.close();
    }
    iPremises.close();
  }

  private static void addOWLTest(Resource rTestCase, Resource rTestType, File dir, Resource rPremise, Resource rConclusion, TestSuite suite) throws Exception {
    Model mPremise = modelFromFile(rPremise, dir);
    Model mConclusion = modelFromFile(rConclusion, dir);
    
    String name = rTestCase.getNameSpace();

    boolean positive = rTestType.equals(R_ENTAILMENT_TEST); //todo: check: only allow entailment test and negative entailment test
     
    suite.addTest(new EntailmentTest(name, mPremise, mConclusion, positive));
    
  }

  private static Model modelFromFile(Resource rModel, File dir) throws Exception {
    String name = rModel.getLocalName();
    File file = new File(dir, name+".rdf");
    return modelFromFile(file);
  }

  private static Model modelFromFile(File f) throws IOException {
    Model m = ModelFactory.createDefaultModel();
    
    FileReader fr = new FileReader(f);
    m.read(fr, null);
    
    return m;
  }
}
