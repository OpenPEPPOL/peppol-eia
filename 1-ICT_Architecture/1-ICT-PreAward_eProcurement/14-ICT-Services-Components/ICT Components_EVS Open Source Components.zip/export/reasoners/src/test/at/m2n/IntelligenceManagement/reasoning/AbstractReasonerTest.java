/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;



import java.io.File;
import java.io.FileInputStream;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

import org.apache.log4j.Logger;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.graph.compose.MultiUnion;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QueryParseException;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.Syntax;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;

public abstract class AbstractReasonerTest extends TestCase {
  
  private static final Property P_MODEL_PATH = new PropertyImpl("m2n://modelPath");
  private static final Property P_ONLY_AS_IN_OUTPUT = new PropertyImpl("m2n://AbstractReasonerTest/onlyAsInOutput");

  public AbstractReasonerTest() {
    super();
  }

  public AbstractReasonerTest(String name) {
    super(name);
  }

  protected void doTest(String[] testcases, Reasoner r) throws Exception {
    for (String testcase : testcases) {
      System.out.println("test case: "+testcase);
    	
      Model mInput = readModel(testcase, "input");
      Model mExpected = readModel(testcase, "output");
      Model mExpectedNot = readModel(testcase, "output_not");
      Set<Property> onlyAsInOutput = getOnlyAsInOutput(mInput);
      
      Model mAdditionalModels = readModel(testcase, "additional");
      if (mAdditionalModels != null) {
        MultiUnion mUnion = new MultiUnion();
        
        StmtIterator iter = mAdditionalModels.listStatements(null, P_MODEL_PATH, (RDFNode)null);
        while (iter.hasNext()) {
          Statement stmt = iter.nextStatement();
          Literal l = stmt.getLiteral();
          String path = l.getString();
          Model mAdditional = readModel(path);
          
          if (mAdditional != null) {
            mUnion.addGraph(mAdditional.getGraph());
          } else Logger.getLogger(getClass()).error("File not found: "+new File(path).getAbsolutePath());
        }
        
        mUnion.addGraph(mInput.getGraph());
        mInput = ModelFactory.createModelForGraph(mUnion);
      }
      
    
      Graph gResult = r.performReasoning(mInput.getGraph());
      Model mResult = ModelFactory.createModelForGraph(gResult);
    

      
      if (mExpected != null)
        assertContains(mExpected, mResult, true, true);
      
      if (mExpectedNot != null && !mExpectedNot.isEmpty())
        assertContains(mExpectedNot, mResult, false, true);
      
      for (Property p : onlyAsInOutput) {
    	  assertSameOccurences(p, mExpected, mResult);
      }      

    }
  }

  private void assertSameOccurences(Property p, Model mExpected, Model mResult) {
	  int expected = countProperty(p, mExpected);
	  int result = countProperty(p, mResult);
	  
	  
	  if (expected != result) {
		  StmtIterator iResult = mResult.listStatements(null, p, (RDFNode)null);
		  while (iResult.hasNext()) {
			  Statement stmt = iResult.nextStatement();
			  if (mExpected.contains(stmt)) {
				  System.out.println("Expected: "+stmt);
			  } else {
				  System.out.println("Unexpected: "+stmt);
			  }
			  
			  dumpResource(stmt.getSubject());
			  if (stmt.getObject() != null && stmt.getObject().canAs(Resource.class))
				  dumpResource(stmt.getResource());

			  System.out.println();
		  }
		  iResult.close();
	  }

	  assertEquals("Property "+p+" shouldn't occur more often than specified in output.", expected, result);

}

private Set<Property> getOnlyAsInOutput(Model m) {
	Set<Property> retVal = new HashSet<Property>();
	
	StmtIterator iter = m.listStatements(null, P_ONLY_AS_IN_OUTPUT, (RDFNode)null);
	while (iter.hasNext()) {
		Resource r = iter.nextStatement().getSubject();
		retVal.add((Property)r.as(Property.class));
	}
	iter.close();
	
	return retVal;
}

private int countProperty(Property p, Model m) {
	int count = 0;
	
	StmtIterator iter = m.listStatements(null, p, (RDFNode)null);
	while (iter.hasNext()) {
		iter.next();
		++count;
	}
	iter.close();
	
	return count;
}

public static void assertContains(Model mExpected, Model mResult, boolean positive, boolean splitNonconclusionsByVariables) {
    try {
      doAssertContains(mExpected, mResult, positive, splitNonconclusionsByVariables);
    } catch (AssertionFailedError afe) {
      System.out.println("\n\n\n\n");
      mResult.write(System.out, "N3");
      
      System.out.println("\n\n\nunmatched:");
      
      Model mUnmatched = ModelFactory.createDefaultModel();
      mUnmatched.add(mExpected);
      mUnmatched.remove(mResult);
      
      mUnmatched.write(System.out, "N3");
      
      throw afe;
    }
  }
  
  private static void doAssertContains(Model mExpected, Model mResult, boolean positive, boolean splitNonconclusionsByVariables) {
    Query q = createAssertContainsQuery(mExpected, positive, splitNonconclusionsByVariables);
    QueryExecution qe = QueryExecutionFactory.create(q, mResult);
    
    ResultSet rs = qe.execSelect();
    if (positive) 
      assertTrue("Unfulfilled Query: "+q, rs.hasNext());
    else
      assertFalse("Unexpectedly fulfilled Query: "+q, rs.hasNext());
  }

  private static Query createAssertContainsQuery(Model mExpected, boolean positive, boolean splitNonconclusions) {
    Set<Triple> triplesWithVariables = extractTriplesWithVariables(mExpected);
    
    boolean split = (!positive) && splitNonconclusions;
    Set<Set<Triple>> distinctVariableGroupsTriples = split ? splitIntoDistinctVariableGroups(triplesWithVariables) : Collections.singleton(triplesWithVariables);
    
    StringBuilder sb = new StringBuilder();
    
    sb.append("SELECT * WHERE {");
    
    boolean first = true;
    
    for (Set<Triple> tg : distinctVariableGroupsTriples) {
      if (!first)
        sb.append("\n  UNION");
      
      first = false;
      sb.append(" {\n");
      for (Triple t : tg) {
        append(t, sb);
      }
      sb.append("  }\n");
    }
    
    
    sb.append("}");
    
    try {
      return QueryFactory.create(sb.toString(), Syntax.syntaxSPARQL);
    } catch (QueryParseException qpe) {
      System.out.println(qpe);
      System.out.println(sb.toString());
      throw qpe;
    }
  }

  private static Set<Set<Triple>> splitIntoDistinctVariableGroups(Set<Triple> triplesWithVariables) {
    Map<Node, Set<Node>> coOccurrences = analyzeCoOccurrences(triplesWithVariables);
    
    Set<Set<Node>> groups = new HashSet<Set<Node>>(coOccurrences.values());
    
    Map<Set<Node>, Set<Triple>> groupMap = new HashMap<Set<Node>, Set<Triple>>();
    
    for (Set<Node> g : groups) {
      groupMap.put(g, new HashSet<Triple>());
    }
    Set<Triple> noVars = new HashSet<Triple>();
    
    for (Triple t : triplesWithVariables) {
      Collection<Node> vars = getCoOccuranceRelevantNodes(t);
      
      if (vars.isEmpty())
        noVars.add(t);
      else {
        Node aVar = vars.iterator().next();
        for (Set<Node> candidateGroup : groups) {
          if (candidateGroup.contains(aVar)) {
            groupMap.get(candidateGroup).add(t);
            break;
          }
        }
      }
    }
    
    
    
    Set<Set<Triple>> r = new HashSet<Set<Triple>>();
    if (!noVars.isEmpty())
      r.add(noVars);
    
    for (Set<Triple> g : groupMap.values()) {
      r.add(g);
    }
    
    
    return r;
  }

  private static Map<Node, Set<Node>> analyzeCoOccurrences(Set<Triple> triplesWithVariables) {
    Map<Node, Set<Node>> r = new HashMap<Node, Set<Node>>();
    
    for (Triple t : triplesWithVariables) {
      analyzeCoOccurrences(t, r);
    }
    
    for (Node n : r.keySet()) {
      Set<Node> tc = transitiveClosure(r.get(n), r);
      r.put(n, tc);
    }
    
    return r;
  }

  private static Set<Node> transitiveClosure(Set<Node> set, Map<Node, Set<Node>> m) {
    return doTransitiveClosure(set, m, new HashSet<Node>());
  }

  private static Set<Node> doTransitiveClosure(Set<Node> set, Map<Node, Set<Node>> m, Set<Node> seen) {
    Set<Node> r = new HashSet<Node>();
    r.addAll(set);

    Set<Node> unseen = new HashSet<Node>(set);
    unseen.removeAll(seen);
    
    seen.addAll(set);
    
    for (Node n : unseen) {
      Set<Node> direct = m.get(n);
      if (! r.containsAll(direct)) {
        r.addAll(direct);
        r.addAll(doTransitiveClosure(direct, m, seen));
      }
    }
    
    return r;
  }

  private static void analyzeCoOccurrences(Triple t, Map<Node, Set<Node>> r) {
    Collection<Node> nodes = getCoOccuranceRelevantNodes(t);
    
    if (nodes.size() >= 2) {
      for (Node v: nodes) {
        add(v, nodes, r);
      }
      
    }
  }

  private static Collection<Node> getCoOccuranceRelevantNodes(Triple t) {
          Set<Node> r = new HashSet<Node>();
          addIfRelevant(t.getSubject(), r);
          addIfRelevant(t.getPredicate(), r);
          addIfRelevant(t.getObject(), r);
          return r;
        }

  private static void addIfRelevant(Node n, Set<Node> r) {
          if (n.isVariable())
            r.add(n);
        }
        
  private static void add(Node v, Collection<Node> vars, Map<Node, Set<Node>> r) {
    Set<Node> s = r.get(v);
    
    if (s == null) {
      s = new HashSet<Node>();
      r.put(v, s);
    }

    s.addAll(vars);
  }

  private static void append(Triple t, StringBuilder sb) {
    sb.append("  ");
    append(t.getSubject(), sb);
    sb.append(" ");
    append(t.getPredicate(), sb);
    sb.append(" ");
    append(t.getObject(), sb);
    sb.append(" .\n");
  }

  private static void append(Node n, StringBuilder sb) {
    if (n.isURI()) {
      sb.append("<" + n.getURI()+ ">");
    } else if (n.isLiteral()) {
    	String lex = n.getLiteralLexicalForm();
    	if (lex.contains("\n")) {
        sb.append("\"\"\"" + lex +"\"\"\"");
    	} else {
    		sb.append("\""+ lex +"\"");
    	}
      
      if (n.getLiteralDatatypeURI() != null) {
        sb.append("^^<"+n.getLiteralDatatypeURI()+">");
      } 
      
      String ll = n.getLiteralLanguage();
      if (ll != null && !ll.trim().isEmpty()) {
        sb.append("@"+ll);
      }
    } else if (n.isVariable()) {
      sb.append("?"+n.getName());
    } else {
      throw new RuntimeException("what could it be?? "+n);
    }
  }

  private static Set<Triple> extractTriplesWithVariables(Model mExpected) {
    Map<Node, Node> vars = new HashMap<Node, Node>();
    Set<Triple> retVal = new HashSet<Triple>();
    
    StmtIterator iter = mExpected.listStatements();
    while (iter.hasNext()) {
      Statement stmt = iter.nextStatement();
      Triple tExpected = stmt.asTriple();
      Triple tRet = withVariables(tExpected, vars);
      retVal.add(tRet);
    }

    return retVal;
  }

  private static Triple withVariables(Triple tExpected, Map<Node, Node> vars) {
    Node s = withVariable(tExpected.getSubject(), vars);
    Node p = withVariable(tExpected.getPredicate(), vars);
    Node o = withVariable(tExpected.getObject(), vars);
    return new Triple(s, p, o);
  }

  private static Node withVariable(Node n, Map<Node, Node> vars) {
    if (n.isBlank()) {
      Node var = vars.get(n);
      
      if (var == null) {
        var = Node.createVariable("bnode"+varName(n.getBlankNodeLabel()));
        vars.put(n, var);
      }
      
      return var;
    }

    return n;
  }

  private static String varName(String s) {
    return s.replaceAll("[\\-\\:]", "");
  }

  private static RDFNode cleanBlank(RDFNode rn) {
    return rn.isAnon() ? null : rn; 
  }

  private Model readModel(String testcase, String qualifier) throws Exception {
    File baseDir = new File("src/test/"+getClass().getPackage().getName().replaceAll("\\.", "/").replaceAll("\\/", "\\"+File.separator));
    File f = new File(baseDir, testcase + "_" + qualifier + ".n3");
    return readModel(f);
  }
  
  private Model readModel(String path) throws Exception {
    File f = new File(path);
    return readModel(f);
  }

  private Model readModel(File f) throws Exception {
    if (!f.exists())
      return null;
    
    Model m = ModelFactory.createDefaultModel();
    FileInputStream fis = new FileInputStream(f);
    m.read(fis, null, "N3");
    return m;
  }

  private void dumpResource(Resource resource) {
    StmtIterator iter = resource.listProperties();
    while (iter.hasNext()) {
      System.out.println(iter.nextStatement());
    }
    iter.close();
  }

}
