/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

import junit.framework.AssertionFailedError;
import junit.framework.Test;
import junit.framework.TestResult;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class EntailmentTest implements Test {
  private String name="EntailmentTest";
  private Model mPremise;
  private Model mConclusion;
  private boolean positive;
  
  private boolean initialized = false;
  
  private OWLDLReasoner reasoner = new OWLDLReasoner();
  

  public EntailmentTest(String name) {}
  public void testDontChoke() {}

  public EntailmentTest(String name, Model mPremise, Model mConclusion, boolean positive) {
    this.name = name;
    
    this.mPremise = mPremise;
    this.mConclusion = mConclusion;
    
    this.positive = positive;
    
    this.initialized = true;
  }
  
  @Override
  public String toString() {
    return name;
  }


  @Override
  public int countTestCases() {
    return 1;
  }

  @Override
  public void run(TestResult result) {
    //if run directly from junit, just skip it
    if (!initialized) {
      return;
    }
    
    result.startTest(this);
    
    try {
      Graph gResult = reasoner.performReasoning(mPremise.getGraph());
      
      Model mResult = ModelFactory.createModelForGraph(gResult);
      
      
      AbstractReasonerTest.assertContains(mConclusion, mResult, positive, false);
    } catch (AssertionFailedError afe) {
      result.addFailure(this, afe);
    } catch (Throwable t) {
      result.addError(this, t);
    }

    result.endTest(this);
  }





}
