/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.hp.hpl.jena.reasoner.ReasonerFactory;
import com.hp.hpl.jena.reasoner.rulesys.OWLFBRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.Rule;

public class ImprovedOWLFBRuleReasoner extends OWLFBRuleReasoner {
  private static final String RULE_FILE_NAME = "owl-dl-additional.rules";

  public ImprovedOWLFBRuleReasoner(ReasonerFactory factory) {
    super(factory);
    
    List ruleSet = OWLFBRuleReasoner.ruleSet;
    List additionalRules = loadAdditionalRules();
    
    additionalRules.addAll(ruleSet);
    
    //these rules are apparently buggy and produce spurious rdfs:domain/rdfs:range statements
    removeRules("rdfs2a", additionalRules);
    removeRules("rdfs3a", additionalRules);
    removeRules("objectProperty", additionalRules);

    //why was that again?
    removeRules("distinct1", additionalRules);
    
    //this is supposed to hide its results but still leaves spurious bnodes as instances of classes that have missing properties (obviously)
    removeRules("prototype1", additionalRules);

    setRules(additionalRules);
  }

  private void removeRules(String name, List<Rule> rules) {
    Set<Rule> remove = new HashSet<Rule>();
    for (Rule r : rules) {
      if (name.equals(r.getName()))
        remove.add(r);
    }
    
    rules.removeAll(remove);
    
  }

  private List loadAdditionalRules() {
    return Rule.rulesFromURL(getClass().getResource(RULE_FILE_NAME).toString());
  }
  

}
