/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.ontology.ProfileRegistry;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class OWLDLReasoner extends JenaModelReasoner {
  public static final OntModelSpec M2N_IMPROVED_OWL_DL_MEM_RULE_INF = new OntModelSpec(ModelFactory.createMemModelMaker(), null, ImprovedOWLFBRuleReasonerFactory.theInstance(), ProfileRegistry.OWL_DL_LANG );
  
  
  @Override
  protected Model createReasoningModel(Model base) {
      return ModelFactory.createOntologyModel(M2N_IMPROVED_OWL_DL_MEM_RULE_INF, base);
//    alternatives (albeit not much better, if at all: pellet, ossi)
//	  return ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC, base);
//	  return AutoValueOntModel.create(base);
  }

}
