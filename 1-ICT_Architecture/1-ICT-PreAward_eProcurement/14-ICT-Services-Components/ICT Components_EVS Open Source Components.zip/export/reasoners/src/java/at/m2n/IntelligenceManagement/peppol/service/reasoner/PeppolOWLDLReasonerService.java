/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.reasoner;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;
import at.m2n.IntelligenceManagement.osSso.service.ServiceResult;
import at.m2n.IntelligenceManagement.osSso.service.impl.MonotonuousServiceResult;
import at.m2n.IntelligenceManagement.osSso.service.impl.ServicePreAndPostConditions;
import at.m2n.IntelligenceManagement.reasoning.OWLDLReasoner;
import at.m2n.IntelligenceManagement.reasoning.Reasoner;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;

public class PeppolOWLDLReasonerService extends ReasonerService {
  private static final PropertyImpl P_TENDERER_IS = new PropertyImpl("http://m2n.at/2009/05/peppol/tendererIs");
  private static final PropertyImpl P_REASONING_PROVIDED = new PropertyImpl("http://m2n.at/2009/05/peppol/dlReasoningProvided");
  private static final String S_PREFIX = "@prefix peppol:   <http://m2n.at/2009/05/peppol/> .";
  private static final String S_PRE = S_PREFIX + "?request peppol:tendererIs ?tenderer.";
  private static final String S_POST = S_PREFIX + "?request peppol:dlReasoningProvided ?reasoningProvided .";
  
  public static final String SERVICE_NAME = "PeppolOWLDL";
  private Reasoner reasoner = new OWLDLReasoner();
  
  public PeppolOWLDLReasonerService() {
    super(SERVICE_NAME, ServicePreAndPostConditions.parse(S_PRE, S_POST));
  }

  
  
  @Override
  protected ServiceExecution doCall(final Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, final OsssoModel model) {
    return new ServiceExecution() {
      
      @Override
      public ServiceResult getResultBlocking() throws InterruptedException {
      	
      	Set<Resource> subjects = getSubjects(model);
      	
      	
      	
        Graph output = reasoner.performReasoning(model.getModel(getName()).getGraph());
        Model source = ModelFactory.createModelForGraph(output);
        Model target = ModelFactory.createDefaultModel();
        target.add(source);
        
        Node n = bindings.get(Node.createVariable("request")); //TODO: this could be empty (and it is, in our test case!) - why?
        if (n != null) {
          Resource r = (Resource)target.asRDFNode(n);
          r.addProperty(P_REASONING_PROVIDED, true); //TODO: maybe use a timestamp or hash to make a more meaningful assertion?
        }
        
        Set<Resource> requests = new HashSet<Resource>();
        StmtIterator iter = target.listStatements(null, P_TENDERER_IS, (RDFNode)null);
        while (iter.hasNext()) {
          requests.add(iter.nextStatement().getSubject());
        }
        iter.close();
        
        for (Resource req: requests) {
          req.addProperty(P_REASONING_PROVIDED, true); //TODO: see above (timestamp? hash?)
        }
        
        
        target = filterBySubject(target, subjects);
//        target = removeAllBlankNodes(target);
        
        return new MonotonuousServiceResult(target);
      }

			private Model filterBySubject(Model source, Set<Resource> allowed) {
				Model target = ModelFactory.createDefaultModel();
				
				StmtIterator iter = source.listStatements();
				while (iter.hasNext()) {
					Statement stmt = iter.nextStatement();
					if (allowed.contains(stmt.getSubject())) {
						target.add(stmt);
//						System.out.println("good "+stmt);
					} else {
//						System.out.println("skipping "+stmt);
					}
				}
				
				
				return target;
			}

			private Set<Resource> getSubjects(final OsssoModel model) {
				Model dataModelOnly = model.getOperatingModelWithoutBase();
      	Set<Resource> subjects = new HashSet<Resource>();
      	ResIterator iter = dataModelOnly.listSubjects();
      	while (iter.hasNext()) {
      		subjects.add(iter.nextResource());
      	}
      	iter.close();
      	
      	return subjects;
			}

	};
  }
}
