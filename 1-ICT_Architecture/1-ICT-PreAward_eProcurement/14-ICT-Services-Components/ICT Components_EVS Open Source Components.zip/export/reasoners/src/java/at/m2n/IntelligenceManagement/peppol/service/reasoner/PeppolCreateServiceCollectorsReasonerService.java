/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.reasoner;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;
import at.m2n.IntelligenceManagement.osSso.service.ServiceResult;
import at.m2n.IntelligenceManagement.osSso.service.impl.MonotonuousServiceResult;
import at.m2n.IntelligenceManagement.osSso.service.impl.ServicePreAndPostConditions;
import at.m2n.IntelligenceManagement.reasoning.Reasoner;
import at.m2n.IntelligenceManagement.reasoning.RuleBasedReasoner;
import at.m2n.jena.util.OntUtil;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;

public class PeppolCreateServiceCollectorsReasonerService extends ReasonerService {
  private static final PropertyImpl P_REASONING_PROVIDED = new PropertyImpl("http://m2n.at/2009/05/peppol/serviceCollectorsBuilt");
	
  private static final String S_PREFIX = "@prefix peppol:   <http://m2n.at/2009/05/peppol/> .";
  private static final String S_PRE = S_PREFIX + "?request peppol:evidencesSelected ?true . ";
  private static final String S_POST = S_PREFIX + "?request peppol:serviceCollectorsBuilt ?built .";
  
  private Logger logger = Logger.getLogger(getClass());
  
  
  private Reasoner reasoner = new RuleBasedReasoner("peppol-step-4-servicecollectors.rules");
  
  public PeppolCreateServiceCollectorsReasonerService() {
    super("PeppolRuleReasonerCreateServiceCollectors", ServicePreAndPostConditions.parse(S_PRE, S_POST));
  }

  
  
  @Override
  protected ServiceExecution doCall(final Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, final OsssoModel model) {
    return new ServiceExecution() {
      
      @Override
      public ServiceResult getResultBlocking() throws InterruptedException {
        Graph output = reasoner.performReasoning(model.getModel().getGraph());
        Model result = ModelFactory.createModelForGraph(output);
        
//        dumpResult(result, model.getModel());
        
        Node n = pp.extractInput(model.getModel(), bindings).get(Node.createVariable("request")); 
        if (n != null) {
          Resource r = (Resource)result.asRDFNode(n);
          r.addProperty(P_REASONING_PROVIDED, true); 
        }
        
        return new MonotonuousServiceResult(result);
      }

      
      
			private void dumpResult(Model result, Model fullModel) {
				logger.info("DUMPING RESULT");
				Set<Resource> tenderers = findTenderers(result);
				
				for (Resource tenderer : tenderers) {
					dumpServiceSelectors(tenderer, fullModel);
				}
				logger.info("END OF DUMPING RESULT\n\n");
				
			}



			private Set<Resource> findTenderers(Model result) {
				Set<Resource> retVal = new HashSet<Resource>();
				StmtIterator it = result.listStatements(null, P_CRIT_COLL, (RDFNode)null);
				
				while (it.hasNext()) {
					Statement stmt = it.nextStatement();
					retVal.add(stmt.getSubject());
				}

				return retVal;
			}



			private void dumpServiceSelectors(Resource tenderer, Model fullModel) {
				logger.info("  "+toString(tenderer, fullModel));
				
				StmtIterator iSSs = tenderer.listProperties(P_SERVICE_COLL);
				while (iSSs.hasNext()) {
					Statement stmt = iSSs.nextStatement();
					Resource rSS = stmt.getResource();
					OntUtil.dumpResource(rSS);
				}
				iSSs.close();
			}



			private String toString(Resource r, Model fullModel) {
				return OntUtil.toString(r.inModel(fullModel));
			}

    };
  }
  
  private static String S_PFX = "http://m2n.at/2009/05/peppol/";
  private static Property P_CRIT_COLL = new PropertyImpl(S_PFX+"criterionCollector");
  private static Property P_SERVICE_COLL = new PropertyImpl(S_PFX+"serviceCollector");

  

}
