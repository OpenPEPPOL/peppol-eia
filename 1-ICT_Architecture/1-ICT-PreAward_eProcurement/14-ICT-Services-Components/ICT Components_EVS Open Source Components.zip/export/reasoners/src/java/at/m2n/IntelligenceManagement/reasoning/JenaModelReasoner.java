/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public abstract class JenaModelReasoner implements Reasoner {
  @Override
  public Graph performReasoning(Graph inputData) {
    Model mInput = createBaseModel(inputData);
    
    Model m = createReasoningModel(mInput);
   
    Model mOutput = ModelFactory.createDefaultModel();
    mOutput.add(m);
    mOutput.remove(mInput);
    
    return m.getGraph();
  }
  
  /** overwrite if you want to e.g. unionize the input data with an existing schema or so. */
  protected Model createBaseModel(Graph inputData) {
    return ModelFactory.createModelForGraph(inputData);
  }

  protected abstract Model createReasoningModel(Model base);
}
