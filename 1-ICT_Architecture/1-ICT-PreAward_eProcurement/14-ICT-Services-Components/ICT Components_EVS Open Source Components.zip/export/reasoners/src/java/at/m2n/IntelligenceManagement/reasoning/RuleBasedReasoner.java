/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.log4j.Logger;

import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.reasoner.rulesys.BuiltinRegistry;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasonerFactory;
import com.hp.hpl.jena.vocabulary.ReasonerVocabulary;

public class RuleBasedReasoner extends JenaModelReasoner {
    private final static Logger logger = Logger.getLogger(RuleBasedReasoner.class);
    
    private String ruleFilePath;

    static {
        BuiltinRegistry.theRegistry.register(new MakeCollector());
    }

    public RuleBasedReasoner(File ruleFile) throws IOException {
        ruleFilePath = ruleFile.getPath();
    }

    public RuleBasedReasoner(String filename) {
       ruleFilePath = getTempRulesFile(filename);

    }
    
    /**
     * creates a temporary file from filename, which is used for reasoning.
     * This is needed, because jena will not have access to the rules-files in a jar.
     * This will not work within applets, because it will cause a security exception
     * @param filename
     * @return
     */
    private String getTempRulesFile(String filename) {
        String result;
        // try to create temporary file
        File tmpFile = null;
        boolean successful = false;
        try {
            tmpFile = File.createTempFile(filename, ".tmp");
            if (tmpFile != null && tmpFile.exists()) {

                // read the rules file from this package
                InputStream in = this.getClass().getResourceAsStream(filename);
                OutputStream out = new FileOutputStream(tmpFile);
                try {
                    byte[] buffer = new byte[1024];
                    int len = 0;
                    while ((len = in.read(buffer)) != -1) {
                        out.write(buffer, 0, len);
                    }
                    out.flush();
                    successful = true;
                }
                finally {
                    if(in != null) in.close();
                    if(out != null) out.close();
                }

            }
            
        }
        catch (IOException e) {
            // something went wrong copying the file...
            // let jena handle finding the correct file
            successful = false;
            logger.warn("Was not able to copy rule file! Can cause reasoner to fail, because of not finding the rule-resource!");

        }

        if(successful) {
            result = tmpFile.getAbsolutePath();
        } else {
            logger.warn("Will use origin filename. Maybe it is not accessible for the reasoner!");
            result = filename;
        }
        return result;
    }

    @Override
    protected Model createReasoningModel(Model base) {
        Model mConfig = ModelFactory.createDefaultModel();
        Resource rConfig = mConfig.createResource();

        rConfig.addProperty(ReasonerVocabulary.PROPruleMode, "hybrid");
        rConfig.addProperty(ReasonerVocabulary.PROPruleSet, ruleFilePath);

        com.hp.hpl.jena.reasoner.Reasoner r = GenericRuleReasonerFactory.theInstance().create(rConfig);

        // GenericRuleReasoner r = new GenericRuleReasoner(rules);
        InfModel m = ModelFactory.createInfModel(r, base);
        m.prepare();

        return m;
    }




}
