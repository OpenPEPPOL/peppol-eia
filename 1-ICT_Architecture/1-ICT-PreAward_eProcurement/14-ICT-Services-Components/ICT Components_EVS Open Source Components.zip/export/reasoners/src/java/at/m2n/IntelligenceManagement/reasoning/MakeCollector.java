/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

/******************************************************************
 * File:        MakeInstance.java
 * Created by:  Dave Reynolds
 * Created on:  02-Jun-2003
 * 
 * (c) Copyright 2003, 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 * $Id: MakeInstance.java,v 1.12 2006/03/22 13:52:34 andy_seaborne Exp $
 *****************************************************************/

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.reasoner.InfGraph;
import com.hp.hpl.jena.reasoner.rulesys.BuiltinException;
import com.hp.hpl.jena.reasoner.rulesys.RuleContext;
import com.hp.hpl.jena.reasoner.rulesys.builtins.BaseBuiltin;
import com.hp.hpl.jena.vocabulary.RDF;

/**
 * Create or lookup an anonymous instance of a property value. Syntax of the call is:
 * 
 * <pre>
 *    makeInstance(X, P, D, T) or makeInstance(X, P, T)
 * </pre>
 * 
 * where X is the instance and P the property for which a temporary value is required, T will be bound to the temp value (a bNode) and D is an optional type cor the T value.
 * 
 * @author <a href="mailto:der@hplb.hpl.hp.com">Dave Reynolds</a>
 * @version $Revision: 1.12 $ on $Date: 2006/03/22 13:52:34 $
 */
public class MakeCollector extends BaseBuiltin {

  /**
   * Return a name for this builtin, normally this will be the name of the functor that will be used to invoke it.
   */
  public String getName() {
    return "makeCollector";
  }

  @Override
  public int getArgLength() {
    return 6;
  }



  /**
   * This method is invoked when the builtin is called in a rule body.
   * 
   * @param args
   *          the array of argument values for the builtin, this is an array of Nodes, some of which may be Node_RuleVariables.
   * @param length
   *          the length of the argument list, may be less than the length of the args array for some rule engines
   * @param context
   *          an execution context giving access to other relevant data
   * @return return true if the buildin predicate is deemed to have succeeded in the current environment
   */
  public boolean bodyCall(Node[] args, int length, RuleContext context) {
    if (length == 6) {
      Node subj = getArg(0, args, context);
      Node obj = getArg(1, args, context);
      Node collType = getArg(2, args, context);
      Node subjToColl = getArg(3, args, context);
      Node collToObj = getArg(4, args, context);
      Node collVar = getArg(5, args, context);

      Node collector = create(context, subj, obj, collType, subjToColl, collToObj);

      return context.getEnv().bind(collVar, collector);

    } else {
      throw new BuiltinException(this, context, "builtin " + getName() + " requries 5 arguments");
    }
  }

  @Override
  public void headAction(Node[] args, int length, RuleContext context) {
    if (length == 6) {
      Node subj = getArg(0, args, context);
      Node obj = getArg(1, args, context);
      Node collType = getArg(2, args, context);
      Node subjToColl = getArg(3, args, context);
      Node collToObj = getArg(4, args, context);
      Node collVar = getArg(5, args, context);

      Node collector = create(context, subj, obj, collType, subjToColl, collToObj);

      context.getEnv().bind(collVar, collector);

    } else {
      throw new BuiltinException(this, context, "builtin " + getName() + " requries 5 arguments");
    }
  }


  private Node create(RuleContext context, Node subject, Node object, Node type, Node subjectToCollector, Node collectorToObject) {
    Node temp = getTemp(context.getGraph(), context, subject, subjectToCollector, object, type);

    context.add(new Triple(subject, subjectToCollector, temp));
    context.add(new Triple(temp, collectorToObject, object));
    context.add(new Triple(temp, RDF.type.asNode(), type));

    return temp;

  }

  private Node getTemp(InfGraph graph, RuleContext context, Node inst, Node prop, Node obj, Node pclass) {
  	String uri = pclass.getURI()+"/"+Integer.toHexString(inst.hashCode())+"/"+Integer.toHexString(prop.hashCode())+"/"+Integer.toHexString(obj.hashCode());
  	return Node.createURI(uri);
  	
//    if (graph instanceof FBRuleInfGraph) return ((FBRuleInfGraph) graph).getTemp(inst, prop, pclass);
//    throw new BuiltinException(this, context, "builtin " + getName() + " doesn't work with " + graph.getClass());
  }



}
