/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.reasoner;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;
import at.m2n.IntelligenceManagement.osSso.service.ServiceResult;
import at.m2n.IntelligenceManagement.osSso.service.impl.MonotonuousServiceResult;
import at.m2n.IntelligenceManagement.osSso.service.impl.ServicePreAndPostConditions;
import at.m2n.IntelligenceManagement.reasoning.ChainReasoner;
import at.m2n.IntelligenceManagement.reasoning.Reasoner;
import at.m2n.IntelligenceManagement.reasoning.RuleBasedReasoner;
import at.m2n.jena.util.OntUtil;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;

public class PeppolStep2ReasonerService extends ReasonerService {
  private static final PropertyImpl P_REASONING_PROVIDED = new PropertyImpl("http://m2n.at/2009/05/peppol/criterionCollectorsBuilt");
	
  private static final String S_PREFIX = "@prefix peppol:   <http://m2n.at/2009/05/peppol/> .";
  private static final String S_PRE = S_PREFIX + "?request peppol:criteriaSelected ?true .";
  private static final String S_POST = S_PREFIX + "?request peppol:criterionCollectorsBuilt ?built .";
  
  private Logger logger = Logger.getLogger(getClass());
  
  
  private Reasoner reasoner2 = new RuleBasedReasoner("peppol-step-2.rules");
  private Reasoner reasoner3a = new RuleBasedReasoner("peppol-step-3.rules");
  private Reasoner reasoner3b = new RuleBasedReasoner("peppol-step-3b-fix-unmapped-criteria.rules");
  private Reasoner reasoner3b2 = new RuleBasedReasoner("peppol-step-3b2-fix-unmatched-criteria.rules");
  private Reasoner reasoner3c = new RuleBasedReasoner("peppol-step-3c-add-eu-groups.rules");
  private Reasoner reasoner3d = new RuleBasedReasoner("peppol-step-3d-suggest-evidences.rules");
  
  private Reasoner reasoner3 = new ChainReasoner(reasoner3a, reasoner3b, reasoner3b2, reasoner3c, reasoner3d);
  
  public PeppolStep2ReasonerService() {
    super("PeppolRuleReasonerStep2", ServicePreAndPostConditions.parse(S_PRE, S_POST));
  }

  
  
  @Override
  protected ServiceExecution doCall(final Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, final OsssoModel model) {
    return new ServiceExecution() {
      
      @Override
      public ServiceResult getResultBlocking() throws InterruptedException {
        Graph output = reasoner3.performReasoning(reasoner2.performReasoning(model.getModel().getGraph()));
        Model result = ModelFactory.createModelForGraph(output);
        
//        dumpResult(result, model.getModel());
        
        Node n = bindings.get(Node.createVariable("request")); //TODO: this could be empty (and it is, in our test case!) - why?
        if (n != null) {
          Resource r = (Resource)result.asRDFNode(n);
          r.addProperty(P_REASONING_PROVIDED, true); //TODO: maybe use a timestamp or hash to make a more meaningful assertion?
        }
        
        
        return new MonotonuousServiceResult(result);
      }

      
      
			private void dumpResult(Model result, Model fullModel) {
				logger.info("DUMPING RESULT");
				Set<Resource> tenderers = findTenderers(result);
				
				for (Resource tenderer : tenderers) {
					dumpCriteriaAndEvidences(tenderer, fullModel);
				}
				logger.info("END OF DUMPING RESULT\n\n");
				
			}



			private Set<Resource> findTenderers(Model result) {
				Set<Resource> retVal = new HashSet<Resource>();
				StmtIterator it = result.listStatements(null, P_CRIT_COLL, (RDFNode)null);
				
				while (it.hasNext()) {
					Statement stmt = it.nextStatement();
					retVal.add(stmt.getSubject());
				}

				return retVal;
			}



			private void dumpCriteriaAndEvidences(Resource tenderer, Model fullModel) {
				logger.info("  "+toString(tenderer, fullModel));
				
				StmtIterator iCSs = tenderer.listProperties(P_CRIT_COLL);
				while (iCSs.hasNext()) {
					Statement stmt = iCSs.nextStatement();
					Resource rCS = stmt.getResource();
					dumpCriterionAndEvidences(rCS, fullModel);
				}
				iCSs.close();
			}



			private String toString(Resource r, Model fullModel) {
				return OntUtil.toString(r.inModel(fullModel));
			}



			private void dumpCriterionAndEvidences(Resource cs, Model fullModel) {
				Statement stmtCACrit = cs.getProperty(P_CA_CRIT);
				Resource rCACrit = stmtCACrit == null ? null : stmtCACrit.getResource();
				if (rCACrit != null)
					logger.info("    "+toString(rCACrit, fullModel));
				else
					logger.info("    unknown criterion");
				
				dumpEvidences(cs, fullModel);
			}



			private void dumpEvidences(Resource cs, Model fullModel) {
				StmtIterator iEvColl = cs.listProperties(P_EV_COLL);
				while (iEvColl.hasNext()) {
					Resource rEvColl = iEvColl.nextStatement().getResource();
					
					StmtIterator iPEv = rEvColl.listProperties(P_SUGG_PRIMARY);
					while (iPEv.hasNext()) {
						Resource rPEv = iPEv.nextStatement().getResource();
						logger.info("      ! "+toString(rPEv, fullModel));
					}
					iPEv.close();
					
					StmtIterator iSEv = rEvColl.listProperties(P_SUGG_SECONDARY);
					while (iSEv.hasNext()) {
						Resource rSEv = iSEv.nextStatement().getResource();
						logger.info("      ? "+toString(rSEv, fullModel));
					}
					iSEv.close();
					
				}
				iEvColl.close();
				
			}
    };
  }
  
  private static String S_PFX = "http://m2n.at/2009/05/peppol/";
  private static Property P_CRIT_COLL = new PropertyImpl(S_PFX+"criterionCollector");
  private static Property P_CA_CRIT = new PropertyImpl(S_PFX+"canCriterion");
  private static Property P_EV_COLL = new PropertyImpl(S_PFX+"evidenceCollector");
  private static Property P_SUGG_PRIMARY = new PropertyImpl(S_PFX+"suggestedPrimaryEvidence");
  private static Property P_SUGG_SECONDARY = new PropertyImpl(S_PFX+"suggestedSecondaryEvidence");
  

}
