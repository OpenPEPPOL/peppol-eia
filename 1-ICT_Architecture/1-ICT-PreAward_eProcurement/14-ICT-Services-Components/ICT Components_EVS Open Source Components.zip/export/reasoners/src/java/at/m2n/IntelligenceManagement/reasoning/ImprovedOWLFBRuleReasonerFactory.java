/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.reasoning;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.ReasonerFactory;
import com.hp.hpl.jena.reasoner.rulesys.Util;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDFS;
import com.hp.hpl.jena.vocabulary.ReasonerVocabulary;

public class ImprovedOWLFBRuleReasonerFactory implements ReasonerFactory {
  
  /** Single global instance of this factory */
  private static ReasonerFactory theInstance = new ImprovedOWLFBRuleReasonerFactory();
  
  /** Static URI for this reasoner type */
  public static final String URI = "http://jena.hpl.hp.com/2003/OWLFBRuleReasoner";
  
  /** Cache of the capabilities description */
  protected Model capabilities;
  
  /**
   * Return the single global instance of this factory
   */
  public static ReasonerFactory theInstance() {
      return theInstance;
  }
  
  /**
   * Constructor method that builds an instance of the associated Reasoner
   * @param configuration a set of arbitrary configuration information to be 
   * passed the reasoner encoded within an RDF graph
   */
  public Reasoner create(Resource configuration) {
      ImprovedOWLFBRuleReasoner reasoner = new ImprovedOWLFBRuleReasoner(this);
      if (configuration != null) {
          Boolean doLog = Util.checkBinaryPredicate(ReasonerVocabulary.PROPderivationLogging, configuration);
          if (doLog != null) {
              reasoner.setDerivationLogging(doLog.booleanValue());
          }
          Boolean doTrace = Util.checkBinaryPredicate(ReasonerVocabulary.PROPtraceOn, configuration);
          if (doTrace != null) {
              reasoner.setTraceOn(doTrace.booleanValue());
          }
      }
      return reasoner;
  }
 
  /**
   * Return a description of the capabilities of this reasoner encoded in
   * RDF. This method is normally called by the ReasonerRegistry which caches
   * the resulting information so dynamically creating here is not really an overhead.
   */
  public Model getCapabilities() {
      if (capabilities == null) {
          capabilities = ModelFactory.createDefaultModel();
          Resource base = capabilities.createResource(getURI());
          base.addProperty(ReasonerVocabulary.nameP, "OWL BRule Reasoner")
              .addProperty(ReasonerVocabulary.descriptionP, "Experimental OWL reasoner.\n"
                                          + "Can separate tbox and abox data if desired to reuse tbox caching or mix them.")
              .addProperty(ReasonerVocabulary.supportsP, RDFS.subClassOf)
              .addProperty(ReasonerVocabulary.supportsP, RDFS.subPropertyOf)
              .addProperty(ReasonerVocabulary.supportsP, RDFS.member)
              .addProperty(ReasonerVocabulary.supportsP, RDFS.range)
              .addProperty(ReasonerVocabulary.supportsP, RDFS.domain)
              // TODO - add OWL elements supported
              .addProperty(ReasonerVocabulary.supportsP, ReasonerVocabulary.individualAsThingP )
              .addProperty(ReasonerVocabulary.supportsP, OWL.ObjectProperty )
              .addProperty(ReasonerVocabulary.supportsP, OWL.DatatypeProperty)
              .addProperty(ReasonerVocabulary.supportsP, OWL.FunctionalProperty )
              .addProperty(ReasonerVocabulary.supportsP, OWL.SymmetricProperty )
              .addProperty(ReasonerVocabulary.supportsP, OWL.TransitiveProperty )
              .addProperty(ReasonerVocabulary.supportsP, OWL.InverseFunctionalProperty )

              .addProperty(ReasonerVocabulary.supportsP, OWL.hasValue )
              .addProperty(ReasonerVocabulary.supportsP, OWL.intersectionOf )
              .addProperty(ReasonerVocabulary.supportsP, OWL.unionOf )        // Only partial
              .addProperty(ReasonerVocabulary.supportsP, OWL.minCardinality )        // Only partial
              .addProperty(ReasonerVocabulary.supportsP, OWL.maxCardinality )        // Only partial
              .addProperty(ReasonerVocabulary.supportsP, OWL.cardinality )           // Only partial
              .addProperty(ReasonerVocabulary.supportsP, OWL.someValuesFrom)         // Only partial
              .addProperty(ReasonerVocabulary.supportsP, OWL.allValuesFrom )         // Only partial
              .addProperty(ReasonerVocabulary.supportsP, OWL.sameAs )
              .addProperty(ReasonerVocabulary.supportsP, OWL.differentFrom )
              .addProperty(ReasonerVocabulary.supportsP, OWL.disjointWith )
              
              .addProperty(ReasonerVocabulary.versionP, "0.1");
      }
      return capabilities;
  }
  
  /**
   * Return the URI labelling this type of reasoner
   */
  public String getURI() {
      return URI;
  }

}
