/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation;

import java.util.Set;

/**
 * An ValidationResultHandler manages a set of {@link IValidationSource}s.
 * 
 * @author sm
 */
public interface IValidationResultHandler {

    /**
     * Add the given validation source and register this handler and result handler if the source is not already added.
     * 
     * @param source
     */
    public void addValidationSource(IValidationSource source);

    /**
     * Remove the given source and remove this handler from the source if the given source is not already removed.
     * 
     * @param source
     *            the source to remove (from)
     */
    public void removeValidationSource(IValidationSource source);

    /**
     * Remove this result handler from all sources it is registered and remove all sources registered to this result handler.
     */
    public void removeAllValidationSources();

    /**
     * @return A copy of the set of associated sources. If no source is associated, the method returns an empty set.
     */
    public Set<IValidationSource> getValidationSources();

    /**
     * @return true, if the conjunction of all {@link ValidationState}s (of associated {@link IValidationSource}s) is valid. This method should retrieve the
     *         {@link ValidationResult} of all associated validation sources and combine them using {@link ValidationResult#and(ValidationResult)}.
     */
    public boolean isValid();

    /**
     * Method which should be called when a validation source has changed such that the result handler needs to update its current state.
     * 
     * @param source
     */
    public void validationSourceChanged(IValidationSource source);

    /**
     * Update the current state of the handler based on the validation input of all attached validation sources if the target object is subject of validation for this result
     * handler.
     * 
     * @param targetObject
     *            The object whose validation result had changed. If null is passed, then the result handler must revalidate (i.e. null is a wildcard).
     * @param result The validation result
     */
    public void updateResult(Object targetObject, ValidationResult result);

}
