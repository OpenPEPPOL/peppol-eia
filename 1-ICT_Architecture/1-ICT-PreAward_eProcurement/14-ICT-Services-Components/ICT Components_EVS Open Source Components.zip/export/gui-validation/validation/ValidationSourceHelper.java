/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation;

import java.util.Set;

import com.google.common.collect.Sets;

/**
 * Helper class which can be used as delegate for objects combining multiple {@link IValidationSource}s
 * to a single source.
 */
public class ValidationSourceHelper {
    
    private final Set<IValidationResultHandler> validationResultHandlers;
    private final IValidationResultHandler aggregated;
    private final IValidationSource representedSource;
    private final boolean required;
    
    
    public static <T extends IValidationResultHandler & IValidationSource> ValidationSourceHelper newInstance(T aggregated, boolean required) {
        return new ValidationSourceHelper(aggregated, aggregated, required);
    }
    
    
    public ValidationSourceHelper(IValidationSource representedSource, IValidationResultHandler aggregated, boolean required) {
        this.validationResultHandlers = Sets.newHashSet();
        this.required = required;
        this.aggregated = aggregated;
        this.representedSource = representedSource;
    }
    

    public void addResultHandler(IValidationResultHandler h) {
        if(h == null)
            throw new NullPointerException("Cannot add null as result handler.");
        
        if(!validationResultHandlers.contains(h)) {
            validationResultHandlers.add(h);
            h.addValidationSource(representedSource);
        }
    }

    public void removeResultHandler(IValidationResultHandler h) {
        if (validationResultHandlers.contains(h)) {
            this.validationResultHandlers.remove(h);
            h.removeValidationSource(representedSource);
        }
    }

    public Set<IValidationResultHandler> getResultHandlers() {
        return Sets.newHashSet(validationResultHandlers);
    }

    public boolean isRequired() {
        return required;
    }
    
    public boolean isInputAvailable() {
    	return getValidationResult().getState().isValid();
    }


    public ValidationResult getValidationResult() {
        ValidationResult result = new ValidationResult();
        for (IValidationSource s : aggregated.getValidationSources()) {
            result = result.and(s.getValidationResult());
        }
        return result;
    }


}
