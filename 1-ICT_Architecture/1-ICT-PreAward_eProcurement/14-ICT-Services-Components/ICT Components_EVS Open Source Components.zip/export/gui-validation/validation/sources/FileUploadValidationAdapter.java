/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.sources;

import at.m2n.peppol.client.validation.IValidator;
import at.m2n.peppol.client.validation.ValidationResult;
import at.m2n.peppol.client.widgets.ValidationIndicator;
import com.google.gwt.event.shared.HandlerManager;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.inject.Inject;
import com.google.inject.assistedinject.Assisted;

public class FileUploadValidationAdapter extends ValidationSourceAdapter<String> {

    private final FileUpload upload;

    @Inject
    public FileUploadValidationAdapter(HandlerManager eventBus, @Assisted FileUpload upload, @Assisted ValidationIndicator indicator, @Assisted IValidator<String> validator) {
        super(eventBus, validator, indicator.isRequired());

        this.upload = upload;

        upload.addChangeHandler(this);
        indicator.addValidationSource(this);
    }

    @Override
    protected ValidationResult doValidate() {
        return validator.isValidInput(upload.getFilename(), required);
    }
    
    @Override
    public boolean isInputAvailable() {
        return upload.getFilename() != null && !upload.getFilename().isEmpty();
    }

}
