/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.sources;

import java.util.Set;

import peppol.cac.EconomicOperator;
import at.m2n.peppol.client.validation.IValidationResultHandler;
import at.m2n.peppol.client.validation.IValidationSource;
import at.m2n.peppol.client.validation.IValidator;
import at.m2n.peppol.client.validation.SimpleSourceHelper;
import at.m2n.peppol.client.validation.ValidationResult;

public class EconomicOperatorValidationSource implements IValidationSource {

    private final SimpleSourceHelper<EconomicOperator> sourceHelper;
    private final EconomicOperator operator;

    
    public EconomicOperatorValidationSource(EconomicOperator operator, IValidator<EconomicOperator> validator) {
        this.operator = operator;
        this.sourceHelper = SimpleSourceHelper.newInstance(validator, true, this);
    }

    @Override
    public void addResultHandler(IValidationResultHandler h) {
        sourceHelper.addResultHandler(h);        
    }

    @Override
    public void removeResultHandler(IValidationResultHandler h) {
        sourceHelper.removeResultHandler(h);        
    }

    @Override
    public Set<IValidationResultHandler> getResultHandlers() {
        return sourceHelper.getResultHandlers();
    }

    @Override
    public boolean isRequired() {
        return sourceHelper.isRequired();
    }
    
    @Override
    public boolean isInputAvailable() {
        return sourceHelper.isInputAvailable();
    }
    
    @Override
    public ValidationResult getValidationResult() {
        return sourceHelper.getResult(operator);
    }
   
   
}
