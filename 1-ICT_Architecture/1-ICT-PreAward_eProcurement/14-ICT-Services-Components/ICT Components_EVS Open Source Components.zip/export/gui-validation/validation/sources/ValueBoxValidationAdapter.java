/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.sources;

import at.m2n.peppol.client.validation.IValidator;
import at.m2n.peppol.client.validation.ValidationResult;
import at.m2n.peppol.client.widgets.ValidationIndicator;
import com.google.gwt.event.shared.HandlerManager;
import com.google.gwt.user.client.ui.ValueBoxBase;
import com.google.inject.Inject;
import com.google.inject.assistedinject.Assisted;

class ValueBoxValidationAdapter extends ValidationSourceAdapter<String> {

    private final ValueBoxBase<String> valueBox;

    @Inject
    public ValueBoxValidationAdapter(HandlerManager eventBus, @Assisted ValueBoxBase<String> valueBox, @Assisted ValidationIndicator indicator, @Assisted IValidator<String> validator) {
        super(eventBus, validator, indicator.isRequired());

        this.valueBox = valueBox;

        valueBox.addBlurHandler(this);
        valueBox.addChangeHandler(this);
        valueBox.addValueChangeHandler(this);
        valueBox.addAttachHandler(this);
        indicator.addValidationSource(this);
    }

    @Override
    public ValidationResult doValidate() {
        return validator.isValidInput(valueBox.getText(), required);
    }
    
    @Override
    public boolean isInputAvailable() {
        final String t = valueBox.getValue();
        return t != null && !t.isEmpty();
    }

}
