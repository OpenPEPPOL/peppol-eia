/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.sources;

import at.m2n.peppol.client.validation.IValidator;
import at.m2n.peppol.client.validation.ValidationResult;
import at.m2n.peppol.client.widgets.ValidationIndicator;

import com.google.gwt.event.shared.HandlerManager;
import com.google.gwt.user.client.ui.ListBox;
import com.google.inject.Provider;

class ListBoxValidationAdapter<T> extends ValidationSourceAdapter<T> {

    private final ListBox listBox;
    private final Provider<T> inputProvider;

    
    ListBoxValidationAdapter(HandlerManager eventBus, ListBox listBox, ValidationIndicator indicator, IValidator<T> validator, Provider<T> inputProvider) {
        super(eventBus, validator, indicator.isRequired());

        this.listBox = listBox;
        this.inputProvider = inputProvider;

        listBox.addBlurHandler(this);
        listBox.addChangeHandler(this);
        listBox.addAttachHandler(this);
        indicator.addValidationSource(this);
    }

    @Override
    public ValidationResult doValidate() {
        final int selectedIndex = listBox.getSelectedIndex();        
        if(selectedIndex <= 0 || selectedIndex> listBox.getItemCount()) {
            return validator.isValidInput(null, required);
        }
        else {
            final T selectedValue = inputProvider.get();
            return validator.isValidInput(selectedValue, required);    
        }        
    }
    
    @Override
    public boolean isInputAvailable() {
        return !listBox.isItemSelected(0);
    }

}
