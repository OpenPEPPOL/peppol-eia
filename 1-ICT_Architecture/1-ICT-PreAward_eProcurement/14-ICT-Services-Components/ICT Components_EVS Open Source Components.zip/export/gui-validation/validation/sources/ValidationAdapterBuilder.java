/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.sources;


import static at.m2n.peppol.shared.Constants.BLOB_ORIGINAL_NAME_MAX_LENGTH;
import static at.m2n.peppol.shared.Constants.MIN_TEXTINPUT_LENGTH;
import static at.m2n.peppol.shared.Constants.MAX_TEXTINPUT_LENGTH;
import at.m2n.peppol.client.validation.IValidator;
import at.m2n.peppol.client.validation.ValidationResult;
import at.m2n.peppol.client.validation.validators.AbstractValidator;
import at.m2n.peppol.client.validation.validators.TextValidator;
import at.m2n.peppol.client.widgets.EnumListBox;
import at.m2n.peppol.client.widgets.ValidationIndicator;
import at.m2n.peppol.shared.CaptionedTranslatable;

import com.google.gwt.event.shared.HandlerManager;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.ValueBoxBase;
import com.google.inject.Inject;

public class ValidationAdapterBuilder {

    private final HandlerManager eventBus;

    @Inject
    public ValidationAdapterBuilder(HandlerManager eventBus) {
        this.eventBus = eventBus;
    }

    /**
     * Create a new ValidationSourceAdapter for the given {@link EnumListBox} and register an default validation adapter. The default adapter will check if an entry different from
     * the first has been selected. In other words, the validator will return a valid state if the indicator is marked optional or {@link EnumListBox#isValueSelected()} returns
     * true.
     * 
     * @param <E>
     * @param listBox
     * @param indicator
     * @return
     */
    public <E extends Enum<E> & CaptionedTranslatable> ValidationSourceAdapter<E> build(EnumListBox<E> listBox, ValidationIndicator indicator) {
        IValidator<E> validator = newValidator(listBox);
        return new ListBoxValidationAdapter<E>(eventBus, listBox, indicator, validator, listBox);
    }

    /**
     * Wraps the given ValueBox into an {@link at.m2n.peppol.client.validation.IValidationSource} using the given validator. Events fired by the
     * {@link com.google.gwt.user.client.ui.ValueBoxBase} will be adapted to validation events. <br>
     * 
     * @param valueBox
     * @param indicator
     * @param validator
     * @return
     */
    public ValidationSourceAdapter<String> build(ValueBoxBase<String> valueBox, ValidationIndicator indicator, IValidator<String> validator) {
        return new ValueBoxValidationAdapter(eventBus, valueBox, indicator, validator);
    }

    /**
     * Wraps the given ValueBox into an {@link at.m2n.peppol.client.validation.IValidationSource} using a {@link at.m2n.peppol.client.validation.validators.TextValidator} having
     * {@link at.m2n.peppol.shared.Constants#MIN_TEXTINPUT_LENGTH} as minimum length and {@link at.m2n.peppol.shared.Constants#MAX_TEXTINPUT_LENGTH} as maximum length. Events fired
     * by the {@link com.google.gwt.user.client.ui.ValueBoxBase} will be adapted to validation events.
     * 
     * @param valueBox
     * @param indicator
     * @param validator
     * @return
     */
    public ValidationSourceAdapter<String> build(ValueBoxBase<String> valueBox, ValidationIndicator indicator) {
        return new ValueBoxValidationAdapter(eventBus, valueBox, indicator, new TextValidator(indicator));
    }


    public ValidationSourceAdapter<String> build(FileUpload upload, ValidationIndicator indicator) {
        IValidator<String> v = new TextValidator(MIN_TEXTINPUT_LENGTH, BLOB_ORIGINAL_NAME_MAX_LENGTH, indicator);
        return new FileUploadValidationAdapter(eventBus, upload, indicator, v);
    }



    //
    // private parts
    //

    /**
     * Create a new IValidator for the given {@link EnumListBox}. The validator returns true, if listBoxs' isValueSelected method returns true.
     * 
     */
    private <E extends Enum<E> & CaptionedTranslatable> IValidator<E> newValidator(final EnumListBox<E> listBox) {
        return new AbstractValidator<E>() {
            @Override
            protected boolean isUserInputAvailable(E input) {
                return input != null && listBox.isValueSelected();
            }

            @Override
            protected boolean getValidationResult(E input) {
                return isUserInputAvailable(input);
            }
        };
    }

}
