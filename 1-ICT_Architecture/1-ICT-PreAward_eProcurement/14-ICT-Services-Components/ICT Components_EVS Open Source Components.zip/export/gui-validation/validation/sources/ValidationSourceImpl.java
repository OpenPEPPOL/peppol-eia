/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.sources;

import java.util.Set;

import at.m2n.peppol.client.validation.IValidationResultHandler;
import at.m2n.peppol.client.validation.IValidationSource;
import at.m2n.peppol.client.validation.IValidator;
import at.m2n.peppol.client.validation.SimpleSourceHelper;
import at.m2n.peppol.client.validation.ValidationResult;

import com.google.inject.Provider;

public final class ValidationSourceImpl<T> implements IValidationSource {

    private final SimpleSourceHelper<T> sourceHelper;
    private final Provider<T> inputProvider;
    
    public static <T> IValidationSource newSource(IValidator<T> validator, final T input) {        
        return new ValidationSourceImpl<T>(validator, new Provider<T>() {
            @Override
            public T get() {
                return input;
            }
        });
    }
    
    public static <T> IValidationSource newSource(IValidator<T> validator, Provider<T> inputProvider) {
        return new ValidationSourceImpl<T>(validator, inputProvider);
    }

    private ValidationSourceImpl(IValidator<T> validator, Provider<T> inputProvider) {
        this.inputProvider = inputProvider;
        this.sourceHelper = SimpleSourceHelper.newInstance(validator, true, this);
    }

    @Override
    public void addResultHandler(IValidationResultHandler h) {
        this.sourceHelper.addResultHandler(h);

    }

    @Override
    public void removeResultHandler(IValidationResultHandler h) {
        this.sourceHelper.removeResultHandler(h);
    }

    @Override
    public Set<IValidationResultHandler> getResultHandlers() {
        return this.sourceHelper.getResultHandlers();
    }

    @Override
    public boolean isRequired() {
        return this.sourceHelper.isRequired();
    }
    
    @Override
    public boolean isInputAvailable() {
        return this.inputProvider.get() != null;
    }

    @Override
    public ValidationResult getValidationResult() {
        return this.sourceHelper.getResult(this.inputProvider.get());
    }
}
