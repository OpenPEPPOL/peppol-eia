/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.sources;

import at.m2n.peppol.client.events.ValidationSourceChangedEvent;
import at.m2n.peppol.client.validation.IValidationResultHandler;
import at.m2n.peppol.client.validation.IValidationSource;
import at.m2n.peppol.client.validation.IValidator;
import at.m2n.peppol.client.validation.ValidationResult;
import com.google.common.collect.Sets;
import com.google.gwt.event.dom.client.BlurEvent;
import com.google.gwt.event.dom.client.BlurHandler;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.logical.shared.AttachEvent;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.HandlerManager;

import java.util.Set;

public abstract class ValidationSourceAdapter<T> implements IValidationSource, BlurHandler, ChangeHandler, ValueChangeHandler<T>, AttachEvent.Handler {

    protected final IValidator<T> validator;
    protected final boolean required;
    private final HandlerManager eventBus;
    private final Set<IValidationResultHandler> resultHandlers;

    public ValidationSourceAdapter(HandlerManager eventBus, IValidator<T> validator, boolean required) {
        this.resultHandlers = Sets.newHashSet();
        this.validator = validator;
        this.required = required;
        this.eventBus = eventBus;
    }

    @Override
    public Set<IValidationResultHandler> getResultHandlers() {
        return Sets.newHashSet(resultHandlers);
    }

    @Override
    public void addResultHandler(IValidationResultHandler h) {
        if (!resultHandlers.contains(h)) {
            this.resultHandlers.add(h);
            h.addValidationSource(this);
        }
    }

    @Override
    public void removeResultHandler(IValidationResultHandler h) {
        if (!resultHandlers.contains(h)) {
            this.resultHandlers.remove(h);
            h.removeValidationSource(this);
        }

    }

    @Override
    public boolean isRequired() {
        return required;
    }

    protected abstract ValidationResult doValidate();

    @Override
    public final ValidationResult getValidationResult() {
        return doValidate();
    }

    private void fireValidationSourceChanged() {
        eventBus.fireEvent(new ValidationSourceChangedEvent(this));
    }

    @Override
    public void onChange(ChangeEvent arg0) {
        fireValidationSourceChanged();
    }

    @Override
    public void onBlur(BlurEvent arg0) {
        fireValidationSourceChanged();
    }

    @Override
    public void onValueChange(ValueChangeEvent<T> arg0) {
        fireValidationSourceChanged();
    }

    @Override
    public void onAttachOrDetach(AttachEvent e) {
        if (e.isAttached()) {
            fireValidationSourceChanged();
        }
    }
}
