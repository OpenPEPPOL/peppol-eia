/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation;

import java.util.Set;

import com.google.common.collect.Sets;

public final class SimpleSourceHelper<T> {
    
    private final Set<IValidationResultHandler> validationResultHandlers;
    private final IValidationSource wrappedSource;
    private final IValidator<T> validator;
    private final boolean required;
    
    public static <T> SimpleSourceHelper<T> newInstance(IValidator<T> validator, boolean required, IValidationSource wrappedSource) {
        return new SimpleSourceHelper<T>(validator, required, wrappedSource);
    }
    
    public SimpleSourceHelper(IValidator<T> validator, boolean required, IValidationSource wrappedSource) {
        if(validator == null) {
            throw new NullPointerException("You must provide a validator.");
        }
        if(wrappedSource == null) {
            throw new NullPointerException("You must supply an IValdidation source to wrap. Parameter wrappedSource was null.");
        }
        
        this.validationResultHandlers = Sets.newHashSet();
        this.wrappedSource = wrappedSource;
        this.validator = validator;
        this.required = required;
    }

    public void addResultHandler(IValidationResultHandler h) {
        if (!validationResultHandlers.contains(h)) {
            validationResultHandlers.add(h);
            h.addValidationSource(wrappedSource);
        }
    }

    public void removeResultHandler(IValidationResultHandler h) {
        if (validationResultHandlers.contains(h)) {
            this.validationResultHandlers.remove(h);
            h.removeValidationSource(wrappedSource);
        }
    }

    public Set<IValidationResultHandler> getResultHandlers() {
        return Sets.newHashSet(validationResultHandlers);
    }

    public boolean isRequired() {
        return required;
    }
    
    public boolean isInputAvailable() {
    	return wrappedSource.isInputAvailable();
    }
    
    public ValidationResult getResult(T input) {
        return validator.isValidInput(input, required);
    }

}
