/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation;

import java.util.Map;

import com.google.common.collect.Maps;

/**
 * Enumeration to manage validation state. A state reflects three boolean values required, available input, and the {@link IValidator} result.
 * 
 * @author sm
 */
public enum ValidationState {

    /** State when a field has valid user input. It validates to true */
    VALID("img/icon_check.png", true),

    /** A field has no input and is not required. It validates to true. */
    NO_INPUT("img/blank.png", true),

    /** An field has invalid input. It validates to false */
    ERROR("img/icon_required_red.png", false),

    /** A field which is required has no valid input. It validates to false. */
    REQUIRED("img/icon_required_red.png", false);

    private final String imageSrc;
    private final boolean valid;

    private ValidationState(String imageSrc, boolean valid) {
        this.imageSrc = imageSrc;
        this.valid = valid;
    }


    /**
     * Combines this validation state and the given state using the following truth table:
     * 
     * <p>
     * <table border="1">
     * <tr>
     * <td>this</td>
     * <td>s</td>
     * <td>this.and(s) == s.and(this)</td>
     * </tr>
     * <tr>
     * <td>NO_INPUT</td>
     * <td>NO_INPUT</td>
     * <td>NO_INPUT</td>
     * </tr>
     * <tr>
     * <td>NO_INPUT</td>
     * <td>VALID</td>
     * <td>VALID</td>
     * </tr>
     * <tr>
     * <td>NO_INPUT</td>
     * <td>REQUIRED</td>
     * <td>REQUIRED</td>
     * </tr>
     * <tr>
     * <td>NO_INPUT</td>
     * <td>ERROR</td>
     * <td>ERROR</td>
     * </tr>
     * <tr>
     * <td>VALID</td>
     * <td>VALID</td>
     * <td>VALID</td>
     * </tr>
     * <tr>
     * <td>VALID</td>
     * <td>REQUIRED</td>
     * <td>REQUIRED</td>
     * </tr>
     * <tr>
     * <td>VALID</td>
     * <td>ERROR</td>
     * <td>ERROR</td>
     * </tr>
     * <tr>
     * <td>REQUIRED</td>
     * <td>REQUIRED</td>
     * <td>REQUIRED</td>
     * </tr>
     *  <tr>
     * <td>REQUIRED</td>
     * <td>ERROR</td>
     * <td>ERROR</td>
     * </tr>
     * <tr>
     * <td>ERROR</td>
     * <td>ERROR</td>
     * <td>ERROR</td>
     * </tr>
     * 
     * <table>
     * </p>
     * 
     * @param s
     * @return
     */
    public ValidationState and(ValidationState s) {
        return and(this, s);
    }

    public boolean isValid() {
        return valid;
    }

    public String getImageSrc() {
        return imageSrc;
    }


    /**
     * The result matches the following truth table:
     * 
     * <p>
     * <table border="1">
     * <tr>
     * <td>validatorResult</td>
     * <td>required</td>
     * <td>userInputAvailable</td>
     * <td></td>
     * </tr>
     * <tr>
     * <td>false</td>
     * <td>false</td>
     * <td>false</td>
     * <td>NO_INPUT</td>
     * </tr>
     * <tr>
     * <td>false</td>
     * <td>false</td>
     * <td>true</td>
     * <td>ERROR</td>
     * </tr>
     * <tr>
     * <td>false</td>
     * <td>true</td>
     * <td>false</td>
     * <td>REQUIRED</td>
     * </tr>
     * <tr>
     * <td>false</td>
     * <td>true</td>
     * <td>true</td>
     * <td>ERROR</td>
     * </tr>
     * <tr>
     * <td>true</td>
     * <td>false</td>
     * <td>false</td>
     * <td>VALID_NO_INPUT</td>
     * </tr>
     * <tr>
     * <td>true</td>
     * <td>false</td>
     * <td>true</td>
     * <td>VALID</td>
     * </tr>
     * <tr>
     * <td>true</td>
     * <td>true</td>
     * <td>false</td>
     * <td>REQUIRED</td>
     * </tr>
     * <tr>
     * <td>true</td>
     * <td>true</td>
     * <td>true</td>
     * <td>VALID</td>
     * </tr>
     * <table>
     * </p>
     * 
     * @param validatorResult
     * @param required
     * @param userInputAvailable
     * @return a validation state
     */
    public static ValidationState fromFlags(boolean validatorResult, boolean required, boolean userInputAvailable) {
        ValidationState state = null;

        if (validatorResult) {
            if (required) {
                if (userInputAvailable) {
                    state = ValidationState.VALID;
                }
                else {
                    state = ValidationState.REQUIRED;
                }
            }
            else {
                if (userInputAvailable) {
                    state = ValidationState.VALID;
                }
                else {
                    state = ValidationState.NO_INPUT;
                }
            }
        }
        else {
            if (required) {
                if (userInputAvailable) {
                    state = ValidationState.ERROR;
                }
                else {
                    state = ValidationState.REQUIRED;
                }
            }
            else {
                if (userInputAvailable) {
                    state = ValidationState.ERROR;
                }
                else {
                    state = ValidationState.NO_INPUT;
                }
            }
        }
        return state;
    }

    private static Map<ValidationState, Map<ValidationState, ValidationState>> AND = Maps.newHashMap();
    static {
        Map<ValidationState, ValidationState> m1 = Maps.newHashMap();
        m1.put(VALID, VALID);
        m1.put(NO_INPUT, VALID);
        m1.put(REQUIRED, REQUIRED);
        m1.put(ERROR, ERROR);

        Map<ValidationState, ValidationState> m2 = Maps.newHashMap();
        m2.put(VALID, VALID);
        m2.put(NO_INPUT, NO_INPUT);
        m2.put(REQUIRED, REQUIRED);
        m2.put(ERROR, ERROR);

        Map<ValidationState, ValidationState> m3 = Maps.newHashMap();
        m3.put(VALID, REQUIRED);
        m3.put(NO_INPUT, REQUIRED);
        m3.put(REQUIRED, REQUIRED);
        m3.put(ERROR, ERROR);

        Map<ValidationState, ValidationState> m4 = Maps.newHashMap();
        m4.put(VALID, ERROR);
        m4.put(NO_INPUT, ERROR);
        m4.put(REQUIRED, ERROR);
        m4.put(ERROR, ERROR);

        AND.put(VALID, m1);
        AND.put(NO_INPUT, m2);
        AND.put(REQUIRED, m3);
        AND.put(ERROR, m4);
    }

    private static ValidationState and(ValidationState s1, ValidationState s2) {
        return AND.get(s1).get(s2);
    }
}