/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation;

import java.util.Collection;
import java.util.Set;

import at.m2n.peppol.client.widgets.ValidationIndicator;

import com.google.common.collect.Sets;




/**
 * A ValidationResult combines a {@link ValidationState} and a set of validation messages (hints).
 * 
 * @author sm
 */
public final class ValidationResult {

	private final Set<String> hints;
	private final ValidationState state;


	public ValidationResult() {
		this("", ValidationState.NO_INPUT);
	}
	

	public ValidationResult(String hint, ValidationState state) {
		this(state, Sets.newHashSet(hint));
	}
	
	public ValidationResult(ValidationState state, Set<String> hints) {
		this.hints = Sets.newHashSet();
		addHintsSkipEmpty(hints, this.hints);		
		this.state = state;
	}


	public String getStateImageSrc() {
		return state.getImageSrc();
	}

	public ValidationState getState() {
		return state;
	}

	/**
	 * @return the first hint
	 */
	public String getHint() {
		return hints.isEmpty() ? "" : hints.iterator().next();
	}

	public Set<String> getHints() {
		return Sets.newHashSet(hints);
	}

	public boolean hasHints() {
		return hints.isEmpty();
	}

	public boolean isValid() {
		return state.isValid();
	}

	/**
	 * Combine this result and the given result into a new {@link ValidationResult}.
	 * 
	 * @param r
	 * @return a new {@link ValidationResult} object reflecting the conjunction of this result and r
	 */
	public ValidationResult and(ValidationResult r) {
		ValidationResult result = new ValidationResult(state.and(r.getState()), r.getHints());
		addHintsSkipEmpty(hints, result.hints);
		return result;
	}
	
	
	private static void addHintsSkipEmpty(Collection<String> source, Collection<String> target) {
		if (source != null && !source.isEmpty()) {
			for (String h : source) {
				addNonEmptyHint(target, h);
			}
		}
	}
	
	private static void addNonEmptyHint(Collection<String> hints, String s) {
		if(s != null && !s.isEmpty()) {
			hints.add(s);
		}
	}
	
	/**
	 * Create a new ValidationResult having the hint based on the state.
	 * 
	 * @param state
	 * @param validHint
	 * @param requiredHint
	 * @param errorHint
	 */
	public static ValidationResult newValidationResult(ValidationState state, String validHint, String requiredHint, String errorHint) {
		final String hint;
		switch(state) {
			case VALID: hint = validHint; break;
			case ERROR: hint = errorHint.isEmpty() ? requiredHint : errorHint; break;
			case REQUIRED: hint = requiredHint; break;
			default: hint = "";
		}
		return new ValidationResult(hint, state);
	}

	public static ValidationResult newValidResult(ValidationIndicator i) {
		return new ValidationResult(i.getValidHint(), ValidationState.VALID);
	}

	public static ValidationResult newRequiredResult(ValidationIndicator i) {
		return new ValidationResult(i.getRequiredHint(), ValidationState.REQUIRED);
	}

	public static ValidationResult newErrorResult(ValidationIndicator i) {
		return new ValidationResult(i.getErrorHint(), ValidationState.ERROR);
	}

}
