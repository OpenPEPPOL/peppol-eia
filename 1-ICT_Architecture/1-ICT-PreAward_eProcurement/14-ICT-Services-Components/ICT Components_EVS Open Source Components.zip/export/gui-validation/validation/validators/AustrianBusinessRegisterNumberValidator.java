/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.validators;


import at.m2n.peppol.client.widgets.ValidationIndicator;

/**
 * Checks if a given austrian business register number is valid. See attachment of <a href="http://bugs.m2n.at/show_bug.cgi?id=5412">http://bugs.m2n.at/show_bug.cgi?id=5412</a> for
 * an excel sheet containing the validation rule.
 * 
 * @author sm
 */
public class AustrianBusinessRegisterNumberValidator extends TextValidator {

	private static final int MIN_LENGTH = 6;
	private static final int MAX_LENGTH = 7;
    private static final int[] WEIGHTS = { 6, 4, 14, 15, 10, 1 };
    private static final char[] KEYS = { 'a', 'b', 'd', 'f', 'g', 'h', 'i', 'k', 'm', 'p', 's', 't', 'v', 'w', 'x', 'y', 'z' };

    public AustrianBusinessRegisterNumberValidator(ValidationIndicator indicator) {
        this(indicator.getErrorHint(), indicator.getValidHint(), indicator.getNoInputHint(), indicator.getRequiredHint());
    }

    public AustrianBusinessRegisterNumberValidator(String errorHint, String validHint, String noInputHint, String requiredHint) {
        super(MIN_LENGTH, MAX_LENGTH, errorHint, validHint, noInputHint, requiredHint);
    }

    @Override
    protected boolean getValidationResult(String input) {
        boolean validatorResult = false;        
        if (super.getValidationResult(input)) {
            try {
            	// note: in case the business number has a total size of 5 (e.g. 42105w), we
            	// append a leading zero. otherwise we would have to alter the WEIGHTS[i] access.
            	final String validateString = input.length() == MAX_LENGTH ? input : "0" + input;
                int overallSum = 0;                
                for (int i = 0; i < MAX_LENGTH - 1; i++) {
                    char c = validateString.charAt(i);
                    int v = Integer.parseInt("" + c);
                    int r = v * WEIGHTS[i];
                    overallSum += r;
                }
                int rest = overallSum % 17; 
                validatorResult = validateString.charAt(MAX_LENGTH - 1) == KEYS[rest];
            }
            catch (NumberFormatException e) {
                validatorResult = false;
            }
        }
        return validatorResult;
    }
}
