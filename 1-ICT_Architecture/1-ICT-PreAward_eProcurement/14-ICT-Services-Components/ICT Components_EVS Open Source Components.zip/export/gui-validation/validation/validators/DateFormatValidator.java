/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.validators;

import at.m2n.peppol.client.widgets.ValidationIndicator;

import com.google.common.base.Preconditions;
import com.google.gwt.i18n.client.DateTimeFormat;

import java.util.Date;

public class DateFormatValidator extends TextValidator {

    private final DateTimeFormat dateTimeFormat;
    private final Date startDate;
    private final Date endDate;

    public DateFormatValidator(DateTimeFormat dateFormat, Date startDate, Date endDate, ValidationIndicator h) {
        this(dateFormat, startDate, endDate, h.getErrorHint(), h.getValidHint(), h.getNoInputHint(), h.getRequiredHint());
    }

    public DateFormatValidator(DateTimeFormat dateTimeFormat, Date startDate, Date endDate, String errorHint, String validHint, String noInputHint, String requiredHint) {
        super(24, errorHint, validHint, noInputHint, requiredHint);
        Preconditions.checkArgument(startDate.before(endDate));        
        this.dateTimeFormat = dateTimeFormat;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    @Override
    protected boolean getValidationResult(String input) {
        boolean result = false;
        if (isUserInputAvailable(input)) {
            try {
                if (input.length() > 0) {
                    final Date date = dateTimeFormat.parseStrict(input);
                    result = ((date.after(startDate) || date.compareTo(startDate) == 0) && (date.before(endDate) || date.compareTo(endDate) == 0));
                }
            } catch (IllegalArgumentException exception) {
                result = false;
            }
        }
        return result;
    }
}
