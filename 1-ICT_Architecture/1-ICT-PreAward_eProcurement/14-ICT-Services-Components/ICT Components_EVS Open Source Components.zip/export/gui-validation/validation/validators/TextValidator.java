/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.validators;

import at.m2n.peppol.client.widgets.ValidationIndicator;
import at.m2n.peppol.shared.Constants;

public class TextValidator extends AbstractValidator<String> {

    private final int minLength;
    private final int maxLength;

    public TextValidator(ValidationIndicator indicator) {
        this(Constants.MIN_TEXTINPUT_LENGTH, Constants.MAX_TEXTINPUT_LENGTH, indicator.getErrorHint(),
            indicator.getValidHint(), indicator.getNoInputHint(), indicator.getRequiredHint());
    }

    public TextValidator(int length) {
        this(length, length, "", "", "", "");
    }

    public TextValidator(int minLength, int maxLength) {
        this(minLength, maxLength, "", "", "", "");
    }

    public TextValidator(int minLength, int maxLength, ValidationIndicator indicator) {
        this(minLength, maxLength, indicator.getErrorHint(), indicator.getValidHint(),
            indicator.getNoInputHint(), indicator.getRequiredHint());
    }

    public TextValidator(int length, String errorHint, String validHint, String noInputHint, String requiredHint) {
        this(length, length, errorHint, validHint, noInputHint, requiredHint);
    }

    public TextValidator(int minLength, int maxLength, String errorHint, String validHint, String noInputHint, String requiredHint) {
        super(errorHint, validHint, noInputHint, requiredHint);
        if (minLength > maxLength) {
            throw new IllegalArgumentException("minLength must be >= maxLength");
        }
        this.maxLength = maxLength;
        this.minLength = minLength;
    }

    protected boolean isUserInputAvailable(String input) {
        return input != null && !(input.trim()).isEmpty();
    }

    @Override
    protected boolean getValidationResult(String input) {
        boolean result = false;
        if (isUserInputAvailable(input)) {
            if (minLength != -1 && maxLength != -1) {
                result = input.length() >= minLength && input.length() <= maxLength;
            } else {
                result = true;
            }
        }
        return result;
    }

}
