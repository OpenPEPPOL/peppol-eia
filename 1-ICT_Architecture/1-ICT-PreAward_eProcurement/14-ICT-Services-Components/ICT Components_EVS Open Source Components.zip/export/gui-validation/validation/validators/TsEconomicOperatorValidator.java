/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.validators;

import peppol.cac.EconomicOperator;

public final class TsEconomicOperatorValidator extends AbstractValidator<EconomicOperator> {

    @Override
    protected boolean isUserInputAvailable(EconomicOperator input) {
        return input != null;
    }

    @Override
    protected boolean getValidationResult(EconomicOperator input) {
        // TODO currently the user is only allowed to save if the operator form iim moment speichern wir nur, wenn das formular valide ist. d
        // im formular ist der ontology domain code als required gesetzt
        boolean result = isUserInputAvailable(input) && input.isSetOntologyDomainCode();
        return result;
    }
}