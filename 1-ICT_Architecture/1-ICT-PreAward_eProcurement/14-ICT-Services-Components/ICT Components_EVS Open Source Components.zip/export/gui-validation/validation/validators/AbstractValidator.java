/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.validators;

import java.util.Map;

import at.m2n.peppol.client.validation.IValidator;
import at.m2n.peppol.client.validation.ValidationResult;
import at.m2n.peppol.client.validation.ValidationState;

import com.google.common.collect.Maps;

public abstract class AbstractValidator<T> implements IValidator<T> {
    
    private final Map<ValidationState, String> hints;
    
    public AbstractValidator() {
        this("", "", "", "");
    }

    public AbstractValidator(String errorHint, String validHint, String noInputHint, String requiredHint) {
        this.hints = Maps.newHashMap();
        setErrorHint(errorHint);
        setValidHint(validHint);
        setRequiredHint(requiredHint);
        setNoInputHint(noInputHint);        
    }    
    
    public final void setNoInputHint(String noInputHint) {
        this.hints.put(ValidationState.NO_INPUT, noInputHint);
    }
    
    public final void setRequiredHint(String requiredHint) {
        this.hints.put(ValidationState.REQUIRED, requiredHint);
    }
    
    public final void setValidHint(String validHint) {
        this.hints.put(ValidationState.VALID, validHint);
    }
    
    public final void setErrorHint(String errorHint) {
        this.hints.put(ValidationState.ERROR, errorHint);
    }
    
    @Override
    public final ValidationResult isValidInput(T input, boolean required) {
        final boolean userInputAvailable = isUserInputAvailable(input);        
        final boolean validatorResult = getValidationResult(input);        
        final ValidationState s = ValidationState.fromFlags(validatorResult, required, userInputAvailable);
        final String hint = hints.get(s);
        ValidationResult r = new ValidationResult(hint, s);        
        return r;
    }
    
    protected abstract boolean isUserInputAvailable(T input);
    
    protected abstract boolean getValidationResult(T input);
}
