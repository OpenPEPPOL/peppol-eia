/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.validators;

import java.util.List;
import java.util.Map;

import peppol.cac.DocumentReferenceType;
import peppol.cac.Evidence;
import at.m2n.peppol.shared.VcdCompound;
import at.m2n.peppol.shared.xmlwrapper.CriterionWrapper;
import at.m2n.peppol.shared.xmlwrapper.EvidenceWrapper;

/**
 * Checks if all selected evidences have a document reference.
 */
public class DocumentReferencesValidator extends AbstractValidator<VcdCompound> {

    private final String uuid;

    public DocumentReferencesValidator(String uuid) {
        this.uuid = uuid;
    }

    @Override
    protected boolean isUserInputAvailable(VcdCompound input) {
        return input != null;
    }

    @Override
    protected boolean getValidationResult(VcdCompound input) {
        boolean result = true;
        Map<CriterionWrapper, EvidenceWrapper> selectedCriterions = input.getSuggestedEvidences().getSelectedCriterionToEvidence(uuid);
        result = checkDocumentReferences(selectedCriterions);
        return result;
    }

    private boolean checkDocumentReferences(Map<CriterionWrapper, EvidenceWrapper> selectedCriterions) {
        boolean result = true;
        for (Map.Entry<CriterionWrapper, EvidenceWrapper> e : selectedCriterions.entrySet()) {
            Evidence evidence = e.getValue().get();
            List<DocumentReferenceType> documentReferences = evidence.getDocumentReferences();
            result &= !documentReferences.isEmpty();
            if (!result) {
                break;
            }
        }
        return result;
    }

}
