/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation.validators;


import at.m2n.peppol.client.i18n.PeppolConstants;
import at.m2n.peppol.shared.CriterionMap;
import at.m2n.peppol.shared.EvidenceMap;
import at.m2n.peppol.shared.GroupedCriteria;
import at.m2n.peppol.shared.VcdCompound;
import at.m2n.peppol.shared.xmlwrapper.CriterionWrapper;
import at.m2n.peppol.shared.xmlwrapper.EvidenceWrapper;
import com.google.inject.Inject;
import com.google.inject.assistedinject.Assisted;

import java.util.Map;

public class EvidenceSelectionValidator extends AbstractValidator<VcdCompound> {

    private final String uuid;

    @Inject
    EvidenceSelectionValidator(PeppolConstants constants, @Assisted String uuid) {
        this.uuid = uuid;
        setRequiredHint(constants.ValidationResult_EvidenceSelectionValidator_Required());
        setValidHint(constants.ValidationResult_EvidenceSelectionValidator_Valid());
    }

    @Override
    protected boolean isUserInputAvailable(VcdCompound input) {
        return input != null;// && input.getNumberOfEvidencesToSelect(uuid) > 0;
    }

    @Override    
    protected boolean getValidationResult(VcdCompound vcdCompound) {
        boolean result = true;
        
        final CriterionMap selectedCriteria = vcdCompound.getSelectedCriteria();
        final EvidenceMap evidenceMap = vcdCompound.getSuggestedEvidences();        
        final GroupedCriteria criteriaByUuid = selectedCriteria.getCriteriaByUuid(uuid);
        
        for (CriterionWrapper criterionWrapper : criteriaByUuid.getAllCriterionWrappers()) {
            final Map<CriterionWrapper,EvidenceWrapper> provedCriteria = evidenceMap.getSelectedCriterionToEvidence(uuid);
            if(!provedCriteria.containsKey(criterionWrapper)) {
                result = false;
                break;
            }            
        }
        
        return result;        
    }

}
