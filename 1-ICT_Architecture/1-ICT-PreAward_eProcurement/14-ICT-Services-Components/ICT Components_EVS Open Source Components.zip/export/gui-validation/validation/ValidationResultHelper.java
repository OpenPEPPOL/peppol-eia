/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.peppol.client.validation;

import java.util.Set;

import at.m2n.peppol.client.events.ValidationSourceChangedEvent;

import com.google.common.collect.Sets;
import com.google.gwt.event.shared.HandlerManager;

/**
 * Use this class as delegate when implementing a result handler.
 */
public final class ValidationResultHelper {

    private final Set<IValidationSource> validationSources;
    private final Runnable onSourceChanged;
    private final IValidationResultHandler representedResultHandler;

    public static <T extends IValidationResultHandler & IValidationSource> ValidationResultHelper newInstance(final T aggregatingHandler, final HandlerManager eventBus) {
        return new ValidationResultHelper(aggregatingHandler, new Runnable() {
            @Override
            public void run() {
                eventBus.fireEvent(new ValidationSourceChangedEvent(aggregatingHandler));
            }
        });
    }


    public ValidationResultHelper(IValidationResultHandler representedResultHandler) {
        this(representedResultHandler, null);
    }


    public ValidationResultHelper(IValidationResultHandler representedResultHandler, Runnable onSourceChanged) {
        this.validationSources = Sets.newHashSet();
        this.onSourceChanged = onSourceChanged;
        this.representedResultHandler = representedResultHandler;
    }


    public void validationSourceChanged(IValidationSource source) {
        if (onSourceChanged != null) {
            if (this.validationSources.contains(source)) {
                onSourceChanged.run();
            }
        }
    }

    public void addValidationSource(IValidationSource source) {
        if (source == null) throw new NullPointerException("Cannot add null as validation source.");
        if (!validationSources.contains(source)) {
            validationSources.add(source);
            source.addResultHandler(representedResultHandler);
        }
    }

    public void removeValidationSource(IValidationSource source) {
        if (this.validationSources.contains(source)) {
            this.validationSources.remove(source);
            source.removeResultHandler(representedResultHandler);
        }
    }

    public Set<IValidationSource> getValidationSources() {
        return Sets.newHashSet(validationSources);
    }


    public void removeAllValidationSources() {
        if (!validationSources.isEmpty()) {
            Set<IValidationSource> sourcesToRemove = Sets.newHashSet(validationSources);
            for (IValidationSource s : sourcesToRemove) {
                removeValidationSource(s);
            }
        }
    }

    public boolean isValid() {
        ValidationState resultingState = ValidationState.NO_INPUT;
        for (IValidationSource s : validationSources) {
            resultingState = resultingState.and(s.getValidationResult().getState());
        }
        return resultingState.isValid();
    }

    public ValidationResult getCombinedResult(ValidationResult initialResult) {
        ValidationResult r = initialResult;
        for (IValidationSource s : validationSources) {
            r = r.and(s.getValidationResult());
        }
        return r;
    }

    public ValidationResult updateResult(ValidationResult initialResult) {
        return getCombinedResult(initialResult);
    }
}
