/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.packing;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import junit.framework.TestCase;
import at.m2n.IntelligenceManagement.vcd.AbstractFileTestUtil;

/**
 * Shows how the VcdZipReader and VcdZpWriter classes can be used to pack/unpack VCD data.
 * 
 * @author Fritz Ritzberger 07.07.2010
 */
public class VcdZipTest extends TestCase {
    
    public void testZipReadWrite() throws Exception   {
        String urlString = AbstractFileTestUtil.urlStringAsClassRelativePath(getClass(), "VCDPackage.zip");
        
        // unpack the test ZIP
        
        VcdZipReader zipReader = new VcdZipReader();
        final File vcdPackageXml = zipReader.unpack(urlString);
        final File tmpDir = vcdPackageXml.getParentFile();
        File zip = null;
        System.err.println("Temporary unpacked file is "+vcdPackageXml);
        
        try {
            assertTrue(vcdPackageXml.isFile());
            assertTrue(vcdPackageXml.length() > 0);
            
            File vcd1 = new File(vcdPackageXml.getParent(), "vcd1");
            File vcd1Xml = new File(vcd1, "VCD.xml");
            assertTrue(vcd1Xml.isFile());
            assertTrue(vcd1Xml.length() > 0);
            
            File vcd2 = new File(vcdPackageXml.getParent(), "vcd2");
            File vcd2Xml = new File(vcd2, "VCD.xml");
            assertTrue(vcd2Xml.isFile());
            assertTrue(vcd2Xml.length() > 0);
            
            // now ZIP it again
            
            VcdZipWriter writer = new VcdZipWriter();
            zip = writer.pack(tmpDir);
            System.err.println("Temporary packed file is "+zip);
            assertTrue(zip.isFile());
            assertTrue(zip.length() > 0);
            assertTrue(zip.getName().endsWith("zip"));
            
            compareZipFiles(urlString, zip);
        }
        finally {
            FileUtil.deleteDir(tmpDir);
            System.err.println("Temporary directory exists after unit test "+tmpDir.exists());
            
            if (zip != null)    {
                zip.delete();
                System.err.println("ZIP file exists after unit test "+zip.exists());
            }
        }
    }

    private void compareZipFiles(String urlString, File zip) throws Exception {
        List<NonEmptyZipEntry> list1 = readZipFile(new ZipInputStream(new URL(urlString).openStream()));
        List<NonEmptyZipEntry> list2 = readZipFile(new ZipInputStream(new FileInputStream(zip)));
        for (NonEmptyZipEntry z1 : list1)    {
            NonEmptyZipEntry found = null;
            for (NonEmptyZipEntry z2 : list2)   {
                if (z1.name.equals(z2.name))    {
                    found = z2;
                    assertEquals(z1.bytes.length, z2.bytes.length);
                    for (int i = 0; i < z1.bytes.length; i++)
                        assertEquals(z1.bytes[i], z2.bytes[i]);
                    // TODO: no array-compare in junit ???
                }
            }
            assertNotNull(found);
        }
    }

    
    private static class NonEmptyZipEntry
    {
        final String name;
        final byte [] bytes;
        
        public NonEmptyZipEntry(String name, byte [] bytes) {
            this.name = normalize(name);
            this.bytes = bytes;
        }
        private String normalize(String path)   {
            String s = path.replace('\\', '/');
            while (s.endsWith("/"))
                s = s.substring(0, s.length() - 1); 
            return s;
        }
    }
    
    
    private List<NonEmptyZipEntry> readZipFile(ZipInputStream in) throws Exception {
        List<NonEmptyZipEntry> zipThings = new ArrayList<NonEmptyZipEntry>();
        try {
            ZipEntry entry;
            while ((entry = in.getNextEntry()) != null)  {
                if (entry.isDirectory() == false)   {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte data[] = new byte[2048];
                    int count;
                    while ((count = in.read(data, 0, 2048)) > 0) {
                        out.write(data, 0, count);
                    }
                    out.close();
                    zipThings.add(new NonEmptyZipEntry(entry.getName(), out.toByteArray()));
                }
            }
        }
        finally {
            in.close();
        }
        return zipThings;
    }
    
}
