/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.loader;

import junit.framework.TestCase;

import org.jdom.Document;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import at.m2n.IntelligenceManagement.vcd.AbstractFileTestUtil;
import at.m2n.IntelligenceManagement.vcd.VcdSchemaTestConstants;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

/**
 * Shows how the XmlLoader class can be used to unpack VCD data.
 * 
 * @author Fritz Ritzberger 07.07.2010
 */
public class XmlLoaderTest extends TestCase {
    
    public void testXmlLoader() throws Exception    {
        // get an URL to the ZIP file
        String url = AbstractFileTestUtil.urlStringAsClassRelativePath(getClass(), "VCDPackage.zip");
        
        // need a base directory the schema files are under
        String schemaUrl = VcdSchemaTestConstants.SCHEMA_URL_BASE;
        
        // get a loader with schema variant "Skeleton"
        VcdSchemaVariant schemaVariant = VcdSchemaVariant.newInstance(
                schemaUrl, VcdSchemaVariant.Name.SKELETON);
        
        XmlLoader loader = new XmlLoader(schemaVariant);

        // retrieve the expanded XML Document from loader
        Document jdomDocument = loader.load(url);
        
        // ensure that this is no null
        assertNotNull(jdomDocument);
        
        // display the Document
        new XMLOutputter(Format.getPrettyFormat()).output(jdomDocument, System.out);
    }
}
