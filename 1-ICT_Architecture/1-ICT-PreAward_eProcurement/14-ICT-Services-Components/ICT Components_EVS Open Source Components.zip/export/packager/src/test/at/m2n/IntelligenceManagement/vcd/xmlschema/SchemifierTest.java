/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import junit.framework.TestCase;

import org.custommonkey.xmlunit.Diff;
import org.jdom.Document;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import at.m2n.IntelligenceManagement.vcd.AbstractFileTestUtil;

/**
 * Tests if the Schemifier is able to correct even VCD packages
 * that have recursive elements (SubcontractorSIngleTenderer).
 * 
 * @author Fritz Ritzberger 02.07.2010
 */
public class SchemifierTest extends TestCase {
    
    public void testSchemify() throws Exception {
        SAXBuilder builder = new SAXBuilder();
        Document document = builder.build(AbstractFileTestUtil.fileAsClassRelativePath(getClass(), "SchemifierVCDPackage.xml"));
        
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        new XMLOutputter(Format.getCompactFormat()).output(document, out);
        out.close();
        
        File vhostDirectory = new File("../runner-server/vhosts/ossso_uis");
        VcdSchemaVariant schemaVariant = VcdSchemaVariant.newInstance(vhostDirectory, VcdSchemaVariant.Name.FULL);
        
        XmlValidator validator = XmlValidator.getInstance(schemaVariant.vcdPackageSchemaUrl);
        assertNotNull(validator.validate(new ByteArrayInputStream(out.toByteArray())));
        
        Schemifier.getInstance(schemaVariant).schemify(document);
        
        out = new ByteArrayOutputStream();
        new XMLOutputter(Format.getCompactFormat()).output(document, out);
        out.close();
        assertNull(validator.validate(new ByteArrayInputStream(out.toByteArray())));
        
        Document controlDocument = builder.build(AbstractFileTestUtil.fileAsClassRelativePath(getClass(), "SchemifierVCDPackage_result.xml"));
        assertTrue(new Diff(jdomToXmlString(controlDocument), jdomToXmlString(document)).identical());
    }

    private String jdomToXmlString(Document jdomDocument) throws IOException  {
        OutputStream out = new ByteArrayOutputStream();
        new XMLOutputter(Format.getCompactFormat()).output(jdomDocument, out);
        out.close();
        return out.toString();
    }

}
