/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * Utilities in conjunction with unit-test files reading and writing.
 * <p />
 * Filenames should be given as path relative to the location of the passed class.
 * So if you have <i>a.b.c.SomeClass</i> in directory <i>a/b/c/</i>, and a resource
 * <i>a/b/c/some.n3</i>, you can load this resource by passing
 * <pre>
 *   (Some.class, "some.n3", model);
 * </pre>
 * to this method.
 * <p />
 * This was made for Eclipse users: Eclipse sometimes does not copy resources into
 * the "target/test-classes" folder (its compile- and run-directory).
 * 
 * @author Fritz Ritzberger, Wolfgang Groiss, Bernhard Stiftner 27.05.2010
 */
public abstract class AbstractFileTestUtil {
    
    /**
     * Get a class-relative InputStream.
     * @param clazz the class that is in the same directory as the file.
     * @param relativePath the path/name of the file to read, relative to clazz.
     */
    public static InputStream inputStreamAsClassRelativePath(Class<?> clazz, String relativePath)
            throws IOException {
        
        URL url = clazz.getResource(relativePath);
        if (url != null)    {
            return url.openStream();
        }
        else    {
            System.err.println("It's most likely that your Eclipse does not copy "+relativePath+" into its target directory ...");
            
            String path = clazz.getPackage().getName();
            String absolutePath = "src/test/"+path.replace('.', '/').replace('\\', File.separatorChar);
            File file = new File(absolutePath, relativePath);
            
            return new FileInputStream(file);
        }
    }

    /**
     * Get a class-relative File.
     * @param clazz the class that is in the same directory as the file.
     * @param relativePath the path/name of the file to read, relative to clazz.
     */
    public static File fileAsClassRelativePath(Class<?> clazz, String relativePath)
            throws IOException {
        
        URL url = clazz.getResource(relativePath);
        if (url != null)    {
            return new File(url.getPath());
        }
        else    {
            System.err.println("It's most likely that your Eclipse does not copy "+relativePath+" into its target directory ...");
            
            String path = clazz.getPackage().getName();
            String absolutePath = "src/test/"+path.replace('.', '/').replace('\\', File.separatorChar);
            return new File(absolutePath, relativePath);
        }
    }

    /**
     * Get a class-relative URL String.
     * @param clazz the class that is in the same directory as the file.
     * @param relativePath the path/name of the file to read, relative to clazz.
     */
    public static String urlStringAsClassRelativePath(Class<?> clazz, String relativePath)
            throws IOException {
        
        URL url = urlAsClassRelativePath(clazz, relativePath);
        return url.toExternalForm();
    }

    /**
     * Get a class-relative URL.
     * @param clazz the class that is in the same directory as the file.
     * @param relativePath the path/name of the file to read, relative to clazz.
     */
    public static URL urlAsClassRelativePath(Class<?> clazz, String relativePath)
            throws IOException {
        
        File file = fileAsClassRelativePath(clazz, relativePath);
        return file.toURI().toURL();
    }

    protected AbstractFileTestUtil()  {}
}
