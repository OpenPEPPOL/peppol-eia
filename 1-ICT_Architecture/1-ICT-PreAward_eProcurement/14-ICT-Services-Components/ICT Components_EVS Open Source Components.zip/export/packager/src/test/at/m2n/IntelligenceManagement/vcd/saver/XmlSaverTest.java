/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.saver;

import java.io.File;
import java.io.InputStream;

import junit.framework.TestCase;

import org.jdom.Document;
import org.jdom.input.SAXBuilder;

import at.m2n.IntelligenceManagement.vcd.AbstractFileTestUtil;
import at.m2n.IntelligenceManagement.vcd.VcdSchemaTestConstants;
import at.m2n.IntelligenceManagement.vcd.packing.VcdZipWriter;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;

/**
 * Shows how the XmlSaver class can be used to pack VCD data.
 * 
 * @author Fritz Ritzberger 07.07.2010
 */
public class XmlSaverTest extends TestCase {

    public void testXmlSaver() throws Exception {
        // get the test document from file
        InputStream in = AbstractFileTestUtil.inputStreamAsClassRelativePath(getClass(), "VcdExpandedPreskeleton.xml");
        SAXBuilder builder = new SAXBuilder();
        Document jdomDocument = builder.build(in);
        
        // need a base directory the schema files are under
        String schemaUrl = VcdSchemaTestConstants.SCHEMA_URL_BASE;
        
        // split and save the document into a ZIP file
        VcdSchemaVariant schemaVariant = VcdSchemaVariant.newInstance(
                schemaUrl, VcdSchemaVariant.Name.PRESKELETON);
        
        XmlSaver saver = new XmlSaver(jdomDocument, schemaVariant, false);
        
        String validationErrors = saver.validate();   // must be called explicitly if needed
        System.err.println("Validation errors are:\n"+validationErrors);
        
        {   // output all involved files
            System.out.println("\n"+saver.getVcdPackage().relativePathWithFileName+"\n\n");
            saver.getVcdPackage().writeDocument(System.out, false);
            
            for (PathAndDocument pathAndDocument : saver.getVcdList())  {
                System.out.println("\n"+pathAndDocument.relativePathWithFileName+"\n\n");
                pathAndDocument.writeDocument(System.out, false);
            }
        }
        
        assertNull(validationErrors);
        
        File zipFile = new VcdZipWriter().pack(saver, validationErrors);
        assert(zipFile.exists() && zipFile.length() > 0);
        
        zipFile.delete();
    }
}
