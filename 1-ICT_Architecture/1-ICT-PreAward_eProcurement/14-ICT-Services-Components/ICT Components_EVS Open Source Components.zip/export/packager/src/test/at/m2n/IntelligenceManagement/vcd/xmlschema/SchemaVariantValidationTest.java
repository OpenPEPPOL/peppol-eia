/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema;

import junit.framework.TestCase;
import at.m2n.IntelligenceManagement.vcd.AbstractFileTestUtil;
import at.m2n.IntelligenceManagement.vcd.VcdSchemaTestConstants;

/**
 * Tests the VCD XML files in this directory against different schemas.
 * 
 * @author Fritz Ritzberger 08.07.2010
 */
public class SchemaVariantValidationTest extends TestCase {

    public void testFullSchema() throws Exception   {
        final String schemaUrl = VcdSchemaTestConstants.SCHEMA_URL_BASE;
        
        final XmlValidator fullValidator = XmlValidator.getInstance(
                VcdSchemaVariant.newInstance(schemaUrl, VcdSchemaVariant.Name.FULL).vcdSchemaUrl);
        final XmlValidator skeletonValidator = XmlValidator.getInstance(
                VcdSchemaVariant.newInstance(schemaUrl, VcdSchemaVariant.Name.SKELETON).vcdSchemaUrl);
        final XmlValidator preSkeletonValidator = XmlValidator.getInstance(
                VcdSchemaVariant.newInstance(schemaUrl, VcdSchemaVariant.Name.PRESKELETON).vcdSchemaUrl);
        
        String errors;
        
        errors = fullValidator.validate(AbstractFileTestUtil.inputStreamAsClassRelativePath(getClass(), "VcdFull.xml"));
        System.err.println("FullPackage validation errors:\n"+errors);
        assertNull(errors);
        
        errors = skeletonValidator.validate(AbstractFileTestUtil.inputStreamAsClassRelativePath(getClass(), "VcdSkeleton.xml"));
        System.err.println("Skeleton validation errors:\n"+errors);
        assertNull(errors);
        
        errors = preSkeletonValidator.validate(AbstractFileTestUtil.inputStreamAsClassRelativePath(getClass(), "VcdPreSkeleton.xml"));
        System.err.println("PreSkeleton validation errors:\n"+errors);
        assertNull(errors);
    }
}
