/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.saver;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Interface to enable external code to write several contents
 * of the XML document (on RDF->XML).
 * 
 * @author Fritz Ritzberger  08.06.2010
 */
public interface TransformerSupport {
    
    /**
     * @return the version of the VCD XML-schema this transformation is driven against.
     */
    String getVCDSchemaVersionID();

    
    /**
     * @return the version of the ontology this transformation is driven against.
     */
    String getOntologyVersionID();
    
    /**
     * @return the compilation date for this transformation.
     */
    String getCompilationDate();
    String getCompilationTime();
    
    /**
     * @return XML text that describes the VCD-Package IssuingService for this transformation.
     */
    IssuingService getIssuingService();

    /**
     * @return XML text that describes the VCD VCDIssuingService for this transformation.
     */
    IssuingService getVcdIssuingService();


    /**
     * Class representing an IssuingService. This is not in the OWL graph
     * but is an required XML element.
     * For any method call that returns null an empty element will created be in XML.
     * 
     * TODO add more methods for IssuingService elements ...
     */
    public interface IssuingService  {
        /** @see XML schema description of the element. */
        String getEndpointID();
        
        /** @see XML schema description of the element. */
        String getName();
        
        /** @see XML schema description of the element. */
        String getProvidingPartyName();
    }
    
    public static class ISImpl implements IssuingService {
    	private String endpointId;
    	private String name;
    	private String providingPartyName;
			
    	public ISImpl(String name, String endpointId, String providingPartyName) {
				this.name = name;
				this.endpointId = endpointId;
				this.providingPartyName = providingPartyName;
			}

			public String getEndpointID() {
				return endpointId;
			}

			public String getName() {
				return name;
			}

			public String getProvidingPartyName() {
				return providingPartyName;
			}
    }

    public static class TSImpl implements TransformerSupport {
      	public static final DateFormat DF = new SimpleDateFormat("yyyy-MM-dd");
      	public static final DateFormat TF = new SimpleDateFormat("HH:mm:ss'Z'");
      	static {
      		TF.setTimeZone(TimeZone.getTimeZone("UTC"));
      	}

      	private DateFormat compilationDateFormatter;
    	private DateFormat compilationTimeFormatter;
    	private IssuingService issuingService;
    	private String ontologyVersionID;
    	private IssuingService vcdIsssuingService;
    	private String vcdSchemaVersionID;

    	public TSImpl(DateFormat compilationDateFormatter, DateFormat compilationTimeFormatter, IssuingService issuingService, IssuingService vcdIsssuingService, String ontologyVersionID, String vcdSchemaVersionID) {
				this.compilationDateFormatter = compilationDateFormatter;
				this.compilationTimeFormatter = compilationTimeFormatter;
				this.issuingService = issuingService;
				this.ontologyVersionID = ontologyVersionID;
				this.vcdIsssuingService = vcdIsssuingService;
				this.vcdSchemaVersionID = vcdSchemaVersionID; 
			}
    	
			public String getCompilationDate() {
				return compilationDateFormatter.format(new Date());
			}
			public String getCompilationTime() {
				return compilationTimeFormatter.format(new Date());
			}
			public IssuingService getIssuingService() {
				return issuingService;
			}
			public String getOntologyVersionID() {
				return ontologyVersionID;
			}
			public IssuingService getVcdIssuingService() {
				return vcdIsssuingService;
			}
			public String getVCDSchemaVersionID() {
				return vcdSchemaVersionID;
			}
    }
    
    
    public static final IssuingService IS_ESP = new ISImpl("European VCD System", "9914:ATU41542700", "Austrian Federal Computing Centre");
    public static final IssuingService IS_NSP = new ISImpl("Austrian National VCD System", "9914:ATU41542700", "Austrian Federal Computing Centre"); //TODO: endpoint id same as ESP?
    
    public static final TransformerSupport TS_ESP = new TSImpl(TSImpl.DF, TSImpl.TF, IS_ESP, IS_ESP, "2.0", "1.3.1");
    public static final TransformerSupport TS_NSP = new TSImpl(TSImpl.DF, TSImpl.TF, IS_NSP, IS_NSP, "2.0", "1.3.1");
    
}
