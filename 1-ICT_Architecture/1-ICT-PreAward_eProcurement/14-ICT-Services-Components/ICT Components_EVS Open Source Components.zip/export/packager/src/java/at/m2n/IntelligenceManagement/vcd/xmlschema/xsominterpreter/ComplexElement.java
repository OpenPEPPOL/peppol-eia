/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The Element that can have actual child elements, and a specified child list type.
 * 
 * @author Fritz Ritzberger 05.07.2010
 */
public class ComplexElement extends Element {

    /** The type of this Element. Purely documentary, no practical value. */
    public final SpacedName type;
    
    private final ChildListType childListType;
    private List<Element> elements = new ArrayList<Element>();

    ComplexElement(Element element, SpacedName type, ChildListType childListType) {
        super(element.nameSpace, element.name, element.getPrefix());
        this.type = type;
        this.childListType = childListType;
    }

    /** @return true as this is always a folder, or potential folder. */
    @Override
    public boolean isFolder()   {
        return childListType != null && childListType != ChildListType.CHOICE;
    }
    
    /** @return the actual children of this. */
    @Override
    public List<Element> getChildren()  {
        return Collections.unmodifiableList(new ArrayList<Element>(elements));
    }
    
    /** @return the actual child List type of this. */
    @Override
    public ChildListType getChildListType() {
        return childListType;
    }

    @Override
    public String toString() {
        return super.toString() + ", type=" + type + ", childListType=" + childListType;
    }
    
    void add(Element element) {
        elements.add(element);
    }
    
}
