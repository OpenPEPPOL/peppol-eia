/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.packing;

import java.io.File;
import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Utilities in conjunction with file handling.
 * 
 * @author Fritz Ritzberger 07.07.2010
 */
public final class FileUtil {

    private static final Log log = LogFactory.getLog(FileUtil.class);
    
    /**
     * Deleted passed file or directory recursively.
     * @param file the file or directory to delete.
     */
    public static void deleteDir(File file) {
        if (file.isDirectory())
            for (File f : file.listFiles())
                deleteDir(f);
        
        boolean ok = file.delete();
        if (ok == false)
            log.warn("Could not delete file or directory: "+file);
    }

    /**
     * Create a temporary directory.
     * @param prefix like the 1st parameter for File.createTempFile(prefix, suffix).
     * @param suffix like the 2nd parameter for File.createTempFile(prefix, suffix).
     */
    static File createTempDirectory(String prefix, String suffix) throws IOException {
        File tempFile = File.createTempFile(prefix, suffix);
        tempFile.delete();
        tempFile.mkdir();
        
        if (tempFile.exists() == false || tempFile.isDirectory() == false)
            log.warn("Could not create temporary directory: "+tempFile);
        
        return tempFile;
    }

    private FileUtil()  {}  // do not instantiate
}
