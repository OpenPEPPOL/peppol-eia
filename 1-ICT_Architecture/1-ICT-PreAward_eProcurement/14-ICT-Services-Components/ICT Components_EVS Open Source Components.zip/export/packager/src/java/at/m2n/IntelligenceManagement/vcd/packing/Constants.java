/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.packing;

/**
 * Contains file- and directory-names for VCD.
 * 
 * @author Fritz Ritzberger 28.06.2010
 */
public interface Constants {
    
  final String VCD_PACKAGE_ZIP_FILE_PREFIX = "VCDContainer";
  final String VCD_PACKAGE_ZIP_FILE_SEPARATOR = "_";
  final String VCD_PACKAGE_ZIP_FILE_SUFFIX = ".zip";

  final String VCD_PACKAGE_XML_FILE_PREFIX = "VCDPackage";
  final String VCD_PACKAGE_XML_FILE_SEPARATOR = "_";
  final String VCD_PACKAGE_XML_FILE_SUFFIX = ".xml";
    
    
  final String VCD_XML_FILE_PREFIX = "VCD";
  final String VCD_XML_FILE_SEPARATOR = "_";
  final String VCD_XML_FILE_SUFFIX = ".xml";

  final String VCD_BASEDIR_NAME_PREFIX = "VCD_";

}
