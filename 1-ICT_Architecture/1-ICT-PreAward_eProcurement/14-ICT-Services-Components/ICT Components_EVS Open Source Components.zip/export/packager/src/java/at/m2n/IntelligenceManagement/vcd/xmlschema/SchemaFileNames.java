/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema;

/**
 * Holds the file names of the XML schemas for VCD.
 * 
 * @author Fritz Ritzberger 05.07.2010
 */
final class SchemaFileNames {

    private static final String VCD_PACKAGE_SCHEMA = "maindoc/WP2-VirtualCompanyDossierPackage-1.xsd";
    private static final String VCD_SCHEMA = "maindoc/WP2-VirtualCompanyDossier-1.xsd";

    static final String BASEDIR = "../ossso/VCDSchema1.3/xsd/";
    
    private static final String SKELETON = "TCE-Skeleton/";
    private static final String TCSKELETON = "TC-Skeleton/";
    private static final String PRE_SKELETON = "T-Skeleton/";
    
    static final String PATH_PKG_FULL = VCD_PACKAGE_SCHEMA;
    static final String PATH_FULL = VCD_SCHEMA;
    static final String PATH_PKG_SKELETON = SKELETON + VCD_PACKAGE_SCHEMA;
    static final String PATH_SKELETON = SKELETON + VCD_SCHEMA;
    static final String PATH_PKG_PRESKELETON = PRE_SKELETON + VCD_PACKAGE_SCHEMA;
    static final String PATH_PRESKELETON = PRE_SKELETON + VCD_SCHEMA;
    static final String PATH_PKG_TCSKELETON = TCSKELETON + VCD_PACKAGE_SCHEMA;
    static final String PATH_TCSKELETON = TCSKELETON + VCD_SCHEMA;

    
    
    
    
//    /** The file of the VCDPackage schema for full-package variant. */
//    static final String VCD_PACKAGE_FULL = BASEDIR + PATH_PKG_FULL;
//    /** The file of the VCD schema for full-package variant. */
//    static final String VCD_FULL = BASEDIR + PATH_FULL;
//
//    /** The file of the VCDPackage schema for skeleton variant. */
//    static final String VCD_PACKAGE_SKELETON = BASEDIR + PATH_PKG_SKELETON;
//    /** The file of the VCD schema for skeleton variant. */
//    static final String VCD_SKELETON = BASEDIR + PATH_SKELETON;
//
//    /** The file of the VCDPackage schema for pre-skeleton variant. */
//    static final String VCD_PACKAGE_PRE_SKELETON = BASEDIR + PATH_PKG_PRESKELETON;
//    /** The file of the VCD schema for pre-skeleton variant. */
//    static final String VCD_PRE_SKELETON = BASEDIR + PATH_PRESKELETON;

    private SchemaFileNames()   {}  // do not instantiate
}
