/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.mapping;

/**
 * Package-visible XML and RDF names for the VCD case.
 * This encapsulates all element names, namespaces, prefixes of VCD and VCD package schema.
 * 
 * @author Fritz Ritzberger  18.05.2010
 */
interface MappingNames {

    // RDF prefixes
    
    String peppol = "http://m2n.at/2009/05/peppol/";
    String t = "http://m2n.at/t/"; // from the sample n3
    String m2n = "m2n://Document#"; // from the sample n3
    
    String peppolprefix = "peppol";
    
    // XML namespaces

    String cacPrefix = "cac";
    String cac = "urn:peppol:wp2:schema:xsd:CommonAggregateComponents-2";
    String cbcPrefix = "cbc";
    String cbc = "urn:peppol:wp2:schema:xsd:CommonBasicComponents-2";
    String cecPrefix = "cec";
    String cec = "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
    String clm54217Prefix = "clm54217";
    String clm54217 = "urn:un:unece:uncefact:codelist:specification:54217:2001";
    String clm66411Prefix = "clm66411";
    String clm66411 = "urn:un:unece:uncefact:codelist:specification:66411:2001";
    String clmIANAMIMEMediaTypePrefix = "clmIANAMIMEMediaType";
    String clmIANAMIMEMediaType = "urn:un:unece:uncefact:codelist:specification:IANAMIMEMediaType:2003";
    String udtPrefix = "udt";
    String udt = "urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2";
    String vcdpPrefix = "vcdp";
    String vcdp = "urn:peppol:wp2:schema:xsd:VirtualCompanyDossierPackage-1";
    String vcdPrefix = "vcd";
    String vcd = "urn:peppol:wp2:schema:xsd:VirtualCompanyDossier-1";
    String xsdPrefix = "xsd";
    String xsd = "http://www.w3.org/2001/XMLSchema-instance";

    // temporary XML namespace for XmlAdjuster
    
    String tmpPrefix = "tmp";
    String tmp = "urn:m2n:transformer:temporary";
    
    // XML element names
    
    String XML_ATTACHMENT = "Attachment";
    String XML_CALL_FOR_TENDER_ID = "CallForTenderID";
    String XML_PROCUREMENT_LOT_ID = "ProcurementLotID";
    String XML_COMPILATION_DATE = "CompilationDate";
    String XML_COMPILATION_TIME = "CompilationTime";
    String XML_VCD_TYPE_CODE = "VCDTypeCode";
    String XML_CONTRACTING_AUTHORITY_NATIONAL_REGULATION = "ContractingAuthorityNationalRegulation";
    String XML_CONTRACTING_AUTHORITY_PARTY = "ContractingAuthorityParty";
    String XML_CRITERION = "Criterion";
    String XML_DOCUMENT_GROUP_ID = "DocumentGroupID";
    String XML_DOCUMENT_REFERENCE = "DocumentReference";
    String XML_ECONOMIC_OPERATOR = "EconomicOperator";
    String XML_SOLE_PROPRIETORSHIP_INDICATOR = "SoleProprietorshipIndicator";
    
    String XML_DESCRIPTIVE_DOCUMENT = "DescriptiveDocument";
    String XML_ECONOMIC_OPERATOR_NATIONAL_REGULATION = "EconomicOperatorNationalRegulation";
    String XML_ENDPOINT_ID = "EndpointID";
    String XML_EUROPEAN_REGULATION = "EuropeanRegulation";
    String XML_CRITERION_GROUP_REGULATION = "CriterionGroupRegulation";
    String XML_EVIDENCE = "Evidence";
    String XML_EXTERNAL_REFERENCE = "ExternalReference";
    String XML_BIRTH_DATE = "BirthDate";
    String XML_PLACE_OF_BIRTH = "PlaceOfBirth";
    String XML_PROFESSION = "Profession";
    String XML_CITIZENSHIP_COUNTRY = "CitizenshipCountry";
    String XML_RESIDENCE_ADDRESS = "ResidenceAddress";
    String XML_FAMILY_NAME = "FamilyName";
    String XML_FILENAME = "FileName";
    String XML_FIRST_NAME = "FirstName";
    String XML_JOB_TITLE = "JobTitle"; 
    String XML_ISSUER_PARTY = "IssuerParty";
    String XML_ISSUING_SERVICE = "IssuingService";
    String XML_ID = "ID";
    String XML_LANGUAGE = "Language";
    String XML_LEGAL_REFERENCE = "LegalReference";
    String XML_LEGAL_TEXT = "LegalText";
    String XML_FURTHER_INFORMATION = "FurtherInformation";
    String XML_LEGAL_TEXT_ENGLISH = "LegalTextEnglish";
    String XML_FURTHER_INFORMATION_ENGLISH = "FurtherInformationEnglish";
    String XML_LEGAL_TEXT_NATIONAL = "LegalTextNational";
    String XML_FURTHER_INFORMATION_NATIONAL = "FurtherInformationNational";
    
    String XML_REQUIREMENT_DESCRIPTION = "RequirementDescription";
    String XML_SUBSTITUTE_EVIDENCE_DESCRIPTION = "SubstituteEvidenceDescription";
    String XML_SUBSTITUTE_EVIDENCE_MINIMUM_LEVEL_CODE = "MinimumSubstituteEvidenceLevelCode";
    
    String XML_LOCALE_CODE = "LocaleCode";
    String XML_MIDDLE_NAME = "MiddleName";
    String XML_NAME = "Name";
    String XML_NAME_ENGLISH = "NameEnglish";
    String XML_NAME_NATIONAL = "NameNational";
    String XML_ONTOLOGY_DEFINITION_REGULATION = "OntologyDefinitionRegulation";
    String XML_ONTOLOGY_DOMAIN_CODE = "OntologyDomainCode";
    String XML_ONTOLOGY_VERSION_ID = "OntologyVersionID";
    String XML_PARTY = "Party";
    String XML_PARTY_IDENTIFICATION = "PartyIdentification";
    String XML_PARTY_NAME = "PartyName";
    String XML_PERSON = "Person";
    String XML_PERSON_DETAILS = "PersonDetails";
    String XML_PROVES_CRITERION_ID = "ProvesCriterionID";
    String XML_PROVING_EVIDENCE_ID = "ProvingEvidenceID";
    String XML_RELEVANT_VCD_PERSON = "RelevantVCDPerson";
    String XML_REQUESTED_INDICATOR = "RequestedIndicator";
    String XML_REQUESTER_PARTY = "RequesterParty";
    String XML_PROVIDING_PARTY = "ProvidingParty";
    String XML_SIGNATORY_PARTY = "SignatoryParty";
    String XML_SINGLE_TENDERER = "SingleTenderer";
    String XML_SUBCONTRACTOR_SINGLE_TENDERER = "SubcontractorSingleTenderer";
    String XML_BIDDING_CONSORTIUM = "BiddingConsortium";
    String XML_BIDDING_CONSORTIUM_LEADER = "LeaderSingleTenderer";
    String XML_BIDDING_CONSORTIUM_MEMBER = "OtherMemberSingleTenderer";
    String XML_TITLE = "Title";
    String XML_TITLE_ENGLISH = "TitleEnglish";
    String XML_TITLE_NATIONAL = "TitleNational";
    String XML_URI = "URI";
    String XML_UUID = "UUID";
    String XML_VCD = "VCD";
    String XML_VCD_ISSUING_SERVICE = "VCDIssuingService";
    String XML_VCD_PACKAGE = "VCDPackage";
    String XML_VCD_PACKAGE_NAME = "VCDPackageName";
    String XML_VCD_SCHEMA_VERSION_ID = "VCDSchemaVersionID";


    String XML_POSTAL_ADDRESS = "PostalAddress";
    String XML_ADDRESS_TYPE_CODE = "AddressTypeCode";
    String XML_ROOM = "Room";
    String XML_STREET_NAME= "StreetName";
    String XML_BUILDING_NAME = "BuildingName";
    String XML_BUILDING_NUMBER = "BuildingNumber";
    String XML_CITY_NAME = "CityName";
    String XML_POSTAL_ZONE = "PostalZone";
    String XML_COUNTRY_SUBENTITY = "CountrySubentity";
    String XML_COUNTRY_SUBENTITY_CODE = "CountrySubentityCode";
    String XML_ADDRESS_LINE = "AddressLine";
    String XML_COUNTRY = "Country";

    String XML_COUNTRY_IDENTIFICATION_CODE = "IdentificationCode";
    String XML_COUNTRY_NAME = "Name";
    
    String XML_CONTACT = "Contact";
    String XML_CONTACT_NAME = "Name";
    String XML_CONTACT_TELEPHONE = "Telephone";
    String XML_CONTACT_TELEFAX = "Telefax";
    String XML_CONTACT_ELECTRONIC_MAIL = "ElectronicMail";
    String XML_CONTACT_NOTE = "Note";
    
    String XML_POLICY_DOCUMENT = "PolicyDocument";
    String XML_ADDITIONAL_DOCUMENT = "AdditionalDocument";

    
    // temporarily used artifical transformer XML elements
    
    String XML_EVIDENCE_COLLECTOR = "EvidenceCollector";
    String XML_SERVICE_COLLECTOR = "ServiceCollector";
    String XML_SERVICE_DOCUMENT_BLOB_URI = "ServiceDocumentBlobUri";
    String XML_EVIDENCE_DOCUMENT_BLOB_URI = "EvidenceDocumentBlobUri";
    
    // XML structural definitions
    
    String XML_REFERENCE_ELEMENT = "VCDReferenceID";
    String XML_REFERENCE_NAMESPACE = cbc;
    
    
    
    // RDF constants
    
    String RDF_ROOT_CLASS = "VCDRequest";
    String RDF_ROOT_PREFIX = peppol;

    String RDF_TARGET_LANGUAGE = "targetLanguage";

}
