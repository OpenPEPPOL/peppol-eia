/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.schemify.xsom;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Namespace;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.util.JdomXmlUtil;
import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.xmlschema.Schemifier;
import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.Element;
import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.UnresolvedRecursiveElement;
import at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter.XsomInterpreter;

/**
 * Schemifier implementation that works with XML files representing schema information.
 * 
 * @author Fritz Ritzberger  02.06.2010
 */
public class SchemifierXsomImpl implements Schemifier.Impl {
    
    private static final Log log = LogFactory.getLog(SchemifierXsomImpl.class);
    
    private final Element vcdPackageRootDescriptor;
    private final Element vcdRootDescriptor;
    
    private final Map<Path.Part,Boolean> isFolderMap = new Hashtable<Path.Part,Boolean>();

    /**
     * Creates a Schemifier that works with XML.
     * @param vcdPackageSchemaUrl the URL of the VCDPackage schema.
     * @param vcdPackageSchemaRootElement the name of the VCDPackage root element.
     * @param vcdSchemaUrl the URL of the VCD schema.
     * @param vcdSchemaRootElement the name of the VCD root element.
     * @throws MalformedURLException
     * @throws SAXException
     */
    public SchemifierXsomImpl(
            String vcdPackageSchemaUrl,
            String vcdPackageSchemaRootElement,
            String vcdSchemaUrl,
            String vcdSchemaRootElement)
    throws MalformedURLException, SAXException  {
        XsomInterpreter interpreter;
        
        interpreter = new XsomInterpreter(vcdPackageSchemaUrl);
        this.vcdPackageRootDescriptor = interpreter.getTopLevelElementDescriptor(vcdPackageSchemaRootElement, null);
        
        interpreter = new XsomInterpreter(vcdSchemaUrl);
        this.vcdRootDescriptor = interpreter.getTopLevelElementDescriptor(vcdSchemaRootElement, null);
        
        buildIsFolderMap();
    }
    
    /**
     * @param element the element for which it should be decided if it is a folder or leaf.
     * @return true when passed element is a folder element and not a leaf element.
     */
    @Override
    public boolean isFolderElement(Path.Part element) {
        return isFolderMap.get(element) != null;
    }
    
    /**
     * Adds required and missing elements,
     * then sorts all elements according to schema information.
     * @param document the XML document to rectify.
     */
    @Override
    public void schemify(Document document) {
        org.jdom.Element root = document.getRootElement();
        Element compareRoot;
        if (root.getName().equals(vcdPackageRootDescriptor.name) &&
                root.getNamespace().getURI().equals(vcdPackageRootDescriptor.nameSpace))   {
            compareRoot = vcdPackageRootDescriptor;
        }
        else if (root.getName().equals(vcdRootDescriptor.name) &&
                    root.getNamespace().getURI().equals(vcdRootDescriptor.nameSpace))   {
            compareRoot = vcdRootDescriptor;
        }
        else
            throw new IllegalArgumentException("Unkown root element in document: "+root.getName()+", namespace: "+root.getNamespaceURI());
        
        addRequiredElements(root, compareRoot, compareRoot);
        sortElements(root, compareRoot, compareRoot);
    }

    private void addRequiredElements(final org.jdom.Element element, final Element compareElement, final Element compareRoot)    {
        assert compareElement != null : "Element found that is not in XML template: name="+JdomXmlUtil.xpath(element);
        final Element resolvedCompareElement = resolveRecursiveElement(compareElement, compareRoot);
        
        if (resolvedCompareElement == null)
        	return;
        
        List children = element.getChildren();  // this is a JDOM "live" List
        List<Element> compareChildren = resolvedCompareElement.getChildren();

        for (Element compareChild : compareChildren)   {
            String minOccursString = compareChild.getMinOccurs();
            int minOccurs = minOccursString == null ? 1 : Integer.parseInt(minOccursString);    // provoke exception when "unbounded"
            
            if (minOccurs > 0 && getChild(element, compareChild.name, compareChild.nameSpace) == null)   {
                log.info("Found missing element "+compareChild+", adding "+minOccurs);
                
                for (int i = 0; i < minOccurs; i++) {
                    Namespace ns = findNamespace(element, compareChild.nameSpace);
                    if (ns == null)
                        ns = Namespace.getNamespace(compareChild.nameSpace);
                    org.jdom.Element missingElement = new org.jdom.Element(compareChild.name, ns);
                    children.add(missingElement);
                }
            }
        }
        
        for (Object o : children)   {   // continue recursively
            org.jdom.Element child = (org.jdom.Element) o;
            addRequiredElements(child, getCompareChild(resolvedCompareElement, child), compareRoot);
        }
    }

    private Namespace findNamespace(org.jdom.Element element, String nameSpace) {
        List namespaces = element.getDocument().getRootElement().getAdditionalNamespaces();
        for (Object o : namespaces)  {
            Namespace ns = (Namespace) o;
            if (ns.getURI().equals(nameSpace))
                return ns;
        }
        return null;
    }

    private org.jdom.Element getChild(org.jdom.Element parent, String name, String nameSpace) {
        for (Object o : parent.getChildren()) {
            org.jdom.Element e = (org.jdom.Element) o;
            if (e.getName().equals(name) && e.getNamespaceURI().equals(nameSpace))
                return e;
        }
        return null;
    }

    private void sortElements(final org.jdom.Element element, final Element compareElement, final Element compareRoot)    {
        final Element resolvedCompareElement = resolveRecursiveElement(compareElement, compareRoot);
        
        if (resolvedCompareElement == null)
        	return;
        
        List children = element.getChildren();  // this is a JDOM "live" List
        final List<Element> compareChildren = resolvedCompareElement.getChildren();

        Comparator comparator = new Comparator()    {
            @Override
            public int compare(Object o1, Object o2) {
                org.jdom.Element e1 = (org.jdom.Element) o1;  // provoke ClassCastException
                org.jdom.Element e2 = (org.jdom.Element) o2;
                Element parallelChild1 = getCompareChild(resolvedCompareElement, e1);  // provoke NullPointerException
                assert parallelChild1 != null : "Element found that is not in XML template: name="+e1.getName()+", namespace="+e1.getNamespaceURI();
                Element parallelChild2 = getCompareChild(resolvedCompareElement, e2);
                assert parallelChild2 != null : "Element found that is not in XML template: name="+e2.getName()+", namespace="+e2.getNamespaceURI();
                return compareChildren.indexOf(parallelChild1) - compareChildren.indexOf(parallelChild2);
            }
        };
        
        // JDOM problem on sorting, so sort a clone and renew the list after
        // org.jdom.IllegalAddException: The Content already has an existing parent "vcdp:VCDPackage"
        final List clone = new ArrayList(children);
        Collections.sort(clone, comparator);
        children.clear();   // remove all curent children
        for (Object o : clone)  // add the sorted list of children
            children.add((org.jdom.Element) o);
        
        for (Object o : children)   {   // continue recursively
            org.jdom.Element child = (org.jdom.Element) o;
            sortElements(child, getCompareChild(resolvedCompareElement, child), compareRoot);
        }
    }

    private void buildIsFolderMap() {
        buildIsFolderMap(vcdPackageRootDescriptor);
        buildIsFolderMap(vcdRootDescriptor);
    }

    private void buildIsFolderMap(Element element) {
        if (element.isFolder())
            isFolderMap.put(new Path.Part(element.nameSpace, element.name), Boolean.TRUE);
        for (Object o : element.getChildren())
            buildIsFolderMap((Element) o);
    }

    private Element getCompareChild(Element compareElementParent, org.jdom.Element child)   {
        for (Element compareChild : compareElementParent.getChildren())    {
            if (compareChild.getChildListType() == Element.ChildListType.CHOICE)   {
                Element found = getCompareChild(compareChild, child);
                if (found != null)
                    return found;
            }
            else if (compareChild.name.equals(child.getName()) && compareChild.nameSpace.equals(child.getNamespaceURI()))  {
                return compareChild;
            }
        }
        return null;
    }
    
    private Element resolveRecursiveElement(Element compareElement, Element root) {
        if (compareElement instanceof UnresolvedRecursiveElement == false)
            return compareElement;
        
        return ((UnresolvedRecursiveElement) compareElement).resolve(root);
    }

}
