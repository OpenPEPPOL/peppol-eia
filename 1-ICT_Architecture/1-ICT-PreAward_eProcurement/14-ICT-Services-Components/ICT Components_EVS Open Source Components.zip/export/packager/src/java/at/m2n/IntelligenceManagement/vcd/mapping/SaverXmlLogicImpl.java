/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.mapping;

import java.util.UUID;

import org.jdom.Element;
import org.jdom.Namespace;

import at.m2n.IntelligenceManagement.vcd.saver.XmlSaver;

/**
 * Contains the XML logic needed to write a VCD Package.
 * 
 * @author Fritz Ritzberger 25.06.2010
 */
public class SaverXmlLogicImpl implements XmlSaver.SaverXmlLogic, MappingNames {
    /**
     * Creates a VCDReferenceID element and writes the passed relative path into it.
     * @param elementContent the content text for the new element.
     */
    @Override
    public Element createUnresolvedDocumentReferenceElement(String elementContent)   {
        Element e = new Element(XML_REFERENCE_ELEMENT, Namespace.getNamespace(cbcPrefix, XML_REFERENCE_NAMESPACE));
        e.setText(elementContent);
        return e;
    }
    
    /**
     * @param element the XML element to be checked if it is an resolved XML document reference.
     * @return true when passed element is a resolved XML document reference.
     */
    @Override
    public boolean isResolvedDocumentReferenceElement(Element element) {
        return
            element.getName().equals(CommonMappingNames.XML_VCD_ROOT_ELEMENT) &&
            element.getNamespaceURI().equals(CommonMappingNames.XML_VCD_ROOT_NAMESPACE);
    }

    /** @return true if the passed element is a UUID element, to be filled with a generator value. */
    @Override
    public boolean isUuidGeneratorXmlElement(Element e) {
        return e.getName().equals(XML_UUID) && e.getNamespaceURI().equals(cbc);
    }

    /**
     * Creates a random based universal unique identifier by means of <i>java.util.UUID</i>.
     * See http://en.wikipedia.org/wiki/Universally_Unique_Identifier and 
     * http://java.sun.com/j2se/1.5.0/docs/api/java/util/UUID.html
     * 
     * @return a new globally unique identifier. To be overridden by unit tests that need a deterministic UUID.
     */
    @Override
    public String generateUuid4Xml()  {
        return UUID.randomUUID().toString();
    }

    /**
     * To be overridden by implementers that use the BLOB save feature.
     * This implementation checks for the element "EvidenceDocumentBlobUri"
     * in namespace "urn:m2n:transformer:temporary" which must be a sibling of "FileName",
     * both being children of some "DocumentReference".
     * @return true if passed element is a evidence's document BLOB URI.
     */
    @Override
    public boolean isEvidenceDocumentBlobUri(Element e) {
        return e.getName().equals(XML_SERVICE_DOCUMENT_BLOB_URI) && e.getNamespaceURI().equals(tmp);
    }

    /** @return true if passed element is an "FileName" element. */
    @Override
    public boolean isEvidenceDocumentBlobFilename(Element e) {
        return e.getName().equals(XML_FILENAME) && e.getNamespaceURI().equals(cbc);
    }

    /** Removes the temporary namespace from passed element which should be the root element of the document. */
    @Override
    public void editRootElement(Element element) {
        element.removeNamespaceDeclaration(Namespace.getNamespace(tmpPrefix, tmp));
    }

}
