/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter;

/**
 * This Element can not have child Elements. For VCD this has a
 * primitive data-type,defined in XML-Schema namespace (datatypes.xsd).
 * 
 * @author Fritz Ritzberger 05.07.2010
 */
public class SimpleElement extends Element {
    
    /** The data type of this Element, defined in namespace of XML-Schema. */
    public final String xsdDataType;

    SimpleElement(Element element, String xsdDataType) {
        super(element.nameSpace, element.name, element.getPrefix());
        this.xsdDataType = xsdDataType;
    }

    @Override
    public String toString() {
        return super.toString() + ", xsdDataType=" + xsdDataType;
    }

}
