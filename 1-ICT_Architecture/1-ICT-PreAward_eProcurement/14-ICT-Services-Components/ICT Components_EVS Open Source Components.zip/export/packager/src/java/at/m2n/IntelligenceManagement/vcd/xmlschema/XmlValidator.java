/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;

/**
 * Verifies XML against a schema.
 * Keeps cached instances of schemas for better performance.
 * 
 * @author Fritz Ritzberger  10.06.2010
 */
public class XmlValidator {
    private static final String W3C_XML_SCHEMA_NS_URI = "http://www.w3.org/2001/XMLSchema";
    private static final Log log = LogFactory.getLog(XmlValidator.class);
    
    private static final Map<String,XmlValidator> cache = new Hashtable<String,XmlValidator>();
    
    /**
     * Singleton factory to deliver cached XmlValidator instances (it takes time to read a schema with JAXP).
     * @return a (cached) XmlValidator instance for passed URL string.
     * @throws SAXException 
     * @throws ParserConfigurationException 
     * @throws MalformedURLException 
     */
    public static XmlValidator getInstance(String schemaUrl) throws MalformedURLException, ParserConfigurationException, SAXException {
        XmlValidator validator = cache.get(schemaUrl);
        if (validator == null)
            cache.put(schemaUrl, validator = new XmlValidator(schemaUrl));

        return validator;
    }
    
    /** Garbage collect all pre-parsed schemas. */
    public static void clearInstances()    {
        cache.clear();
    }

    private final Schema schema;
    
    /**
     * Constructor that validates passed XML stream against passed Schema file.
     * The schema must be a file to enable simple resolution of imported schemas
     * without catalogs (problems with InputStream).
     * @param schemaFile the schema to validate against.
     * @throws ParserConfigurationException when parser could not be loaded.
     * @throws SAXException when schema is incorrect XML, or invalid itself.
     */
    private XmlValidator(String schemaUrl) throws ParserConfigurationException, SAXException, MalformedURLException {
        log.info("Standing in "+System.getProperty("user.dir")+", building XML schema from "+schemaUrl);
        SchemaFactory factory = SchemaFactory.newInstance(W3C_XML_SCHEMA_NS_URI);
        this.schema = factory.newSchema(new URL(schemaUrl));
        
        assert schema != null : "Could not create schema object from URL: "+schemaUrl;
    }
    
    /** Currently unused constructor. The URL is sufficient, need no File. */
    private XmlValidator(File schemaFile) throws ParserConfigurationException, SAXException {
        log.info("Standing in "+System.getProperty("user.dir")+", building XML schema from "+schemaFile);
        SchemaFactory factory = SchemaFactory.newInstance(W3C_XML_SCHEMA_NS_URI);
        this.schema = factory.newSchema(schemaFile);
        
        assert schema != null : "Could not create schema object from file: "+schemaFile;
    }
    
    /**
     * Validates passed XML stream against schema file of this validator.
     * @param xmlStream the XML to validate.
     * @throws IOException when something goes wrong with reading files.
     */
    public String validate(InputStream xmlStream) throws IOException {
        Validator validator = schema.newValidator();
        try {
            validator.validate(new StreamSource(xmlStream));
            return null;
        }
        catch (SAXException e) {
        	e.printStackTrace();
            return e.getMessage();
        }
    }
    

    /**
     * Validates XML files against a schema, both given in commandline.
     * @param args Syntax is: schemaFile xmlfile [xmlfile ...]
     */
    public static void main(String[] args) throws Exception {
        if (args.length < 2)   {
            System.err.println("SYNTAX: java "+XmlValidator.class.getName()+" schemaFile xmlFile [xmlFile ...]");
            System.exit(1);
        }
        
        System.err.println("Standing in "+System.getProperty("user.dir"));
        File schema = null;
        String xml = null;
        for (String filename : args)    {
            if (schema == null) {
                schema = new File(filename);
                System.err.println("Validating with "+schema);
            }
            else    {
                xml = filename;
            }
            
            if (schema != null && xml != null) {
                //XmlValidator verifier = new XmlValidator(schema);
                XmlValidator verifier = XmlValidator.getInstance("file:"+schema.getPath());
                String errors = verifier.validate(new java.io.FileInputStream(xml));
                System.err.println("Errors for "+xml+" are:");
                System.err.println(errors);
            }
        }
        System.exit(0);
    }

}
