/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.saver;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.jdom.Document;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;


/**
 * Representation of the transformer result - to be written to file/system or to ZIP.
 * This is to be used by PeppolSkeletonPackagingService to generate a ZIP file.
 * Uses JDOM to print a wrapped XML document, optionallz with attachments.
 * 
 * @author Fritz Ritzberger 28.06.2010
 */
public class PathAndDocument   {
    
    /** The document's relative save path, including the file name. */
    public final String relativePathWithFileName;
    public final String relativePath;
    Document document;    // variant1: the XML document
    String documentText;    // variant 2: the XML document text
    private List<PathAndDocument> attachments = new ArrayList<PathAndDocument>();
    
    /** Constructor for implementers that override writeDocument(). */
    public PathAndDocument(String relativePathWithFileName) {
        this.relativePathWithFileName = relativePathWithFileName;
        this.relativePath = new File(relativePathWithFileName).getParent();
        this.documentText = null;
        this.document = null;
    }
    
    /** Constructor for implementers that pass a ready-made XML text. */
    public PathAndDocument(String documentText, String relativePathWithFileName) {
        this.documentText = documentText;
        this.relativePathWithFileName = relativePathWithFileName;
        this.relativePath = new File(relativePathWithFileName).getParent();
        this.document = null;
    }
    
    /** Constructor for implementers that pass a JDOM XML document. */
    public PathAndDocument(Document document, String relativePathWithFileName) {
        this.document = document;
        this.relativePathWithFileName = relativePathWithFileName;
        this.relativePath = new File(relativePathWithFileName).getParent();
        this.documentText = null;
    }
    
    /** Writes the wrapped document to passed output stream. Does no close the output stream. */
    public void writeDocument(OutputStream out, boolean writeOptimized) throws IOException {
        assert documentText != null || document != null : "Having neither docuemnt nor text for writeDocument() call!";
        
        if (documentText != null)   {
            out.write(documentText.getBytes());
        }
        else    {
            XMLOutputter outputter = writeOptimized
                ? new XMLOutputter(Format.getCompactFormat())
                : new XMLOutputter(Format.getPrettyFormat());
            outputter.output(document, out);
        }
    }
    
    /** Returns a List of attachments, each relative to this PathAndDocument. Call writeDocument() for each! */
    public List<PathAndDocument> getAttachments()    {
        return attachments;
    }
    
    /**
     * Adds another BLOB Filename/URL information tuple, and a resolver able to retrieve an InputStream from that URL.
     * @param relativePathWithFileName the relative pat and filename for this attachment, separated by "/", normally only a filename.
     * @param resolver the object able to turn a URL into the InputStream for that attachment, will be called on <i>writeDocument()</i> method call.
     * @param rdfResourceUri the URL to pass to the resolver for that attachment.
     */
    void addBlobDocumentAttachment(String relativePathWithFileName, final BlobDocumentResolver resolver, final String rdfResourceUri)    {
        attachments.add(new PathAndDocument((Document) null, relativePathWithFileName) {
            @Override
            public void writeDocument(OutputStream out, boolean writeOptimized) throws IOException {
                InputStream in = resolver.resolveBlob(rdfResourceUri);
                if (in == null)
                    throw new IOException("BlobDocumentResolver returned null InputStream for file "+relativePathWithFileName+" with ResourceUri "+rdfResourceUri);

                try {
                    for (int c; (c = in.read()) != -1; )
                        out.write(c);
                }
                finally {
                    in.close();
                }
            }
        });
    }

}
