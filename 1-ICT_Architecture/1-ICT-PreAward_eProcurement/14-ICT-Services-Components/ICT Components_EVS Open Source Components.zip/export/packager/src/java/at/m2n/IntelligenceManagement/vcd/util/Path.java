/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.util;

import java.util.ArrayList;

/**
 * Utility class to aggregate XML element path parts and thus build a path
 * that describes an hierarchical XML location. This implements equals()
 * and hashCode() to be map-able.
 * 
 * @author Fritz Ritzberger  25.05.2010

 */
public class Path extends ArrayList<Path.Part> {

	private static final long serialVersionUID = -4088789935335158668L;

	/**
     * Part of a path, holding namespace and name of exactly one element in path.
     */
    public static class Part    {
        public final String namespace;
        public final String name;
        
        public Part(String namespace, String name) {
            assert namespace != null && name != null : "Must have non-null namespace and name! name="+name+", namespace="+namespace;
            this.namespace = namespace;
            this.name = name;
        }
        
        @Override
        public int hashCode()   {
            return namespace.hashCode() + name.hashCode();
        }
        @Override
        public boolean equals(Object other)   {
            if (other instanceof Part == false)
                return false;
            Part otherPart = (Part) other;  // provoke ClassCastException
            return otherPart.namespace.equals(namespace) && otherPart.name.equals(name);
        }
        @Override
        public String toString() {
            return name;
        }
    }
    
    
    /** @return a clone of this Path, containing exactly the same parts as this one. */
    public Path copy() {
        Path newPath = new Path();
        for (Part part : this)
            newPath.add(part);
        return newPath;
    }
    
    /** @return the leftmost part of this path (highest level). */
    public Path.Part getLastPart() {
        return get(size() - 1);
    }
    
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        for (Part p : this)
            sb.append(p+"/");
        return sb.toString();
    }

}

