/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter;

/**
 * Any element tat can occur recursively (like SubcontractorSingleTenderer)
 * can not be resolved by the schema-interpreter. Tree traversers must do
 * this by themselves. They can use <i>resolve(root)</i> to do such.
 * 
 * @author Fritz Ritzberger 05.07.2010
 */
public class UnresolvedRecursiveElement extends Element   {
    
    private Element resolved;
    
    UnresolvedRecursiveElement(Element element) {
        super(element.nameSpace, element.name, element.getPrefix());
    }
    
    /**
     * Resolves this recursive element by returning an element
     * that has same name and namespace but valid child nodes.
     * 
     * @param root the search start node for finding an element with same name / namespace.
     * @return the first found element with same name and namespace.
     */
    public Element resolve(Element root)  {
        if (resolved != null)
            return resolved;
        
        if (root.name.equals(name) && root instanceof UnresolvedRecursiveElement == false && root.nameSpace.equals(nameSpace))
            return resolved = root;
        
        for (Element child : root.getChildren())
            resolve(child);

        return resolved;
    }
    
    @Override
    public boolean isFolder() {
        return true;
    }
    
    public String toString() {
        return "["+super.toString()+"] (unresolved recursive element)";
    }

}
