/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents an XML element node.
 * This is the base class for both ComplexElement and SimpleElement.
 * 
 * @author Fritz Ritzberger 05.07.2010
 */
public class Element extends SpacedName {
    
    /**
     * The type of children list:
     * ALL = each contained element just once but in any order,
     * SEQUENCE: elements ordered, repeating 0-n times according to their cardinality,
     * CHOICE: just one of the elements contained, default the first.
     */
    public enum ChildListType {
        ALL, SEQUENCE, CHOICE
    }


    private static final List<Element> EMPTY_LIST = new ArrayList<Element>(0);

    public static final String UNBOUNDED = "unbounded";
    
    private String minOccurs, maxOccurs;
    private String prefix;

    Element(String nameSpace, String elementName, String prefix) {
        super(nameSpace, elementName);
        this.prefix = prefix;
    }

    /**
     * @return true if this Element has children, or can have children.
     *  This implementation returns true, override for ComplexElements.
     */
    public boolean isFolder()   {
        return false;
    }
    
    /**
     * @return the empty list if this is a SimpleElement,
     *  and a List of child Elements when this is a non-empty ComplexElement.
     */
    public List<Element> getChildren()  {
        return EMPTY_LIST;
    }

    /**
     * @return the type the child List is of.
     *  This implementation returns null, override to deliver children.
     */
    public ChildListType getChildListType() {
        return null;
    }
    
    /** @return the minimum cardinality of this Element. */
    public String getMinOccurs() {
        return minOccurs;
    }

    /** @return the maximum cardinality of this Element. */
    public String getMaxOccurs() {
        return maxOccurs;
    }

    void setMinMaxOccurs(String[] minMaxOccurs) {
        this.minOccurs = minMaxOccurs[0];
        this.maxOccurs = minMaxOccurs[1];
    }

    /** @return the prefix (namespace abbreviation) of this element, can be null. */
    public String getPrefix() {
        return prefix;
    }

    void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    @Override
    public String toString() {
        return (prefix != null ? prefix+":" : "") + super.toString() + ", min=" + (minOccurs != null ? minOccurs : "1") + ", max=" + (maxOccurs != null ? maxOccurs : "1");
    }

}
