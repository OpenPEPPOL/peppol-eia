/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.packing;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * A utility to extract a ZIP file containing VCD data.
 * 
 * @author Fritz Ritzberger 28.06.2010
 */
public class VcdZipReader {
    
    /**
     * A direct way to get into the ZIP file without explicitly unpacking it.
     * E.g. following URL could be read via <i>url.openStream()</i> by Java:
     * <code>jar:file:../runner-server/vhosts/ossso/vcd_package_examples/simple_vpps.zip!/VCDPackage.xml</code>.
     * @param vcdZip the ZIP file containing VCD files.
     * @return the URL to use for the VCDPackage.xml file in ZIP root directory.
     *      All referenced files (vcd1/VCD.xml, ...) will be read similarly.
     */
    public static String getVcdPackageXmlZipUrl(File vcdZip) throws IOException {
    	ZipFile zf = new ZipFile(vcdZip);
    	Enumeration<? extends ZipEntry> entries = zf.entries();
    	
    	while (entries.hasMoreElements()) {
    		ZipEntry entry = entries.nextElement();
    		String name = entry.getName();
    		
    		if (isPackageName(name))
    			return "jar:file:" + vcdZip.getPath() + "!/" + name;	
    	}
    	
    	throw new IOException("The given ZIP file doesn't seem to contain a VCD Package XML file");
    }
    
    /**
     * Extracts a ZIP into a temporarily created directory.
     * MIND: The caller is responsible for deleting the parent directory after processing
     * the returned File. Example implementation:
     * <pre>
     *  File vcdPackageXml = new VcdZipReader().unpack(zipPath);
     *  try {
     *    ...  // process VCD file
     *  }
     *  finally {
     *    FileUtil.deleteDir(vcdPackageXml.getParentFile());
     *  }
     * </pre>
     * The returned String can be used as argument for <i>XmlLoader.load()</i> method.
     * @param urlString the URL to read the ZIP stream from.
     * @return the URL String of the main VCDPackage.xml file that has been extracted.
     * @throws IOException when passed URL is invalid or could not be opened as ZIP stream.
     */
    public static File unpack(String urlString) throws IOException  {
        URL url = new URL(urlString);
        ZipInputStream in = new ZipInputStream(new BufferedInputStream(url.openStream()));
        File tmpDir = FileUtil.createTempDirectory("VCD_Unpack", "dir");
        boolean exception = false;
        try {
            ZipEntry entry;
            while ((entry = in.getNextEntry()) != null)  {
                if (entry.isDirectory() == false)   {
                    File newFile = new File(tmpDir, entry.getName());
                    newFile.getParentFile().mkdirs();
                    OutputStream out = new BufferedOutputStream((new FileOutputStream(newFile)));
                    byte data[] = new byte[2048];
                    int count;
                    while ((count = in.read(data, 0, 2048)) > 0) {
                        out.write(data, 0, count);
                    }
                    out.close();
                }
            }
        }
        catch (IOException e)   {
            exception = true;
            throw e;
        }
        finally{
            try { in.close(); } catch (IOException e) { /*ignore*/ }
            if (exception)  {
                tmpDir.delete();
            }
        }
        
        File vcdPackageFile = findVCDPackageFile(tmpDir);
        assert vcdPackageFile.exists() : "VCD top file not found: "+vcdPackageFile;
        
        return vcdPackageFile;
    }

		private static File findVCDPackageFile(File dir) {
			for (File f : dir.listFiles()) {
				String name = f.getName();
				if (isPackageName(name) && f.isFile()) {
					return f;
				}
			}
			
			return null;
		}

		public static final boolean isPackageName(String name) {
			return name.startsWith(Constants.VCD_PACKAGE_XML_FILE_PREFIX) &&
							name.endsWith(Constants.VCD_PACKAGE_XML_FILE_SUFFIX) ;
		}
}
