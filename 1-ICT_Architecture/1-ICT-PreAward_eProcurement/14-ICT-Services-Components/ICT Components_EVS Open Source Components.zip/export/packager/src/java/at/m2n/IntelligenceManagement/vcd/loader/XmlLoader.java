/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.loader;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.mapping.LoaderXmlLogicImpl;
import at.m2n.IntelligenceManagement.vcd.packing.Constants;
import at.m2n.IntelligenceManagement.vcd.packing.FileUtil;
import at.m2n.IntelligenceManagement.vcd.packing.VcdZipReader;
import at.m2n.IntelligenceManagement.vcd.util.JdomXmlUtil;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;
import at.m2n.IntelligenceManagement.vcd.xmlschema.XmlValidator;

/**
 * Loads the XML input master document of the VCD pre-skeleton.
 * The document URL can be given as a ZIP URL:
 * <pre>
 * jar:file:../runner-server/vhosts/ossso/vcd_package_examples/simple_vpps.zip!/VCDPackage.xml
 * </pre>
 * or, for a normal file:
 * <pre>
 * file:../runner-server/vhosts/ossso/vcd_package_examples/simple_vpps/VCDPackage.xml
 * </pre>
 * The document also can be given as the raw ZIP file, this loader will find the files
 * even within the ZIP.
 * 
 * @author Fritz Ritzberger 17.05.2010
 */
public class XmlLoader implements Constants {
    
    private static final Log log = LogFactory.getLog(XmlLoader.class);
    
    /**
     * The XML-specific functionality the loader needs to work.
     */
    public interface LoaderXmlLogic
    {
        /** @return true if the passed element is a XML document reference that has to be resolved. */
        boolean isUnresolvedDocumentReferenceElement(Element element);
    }
    
    
    private final LoaderXmlLogic loaderLogic;
    private final VcdSchemaVariant schemaVariant;
    private String validationErrors;
    private boolean validate;
    
    /**
     * This constructor is for public use by all parties that process VCD XML documents in any way.
     * @param schemaVariant the location of the VCD schemas the XML must conform to.
     */
    public XmlLoader(VcdSchemaVariant schemaVariant) {
        this(new LoaderXmlLogicImpl(), schemaVariant);
    }
    
    /**
     * @param loaderLogic needed to figure out 
     *     if an XML element is a reference element naming a document that has to be imported.
     * @param schemaVariant the location of the VCD schemas the XML must conform to.
     */
    private XmlLoader(LoaderXmlLogic loaderLogic, VcdSchemaVariant schemaVariant) {
        assert loaderLogic != null : "Need a mapper to resolve document references!";
        this.loaderLogic = loaderLogic;
        this.schemaVariant = schemaVariant;
    }
    
    /**
     * @return the XML validation errors on loading the VCD files,
     *   will be null if validation flag was turned off, or no errors occurred on validation.
     */
    public String getValidationErrors() {
        return validationErrors;
    }

    /**
     * Loads the passed URL as XML document, validates it, and resolves all internal VCDReferenceIDs.
     * @param the top VCD file.
     * @return the expanded XML document.
     * @throws IOException when XML loading failed
     * @throws ParserConfigurationException 
     * @throws SAXException when XML loading failed
     */
    public Document load(File vcdPackageXml) throws JDOMException, IOException, ParserConfigurationException, SAXException {
        return load(vcdPackageXml, true);
    }
    
    /**
     * See above.
     * @param url the URL of the top VCD file.
     */
    public Document load(String url) throws JDOMException, IOException, ParserConfigurationException, SAXException {
        return load(url, true);
    }
    
    /**
     * See above.
     * @param validate when false the XML will not be validated.
     */
    public Document load(File vcdPackageXml, boolean validate) throws JDOMException, IOException, ParserConfigurationException, SAXException {
        String url = vcdPackageXml.getName().toLowerCase().endsWith(".zip")
                ? new VcdZipReader().getVcdPackageXmlZipUrl(vcdPackageXml)
                : vcdPackageXml.toURI().toURL().toExternalForm();
        return load(url, validate);
    }
    
    /**
     * See above.
     * @param validate when false the XML will not be validated.
     */
    public Document load(String url, boolean validate) throws JDOMException, IOException, ParserConfigurationException, SAXException {
        this.validate = validate;
        File vcdPackageXmlFile = null;
        try {
            if (url.toLowerCase().endsWith(".zip")) {
                vcdPackageXmlFile = new VcdZipReader().unpack(url);
                url = vcdPackageXmlFile.toURI().toURL().toExternalForm();
            }
            return loadVcdPackage(url);
        }
        finally {
            if (vcdPackageXmlFile != null)
                FileUtil.deleteDir(vcdPackageXmlFile);
        }
    }
    
    
    private Document loadVcdPackage(String url) throws JDOMException, IOException, ParserConfigurationException, SAXException {
        URL theUrl = new URL(url);
        validate(theUrl, getSchemaFile(true));
        return load(theUrl.openStream(), url);
    }
    
    private Document loadVcd(String baseUrl, String uuid) throws JDOMException, IOException, ParserConfigurationException, SAXException {
    	String url = concatUrl(baseUrl, VCD_BASEDIR_NAME_PREFIX + uuid + "/" + VCD_XML_FILE_PREFIX + VCD_XML_FILE_SEPARATOR + uuid + VCD_XML_FILE_SUFFIX); 
        URL theUrl = new URL(url);
        validate(theUrl, getSchemaFile(false));
        return load(theUrl.openStream(), url);
    }
    
    private Document load(InputStream instream, String url) throws JDOMException, IOException, ParserConfigurationException, SAXException {
        assert instream != null && url != null : "Need InputStream *AND* URL to parse XML pre-skeleton!";
        
        SAXBuilder builder = new SAXBuilder();
        try {
            Document doc = builder.build(instream); // would detect non-well-formed XML
            resolveReference(doc.getRootElement(), url);
            return doc;
        }
        finally {
            instream.close();
        }
    }

    /**
     * Puts the vcd[n]/VCD.xml reference documents into the main document
     * in place of VCDReferenceID element.
     */
    private void resolveReference(Element element, String url) throws MalformedURLException, IOException, JDOMException, ParserConfigurationException, SAXException   {
        final boolean isContainer = element.getChildren().size() > 0;   //mapper.isContainer(element);
        
        if (isContainer == false)   {
            String uuid = element.getText();
            
            // resolve any VCDReferenceID element
            if (uuid != null && uuid.trim().length() > 0 && loaderLogic.isUnresolvedDocumentReferenceElement(element))   {
                Document doc = loadVcd(url, uuid);
                
                // move the VCD root element into this document
                Element rootElement = doc.getRootElement();
                doc.removeContent(rootElement);
                
                // replace the VCDReferenceId element by VCD element
                JdomXmlUtil.replaceElementBy(element, rootElement);
            }
        }
        else    {
            List<Element> children = element.getChildren();
            // must clone list to avoid concurrent modification
            Element [] childArray = children.toArray(new Element [children.size()]);
            for (Element child : childArray)  {
                resolveReference(child, url);
            }
        }
    }
    
    private String getSchemaFile(boolean isVcdPackage)    {
        return schemaVariant == null ? null : isVcdPackage ? schemaVariant.vcdPackageSchemaUrl : schemaVariant.vcdSchemaUrl;
    }

    private void validate(URL url, String schemaUrl) throws ParserConfigurationException, SAXException, IOException {
        if (validate == false)  {
            log.info("XML schema validation was turned off for "+url);
            return;
        }
        
        assert schemaVariant != null : "Having no schema variant for validation!";

        InputStream instream = url.openStream();
        XmlValidator validator = XmlValidator.getInstance(schemaUrl);
        validationErrors = validator.validate(instream);
        if (validationErrors != null) {   // not valid against schema
            log.error("Schema validation errors for "+url+" are: "+validationErrors);
            throw new SAXException("Validaton errors are:\n"+validationErrors);
        }
        else    {
            log.info("XML schema validation succeeded for "+url);
        }
    }

    private String concatUrl(String docUrl, String relativePath) throws MalformedURLException, IOException {
        docUrl = docUrl.replace('\\', '/');   // be safe
        relativePath = relativePath.replace('\\', '/');   // against windozer pathes
        
        int i = docUrl.lastIndexOf("/");   // ref url will be relative to this one
        String newUrl = i >= 0 ? docUrl.substring(0, i + 1) : "";
        if (newUrl.endsWith("/") == false)  {
            newUrl = newUrl + '/';
        }
        newUrl = newUrl + relativePath;
        return newUrl;
    }

}
