/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema.xsominterpreter;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.Stack;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;

import com.sun.xml.xsom.XSComplexType;
import com.sun.xml.xsom.XSContentType;
import com.sun.xml.xsom.XSElementDecl;
import com.sun.xml.xsom.XSModelGroup;
import com.sun.xml.xsom.XSModelGroup.Compositor;
import com.sun.xml.xsom.XSModelGroupDecl;
import com.sun.xml.xsom.XSParticle;
import com.sun.xml.xsom.XSSchema;
import com.sun.xml.xsom.XSSchemaSet;
import com.sun.xml.xsom.XSSimpleType;
import com.sun.xml.xsom.XSTerm;
import com.sun.xml.xsom.XSType;
import com.sun.xml.xsom.parser.XSOMParser;

/**
 * The XML schema information is needed to sort the XML children
 * created by the RDF->XML transformation (no sort order exists in RDF),
 * and to detect missing required elements before validation.
 * <p />
 * This class is for analyzing the VCD XML schema dynamically at runtime.
 * The advantage of such is that no source generation or other maintenance
 * has to be done when the schema changes.
 * Mind that this does not affect the RDF/XML Mapper, this has to maintained
 * manually anyway.
 * <p />
 * CAUTION: no other schema capacities than those required by VCD were
 * implemented here. Type-inheritance should work, but a lot of other things,
 * particularly XML attributes, were NOT implemented!
 * 
 * @author Fritz Ritzberger  01.07.2010
 */
public class XsomInterpreter {
    
    private static final Log log = LogFactory.getLog(XsomInterpreter.class);
    
    private XSSchemaSet schemaSet;  // the main schema and all imported ones
    private Stack<XSElementDecl> recursionStack = new Stack<XSElementDecl>();   // detect element recursion
    
    /**
     * Creates an XSOM schema interpreter.
     * @param schemaUrl the URL of the schema to analyze.
     * @throws MalformedURLException when schema URL is invalid.
     * @throws SAXException the exception 
     */
    public XsomInterpreter(String schemaUrl) throws MalformedURLException, SAXException {
        log.info("Starting XSOM on "+schemaUrl);
        XSOMParser parser = new XSOMParser();
        parser.setErrorHandler(new SchemaErrorHandler());
        URL url = new URL(schemaUrl);
        parser.parse(url);
        this.schemaSet = parser.getResult();
        
        assert schemaSet != null : "No schema could be read from "+schemaUrl;
    }

    /**
     * Returns a Descriptor hierarchy for passed element, containing Descriptors of all
     * children, starting with passed root.
     * @param rootLocalName the local name of the desired element which MUST be a top-level element.
     * @param rootNamespace the namespace of the desired element.
     * @return a Descriptor hierarchy for passed root element.
     */
    public Element getTopLevelElementDescriptor(String rootLocalName, String rootNamespace) {
        XSElementDecl elementDecl = findTopLevelElementDecl(rootLocalName, rootNamespace);
        assert elementDecl != null : "Top-level element not found: "+rootLocalName+", namespace "+rootNamespace;
        log.debug("Found root element: "+elementDecl);
        return getElementDescriptor(elementDecl);
    }
    
    /**
     * @param rootLocalName the desired element to build a tree for, or the first found when null,
     *      else throw exception, and throw exception when name is not null and ambiguous.
     * @param rootNamespace the desired element namespace to build a tree for,
     *      can be null when rootLocalName is null.
     * @return the found top level element declaration.
     */
    private XSElementDecl findTopLevelElementDecl(String rootLocalName, String rootNamespace) {
        XSElementDecl elementDecl = null;
        for (Iterator<XSSchema> schemaIterator = schemaSet.iterateSchema(); schemaIterator.hasNext(); ) {
            XSSchema schema = schemaIterator.next();
            
            if (rootNamespace == null || schema.getTargetNamespace().equals(rootNamespace))   {
                XSElementDecl ed = null;
                if (rootLocalName != null)  {
                    ed = schema.getElementDecl(rootLocalName);
                }
                else if (elementDecl == null)   {
                    Iterator<XSElementDecl> elementDeclIterator = schema.iterateElementDecls();
                    if (elementDeclIterator.hasNext())
                        ed = elementDeclIterator.next();
                }
                
                if (ed != null) {
                    if (elementDecl != null)    {
                        if (rootLocalName != null && rootNamespace != null)
                            throw new IllegalArgumentException("Ambiguous rootLocalName given: "+rootLocalName+" for namespace "+rootNamespace);
                    }
                    else    {
                        elementDecl = ed;
                    }
                }
            }
        }
        return elementDecl;
    }

    private Element getElementDescriptor(XSElementDecl elementDecl)   {
        XSType type = elementDecl.getType();
        Element elementDescriptor = new Element(elementDecl.getTargetNamespace(), elementDecl.getName(), null);
        
        XSSimpleType simpleType = type.asSimpleType();
        XSComplexType complexType = type.asComplexType();
        if (simpleType == null && complexType != null && complexType.getContentType().asEmpty() == null)   {
            simpleType = complexType.getContentType().asSimpleType();
        }
        
        if (simpleType != null)   {
            return new SimpleElement(elementDescriptor, simpleType.getName());
        }
        else if (complexType != null)   {
            if (pushRecursion(elementDecl) == false)   {
                return new UnresolvedRecursiveElement(elementDescriptor);
            }
            
            try {
                SpacedName typeDescriptor = new SpacedName(complexType.getTargetNamespace(), complexType.getName());
                XSContentType contentType = complexType.getContentType();
                if (contentType.asEmpty() != null)  {
                    return new ComplexElement(elementDescriptor, typeDescriptor, null);
                }
                
                XSParticle particle = contentType.asParticle();
                assert particle != null : "No Particle found in ComplexType "+complexType.getName();
                
                XSModelGroup modelGroup = getModelGroup(particle);
                Element.ChildListType groupType = getChildListTypeFor(modelGroup);
                ComplexElement complexElement = new ComplexElement(elementDescriptor, typeDescriptor, groupType);
                setMinMaxOccurs(complexElement, particle);
            
                addChildren(modelGroup, complexElement);
                
                return complexElement;
            }
            finally {
                popRecursion();
            }
        }
        throw new IllegalArgumentException("Unsupported type category: "+type);
    }
    
    private boolean pushRecursion(XSElementDecl elementDecl) {
        for (XSElementDecl ed : recursionStack)   {
            if (ed.equals(elementDecl))
                return false;
        }
        recursionStack.push(elementDecl);
        return true;
    }

    private void popRecursion() {
        recursionStack.pop();
    }

    private XSModelGroup getModelGroup(XSParticle particle)   {
        XSTerm term = particle.getTerm();
        XSModelGroup modelGroup = term.asModelGroup();
        if (modelGroup == null)  {
            XSModelGroupDecl modelGroupDecl = term.asModelGroupDecl();
            modelGroup = modelGroupDecl.getModelGroup();
        }
        assert modelGroup != null: "No model group could be detected: "+particle;
        return modelGroup;
    }
        
    private Element.ChildListType getChildListTypeFor(XSModelGroup modelGroup)   {
        Element.ChildListType groupType = null;
        Compositor compositor = modelGroup.getCompositor();
        if (compositor == Compositor.ALL)
            groupType = Element.ChildListType.ALL;
        else if (compositor == Compositor.CHOICE)
            groupType = Element.ChildListType.CHOICE;
        else if (compositor == Compositor.SEQUENCE)
            groupType = Element.ChildListType.SEQUENCE;

        return groupType;
    }
    
    private void addChildren(XSModelGroup modelGroup, ComplexElement complexElement) {
        for (XSParticle particle : modelGroup.getChildren())    {
            Element descriptor = null;
            
            XSTerm term = particle.getTerm();
            if (term.isElementDecl())   {
                descriptor = getElementDescriptor(term.asElementDecl());
            }
            else if (term.isModelGroupDecl() || term.isModelGroup())   {
                XSModelGroup subModelGroup = getModelGroup(particle);
                addChildren(subModelGroup, complexElement);
            }
            
            if (descriptor != null)  {
                setMinMaxOccurs(descriptor, particle);
                complexElement.add(descriptor);
            }
        }
    }
    
    private void setMinMaxOccurs(Element descriptor, XSParticle particle)  {
        String min = ""+particle.getMinOccurs();
        String max = particle.getMaxOccurs() == XSParticle.UNBOUNDED ? Element.UNBOUNDED : ""+particle.getMaxOccurs();
        descriptor.setMinMaxOccurs(new String [] { min, max });
    }

}
