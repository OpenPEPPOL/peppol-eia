/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.util;

import java.util.ArrayList;
import java.util.List;

import org.jdom.Element;


/**
 * Common utilities in conjunction with XML and JDOM.
 * 
 * @author Fritz Ritzberger  07.06.2010
 */
public final class JdomXmlUtil {

    /**
     * Replaces an XML element by another one.
     * @param toReplace the element to be replaced, can not be null.
     * @param substitute the new element to insert instead of toReplace, can not be null.
     */
    public static void replaceElementBy(Element toReplace, Element substitute)    {
        assert toReplace != null : "No XML element to replace was given!";
        assert substitute != null : "No XML substitution element was given as replacement!";
        
        Element parent = toReplace.getParentElement();
        List<Element> children = parent.getChildren();
        
        // remember its index for insertion of new element
        int referenceIdIndex = children.indexOf(toReplace);
        parent.removeContent(toReplace);
        
        // insert new element, at position, into child list
        children.add(referenceIdIndex, substitute);
    }

    /**
     * Debug helper.
     * @param e the element to output its path.
     * @return the path parts of the passed XML element, concatenated by "/", with a leading "/".
     */
    public static String xpath(Element e) {
        StringBuffer sb = new StringBuffer();
        while (e != null)   {
            sb.insert(0, "/"+e.getName());
            e = e.getParentElement();
        }
        return sb.toString();
    }

    /**
     * Finds any XML element that matches the passed path, starting the
     * search from passed parent element, including the startSearchElement itself.
     * @param startSearchElement the element on which to start the hierarchical search.
     * @param part the namespace:name to find in startSearchElement.
     * @return list of all elements that match.
     */
    public static List<Element> findByName(Element startSearchElement, Path.Part part) {
        List<Element> returnList = new ArrayList<Element>();
        if (matches(startSearchElement, part))  {
            returnList.add(startSearchElement);
        }
        for (Object o : startSearchElement.getChildren())   {
            Element child = (Element) o;
            returnList.addAll(findByName(child, part));
        }
        return returnList;
    }
    
    /**
     * @param element the XML element to match.
     * @param part the path part to check.
     * @return true if the element name and its namespace both equal the passed path part.
     */
    public static boolean matches(Element element, Path.Part part) {
        return element.getName().equals(part.name) && element.getNamespaceURI().equals(part.namespace);
    }

    /**
     * Finds all direct XML children that match the passed path, starting the
     * search from passed parent element, excluding the parent itself.
     * @param startSearchElement the element on which to start the hierarchical search.
     * @param path the path to find in startSearchElement.
     */
    public static List<Element> findDirectChildren(Element parent, Path.Part part) {
        List<Element> returnList = new ArrayList<Element>();
        for (Object o : parent.getChildren())   {
            Element child = (Element) o;
            if (matches(child, part))   {
                returnList.add(child);
            }
        }
        return returnList;
    }
    
    /**
     * @param parent the parent element.
     * @param part the namespace:name to find.
     * @return the single child with passed namespace:name, IllegalArgumentException when not found or ambiguous.
     */
    public static Element findSingleDirectChild(Element parent, Path.Part part) {
        return findSingleDirectChild(parent, part, true);
    }
    
    /**
     * @param throwExceptionWhenNotFound when true an exception is thrown when the result is ambiguous or not existent.
     */
    public static Element findSingleDirectChild(Element parent, Path.Part part, boolean throwExceptionWhenNotFound) {
        List<Element> found = findDirectChildren(parent, part);
        if (throwExceptionWhenNotFound && found.size() != 1)
            throw new IllegalArgumentException("The single child element "+part+" could not be identified within "+JdomXmlUtil.xpath(parent));

        return found.size() == 1 ? found.get(0) : null;
    }

}
