/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.mapping;

import org.jdom.Element;

import at.m2n.IntelligenceManagement.vcd.loader.XmlLoader;

/**
 * Contains the XML logic needed to read a VCD Package.
 * 
 * @author Fritz Ritzberger 25.06.2010
 */
public class LoaderXmlLogicImpl implements XmlLoader.LoaderXmlLogic, MappingNames {
    /**
     * @param element the XML element to be checked if it is an external XML document reference.
     * @return true when passed element is an unresolved XML document reference.
     */
    @Override
    public boolean isUnresolvedDocumentReferenceElement(Element element) {
        return element.getName().equals(XML_REFERENCE_ELEMENT) && element.getNamespaceURI().equals(XML_REFERENCE_NAMESPACE);
    }

}
