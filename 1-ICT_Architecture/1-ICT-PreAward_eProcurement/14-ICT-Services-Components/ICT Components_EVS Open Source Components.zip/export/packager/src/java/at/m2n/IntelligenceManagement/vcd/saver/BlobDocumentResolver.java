/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.saver;

import java.io.IOException;
import java.io.InputStream;

/**
 * Resolves references to document BLOBs of VCDPackage or VCD EvidenceCollectors.
 * This is to be implemented and passed in by PeppolSkeletonPackagingService.
 * 
 * @author Fritz Ritzberger  15.06.2010
 */
public interface BlobDocumentResolver   {
    /**
     * Resolves the passed URL and returns an InputStream to a BLOB.
     * 
     * @param documentResourceUri the RDF property resource URI to resolve to  BLOB input stream.
     * @return the BLOB of the attached document, occurring in EvidenceCollectors and VCDPackage.
     * @throws IOException when the BLOB could not be resolved.
     */
    public InputStream resolveBlob(String documentResourceUri) throws IOException;

}
