/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.packing;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipOutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import at.m2n.IntelligenceManagement.vcd.Util;
import at.m2n.IntelligenceManagement.vcd.VcdCompound;
import at.m2n.IntelligenceManagement.vcd.VcdLanguage;
import at.m2n.IntelligenceManagement.vcd.VcdPackageLoader;
import at.m2n.IntelligenceManagement.vcd.VcdSummarizer;
import at.m2n.IntelligenceManagement.vcd.saver.PathAndDocument;
import at.m2n.IntelligenceManagement.vcd.saver.XmlSaver;
import at.m2n.IntelligenceManagement.vcd.summary.CompoundNode;
import at.m2n.IntelligenceManagement.vcd.summary.NodeUtil;

/**
 * A utility to write ZIP files from an VCD XmlSaver output,
 * or from a file-system directory.
 * 
 * @author Fritz Ritzberger 28.06.2010
 */
public class VcdZipWriter {
	
    private static final Log log = LogFactory.getLog(VcdZipWriter.class);
	
    /**
     * Packs passed VCD Packages and VCDs into a ZIP file with a random name.
     * @param vcdPackage the main VCD data to be written (XML in VCD root).
     * @param vcdList the list of VCD data referenced by the main VCD.
     * @param infoText the error messages, if any, that should appear in "info.txt" file in ZIP root.
     * @return the created ZIP file.
     * @throws IOException when things go wrong.
     */
    public File pack(XmlSaver saver, String infoText) throws IOException {
    	return pack(saver, infoText, false, null, null);
    }
    
    public File pack(XmlSaver saver, String infoText, boolean addSummary, File tempDir, String language) throws IOException {
        List<PathAndDocument> newList = new ArrayList<PathAndDocument>(saver.getVcdList());
        newList.add(saver.getVcdPackage());
        File zipFile = pack(saver.getVcdPackageUUID(), newList, infoText);
        
        if (addSummary) {
    		zipFile = addSummaryToZip(zipFile, language, saver.getVcdPackageUUID());
    	}
    	
        return zipFile;
    }
    
    private File addSummaryToZip(File zipFile, String mainLangTag, String uuid) throws IOException {
    	File packageFile = VcdZipReader.unpack(zipFile.toURL().toString());
    	File unpackedDir = packageFile.getParentFile();
        final VcdCompound compound = VcdPackageLoader.loadFromUnpackedDir(unpackedDir);
        final CompoundNode root = compound.getCompoundNode();

        final String fileName = "summary_" + uuid + ".pdf";
        
        final File dest = new File(unpackedDir, fileName);
        
        VcdLanguage mainLang = VcdLanguage.EN;

        if (mainLangTag != null) {
            try {
            	mainLang = VcdLanguage.valueOf(mainLangTag.toUpperCase());
            } catch (Exception e) {
            	log.warn("Unable to get desired language "+mainLangTag+" for summary, defaulting to "+mainLang);
            }
        }
        
        mainLang = VcdLanguage.EN;
        
        try {
            VcdSummarizer sum = new VcdSummarizer();
            File temp = sum.renderPackageToTempPdf(unpackedDir, mainLang);
            if (dest.exists()) dest.delete();
            
            boolean renamed = temp.renameTo(dest);
            if (!renamed) {
                Util.copyFile(temp, dest);
                temp.delete();
            }
            
            
            
        } catch (Exception e) {
        	log.warn("Unable to build summary PDF, returning package without one.", e); 
        	return zipFile;
        }

        zipFile.delete();
        File packed = pack(uuid, unpackedDir);
        FileUtil.deleteDir(unpackedDir);
        return packed;
	}

	/**
     * Packs passed directory, containing VCDPackage.xml and VCD XMLs, into a ZIP file with a random name.
     * @param directory the directory to pack.
     * @return the created ZIP file.
     * @throws IOException when things go wrong.
     */
    public File pack(File directory) throws IOException    {
    	return pack("unknown", directory);
    }
    
    public File pack(String packageUUID, File directory) throws IOException    {
        if (directory == null || directory.isDirectory() == false)
           throw new IllegalArgumentException("Invalid directory to pack: "+directory);
 
        String absolutePath = directory.getAbsolutePath();
        if (absolutePath.endsWith(File.separator) == false)
            absolutePath = absolutePath + File.separator;
        
        List<PathAndDocument> list = new ArrayList<PathAndDocument>();
        listFiles(directory, list, absolutePath);
        
        return pack(packageUUID, list, null);
    }
    
    private File pack(String packageUUID, Collection<PathAndDocument> vcdList, String infoText) throws IOException {
    	StringBuilder sbInfo = new StringBuilder(infoText == null ? "" : infoText);
    
    	File tempDir = File.createTempFile("VCDPackaging-", ".tempdir");
    	tempDir.delete();
    	tempDir.mkdirs();
    	
      File zipFile = new File(tempDir, Constants.VCD_PACKAGE_ZIP_FILE_PREFIX + Constants.VCD_PACKAGE_ZIP_FILE_SEPARATOR + packageUUID + Constants.VCD_PACKAGE_ZIP_FILE_SUFFIX);
      zipFile.deleteOnExit();
      
        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
        try {
            for (PathAndDocument pathAndDocument : vcdList) {
            	  createZipEntry(zos, pathAndDocument.relativePath);
                createZipEntry(zos, pathAndDocument);
                
                for (PathAndDocument attachment : pathAndDocument.getAttachments())
                	try {
                    createZipEntry(zos, attachment, pathAndDocument.relativePath);
                   } catch (Exception e) {
                  	 sbInfo.append("\n");
                  	 sbInfo.append("With file "+attachment.relativePathWithFileName+":\n");
                  	 StringWriter sw = new StringWriter();
                  	 PrintWriter pw = new PrintWriter(sw);
                  	 e.printStackTrace(pw);
                  	 sbInfo.append(sw.toString());
                   }
            
            }
            
            try {
              zos.putNextEntry(new ZipEntry("info.txt"));
              zos.write(sbInfo.toString().getBytes());
            } catch (ZipException e) {
            	//ignore: probably just: info.txt already there
            }
        }
        finally  {
            zos.close();
        }
        return zipFile;
    }
    


		private void createZipEntry(ZipOutputStream zos, PathAndDocument pathAndDocument) throws IOException    {
    	createZipEntry(zos, pathAndDocument, null);
    }
		
    private void createZipEntry(ZipOutputStream zos, String relativePath) throws IOException {
    	if (relativePath != null) {
    		ZipEntry ze = new ZipEntry(relativePath+"/");
    		try {
    			zos.putNextEntry(ze);
    		} catch (ZipException zex) {
    			//ignore... probably just a duplicate entry for a directory or something.
    		}
    	}
			
		}		
    	
    private void createZipEntry(ZipOutputStream zos, PathAndDocument pathAndDocument, String prefixPath) throws IOException    {
    	if (pathAndDocument.relativePathWithFileName == null)
    		return; //when testing, we might end up getting empty blobs?!
    	
    	String path = pathAndDocument.relativePathWithFileName;
    	if (prefixPath != null)
    		path = prefixPath + "/" + path;
    	
    	zos.putNextEntry(new ZipEntry(path));
      pathAndDocument.writeDocument(zos, false);
    }
    
    private void listFiles(File directory, List<PathAndDocument> list, String absolutePath)    {
        for (final File f : directory.listFiles())    {
            if (f.isDirectory() == false && f.isFile())    {    // beware of UNIX symbolic links
                // subtract parent directory from filename, this makes it relative
                String name = f.getAbsolutePath().substring(absolutePath.length()).replace(File.separatorChar, '/');
                
                PathAndDocument pd = new PathAndDocument(name)  {
                    @Override
                    public void writeDocument(OutputStream out, boolean writeOptimized) throws IOException {
                        InputStream in = new BufferedInputStream(new FileInputStream(f));
                        try {
                            int c;
                            while ((c = in.read()) >= 0) {
                                out.write(c);
                        	}
                        }
                        finally {
                            in.close();
                        }
                    }
                };
                list.add(pd);
            }
            else if (f.isDirectory())    {
                listFiles(f, list, absolutePath);
            }
        }
    }

}
