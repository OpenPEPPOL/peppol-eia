/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import at.m2n.IntelligenceManagement.vcd.mapping.CommonMappingNames;

/**
 * "Parameter Object" that contains all necessary informations to use a VCD XML Schema.
 * Instances can be obtained by calling the static factory.
 * 
 * @author Fritz Ritzberger 06.07.2010
 */
public class VcdSchemaVariant {
    
    /**
     * Possible constructor parameter values, designating different XML schema variants.
     */
    public enum Name
    {
        SKELETON(false, "INVALID"),
        PRESKELETON(false, "INVALID"),
        
        
        TENDERER_SKELETON(false, "vcd-t-skeleton"),
        TENDERER_CRITERION_SKELETON(false, "vcd-tc-skeleton"),
        TENDERER_CRITERION_EVIDENCE_SKELETON(false, "vcd-tce-skeleton"),
        
        FULL(true, "vcd-completed");
        
        private final boolean hasEvidenceDocuments;
        private final String vcdTypeCode;

				private Name(boolean hasEvidenceDocuments, String vcdTypeCode) {
					this.hasEvidenceDocuments = hasEvidenceDocuments;
					this.vcdTypeCode = vcdTypeCode;
				}

				public boolean hasEvidenceDocuments() {
					return hasEvidenceDocuments;
				}
				
			    public String getVCDTypeCode() {
			    	return vcdTypeCode;
			    }
        
    }
    
    /** The URL of VCDPackage schema. */
    public final String vcdPackageSchemaUrl;
    /** The root element name in VCDPackage. */
    public final String vcdPackageRootElement;
    /** The URL of VCD schema. */
    public final String vcdSchemaUrl;
    /** The root element name in VCD. */
    public final String vcdSchemaRootElement;
    
    private Name name;

    /**
     * @param vcdPackageSchemaUrl the URL of VCDPackage schema.
     * @param vcdPackageRootElement the root element name in VCDPackage.
     * @param vcdSchemaUrl the URL of VCD schema.
     * @param vcdSchemaRootElement the root element name in VCD.
     */
    private VcdSchemaVariant(
            Name name,
            String vcdPackageSchemaUrl,
            String vcdPackageRootElement,
            String vcdSchemaUrl,
            String vcdSchemaRootElement)  {
        
    		this.name = name;
        this.vcdPackageSchemaUrl = getClass().getResource(vcdPackageSchemaUrl).toString();
        this.vcdPackageRootElement = vcdPackageRootElement;
        this.vcdSchemaUrl = getClass().getResource(vcdSchemaUrl).toString();
        this.vcdSchemaRootElement = vcdSchemaRootElement;
    }
    
    public boolean hasEvidenceDocuments() {
    	return name.hasEvidenceDocuments();
    }
    
    /** Overridden to be good for hashing instances of this class. */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof VcdSchemaVariant == false)
            return false;
        VcdSchemaVariant other = (VcdSchemaVariant) obj;
        return
            vcdPackageSchemaUrl.equals(other.vcdPackageSchemaUrl) &&
            vcdPackageRootElement.equals(other.vcdPackageRootElement) &&
            vcdSchemaUrl.equals(other.vcdSchemaUrl) &&
            vcdSchemaRootElement.equals(other.vcdSchemaRootElement);
    }
    
    /** Overridden to be good for hashing instances of this class. */
    @Override
    public int hashCode() {
        return vcdPackageSchemaUrl.hashCode() + vcdPackageRootElement.hashCode() + vcdSchemaUrl.hashCode() + vcdSchemaRootElement.hashCode();
    }
    
    @Override
    public String toString() {
        return "vcdPackageSchemaUrl="+vcdPackageSchemaUrl+", vcdPackageRootElement="+vcdPackageRootElement+", vcdSchemaUrl="+vcdSchemaUrl+", vcdSchemaRootElement="+vcdSchemaRootElement;
    }
    
    /** @return the Variant this was created for. */
    public Name getName()    {
        return name;
    }
    
    /**
     * Configures VcdSchemaVariant instances from given directory path.
     * The top-schemas are expected to be in directory <i>maindoc</i> below the given directory.
     * Mind that the passed URL already must have a leading "file:" if it points to the file-system.
     * @param directoryUrl the base URL where the top schema files are in under <i>maindoc</i>.
     * @param variant the selector for the schema variant.
     * @return an instance using schema files from the m2n "ossso" directory structure.
     */
    public static VcdSchemaVariant newInstance(String directoryUrl, Name variant) throws MalformedURLException    {
        switch (variant)    {
            case PRESKELETON:
            case TENDERER_SKELETON:
                return new VcdSchemaVariant(
                        variant,
                        directoryUrl + SchemaFileNames.PATH_PKG_PRESKELETON,
                        CommonMappingNames.XML_VCDPACKAGE_ROOT_ELEMENT,
                        directoryUrl + SchemaFileNames.PATH_PRESKELETON,
                        CommonMappingNames.XML_VCD_ROOT_ELEMENT);
            
            case TENDERER_CRITERION_SKELETON:
              return new VcdSchemaVariant(
                      variant,
                      directoryUrl + SchemaFileNames.PATH_PKG_TCSKELETON,
                      CommonMappingNames.XML_VCDPACKAGE_ROOT_ELEMENT,
                      directoryUrl + SchemaFileNames.PATH_TCSKELETON,
                      CommonMappingNames.XML_VCD_ROOT_ELEMENT);

            case SKELETON:
            case TENDERER_CRITERION_EVIDENCE_SKELETON:
                return new VcdSchemaVariant(
                        variant,
                        directoryUrl + SchemaFileNames.PATH_PKG_SKELETON,
                        CommonMappingNames.XML_VCDPACKAGE_ROOT_ELEMENT,
                        directoryUrl + SchemaFileNames.PATH_SKELETON,
                        CommonMappingNames.XML_VCD_ROOT_ELEMENT);
            case FULL:
                return new VcdSchemaVariant(
                        variant,
                        directoryUrl + SchemaFileNames.PATH_PKG_FULL,
                        CommonMappingNames.XML_VCDPACKAGE_ROOT_ELEMENT,
                        directoryUrl + SchemaFileNames.PATH_FULL,
                        CommonMappingNames.XML_VCD_ROOT_ELEMENT);
            default:
                throw new IllegalArgumentException("Type of schema variant not implemented: "+variant);
        }
    }
    
    /**
     * Configures VcdSchemaVariant instances from M2N schema file locations.
     * Do not use unless you are sure those locations work for your environment!
     * @param vhostDirectory the base directory for building a path to schema files.
     * @param variant the selector for the schema variant.
     * @return an instance using schema files from the m2n "ossso" directory structure.
     */
    public static VcdSchemaVariant newInstance(File vhostDirectory, Name variant) throws MalformedURLException    {
        return newInstance(fileUrl(vhostDirectory, SchemaFileNames.BASEDIR), variant);
    }
    
    private static String fileUrl(File vhostDirectory, String filename) throws MalformedURLException  {
        File relativeFile = new File(vhostDirectory, filename);
        try {
            return relativeFile.getCanonicalFile().toURI().toURL().toExternalForm();
        } catch (IOException e) {
            throw new MalformedURLException("could not canonize " + relativeFile.getPath());
        }
    }


}
