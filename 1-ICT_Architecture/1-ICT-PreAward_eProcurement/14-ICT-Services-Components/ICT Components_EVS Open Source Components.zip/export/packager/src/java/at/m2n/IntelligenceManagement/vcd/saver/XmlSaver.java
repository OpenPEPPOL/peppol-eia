/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.saver;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;
import org.jdom.output.XMLOutputter;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.mapping.SaverXmlLogicImpl;
import at.m2n.IntelligenceManagement.vcd.packing.Constants;
import at.m2n.IntelligenceManagement.vcd.xmlschema.Schemifier;
import at.m2n.IntelligenceManagement.vcd.xmlschema.VcdSchemaVariant;
import at.m2n.IntelligenceManagement.vcd.xmlschema.XmlValidator;

/**
 * Splits the transformer result XML document into several documents / files:
 * <ul>
 *  <li>VCDPackage.xml (to be put into top directory)</li>
 *  <li>0-n VCD.xml documents, put into subdirs names vcd1 - vcd[n],
 *      below top directory, referenced by "VCDReferenceID" elements</li>
 * </ul>
 * After constructor call they are ready to be packed into a ZIP.
 * <p />
 * Writes generated UUID values into all empty UUID elements.
 * <p />
 * This class also makes saved documents conform to the VCD schema
 * by sorting child lists and adding required elements (empty).
 * <p />
 * Sample application in conjunction with VcdZipWriter:
 * <pre>
 *  XmlSaver saver = new XmlSaver(document, vcdPackageSchema, vcdSchema);
 *  new VcdZipWriter().pack(saver.getVcdPackage(), saver.getVcdList(), "This appears in info.txt");
 * </pre>
 * 
 * @author Fritz Ritzberger  02.06.2010
 */
public class XmlSaver {
	private static final Pattern P_NON_ASCII = Pattern.compile("[^\\p{Print}\\p{Blank}]");
	private static final String FILE_URI_PREFIX = "urn:eu:peppol:vcd:document:";  

    private static final Log log = LogFactory.getLog(XmlSaver.class);

    /**
     * The transformer's XML-specific functionality the saver needs to work.
     */
    public interface SaverXmlLogic
    {
        // common SaverXmlLogic
        
        /** @return true when the passed element is an element whose sub-elements have to be extracted to a separate XML document. */
        boolean isResolvedDocumentReferenceElement(Element element);
        
        /** @return a newly created XML element that represents an XML document reference ("VCDReferenceID"). */
        Element createUnresolvedDocumentReferenceElement(String relativePath);
        
        /** @return true if the passed element is an UUID element (ignored on import, filled with generator value on export). */
        boolean isUuidGeneratorXmlElement(Element element);
        
        /** @return a new UUID generator value. */
        String generateUuid4Xml();
        
        // transformer specific SaverXmlLogic
        
        /**
         * Called at end of saving process for every involved XML document.
         * Can be used to e.g. remove conversion-specific namespaces.
         * @param rootElement the document's root element.
         */
        void editRootElement(Element rootElement);
        
        /** @return true if passed element is a document BLOB URI to be used for retrieving an InputStream of an evidence attachment document. */
        boolean isEvidenceDocumentBlobUri(Element element);
        
        /** @return true if passed element is the DocumentReference sub-element holding the filename of an attachment. */
        boolean isEvidenceDocumentBlobFilename(Element element);
    }
    
    /** The resulting top VCDPackage document. */
    private PathAndDocument vcdPackagePathAndDocument;
    
    /** The resulting List of VCD documents, in order of occurrence in input document. */
    private List<PathAndDocument> vcdList = new ArrayList<PathAndDocument>();

    private VcdSchemaVariant schemaVariant;
    private SaverXmlLogic saverXmlLogic;
    private Document vcdPackageXml;
    private int vcdCounter;
    private String vcdPackageUUID;
    
    /**
     * Splits passed document.
     * Does not support schemifying and BLOB processing.
     * @param vcdXmlDocument the XML document to split.
     * @param schemaVariant the schema for validation.
     * @throws SAXException 
     * @throws MalformedURLException 
     */
    public XmlSaver(Document vcdXmlDocument, VcdSchemaVariant schemaVariant) throws MalformedURLException, SAXException {
        this(vcdXmlDocument, schemaVariant, false);
    }
    
    /**
     * Splits passed document and schemifies the results.
     * Does not support BLOB processing.
     * @param vcdXmlDocument the XML document to split.
     * @param schemaVariant the schema for schemification and validation.
     * @param schemify when true, schemification is performed, i.e. elements are sorted and required elements are added (empty).
     * @throws SAXException 
     * @throws MalformedURLException 
     */
    public XmlSaver(Document vcdXmlDocument, VcdSchemaVariant schemaVariant, boolean schemify) throws MalformedURLException, SAXException {
        this(
            vcdXmlDocument,
            schemaVariant,
            new SaverXmlLogicImpl(),
            null,   // BLOBs not supported
            schemify && schemaVariant != null ? Schemifier.getInstance(schemaVariant) : null);
    }
    
    /**
     * Splits passed document and schemifies the results.
     * Captures the BlobResolver of all referenced BLOBs (if any) and adds them as attachments
     * to their referencing documents (searching for XML element "EvidenceDocumentBlobUri").
     * @param vcdXmlDocument the merged XML in intermediate format.
     * @param isFullPackageTransform true when this is a "full package" transformation (Skeleton is not the target).
     * @param saveLogic a Mapper object used for treatment of VCDReferenceID and UUID elements.
     * @param blobResolver the BLOB resolver that returns VCD document attachments, can be null.
     * @throws SAXException 
     * @throws MalformedURLException 
     * @throws IOException when Schemifier failed to read schema config.
     * @throws JDOMException when Schemifier failed to read schema config.
     */
    public XmlSaver(Document vcdXmlDocument, VcdSchemaVariant schemaVariant, SaverXmlLogic saveLogic, BlobDocumentResolver blobResolver) throws MalformedURLException, SAXException {
        this(
            vcdXmlDocument,
            schemaVariant,
            saveLogic,
            blobResolver,
            Schemifier.getInstance(schemaVariant));
    }
    
    private XmlSaver(
            Document vcdXmlDocument,
            VcdSchemaVariant schemaVariant,
            SaverXmlLogic saveLogic,
            BlobDocumentResolver blobResolver,
            Schemifier schemifier)  {

        assert vcdXmlDocument != null : "Null value for transformer-document does not make sense here!";
        assert saveLogic != null : "Null value for SaverLogic does not make sense here!";
        
        this.vcdPackageXml = vcdXmlDocument;
        this.saverXmlLogic = saveLogic;
        this.schemaVariant = schemaVariant;
        
        split(vcdXmlDocument.getRootElement());
        
        
        Element packageRoot = vcdXmlDocument.getRootElement();
        
        Element existingUUID = packageRoot.getChild("UUID", Namespace.getNamespace("cbc", "urn:peppol:wp2:schema:xsd:CommonBasicComponents-2"));
        if (existingUUID != null) {
        	this.vcdPackageUUID = existingUUID.getText();
        } else {
        	this.vcdPackageUUID = saverXmlLogic.generateUuid4Xml();
        	setUUID(packageRoot, vcdPackageUUID);
        }
        
        vcdPackagePathAndDocument = new PathAndDocument(vcdPackageXml, Constants.VCD_PACKAGE_XML_FILE_PREFIX + Constants.VCD_PACKAGE_XML_FILE_SEPARATOR + vcdPackageUUID + Constants.VCD_PACKAGE_XML_FILE_SUFFIX);
        process(vcdPackagePathAndDocument, schemifier, blobResolver);
        
        for (PathAndDocument vcd : vcdList)   {
            // in splitted VCD documents there are no namespace declarations in root element,
            // so add them (else unit test would detect diffs to control-doc ...)
            for (Object o : vcdPackageXml.getRootElement().getAdditionalNamespaces()) {
                Namespace ns = (Namespace) o;
                vcd.document.getRootElement().addNamespaceDeclaration(ns);
            }
            
            process(vcd, schemifier, blobResolver);
        }
        
        log.debug("Skeleton save done!");
        assert vcdCounter == vcdList.size() : "VCD counter is "+vcdCounter+", but size of VCD list is "+vcdList.size();
    }


    /** @return the top VCDPackage document. */
    public PathAndDocument getVcdPackage() {
        return vcdPackagePathAndDocument;
    }

    /** @return the List of VCD documents referenced by the top document, including path informations. */
    public Collection<PathAndDocument> getVcdList() {
        return Collections.unmodifiableCollection(vcdList);
    }


    /**
     * Validates all contained XML documents according to their XML schema.
     * @return null when validation succeeded, else a multi-line text containing detected errors.
     * @throws SAXException 
     * @throws ParserConfigurationException 
     * @throws IOException 
     */
    public String validate() throws IOException, ParserConfigurationException, SAXException   {
        assert schemaVariant != null : "Can not validate when no schema variant was passed in constructor!";
        
        // validate package
        String errors = validate(this.vcdPackageXml, true);
        
        // validate all VCDs
        for (PathAndDocument vcd : this.vcdList)  {
            String vcdError = validate(vcd.document, false);
            if (vcdError != null)
                errors = (errors == null ? "" : errors+"\n") + vcdError;
        }
        return errors;
    }
    
    
    private String validate(Document document, boolean isVcdPackageXmlFile) throws IOException, ParserConfigurationException, SAXException {
        ByteArrayOutputStream xmlStream = new ByteArrayOutputStream();
        new XMLOutputter().output(document, xmlStream);
        xmlStream.close();
        
        String schemaUrl = isVcdPackageXmlFile ? schemaVariant.vcdPackageSchemaUrl : schemaVariant.vcdSchemaUrl;
        return XmlValidator.getInstance(schemaUrl).validate(new ByteArrayInputStream(xmlStream.toByteArray()));
    }

    private void process(PathAndDocument pathAndDocument, Schemifier schemifier, BlobDocumentResolver blobResolver)  {
        resolveDocumentBlobs(blobResolver, pathAndDocument);
        if (schemifier != null)
            schemifier.schemify(pathAndDocument.document);
        setUUIDs(pathAndDocument.document.getRootElement());
        
        saverXmlLogic.editRootElement(pathAndDocument.document.getRootElement());
    }
    
    private void split(Element element) {
        if (saverXmlLogic.isResolvedDocumentReferenceElement(element)) {
          Element parent = element.getParentElement();

          List<Element> children = parent.getChildren();
          int referenceIdIndex = children.indexOf(element);
          parent.removeContent(element);
          
          if (parent.getName().equals("RelevantVCDPerson")) {
          	//skip it, relevantvcdpersons have been integrated with their company's vcd anyway.
          	return;
          }

          
          String vcdUUID = saverXmlLogic.generateUuid4Xml();

          Element existingUUID = element.getChild("UUID", Namespace.getNamespace("cbc", "urn:peppol:wp2:schema:xsd:CommonBasicComponents-2"));
          if (existingUUID != null) {
        	  vcdUUID = existingUUID.getText();
          } else {
          	  setUUID(element, vcdUUID);
          }

          

          log.info("Found VCD element, externalizing it and adding VCDReferenceID for UUID "+vcdUUID);
            
          Document referencedDocument = new Document(element);
            
          // insert new element at remembered position
          String path = createRelativePath(vcdUUID);
          Element referenceElement = saverXmlLogic.createUnresolvedDocumentReferenceElement(vcdUUID);
            
          vcdList.add(new PathAndDocument(referencedDocument, path));
            
          children.add(referenceIdIndex, referenceElement);
        }
        
        List clone = new ArrayList(element.getChildren());  // beware of concurrent modification exception!
        for (Object o : clone)  {
            Element e = (Element) o;
            split(e);
        }
    }

		private void setUUID(Element vcdOrPackage, String sUUID) {
			Element uuid = new Element("UUID", Namespace.getNamespace("cbc", "urn:peppol:wp2:schema:xsd:CommonBasicComponents-2"));
			uuid.setText(sUUID);
			vcdOrPackage.addContent(0, uuid);
		}
    
    private void setUUIDs(Element element)  {
        if (saverXmlLogic.isUuidGeneratorXmlElement(element) && element.getTextTrim().length() <= 0)
            element.setText(saverXmlLogic.generateUuid4Xml());
        
        for (Object o : element.getChildren())
            setUUIDs((Element) o);
    }
    
    private String createRelativePath(String vcdUUID) {
        vcdCounter++;
        // use a platform independent file separator that any Java application knows
        return Constants.VCD_BASEDIR_NAME_PREFIX + vcdUUID + "/" + Constants.VCD_XML_FILE_PREFIX + Constants.VCD_XML_FILE_SEPARATOR + vcdUUID + Constants.VCD_XML_FILE_SUFFIX;
    }

    private void resolveDocumentBlobs(BlobDocumentResolver blobResolver, PathAndDocument pathAndDocument) {
        if (blobResolver == null)
            return;
        
        List<Element> removeList = new ArrayList<Element>();
        resolveDocumentBlobs(pathAndDocument.document.getRootElement(), blobResolver, pathAndDocument, removeList);
        for (Element e : removeList)
            e.getParent().removeContent(e);
    }

    private void resolveDocumentBlobs(Element element, BlobDocumentResolver blobResolver, PathAndDocument pathAndDocument, List<Element> removeList) {
        // the BLOB info for the BlobDocumentResolver is in tmp:XmlEvidenceDocumentBlobUri
        List children = element.getChildren();
        List<Element> uris = new LinkedList<Element>();
        for (Object o : children)   {
            Element e = (Element) o;
            if (saverXmlLogic.isEvidenceDocumentBlobUri(e))    {
                String blobUri = e.getText();
                Element eFileName = findFilename(element); //Mapper maps the original filename from m2n into cbc:FileName so we can find it!
                assert eFileName != null : "Can not store a BLOB without filename, BlobDocument URI is "+blobUri;
                
                String origFullName = eFileName == null ? "foo.txt" : eFileName.getText();
                String uuid = findId(element);
                
                int lastDot = origFullName.lastIndexOf(".");
                String origName = lastDot == - 1 ? origFullName : origFullName.substring(0, lastDot);
                String origExtWithDot = lastDot == - 1 ? "" : origFullName.substring(lastDot);
                
                // spec of physical container format says:
                // - actual filename in zip is <uuid>.<originalextension>
                // - cbc:FileName is <filename-in-zip>
                // - cbc:URI is <urn-prefix>:<filename-in-zip>
                // - cbc:Description is a human readable description or the original file name.
                String fileName = uuid + origExtWithDot;
                String fileUri = FILE_URI_PREFIX + fileName;
                String fileDescription = origFullName;
                
                //we remove all non-ascii characters. This is because java's ZipOutputStream would encode those as UTF-8, which is NOT what unzippers expect (some old dos codepage or so).
                //this is actually pretty obsolete as the UUID can't contain non-ascii characters (but the extension COULD)
                fileName = P_NON_ASCII.matcher(fileName).replaceAll("_");
              	
                eFileName.setText(fileName);
                
                Element eURI = new Element("URI", Namespace.getNamespace("cbc", "urn:peppol:wp2:schema:xsd:CommonBasicComponents-2"));
                eURI.setText(fileUri);
                uris.add(eURI);
                
                Element eDescription = new Element("Description", Namespace.getNamespace("cbc", "urn:peppol:wp2:schema:xsd:CommonBasicComponents-2"));
                eDescription.setText(fileDescription);
                uris.add(eDescription);
                
                pathAndDocument.addBlobDocumentAttachment(fileName, blobResolver, blobUri);
                removeList.add(e);
            }
            else    {
                resolveDocumentBlobs(e, blobResolver, pathAndDocument, removeList);
            }
        }
        
        for (Element eURI : uris) {
          element.addContent(0, eURI);
        }
    }

    private String findId(Element extRef) {
    	return extRef.getParentElement().getParentElement().getChildText("ID", Namespace.getNamespace("urn:peppol:wp2:schema:xsd:CommonBasicComponents-2"));
		}

		private Element findFilename(Element element) {
        List children = element.getChildren();
        for (Object o : children)   {
            Element e = (Element) o;
            if (saverXmlLogic.isEvidenceDocumentBlobFilename(e))
                return e;
        }
        return null;
    }

		public String getVcdPackageUUID() {
			return vcdPackageUUID;
		}
}
