/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.xmlschema;

import java.net.MalformedURLException;
import java.util.Hashtable;
import java.util.Map;

import org.jdom.Document;
import org.xml.sax.SAXException;

import at.m2n.IntelligenceManagement.vcd.util.Path;
import at.m2n.IntelligenceManagement.vcd.xmlschema.schemify.xsom.SchemifierXsomImpl;

/**
 * Makes a schema compatible XML document from a raw XML document.
 * This task includes following steps:
 * <ul>
 *  <li>sorting child elements in all container-elements according to schema</li>
 *  <li>adding required elements (but without text content)</li>
 * </ul>
 * This class should encapsulate XML schema specific logic.
 * This class offers only a singleton factory to avoid repeated instance
 * allocations of this quite expensive class (has to read schema set every time).
 * 
 * @author Fritz Ritzberger  02.06.2010
 */
public class Schemifier {
    
    private static Map<VcdSchemaVariant,Schemifier> cache = new Hashtable<VcdSchemaVariant,Schemifier>();
    
    /**
     * Singleton factory to deliver cached Schemifier instances (it takes time to read a schema with XSOM).
     * @return a (cached) Schemifier instance fitting for passed schema set.
     * @throws SAXException 
     * @throws MalformedURLException 
     */
    public static Schemifier getInstance(VcdSchemaVariant schemaVariant) throws MalformedURLException, SAXException {
        Schemifier schemifier = cache.get(schemaVariant);
        if (schemifier == null)
            cache.put(schemaVariant, schemifier = new Schemifier(schemaVariant));

        return schemifier;
    }
    
    /** Garbage collect all pre-parsed schemas. */
    public static void clearInstances()    {
        cache.clear();
    }
    
    /**
     * Just internal, do not use.
     * Actual Schemifier implementations must be able to work out this interface.
     */
    public interface Impl
    {
        /**
         * @param element the element for which it should be decided if it is a folder or leaf.
         * @return true when passed element is a folder element and not a leaf element.
         */
        boolean isFolderElement(Path.Part element);
        
        /**
         * Adds required and missing elements,
         * then sorts all elements according to schema information.
         * @param document the XML document to rectify.
         */
        void schemify(Document document);
    }
    
    private Impl delegate;
    
    private Schemifier(VcdSchemaVariant v) throws MalformedURLException, SAXException {
        delegate = new SchemifierXsomImpl(v.vcdPackageSchemaUrl, v.vcdPackageRootElement, v.vcdSchemaUrl, v.vcdSchemaRootElement);
    }
    
    /** @see at.m2n.IntelligenceManagement.vcd.xmlschema.Schemifier.Impl#isFolderElement(at.m2n.IntelligenceManagement.vcd.util.Path.Part) */
    public boolean isFolderElement(Path.Part element) {
        return delegate.isFolderElement(element);
    }
    
    /** @see at.m2n.IntelligenceManagement.vcd.xmlschema.Schemifier.Impl#schemify(Document)) */
    public void schemify(Document document) {
        delegate.schemify(document);
    }

}
