/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd;

import at.m2n.IntelligenceManagement.vcd.xmlbeans.vcdp.VCDPackageDocument;
import at.m2n.IntelligenceManagement.vcd.xmlbeans.vcdp.VCDPackageType;
import junit.framework.Assert;
import junit.framework.TestCase;

import java.io.File;

public class VcdPackageLoaderTest extends TestCase {
    public void testLoadSampleWithXmlBeans() throws Exception {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD_ROOT1);
        final VCDPackageDocument packageDocument = VCDPackageDocument.Factory.parse(packageFile);
        final VCDPackageType vcdPackage = packageDocument.getVCDPackage();

        Assert.assertEquals(VcdTestConstants.CALL_FOR_TENDER_ID1, vcdPackage.getCallForTenderID().getStringValue());
    }

    public void testLoadSampleUnzipped1() throws Exception {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD1);
        VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
        final VcdCompound compound = VcdPackageLoader.loadFromUnpackedDir(packageFile);
        final VCDPackageDocument packageDocument = compound.getVcdPackage();
        final VCDPackageType vcdPackage = packageDocument.getVCDPackage();

        Assert.assertEquals("11 compound references", 11, compound.getVcdReferences().size());
        Assert.assertEquals(VcdTestConstants.CALL_FOR_TENDER_ID1, vcdPackage.getCallForTenderID().getStringValue());
    }

    public void testLoadSampleUnzipped2() throws Exception {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD2);
        VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
        final VcdCompound compound = VcdPackageLoader.loadFromUnpackedDir(packageFile);
        final VCDPackageDocument packageDocument = compound.getVcdPackage();
        final VCDPackageType vcdPackage = packageDocument.getVCDPackage();

        Assert.assertEquals("3 compound references", 3, compound.getVcdReferences().size());
        Assert.assertEquals(VcdTestConstants.CALL_FOR_TENDER_ID2, vcdPackage.getCallForTenderID().getStringValue());
    }

    public void testLoadSampleZipped() throws Exception {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.ZIPPED_VCD);
        final File tempDir = Util.createTempDirectory();
        VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
        final VcdCompound compound = VcdPackageLoader.loadFromZipFile(packageFile, tempDir);
        final VCDPackageDocument packageDocument = compound.getVcdPackage();
        final VCDPackageType vcdPackage = packageDocument.getVCDPackage();

        Assert.assertEquals("3 compound references", 3, compound.getVcdReferences().size());
        Assert.assertEquals(VcdTestConstants.CALL_FOR_TENDER_ID2, vcdPackage.getCallForTenderID().getStringValue());
        Assert.assertTrue("temporary files deleted", Util.removeDirectory(tempDir));
    }

}
