/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd.summary;

import at.m2n.IntelligenceManagement.vcd.*;
import at.m2n.IntelligenceManagement.vcd.xmlbeans.cac.CriterionType;
import at.m2n.IntelligenceManagement.vcd.xmlbeans.cac.VCDPersonType;
import at.m2n.IntelligenceManagement.vcd.xmlbeans.vcd.VCDDocument;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import junit.framework.Assert;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class NodeUtilTest extends TestCase {
    /**
     * This test tries to index and sort the criteria of all entities in a given VCD package. It fails when wrongly
     * specified orderings within the function result in dropped criteria (reason: ordering==0 <==> objects.equals())
     */
    public void testCreateGroupedSortedCriteriaIndex() throws IOException {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD1);
        VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
        final VcdCompound compound = VcdPackageLoader.loadFromUnpackedDir(packageFile);

        for (VCDDocument vcdDocument : compound.getVcdReferences().values()) {
            final List<CriterionType> vcdCriterionXmlList = vcdDocument.getVCD().getEconomicOperator().getCriterionList();
            final Multimap<RegulationNode, CriterionNode> vcdCriteriaIndex = createSortedIndex(compound, vcdCriterionXmlList);
            final String vcdId = vcdDocument.getVCD().getUUID().getStringValue();
            Assert.assertEquals("XML criteria for VCD " + vcdId + " were illegaly modified during indexing.", vcdCriterionXmlList.size(), vcdCriteriaIndex.size());

            for (VCDPersonType vcdPerson : vcdDocument.getVCD().getRelevantVCDPersonList()) {
                final List<CriterionType> personCriterionXmlList = vcdPerson.getCriterionList();
                final Multimap<RegulationNode, CriterionNode> personCriteriaIndex = createSortedIndex(compound, personCriterionXmlList);
                final String personname = NodeUtil.getPersonDetailsCompositeName(vcdPerson.getPersonDetails());
                Assert.assertEquals("XML criteria for VCD person " + personname + " were illegaly modified during indexing.", personCriterionXmlList.size(), personCriteriaIndex.size());
            }
        }
    }

    private Multimap<RegulationNode, CriterionNode> createSortedIndex(final VcdCompound compound, List<CriterionType> criterionXmlList) {
        List<CriterionNode> criterionNodeList = Lists.transform(criterionXmlList, new Function<CriterionType, CriterionNode>() {
            public CriterionNode apply(CriterionType input) {
                final CriterionNode ret = new CriterionNode();
                ret.parse(input, compound);
                return ret;
            }
        });
        return NodeUtil.createGroupedSortedCriteriaIndex(criterionNodeList);
    }
}
