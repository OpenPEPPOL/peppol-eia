/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.google.common.collect.Lists;

public class KeyExtractor {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println("You must specify a properties file as program argument.");
			System.exit(1);
		}

		final Properties properties = readProperties(args[0]);
		List<String> l = Lists.newArrayList();
		for (Object o : properties.keySet()) {
			l.add(o.toString());			
		}
		
		for(String s: l) {
			System.out.println(s);
		}
		
		System.out.println("------");
		
		for(String s: l) {
			System.out.println(properties.get(s));
		}
	}

	private static Properties readProperties(String file) {
		final Properties properties = new Properties();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			properties.load(fis);
		} catch (IOException e) {
			System.err.println("Could not read properties file '" + file + "'");
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e1) {
				// swallow
			}
			System.exit(1);
		}
		return properties;
	}

}
