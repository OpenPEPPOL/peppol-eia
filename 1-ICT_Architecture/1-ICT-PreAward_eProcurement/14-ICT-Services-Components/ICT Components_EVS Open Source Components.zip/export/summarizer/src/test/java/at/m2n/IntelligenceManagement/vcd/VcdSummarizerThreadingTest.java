/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd;

import junit.framework.TestCase;
import org.xhtmlrenderer.util.XRLog;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

public class VcdSummarizerThreadingTest extends TestCase {

    private static final String OUTPUT_BASE = "./target/VcdCompoundTest_testRenderToPdf";
    private static final int THREAD_COUNT = 3;

    private volatile Throwable threadingError;

    @Override
    protected void setUp() throws Exception {
        XRLog.init("Warming up logger since it doesn't seem to be thread-safe :(");
    }

    public void testRenderSerial() throws IOException, InterruptedException {
        this.threadingError = null;
        final Collection<Thread> workers = new ArrayList<Thread>();

        for (int i = 0; i < THREAD_COUNT; i++) {
            workers.add(createSummarizerThreadCrappy("ser" + i));
        }

        System.out.println("waiting for summaries to complete");
        for (Thread worker : workers) {
            worker.run();
        }
        System.out.println("summaries completed");

        assertNull("A threading error has occured: " + getErrorMessage(threadingError), threadingError);
    }

    public void testRenderThreadedCrappy() throws IOException, InterruptedException {
        this.threadingError = null;
        final Collection<Thread> workers = new ArrayList<Thread>();

        for (int i = 0; i < THREAD_COUNT; i++) {
            workers.add(createSummarizerThreadCrappy("thr" + i));
        }

        for (Thread worker : workers) {
            worker.start();
        }

        System.out.println("waiting for summaries to complete");
        for (Thread worker : workers) {
            worker.join();
        }
        System.out.println("summaries completed");

        assertNotNull("A threading error should occur", threadingError);
    }

    public void testRenderThreadedCorrectly() throws IOException, InterruptedException {
        this.threadingError = null;
        final Collection<Thread> workers = new ArrayList<Thread>();

        final VcdSummarizer summarizer = new VcdSummarizer();

        for (int i = 0; i < THREAD_COUNT; i++) {
            workers.add(createSummarizerThreadCorrectly(summarizer, "thr" + i));
        }

        for (Thread worker : workers) {
            worker.start();
        }

        System.out.println("waiting for summaries to complete");
        for (Thread worker : workers) {
            worker.join();
        }
        System.out.println("summaries completed");

        summarizer.cleanup();

        assertNull("A threading error has occured: " + getErrorMessage(threadingError), threadingError);
    }

    private void renderOneSummaryCrappy(String name) throws IOException {
        final VcdSummarizer summarizer = new VcdSummarizer();

        try {
            renderOneSummaryCorrectly(summarizer, name);
        } finally {
            summarizer.cleanup();
        }
    }

    private void renderOneSummaryCorrectly(VcdSummarizer summarizer, String name) throws IOException {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD1);

        final File dump = new File(OUTPUT_BASE + name + ".html");
        final File dest = new File(OUTPUT_BASE + name + ".pdf");

        VcdLanguageProvider.set(VcdLanguage.DE, VcdLanguage.DE);
        final File summary = summarizer.renderPackageToTempPdf(packageFile, dump);
        final boolean success = summary.renameTo(dest);
        assertTrue("summary rendered and saved", success);
        assertTrue("xhtml dump file deleted", dump.delete());
        assertTrue("temporary file deleted", dest.delete());
    }

    private Thread createSummarizerThreadCrappy(final String name) {
        return new Thread() {

            @Override
            public void run() {
                try {
                    System.out.println("started summary " + name);
                    renderOneSummaryCrappy(name);
                    System.out.println("finished summary " + name);
                } catch (Exception e) {
                    e.printStackTrace();
                    threadingError = e;
                }
            }

        };
    }

    private Thread createSummarizerThreadCorrectly(final VcdSummarizer summarizer, final String name) {
        return new Thread() {

            @Override
            public void run() {
                try {
                    System.out.println("started summary " + name);
                    renderOneSummaryCorrectly(summarizer, name);
                    System.out.println("finished summary " + name);
                } catch (Exception e) {
                    e.printStackTrace();
                    threadingError = e;
                }
            }

        };
    }

    private String getErrorMessage(Throwable error) {
        final String message;
        if (error != null) {
            message = error.getMessage();
        } else {
            message = "no error";
        }
        return message;
    }

}
