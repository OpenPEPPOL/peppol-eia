/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd;

import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;

import com.google.common.io.Files;

public class VcdSummarizerTest extends TestCase {

    private static final String OUTPUT_BASE = "./target/VcdCompoundTest_testRenderToPdf";
    
    public void testRenderToPdf() throws IOException {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD4);

        final File dump = new File(OUTPUT_BASE + "4.html");
        final File dest = new File(OUTPUT_BASE + "4.pdf");
        final VcdSummarizer summarizer = new VcdSummarizer();

        
        try {
            VcdLanguageProvider.set(VcdLanguage.DE, VcdLanguage.EN);
            final File summary = summarizer.renderPackageToTempPdf(packageFile, dump);
            Files.move(summary, dest);            
            assertTrue("summary rendered but not moved", dest.exists());
            //assertTrue("xhtml dump file deleted", dump.delete());
            //assertTrue("temporary file deleted", dest.delete());
        } finally {
            summarizer.cleanup();
        }
    }

    public void testRenderZipToPdf() throws IOException {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.ZIPPED_VCD1);

        final File dump = new File(OUTPUT_BASE + "1z.html");
        final File dest = new File(OUTPUT_BASE + "1z.pdf");
        final VcdSummarizer summarizer = new VcdSummarizer();

        try {
            VcdLanguageProvider.set(VcdLanguage.DE, VcdLanguage.DE);
            final File summary = summarizer.renderPackageToTempPdf(packageFile, dump);
            Files.move(summary, dest);            
            assertTrue("summary rendered and saved", dest.exists());
//            assertTrue("xhtml dump file deleted", dump.delete());
//            assertTrue("temporary file deleted", dest.delete());
        } finally {
            summarizer.cleanup();
        }
    }

    public void testRenderPierrosZip() throws IOException {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, "pierro_VCDContainer_020b3702-1b2f-479e-baac-44b33bd8e483");

        final File dump = new File(OUTPUT_BASE + "_pierro.html");
        final File dest = new File(OUTPUT_BASE + "_pierro.pdf");
        final VcdSummarizer summarizer = new VcdSummarizer();

        try {
            VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
            final File summary = summarizer.renderPackageToTempPdf(packageFile, dump);
            Files.move(summary, dest);
            assertTrue("summary rendered and saved", dest.exists());
//            assertTrue("xhtml dump file deleted", dump.delete());
//            assertTrue("temporary file deleted", dest.delete());
        } finally {
            summarizer.cleanup();
        }
    }

    public void testRenderToPdf2() throws IOException {
        final VcdLanguage mainLang = VcdLanguage.EN;
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD2);

        final File dump = new File(OUTPUT_BASE + "2.html");
        final File dest = new File(OUTPUT_BASE + "2.pdf");
        final VcdSummarizer summarizer = new VcdSummarizer();

        try {
            VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
            final File summary = summarizer.renderPackageToTempPdf(packageFile, dump);
            Files.move(summary, dest);            
            assertTrue("summary rendered and saved", dest.exists());
//            assertTrue("xhtml dump file deleted", dump.delete());
//            assertTrue("temporary file deleted", dest.delete());
        } finally {
            summarizer.cleanup();
        }
    }

    public void testRenderToPdf3() throws IOException {
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD3);

        final File dump = new File(OUTPUT_BASE + "3.html");
        final File dest = new File(OUTPUT_BASE + "3.pdf");
        final VcdSummarizer summarizer = new VcdSummarizer();

        try {
            VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
            final File summary = summarizer.renderPackageToTempPdf(packageFile, dump);
            Files.move(summary, dest);
            assertTrue("summary rendered and saved", dest.exists());
//            assertTrue("xhtml dump file deleted", dump.delete());
//            assertTrue("temporary file deleted", dest.delete());
        } finally {
            summarizer.cleanup();
        }
    }
}
