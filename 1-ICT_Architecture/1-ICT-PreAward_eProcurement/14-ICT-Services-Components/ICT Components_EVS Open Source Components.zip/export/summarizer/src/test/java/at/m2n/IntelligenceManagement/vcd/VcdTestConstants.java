/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd;

public class VcdTestConstants {
    public static final String BASE_DIR = "src/test/resources/samples";
    public static final String ZIPPED_VCD = "VCDPackage_56732ee3-94ca-4922-b2e7-688b50177682.zip";

    public static final String ZIPPED_VCD1 = "VCDPackage_e8098f4f-b576-4de3-bf62-804edfaa84b2.zip";
    public static final String UNZIPPED_VCD1 = "VCDPackage_e8098f4f-b576-4de3-bf62-804edfaa84b2";
    public static final String UNZIPPED_VCD_ROOT1 = UNZIPPED_VCD1 + "/VCDPackage_e8098f4f-b576-4de3-bf62-804edfaa84b2.xml";
    public static final String CALL_FOR_TENDER_ID1 = "CON-584324";

    public static final String UNZIPPED_VCD2 = "VCDPackage_56732ee3-94ca-4922-b2e7-688b50177682";
    public static final String UNZIPPED_VCD_ROOT2 = UNZIPPED_VCD2 + "/VCDPackage_56732ee3-94ca-4922-b2e7-688b50177682.xml";
    public static final String CALL_FOR_TENDER_ID2 = "TDID-123456789";

    public static final String UNZIPPED_VCD3 = "VCDContainer_02c43edb-cd19-42f8-81e4-19be6b7036f5";
    public static final String UNZIPPED_VCD_ROOT3 = UNZIPPED_VCD3 + "/VCDContainer_02c43edb-cd19-42f8-81e4-19be6b7036f5.xml";
    public static final String CALL_FOR_TENDER_ID3 = "TDID-123456789";

    public static final String UNZIPPED_VCD4 = "4";
}
