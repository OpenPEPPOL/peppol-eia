/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.vcd;

import at.m2n.IntelligenceManagement.vcd.summary.CompoundNode;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.Ordering;
import com.googlecode.gentyref.GenericTypeReflector;
import junit.framework.Assert;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

import java.io.*;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.util.*;

public class VcdCompoundTest extends TestCase {
    /**
     * This test tries to load and parse/filter a sample VCD
     */
    public void testLoadSampleWithXmlBeans1() throws IOException {
        VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD1);
        final VcdCompound compound = VcdPackageLoader.loadFromUnpackedDir(packageFile);
        final CompoundNode root = compound.getCompoundNode();

        Assert.assertEquals(VcdTestConstants.CALL_FOR_TENDER_ID1, root.getCallForTenderId().getRawValue());

        for (File attachment : compound.getExternalReferences().values()) {
            if (!attachment.exists()) Assert.fail("attachment " + attachment.getAbsolutePath() + " does not exist in the unpacked VCD");
        }
    }

    /**
     * This test tries to load and parse/filter a sample VCD
     */
    public void testLoadSampleWithXmlBeans2() throws IOException {
        VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
        final File packageFile = new File(VcdTestConstants.BASE_DIR, VcdTestConstants.UNZIPPED_VCD2);
        final VcdCompound compound = VcdPackageLoader.loadFromUnpackedDir(packageFile);
        final CompoundNode root = compound.getCompoundNode();

        Assert.assertEquals(VcdTestConstants.CALL_FOR_TENDER_ID2, root.getCallForTenderId().getRawValue());

        for (File attachment : compound.getExternalReferences().values()) {
            if (!attachment.exists()) Assert.fail("attachment " + attachment.getAbsolutePath() + " does not exist in the unpacked VCD");
        }
    }

    /**
     * This is not a real test, it just dumps the VCD node composition graph.
     * @throws java.io.IOException Can occur during file operations
     */
    public void testDumpNodeTree() throws IOException {
        VcdLanguageProvider.set(VcdLanguage.EN, VcdLanguage.EN);
        final StringWriter sw = new StringWriter();
        dumpNode(sw, CompoundNode.class, new ArrayList<Class<?>>());

        final File dump = new File("./target/VcdCompoundTest_testDumpNodeTree.txt");
        new FileOutputStream(dump).write(sw.toString().getBytes());
    }

    private void dumpNode(StringWriter sw, Class<?> cl, List<Class<?>> nodePath) throws IOException {
        final Method[] allMethods = cl.getMethods();

        for (Method m : methodSort(allMethods)) {
            final String name = m.getName();
            if (name.startsWith("get")) {
                final Class<?> retClass = m.getReturnType();

                if (GenericTypeReflector.isSuperType(Collection.class, retClass)) {
                    final ParameterizedType type = (ParameterizedType) GenericTypeReflector.getExactReturnType(m, cl);
                    final Class<?> typeParameter = (Class<?>) type.getActualTypeArguments()[0];

                    StringUtils.repeat("\t", nodePath.size());
                    sw.append("+ ").append(name.substring(3)).append(" (").append(retClass.getSimpleName())
                            .append(" of ").append(typeParameter.getSimpleName()).append(")\n");

                    final List<Class<?>> newPath = new ArrayList<Class<?>>(nodePath);
                    if (!newPath.contains(typeParameter) && !cl.equals(typeParameter)) {
                        newPath.add(cl);
                        dumpNode(sw, typeParameter, newPath);
                    }
                } else if (retClass.equals(String.class) || retClass.equals(Integer.class) || retClass.equals(Boolean.class) || retClass.equals(Date.class)) {
                    StringUtils.repeat("\t", nodePath.size());
                    sw.append(". ").append(name.substring(3)).append(" (").append(retClass.getSimpleName()).append(")\n");
                } else if (retClass.getName().startsWith("at.m2n.")) {
                    StringUtils.repeat("\t", nodePath.size());
                    sw.append("> ").append(name.substring(3)).append(" (").append(retClass.getSimpleName()).append(")\n");

                    final List<Class<?>> newPath = new ArrayList<Class<?>>(nodePath);
                    if (!newPath.contains(retClass) && !cl.equals(retClass)) {
                        newPath.add(cl);
                        dumpNode(sw, retClass, newPath);
                    }
                } else if (retClass.equals(Class.class) || retClass.equals(InputStream.class)) {
                    // ignore
                } else {
                    throw new IOException("dumping class " + retClass.getName() + " not supported");
                }
            }
        }
    }

    private List<Method> methodSort(Method[] methods) {
        final ArrayList<Method> simpleGetters = new ArrayList<Method>();
        final ArrayList<Method> nodeGetters = new ArrayList<Method>();
        final ArrayList<Method> collectionGetters = new ArrayList<Method>();

        for (Method m : methods) {
            final Class<?> retClass = m.getReturnType();

            if (GenericTypeReflector.isSuperType(Collection.class, retClass)) {
                collectionGetters.add(m);
            } else if (retClass.equals(String.class) || retClass.equals(Integer.class) || retClass.equals(Boolean.class) || retClass.equals(Date.class)) {
                simpleGetters.add(m);
            } else if (retClass.getName().startsWith("at.m2n.")) {
                nodeGetters.add(m);
            }
        }

        final Ordering<Method> lexicalMethodNameOrdering = Ordering.from(new Comparator<Method>() {
            public int compare(Method m1, Method m2) {
                return m1.getName().compareTo(m2.getName());
            }
        });

        return ImmutableList.copyOf(Iterables.concat(
                lexicalMethodNameOrdering.immutableSortedCopy(simpleGetters),
                lexicalMethodNameOrdering.immutableSortedCopy(nodeGetters),
                lexicalMethodNameOrdering.immutableSortedCopy(collectionGetters)));
    }
}
