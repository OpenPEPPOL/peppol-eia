/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.stages;

import junit.framework.TestCase;

import org.apache.http.client.HttpClient;

import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult;

public class PortalAuthenticatingServiceStageTest extends TestCase {

	private final TestStageFactory factory = new TestStageFactory();

	public void _testAuthentication() {
		PortalAuthenticatingServiceStage stage = factory
				.createPortalAuthenticatingServiceStage();
		HttpServiceStageResult result = stage.call(factory.getHttpClient(),
												   factory.getContext());

		TestCase.assertNotNull("Security Token retrieved successfully", factory
				.getContext().getValue("SMSESSION", null));
	}

	public void testDocumentRetrieval() {
		PortalAuthenticatingServiceStage stage = factory
				.createPortalAuthenticatingServiceStage();
		HttpClient httpClient = factory.getHttpClient();
		HttpServiceStageResult result = stage.call(httpClient, factory
				.getContext());

		TestCase.assertNotNull("Security Token retrieved successfully", factory.getContext().getValue("SMSESSION", null));
		boolean done = false;

		while (!done) {
			FirmenbuchAuszugRetrievalStage retrieval = factory.createFirmenbuchAuszugRetrievalStage();
			result = retrieval.call(httpClient, factory.getContext());
			if (!result.isRetryFeasible()) {
				done = true;
			}
		}
		TestCase.assertEquals(HttpServiceStageResult.State.SUCCESS, result.getState());
	}
}
