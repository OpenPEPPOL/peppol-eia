/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.stages;

import java.io.File;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.ProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultRedirectStrategy;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HttpContext;
import org.picocontainer.MutablePicoContainer;
import org.picocontainer.defaults.DefaultPicoContainer;

import at.m2n.IntelligenceManagement.component.ComponentManager;
import at.m2n.IntelligenceManagement.dataNetwork.DataNetworkPlugin;
import at.m2n.IntelligenceManagement.dataNetwork.api.BLOBDataSource;
import at.m2n.IntelligenceManagement.dataNetwork.api.BLOBRetrievalHints;
import at.m2n.IntelligenceManagement.dataNetwork.api.BLOBRetrievalHints.Mode;
import at.m2n.IntelligenceManagement.dataNetwork.api.Capability;
import at.m2n.IntelligenceManagement.dataNetwork.api.RDFDataSource;
import at.m2n.IntelligenceManagement.osSso.OsssoMachine;
import at.m2n.IntelligenceManagement.osSso.OsssoProcess;
import at.m2n.IntelligenceManagement.osSso.OsssoVHostPlugin;
import at.m2n.IntelligenceManagement.osSso.ServiceRegistry;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModelFactory;
import at.m2n.IntelligenceManagement.osSso.model.impl.SimpleOsssoModelFactory;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration;
import at.m2n.IntelligenceManagement.peppol.service.external.common.apache.CustomHttpClient;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.FirmenbuchServiceWrapper;
import at.m2n.IntelligenceManagement.plugIn.PlugInInitialisationException;
import at.m2n.IntelligenceManagement.rdfPojo.RdfPojoConfigurationException;
import at.m2n.configuration.Configuration;
import at.m2n.configuration.ConfigurationException;
import at.m2n.configuration.PropertiesConfiguration;

import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Resource;

public class TestStageFactory {

	private static final Collection<String> CONFIG_KEYS = new ArrayList<String>();
	static {
		CONFIG_KEYS.add("portal.baseURL");
		CONFIG_KEYS.add("portal.auth.user");
		CONFIG_KEYS.add("portal.auth.password");
		CONFIG_KEYS.add("fbService.fileNamePattern");
		CONFIG_KEYS.add("fbService.baseURL");
	}

	private final HttpServiceConfiguration serviceConfiguration;
	private final HttpServiceContext context;

	public TestStageFactory() {
		super();
		this.serviceConfiguration = new HttpServiceConfiguration(
																 FirmenbuchServiceWrapper.class, CONFIG_KEYS,
																 HttpServiceConfiguration.EVAL_LENIENT);

		final MutablePicoContainer mpc = new DefaultPicoContainer();
		ComponentManager simpleCM = new ComponentManager() {

			@Override
			public MutablePicoContainer getComponentContainer() {
				return mpc;
			}
		};

		BLOBDataSource blobSource = new BLOBDataSource() {

			@Override
			public void performPostInitialization() throws RdfPojoConfigurationException {
			}

			@Override
			public boolean isStillAlive() {
				return false;
			}

			@Override
			public boolean isInitialized() {
				return false;
			}

			@Override
			public Resource getInstanceResource() {
				return null;
			}

			@Override
			public void stop() {
			}

			@Override
			public void start() {
			}
			
			@Override
			public void dispose() {
			}

			@Override
			public String getElementName() {
				return "StubBLOBSource";
			}

			@Override
			public String getElementDescription() {
				return "Stub BLOB source implementation for Unit-Test";
			}

			@Override
			public boolean isRDFDataSource() {
				return false;
			}

			@Override
			public boolean isBLOBDataSource() {
				return true;
			}

			@Override
			public Set<Capability> getCapabilities() {
				return null;
			}

			@Override
			public RDFDataSource asRDFDataSource() {
				return null;
			}

			@Override
			public BLOBDataSource asBLOBDataSource() {
				return this;
			}

			@Override
			public long getBlobSize(String uri) {
				return 0;
			}

			@Override
			public InputStream getBlob(String uri) {
				return null;
			}
			
			@Override
			public InputStream getBlob(String uri, BLOBRetrievalHints hints) throws UnsupportedOperationException {
		        if (hints.getMode() == Mode.ORIGINAL) {
		            return getBlob(uri);
		        } else {
		            throw new UnsupportedOperationException("BLOB transformation not supported");
		        }
			}

			@Override
			public boolean deleteBlob(String uri) {
				return false;
			}

			@Override
			public boolean canHandleBlob(String uri) {
				return false;
			}

            @Override
            public String saveBlob(InputStream blob, String originalURI) {
                return "TEST";
            }

            @Override
            public String createBlob(InputStream blob) {
                return "TEST";
            }
		};

		simpleCM.getComponentContainer().registerComponentInstance(BLOBDataSource.class, blobSource);

		ServiceRegistry sr = new ServiceRegistry();
		OsssoMachine om = new OsssoMachine(sr, getPersistenceBase());

		Configuration configuration = new PropertiesConfiguration(System.getProperties());
		try {
			DataNetworkPlugin dne = new DataNetworkPlugin(null, configuration, simpleCM);
			OsssoVHostPlugin ovhostPlugin = new OsssoVHostPlugin(configuration, simpleCM, dne);

			OsssoModelFactory modelFactory = new SimpleOsssoModelFactory(ModelFactory.createDefaultModel(), ovhostPlugin, om.getProcessRegistry(), simpleCM);
			om.setOsssoModelFactory(modelFactory);
		} catch (PlugInInitialisationException e) {
		} catch (ConfigurationException e) {
		}

		OsssoProcess process = om.createProcess();
		OsssoModel model = process.getOsssoModel();

		context = new HttpServiceContext(ModelFactory.createDefaultModel(), model);
		fillContextWithInitialValues();
	}

	private File getPersistenceBase() {
		return new File(System.getProperty("user.home"), ".m2n-im/test/ossso/persistence");
	}

	private void fillContextWithInitialValues() {
		context.setValue("companyId", "183286p");
		context.setValue("coll", "blablabla");

		for (String tunnelConfigurationKey : CONFIG_KEYS) {
			String tunnelValue = serviceConfiguration
					.getAdditionalValue(tunnelConfigurationKey);
			context.setValue(tunnelConfigurationKey, tunnelValue);
		}
	}

	public PortalAuthenticatingServiceStage createPortalAuthenticatingServiceStage() {
		return new PortalAuthenticatingServiceStage(serviceConfiguration);
	}

	public FirmenbuchAuszugRetrievalStage createFirmenbuchAuszugRetrievalStage() {
		return new FirmenbuchAuszugRetrievalStage(serviceConfiguration);
	}

	public HttpServiceContext getContext() {
		return context;
	}

	public HttpClient getHttpClient() {

		String logging = "org.apache.commons.logging";
		// Configure Logging
		System.setProperty(logging + ".Log", logging + ".impl.SimpleLog");
		System.setProperty(logging + ".logging.simplelog.showdatetime", "true");
		System.setProperty(logging + ".simplelog.log.httpclient.wire", "debug");
		System.setProperty(logging
						   + ".simplelog.log.org.apache.commons.httpclient", "debug");

		HttpParams basicParams = new BasicHttpParams();
		HttpProtocolParams.setVersion(basicParams, HttpVersion.HTTP_1_1);

		SchemeRegistry schemeRegistry = new SchemeRegistry();

		Scheme http = new Scheme("http", 80, PlainSocketFactory
				.getSocketFactory());
		schemeRegistry.register(http);

		// TODO: maybe we don't want an easy trust manager?
		try {
			SSLContext sslContext = SSLContext.getInstance("SSL");

			TrustManager easyTrustManager = new X509TrustManager() {

				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain,
											   String authType) throws CertificateException {
					// easy peasy
				}

				@Override
				public void checkClientTrusted(X509Certificate[] chain,
											   String authType) throws CertificateException {
					// easy peasy
				}
			};

			sslContext
					.init(null, new TrustManager[] {
						  easyTrustManager
					}, null);
			SSLSocketFactory sslFactory = new SSLSocketFactory(sslContext,
															   SSLSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
			Scheme https = new Scheme("https", 443, sslFactory);
			schemeRegistry.register(https);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ClientConnectionManager cm = new ThreadSafeClientConnManager(
																	 schemeRegistry);
		CustomHttpClient client = new CustomHttpClient(cm, basicParams);

		client.setRedirectStrategy(new DefaultRedirectStrategy() {

			public boolean isRedirected(HttpRequest request,
										HttpResponse response, HttpContext context) {
				boolean isRedirect = false;
				try {
					isRedirect = super.isRedirected(request, response, context);
				} catch (ProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (!isRedirect) {
					int responseCode = response.getStatusLine().getStatusCode();
					if (responseCode == 301 || responseCode == 302) {
					return true;
					}

					/*
					 * if (response.getStatusLine().getReasonPhrase().contains(
					 * "Document follows")) { return true; }
					 */
				}
				return false;
			}
		});

		return client;
	}
}
