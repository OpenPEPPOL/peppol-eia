/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.ProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.DefaultRedirectStrategy;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HttpContext;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.peppol.service.external.common.AbstractHTTPServiceWrapper;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceUtil;
import at.m2n.IntelligenceManagement.peppol.service.external.common.apache.CustomHttpClient;
import at.m2n.IntelligenceManagement.peppol.service.external.common.failure.impl.ErrorDocumentGeneratingFailureHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceErrorHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStage;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult;
import at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.fallback.FirmenbuchFallbackErrorHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.stages.FirmenbuchAuszugRetrievalStage;
import at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.stages.PortalAuthenticatingServiceStage;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;

public class FirmenbuchServiceWrapper extends AbstractHTTPServiceWrapper implements HttpServiceErrorHandler {

	private static final Collection<String> tunnelConfigurationKeys = new ArrayList<String>();
	static {
		tunnelConfigurationKeys.add("portal.baseURL");
		tunnelConfigurationKeys.add("portal.auth.user");
		tunnelConfigurationKeys.add("portal.auth.password");
		tunnelConfigurationKeys.add("fbService.fileNamePattern");
		tunnelConfigurationKeys.add("fbService.baseURL");
	}

	public FirmenbuchServiceWrapper(String name) {
		this(name, new HttpServiceConfiguration(FirmenbuchServiceWrapper.class, tunnelConfigurationKeys, HttpServiceConfiguration.EVAL_LENIENT));
	}

	private FirmenbuchServiceWrapper(String name, HttpServiceConfiguration serviceConfiguration) {
		super(name, serviceConfiguration);

		registerStages();
	}

	private void registerStages() {
		HttpServiceStage portalAuthentication = new PortalAuthenticatingServiceStage(getServiceConfiguration());
		HttpServiceStage serviceAccess = new FirmenbuchAuszugRetrievalStage(getServiceConfiguration());

		addServiceStage(portalAuthentication);
		addServiceStage(serviceAccess);
	}

	@Override
	protected void fillInitialServiceContext(HttpServiceContext context, Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model) {
		if (bindings != null) {
			context.setValue("companyId", HttpServiceUtil.getCompanyId(bindings));
			context.setValue("coll", bindings.get(Node.createVariable("coll")).getURI());
		}

		HttpServiceConfiguration serviceConfiguration = getServiceConfiguration();

		for (String tunnelConfigurationKey : tunnelConfigurationKeys) {
			String tunnelValue = serviceConfiguration.getAdditionalValue(tunnelConfigurationKey);
			context.setValue(tunnelConfigurationKey, tunnelValue);
		}
	}

	@Override
	protected HttpClient createHttpClient() {
		String logging = "org.apache.commons.logging";
		// Configure Logging
		System.setProperty(logging + ".Log", logging + ".impl.SimpleLog");
		System.setProperty(logging + ".logging.simplelog.showdatetime", "true");
		System.setProperty(logging + ".simplelog.log.httpclient.wire", "debug");
		System.setProperty(logging + ".simplelog.log.org.apache.commons.httpclient", "debug");

		HttpParams basicParams = new BasicHttpParams();
		HttpProtocolParams.setVersion(basicParams, HttpVersion.HTTP_1_1);

		SchemeRegistry schemeRegistry = new SchemeRegistry();

		Scheme http = new Scheme("http", 80, PlainSocketFactory.getSocketFactory());
		schemeRegistry.register(http);

		// TODO: maybe we don't want an easy trust manager?
		try {
			SSLContext sslContext = SSLContext.getInstance("SSL");

			TrustManager easyTrustManager = new X509TrustManager() {

				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					// easy peasy
				}

				@Override
				public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					// easy peasy
				}
			};

			sslContext.init(null, new TrustManager[] {
							easyTrustManager
			}, null);
			SSLSocketFactory sslFactory = new SSLSocketFactory(sslContext,
															   SSLSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
			Scheme https = new Scheme("https", 443, sslFactory);
			schemeRegistry.register(https);
		} catch (NoSuchAlgorithmException e) {
			logger.error("No Such Algorithm!", e);
		} catch (KeyManagementException e) {
			logger.error("Key Management Error!", e);
		}

		ClientConnectionManager cm = new ThreadSafeClientConnManager(
																	 schemeRegistry);
		CustomHttpClient client = new CustomHttpClient(cm, basicParams);

		client.setRedirectStrategy(new DefaultRedirectStrategy() {

			public boolean isRedirected(HttpRequest request,
										HttpResponse response, HttpContext context) {
				boolean isRedirect = false;
				try {
					isRedirect = super.isRedirected(request, response, context);
				} catch (ProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (!isRedirect) {
					int responseCode = response.getStatusLine().getStatusCode();
					if (responseCode == 301 || responseCode == 302) {
					return true;
					}

					/*
					 * if (response.getStatusLine().getReasonPhrase().contains(
					 * "Document follows")) { return true; }
					 */
				}
				return false;
			}
		});

		return client;
	}

	@Override
	public HttpServiceStageResult handleError(HttpClient httpClient, HttpServiceContext context) {
		// TODO: Make this configurable which error handling strategy we want to apply? (presentation vs. production)
		HttpServiceErrorHandler delegate = null;
		if (System.getProperty("presentation") != null) {
			delegate = new FirmenbuchFallbackErrorHandler();
		}
		else {
			delegate = new ErrorDocumentGeneratingFailureHandler("fb_auszug_fehler.pdf", "Fehlerhafter Aufruf Firmenbuchauszug.pdf", "application/pdf");
		}
		return delegate.handleError(httpClient, context);
	}
}
