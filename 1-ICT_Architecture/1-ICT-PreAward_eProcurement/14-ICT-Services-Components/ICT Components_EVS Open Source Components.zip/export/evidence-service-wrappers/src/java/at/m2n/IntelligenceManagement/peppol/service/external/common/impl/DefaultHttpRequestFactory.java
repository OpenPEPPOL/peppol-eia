/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common.impl;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;

import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpRequestFactory;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration.Method;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;

/**
 * Default implementation for a HTTP GET/POST factory.
 * 
 * @author schwingenschloegl
 */
public class DefaultHttpRequestFactory implements HttpRequestFactory {

	@Override
	public HttpRequestBase createForConfiguration(HttpServiceConfiguration configuration, HttpServiceContext context) {
		HttpServiceConfiguration.Method method = configuration.getMethod();
		if (method == Method.HTTP_GET) {
			return new HttpGet(configuration.getBaseURL());
		}
		else if (method == Method.HTTP_POST) { return new HttpPost(configuration.getBaseURL()); }

		// invariant: If control reaches this point, an invalid/unsupported method was provided
		throw new RuntimeException("Invalid/unsupported HTTP method! (only GET or POST possible)");
	}
}
