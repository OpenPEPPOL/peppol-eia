/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common.stages;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.util.Pair;

import com.hp.hpl.jena.rdf.model.Model;

/**
 * @author schwingenschloegl
 */
public class HttpServiceContext {

	private Map<String, String> params = new HashMap<String, String>();
	private static final Logger logger = Logger.getLogger(HttpServiceContext.class);

	private final Model additionsModel;
	private final OsssoModel osssoModel;

	public HttpServiceContext(Model additionsModel, OsssoModel osssoModel) {
		this.additionsModel = additionsModel;
		this.osssoModel = osssoModel;
	}

	public Model getAdditionsModel() {
		return additionsModel;
	}

	public OsssoModel getOsssoModel() {
		return osssoModel;
	}

	public void setValue(String key, String value) {
		params.put(sanitizedKey(key), value);
	}

	public String getValue(String key, String defaultValue) {
		String value = params.get(sanitizedKey(key));
		if (value == null) {
			value = defaultValue;
		}

		return value;
	}

	public Collection<Pair<String, String>> getFilteredValues(String keyStart) {
		keyStart = sanitizedKey(keyStart);

		Collection<Pair<String, String>> retVal = new ArrayList<Pair<String, String>>();

		for (Map.Entry<String, String> paramsEntry : params.entrySet()) {
			String key = sanitizedKey(paramsEntry.getKey());
			if (key.startsWith(keyStart)) {
				retVal.add(new Pair<String, String>(key, paramsEntry.getValue()));
			}
		}

		return retVal;
	}

	public boolean satisfiesPrecondition(Collection<String> requiredKeys) {
		if (requiredKeys == null || requiredKeys.isEmpty()) {
			// No requirements -> precondition automatically satisfied
			return true;
		}

		// invariant: requiredKeys != null and also not empty
		for (String requiredKey : requiredKeys) {
			// We do a negative check: If we find one required key that is not satisfied, we can branch out early.
			if (!params.containsKey(sanitizedKey(requiredKey))) {
				logger.info("Requirement for key " + requiredKey + " is not satisfied.");
				logger.debug(params);
				return false;
			}
		}

		// invariant: If control reaches this point, all required keys are "satisfied"
		return true;
	}

	public Collection<String> getPreconditionViolations(Collection<String> requiredKeys) {
		Collection<String> violations = new HashSet<String>();

		if (requiredKeys != null) {
			for (String requiredKey : requiredKeys) {
				if (!params.containsKey(sanitizedKey(requiredKey))) {
					violations.add(requiredKey);
				}
			}
		}

		return violations;
	}

	private String sanitizedKey(String key) {
		return key.toLowerCase();
	}
}
