/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.edikt;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.peppol.service.external.common.AbstractHTTPServiceWrapper;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpRequestFactory;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpResponseHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceUtil;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStage;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.impl.ResponseHandlerWrappingServiceStage;
import at.m2n.IntelligenceManagement.uis.UISPlugin;
import at.m2n.jena.util.URIGenerator;
import at.m2n.jena.util.transaction.ModelTransaction;
import at.m2n.util.Util;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;
import com.hp.hpl.jena.vocabulary.RDF;

/** a pseudoservice for the demo on monday.. placed here to re-use most of the ediktsdatei logic. */
public class UnschuldServiceWrapper extends AbstractHTTPServiceWrapper {

	private static final Logger logger = Logger.getLogger(UnschuldServiceWrapper.class);
	private UISPlugin uisPlugin;

	public UnschuldServiceWrapper(String name, UISPlugin uisPlugin) {
		this(name, new HttpServiceConfiguration(UnschuldServiceWrapper.class));
		this.uisPlugin = uisPlugin;
		
		HttpServiceUtil.setUISPlugin(uisPlugin);
	}

	private UnschuldServiceWrapper(String name, HttpServiceConfiguration configuration) {
		super(name, configuration);

		setup();
	}

	private void setup() {
		HttpResponseHandler blobSavingResponseHandler = new HttpResponseHandler() {

			@Override
			public void handleResponse(InputStream responseStream, HttpResponse response, HttpServiceContext context) throws IOException {
				StringBuilder sb = new StringBuilder("Westen-Wäsche-Zertifikat\n\n    für ");
				sb.append(context.getValue("companyId", "Unbekannt"));
				sb.append("\n\nIhre Weste wurde weißgewaschen.\n");
				sb.append("\n\n");
				sb.append("Stand: " + new Date());
				sb.append("\n\nWestenwäscherei Saubermann & Söhne");

				String fileName = "Westenwäschezertifikat für " + context.getValue("companyId", "Unbekannt") + ".txt";
				HttpServiceUtil.saveBlobFromStream(	new ByteArrayInputStream(sb.toString().getBytes()), fileName, "text/html", context.getOsssoModel(),
													context.getAdditionsModel(),
													context);
			}
		};
		HttpRequestFactory requestFactory = new HttpRequestFactory() {

			@Override
			public HttpGet createForConfiguration(HttpServiceConfiguration configuration, HttpServiceContext context) {
				HttpGet httpGetMethod = new HttpGet(context.getValue("baseURL", null));
				return httpGetMethod;
			}
		};

		HttpServiceStage blobFetchingStage = new ResponseHandlerWrappingServiceStage(getServiceConfiguration(), blobSavingResponseHandler, requestFactory, null,
																						Util.toList("baseURL", "coll", "companyId"));
		addServiceStage(blobFetchingStage);
	}

	private boolean saveBlobFromStream(InputStream responseStream, OsssoModel model, Model modelAdd, Node_Concrete coll, Map<Node_Variable, Node_Concrete> resolvedBindings) {
		AtomicLong savedBlobSize = new AtomicLong();
		String savedBlobURI = model.saveBlob(responseStream, null, savedBlobSize);
		if (savedBlobURI != null) {
			// invariant: The blob could be saved successfully
			Resource blob = new ResourceImpl(savedBlobURI);

			Resource rCollector = (Resource) modelAdd.getRDFNode(coll).as(Resource.class);
			Property pDocument = new PropertyImpl("http://m2n.at/2009/05/peppol/evidenceDocument");
			String fileName = "Westenwäschezertifikat für " + getCompanyId(resolvedBindings) + ".txt";
			Resource rTheDocument = createDocumentResource(modelAdd, blob, fileName, savedBlobSize.get());
			modelAdd.add(modelAdd.createStatement(rCollector, pDocument, rTheDocument));

			// TODO: this is only for the demo - we want to have the result show up in the userstatusfragment, hence we need to write into the other model, too, and attach it to
			// the request.
			// TODO: once this is gone we probably don't need the UIS plugin dependency anymore and can kick it out again
			Resource rRequest = findRequest(model);
			Property pAddToRequest = new PropertyImpl("http://m2n.at/2009/05/peppol/resultArchiveFull");
			attachToRequest(rRequest, pAddToRequest, blob, fileName, savedBlobSize.get());
			return true;
		}
		else {
			logger.fatal("Could not save the BLOB!");
			return false;
		}
	}

	private Resource createDocumentResource(Model targetModel, Resource blob, String fileName, long fileSize) {
		Resource document = targetModel.getResource(URIGenerator.getForURI("m2n://Document/Unschuld"));
		document.addProperty(RDF.type, new ResourceImpl("m2n://Document"));
		document.addProperty(new PropertyImpl("m2n://Document#blob"), blob);
		document.addProperty(new PropertyImpl("m2n://Document#fileName"), fileName);
		document.addProperty(new PropertyImpl("m2n://Document#mimeType"), "text/plain");
		document.addProperty(new PropertyImpl("m2n://Document#fileSize"), fileSize);
		return document;
	}

	private void attachToRequest(Resource rRequest, Property pAddToRequest, Resource blob, String fileName, long fileSize) {


		final Model m = ModelFactory.createDefaultModel();
		Resource rTheDocument = createDocumentResource(m, blob, fileName, fileSize);
		rRequest = (Resource) rRequest.inModel(m).as(Resource.class);
		rRequest.addProperty(pAddToRequest, rTheDocument);


		// we also want to write this into the process metadata model!
		ModelTransaction mt = ModelTransaction.create(uisPlugin.getOsssoProcessMetadataModel());
		try {
			mt.add(m);
			mt.commit();
		}
		finally {
			mt.close();
		}
	}

	private Resource findRequest(OsssoModel model) {
		StmtIterator iRequests = model.getModel().listStatements(null, RDF.type, new ResourceImpl("http://m2n.at/2009/05/peppol/VCDRequest"));
		try {
			if (iRequests.hasNext()) { return iRequests.nextStatement().getSubject(); }
		}
		finally {
			iRequests.close();
		}

		return null;
	}

	private String getCompanyId(Map<Node_Variable, Node_Concrete> bindings) {
		Node companyIdNode = bindings.get(Node.createVariable("economicOperatorID"));
		if (companyIdNode != null) {
			String companyId = companyIdNode.getLiteralLexicalForm();
			return companyId;
		}

		return "Firma/Person X";
	}

	@Override
	protected void fillInitialServiceContext(HttpServiceContext context, Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model) {
		context.setValue("companyId", HttpServiceUtil.getCompanyId(bindings));
		context.setValue("coll", bindings.get(Node.createVariable("coll")).getURI());
	}
}
