/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common.stages;

/**
 * The result of the call of the stage of a service. Immutable.
 * 
 * @author schwingenschloegl
 */
public class HttpServiceStageResult {

	public static final boolean NO_RETRY = false;
	public static final boolean ATTEMPT_RETRY = true;

	public static enum State {
		SUCCESS("success"), EXECUTING("executing"), FAILURE_TEMPORARY("failure_temporary"), FAILURE("failure");

		private String stringRep;

		private State(String stringRep) {
			this.stringRep = stringRep;
		}

		public String toString() {
			return stringRep;
		}

		public boolean isSuccess() {
			return this == SUCCESS;
		}

		public boolean isFailure() {
			return this == FAILURE_TEMPORARY || this == FAILURE;
		}
	};

	private State state;
	private boolean isRetryFeasible;

	public HttpServiceStageResult(State state) {
		if (state.isFailure()) { throw new IllegalStateException("If you specify an error state, you need to tell if a retry attempt is feasible or not."); }

		// invariant: !state.isFailure()
		this.state = state;
		this.isRetryFeasible = NO_RETRY; // doesn't matter what we pass
	}

	public HttpServiceStageResult(State state, boolean isRetryFeasible) {
		this.state = state;
		this.isRetryFeasible = isRetryFeasible;
	}

	public State getState() {
		return state;
	}

	public boolean isRetryFeasible() {
		return state.isFailure() && isRetryFeasible;
	}

	public void assertState(State state) {
		if (getState() != state) {
			// oh oh
			throw new IllegalStateException("Expected state '" + state + "' but had state '" + this.state + "'!");
		}
	}
}
