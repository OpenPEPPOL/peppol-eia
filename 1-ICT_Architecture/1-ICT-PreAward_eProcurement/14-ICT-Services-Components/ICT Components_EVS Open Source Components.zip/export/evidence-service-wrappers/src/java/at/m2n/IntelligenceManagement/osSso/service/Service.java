/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.osSso.service;

import java.util.Map;
import java.util.Set;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;

import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.graph.Triple;



/** The Interface for Semantic Services (or Semantic Service Wrappers).
 *
 */
public interface Service {

  /** Used to query whether the service can, in principle, solve the given problem.
   *  Since no further data is given, this will usually be answered through some kind of heuristic approach. 
   *  
   *  When in doubt, this should return true.  
   * 
   * @param problem The Problem to solve.
   * @return true if the service expects to be able to solve the given problem.
   */
  boolean canResolve(Problem problem);
  
  
  /** Used to query whether the service can, in principle, solve the given problem with the given model as additional input data.
   * 
   * @deprecated REMOVAL CANDIDATE, ONLY USED IN SERVICE TRIAGER AND NOT STRICTLY NECCESSARY THERE 
   * @param problem
   * @param model
   * @return
   */
  boolean canResolve(Problem problem, OsssoModel model);
  
  
  /** Call this service. 
   * 
   * The given bindings have to be respected, but the service is free to query the model for any additional data it may need. 
   * If the bindings passed here aren't specific enough, the service has several options:
   * 
   * <ul>
   *   <li>fail. TODO: what exception to throw?</li>
   *   <li>fail silently</li>
   *   <li>consult the given problem(s) to see what might be most useful in the current context</li>
   *   <li>choose freely</li>
   * </ul>
   * 
   *  TODO: which shall we recommend? which shall we prohibit?
   * 
   * @param bindings
   * @param problem
   * @param problems
   * @param model
   * @return
   */
  ServiceExecution call(Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model);

  /** @return true if the service has preconditions, i.e. getPreconditions() will return a non-null, non-empty Set. 
   */
  boolean hasPreconditions();
  
  /** A service can have preconditions,triple patterns that have to be satisfied for it to work. 
   * 
   * @return the preconditions that need to be satisfied
   */
  Set<Triple> getPreconditions();
  
  /** A service promises to the ossso machine that its result will have a certain form.
   *  Of course, a service is free to produce more than it promises, 
   *  and an actual call might also fail, so this is a relatively weak promise.
   * 
   * @return
   */
  Set<Triple> predictResults();
  
  /** Create bindings for the preconditions by applying your postconditions to the given problem.
   * 
   *  For example, the problem might be of the form (<A> <b> ANY), and your postconditions might contain (or even be equal to) (?x <b> ?y); 
   *  this would mean the bindings should contain ?x => <A>.
   */
  Map<Node_Variable, Node_Concrete> getVariableBindings(Problem solveThis);
  
  
  /** Get the value for the given QOS parameter. 
   *  If you don't know any better, return 0.
   * @param uri
   * @return
   */
  float getQOSParameter(String uri);
  
  /**
   * Needed only by PotentiallyPassiveServiceSelector
   * @return
   */
  boolean isPassive();
}
