/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import at.m2n.IntelligenceManagement.osSso.service.impl.ServicePreAndPostConditions;

/**
 * All the configuration for a specific HTTP-based service request.
 * 
 * @author schwingenschloegl
 */
public class HttpServiceConfiguration {

	public static final Boolean EVAL_STRICT = Boolean.FALSE;
	public static final Boolean EVAL_LENIENT = Boolean.TRUE;

	private String baseURL;

	private String preCondition;
	private String postCondition;

	public enum Method {
		HTTP_GET, HTTP_POST
	};

	private Map<String, String> additionalParams = new HashMap<String, String>();

	private Method method;

	// TODO: Also manage Service URI and provided Evidence URI?

	public HttpServiceConfiguration(Class<?> configurationForClass, Collection<String> additionalParamKeys, boolean lenient) {
		ResourceBundle bundle = ResourceBundle.getBundle(configurationForClass.getName());
		baseURL = getFromBundle(bundle, "service.http.baseURL", lenient);
		preCondition = getFromBundle(bundle, "service.precondition", lenient);
		postCondition = getFromBundle(bundle, "service.postcondition", lenient);
		String method = getFromBundle(bundle, "service.method", lenient);
		if ("post".equalsIgnoreCase(method)) {
			this.method = Method.HTTP_POST;
		}
		else {
			this.method = Method.HTTP_GET;
		}

		for (String additionalParamKey : additionalParamKeys) {
			String additionalParamValue = getFromBundle(bundle, additionalParamKey, lenient);
			additionalParams.put(additionalParamKey, additionalParamValue);
		}
	}

	/**
	 * @deprecated use {@link #HttpServiceConfiguration(Class, Collection, boolean)} instead
	 * @param configurationForClass
	 */
	@Deprecated
	public HttpServiceConfiguration(Class<?> configurationForClass) {
		this(configurationForClass, Collections.<String> emptySet(), EVAL_STRICT);
	}

	public HttpServiceConfiguration(String baseURL, String preCondition, String postCondition, Method method) {
		this.baseURL = baseURL;
		this.preCondition = preCondition;
		this.postCondition = postCondition;
		this.method = method;
	}

	public String getBaseURL() {
		return baseURL;
	}

	public Method getMethod() {
		return method;
	}

	public String getPreCondition() {
		return preCondition;
	}

	public String getPostCondition() {
		return postCondition;
	}

	public ServicePreAndPostConditions getServicePreAndPostConditions() {
		return ServicePreAndPostConditions.parse(getPreCondition(), getPostCondition());
	}

	public String getAdditionalValue(String key) {
		return additionalParams.get(key);
	}

	private String getFromBundle(ResourceBundle bundle, String key, boolean lenient) {
		try {
			String retVal = bundle.getString(key);
			return retVal;
		}
		catch (NullPointerException e) {
			if (!lenient) {
				throw e;
			}
			else {
				return null;
			}
		}
		catch (MissingResourceException e) {
			if (!lenient) {
				throw e;
			}
			else {
				return null;
			}
		}
		catch (ClassCastException e) {
			if (!lenient) {
				throw e;
			}
			else {
				return null;
			}
		}
	}
}
