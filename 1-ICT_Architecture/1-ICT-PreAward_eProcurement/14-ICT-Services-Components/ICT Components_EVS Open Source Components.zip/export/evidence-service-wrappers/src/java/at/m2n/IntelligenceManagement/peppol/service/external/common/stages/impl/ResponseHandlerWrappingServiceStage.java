/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common.stages.impl;

import java.io.IOException;
import java.util.Collection;
import java.util.Collections;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;

import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpRequestFactory;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpResponseHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceUtil;
import at.m2n.IntelligenceManagement.peppol.service.external.common.params.HttpRequestArgumentsHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStage;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult.State;

/**
 * @author schwingenschloegl
 */
public class ResponseHandlerWrappingServiceStage implements HttpServiceStage {

	private final HttpServiceConfiguration serviceConfiguration;
	private final HttpResponseHandler responseHandler;
	private final HttpRequestFactory requestFactory;
	private final HttpRequestArgumentsHandler argumentsHandler;

	private final Collection<String> requiredKeys;

	public ResponseHandlerWrappingServiceStage(HttpServiceConfiguration serviceConfiguration, HttpResponseHandler responseHandler, HttpRequestFactory requestFactory,
												HttpRequestArgumentsHandler argumentsHandler, Collection<String> requiredKeys) {
		this.serviceConfiguration = serviceConfiguration;
		this.responseHandler = responseHandler;
		this.requestFactory = requestFactory;
		this.argumentsHandler = argumentsHandler;
		this.requiredKeys = requiredKeys;
	}

	@Override
	public HttpServiceStageResult call(HttpClient httpClient, HttpServiceContext context) {

		try {
			HttpServiceUtil.executeHttpRequest(httpClient, context, serviceConfiguration, responseHandler, requestFactory, argumentsHandler);
			return new HttpServiceStageResult(State.SUCCESS);
		}
		catch (ClientProtocolException e) {
			return new HttpServiceStageResult(State.FAILURE, HttpServiceStageResult.NO_RETRY);
		}
		catch (IOException e) {
			return new HttpServiceStageResult(State.FAILURE_TEMPORARY, HttpServiceStageResult.ATTEMPT_RETRY);
		}
	}

	@Override
	public Collection<String> getRequiredKeys() {
		return Collections.unmodifiableCollection(requiredKeys);
	}
}
