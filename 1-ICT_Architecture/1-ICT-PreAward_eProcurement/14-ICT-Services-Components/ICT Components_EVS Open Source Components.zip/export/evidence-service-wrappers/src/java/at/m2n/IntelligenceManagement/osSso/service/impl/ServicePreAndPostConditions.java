/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.osSso.service.impl;

import java.io.StringReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import antlr.RecognitionException;
import antlr.TokenStreamException;
import antlr.collections.AST;
import at.m2n.IntelligenceManagement.osSso.MissingTripleProblem;
import at.m2n.IntelligenceManagement.osSso.Problem;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.n3.AntlrUtils;
import com.hp.hpl.jena.n3.N3Parser;
import com.hp.hpl.jena.n3.N3ParserEventHandler;
import com.hp.hpl.jena.n3.NullN3EventHandler;
import com.hp.hpl.jena.n3.RelURI;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.Syntax;
import com.hp.hpl.jena.query.core.BindingMap;
import com.hp.hpl.jena.query.core.ResultBinding;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.shared.JenaException;
import com.hp.hpl.jena.shared.PrefixMapping;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.XSD;

public class ServicePreAndPostConditions {
  private Set<Triple> pre;
  private Set<Triple> post;
  private Query construct;
  private Query ask;
  private Query select;
  
  public ServicePreAndPostConditions(Set<Triple> pre, Set<Triple> post) {
    super();
    this.pre = pre;
    this.post = post;
    
    this.construct = createConstructQuery(pre, post);
    this.ask = createAskQuery(pre);
    this.select = createSelectQuery(pre);
  }
  
  
  
  
  
  
  
  
  /** Produces a full set of bindings for all precondition variables.
   * Matches the precondition triples against the given model, optionally applying the passed bindings.
   * 
   * @param model The model againts which to match
   * @param bindings A set of bindings that should be applied before matching, or null (or an empty map).
   * @return A set of bindings that includes all variables from the precondition triples.
   */
  public Map<Node_Variable, Node_Concrete> extractInput(Model model, Map<Node_Variable, Node_Concrete> bindings) {
    Map<Node_Variable, Node_Concrete> newMap = new HashMap<Node_Variable, Node_Concrete>(bindings);

    QueryExecution qe = QueryExecutionFactory.create(select, model, createBindings(bindings, model));
    try {
      ResultSet rs = qe.execSelect();
      
      if (rs.hasNext()) {
        QuerySolution qs = rs.nextSolution();
        Iterator<?> vars = qs.varNames();
        while(vars.hasNext()) {
          String var = (String) vars.next();
          RDFNode val = qs.get(var);
          newMap.put((Node_Variable)Node.createVariable(var), (Node_Concrete)val.asNode());
        }
      } else {
        //TODO: what if no result?!??
        //TODO: what if multiple results???!
      }
      
    } finally {
      qe.close();
    }
    
    return newMap;
  }
  
  /** Construct a result model by applying the given binding to the postcondition triples. */
  public Model constructOutput(Model m, Map<Node_Variable, Node_Concrete> bindings) {
    if (construct == null) 
      return ModelFactory.createDefaultModel();
    
    return QueryExecutionFactory.create(construct, m, createBindings(bindings, m)).execConstruct();
  }

  
  
  
  
  
  

  public Set<Triple> getPre() {
    return pre;
  }

  public Set<Triple> getPost() {
    return post;
  }

  public Map<Node_Variable, Node_Concrete> getVariableBindings(Problem solveThis) {
    Map<Node_Variable, Node_Concrete> retVal = new HashMap<Node_Variable, Node_Concrete>();
    
    if (solveThis instanceof MissingTripleProblem) { //TODO: what if it is NOT an mtp?
      
      MissingTripleProblem mtp = (MissingTripleProblem)solveThis;
      Triple pt = mtp.getTriple().asTriple();
      
      Node n = pt.getMatchPredicate();
      if (n.hasURI("m2n://produces")) {
        System.out.println("uah");
      }

      for (Triple t: post) {
        if (ServiceUtil.matches(t, pt)) {
          bindIfVar(t.getSubject(), pt.getSubject(), retVal);
          bindIfVar(t.getPredicate(), pt.getPredicate(), retVal);
          bindIfVar(t.getObject(), pt.getObject(), retVal);
        }
      }
    }      
    
    
    return retVal;
  }







  private void bindIfVar(Node var, Node conc, Map<Node_Variable, Node_Concrete> m) {
    if (var.isVariable() && conc.isConcrete()) {
      m.put((Node_Variable)var, (Node_Concrete)conc);
    }
  }



  public boolean preconditionsMet(Model m) {
    if (ask == null) return true;
    return QueryExecutionFactory.create(ask, m).execAsk();
  }



  
  
  private QuerySolution createBindings(Map<Node_Variable, Node_Concrete> bindings, Model m) throws NoSuchElementException {
    ResultBinding r = new ResultBinding(m, new BindingMap());
    
    if (bindings != null) {
      for (Node_Variable var : bindings.keySet()) {
        Node_Concrete val = bindings.get(var);
        
        if (val == null)
          throw new NoSuchElementException("Variable "+var+" has no value.");
        
        r.add(var.getName(), m.asRDFNode(val));
      }
    }

    return r;
  }





  static Set<Triple> parse(String s) {
      final Set<Triple> retVal = new HashSet<Triple>();
      
      if (s == null)
        return retVal;
      
      N3ParserEventHandler neh = new NullN3EventHandler() {
        private Model model = ModelFactory.createDefaultModel();
               
        private void error(String msg) {
          error(new JenaException(msg), msg);
        }
        
        
        public void directive(int line, AST directive, AST[] args, String context)
        {
            if ( directive.getType() == N3Parser.AT_PREFIX )
            {
                // @prefix now
                if ( args[0].getType() != N3Parser.QNAME )
                {
                    error("Line "+line+": N3toRDF: Prefix directive does not start with a prefix! "+args[0].getText()+ "["+N3Parser.getTokenNames()[args[0].getType()]+"]") ;
                    return ;
                }
                        
                String prefix = args[0].getText() ;
                if ( prefix.endsWith(":") )
                    prefix = prefix.substring(0,prefix.length()-1) ;
                    
                if ( args[1].getType() != N3Parser.URIREF )
                {
                    error("Line "+line+": N3toRDF: Prefix directive does not supply a URIref! "+args[1].getText()) ;
                    return ;
                }
                
                String uriref = args[1].getText() ;
                uriref = expandURIRef(uriref, line) ;
                
                if ( uriref == null )
                    error("Line "+line+": N3toRDF: Relative URI can't be resolved in in @prefix directive") ;  
                    
                setPrefixMapping(model, prefix, uriref) ;
                return ;
            }
            
            error("Line "+line+": N3toRDF: Directive not recongized and ignored: "+directive.getText()) ;
            return ;
        }

        private void setPrefixMapping(Model m, String prefix, String uriref)
        {
            try { model.setNsPrefix(prefix, uriref); }
            catch (PrefixMapping.IllegalPrefixException ex)
            {
                error("Prefix mapping '" + prefix + "' illegal: used but not recorded in model");
            }
        }

        private String expandURIRef(String text, int line)
        {
            try {
                return RelURI.resolve(text, null) ;
            } catch (Exception ex)
            { 
                error("Line "+line+": N3toRDF: Bad URI: "+text+ " ("+ex.getMessage()+")") ;
            }
            return null ;
        }

        @Override
        public void quad(int line, AST subj, AST prop, AST obj, String context) {
          Node sNode = createNode(line, subj);
          Node pNode = createNode(line, prop);
          Node oNode = createNode(line, obj);
          
          Triple t = new Triple(sNode, pNode, oNode) ;
          retVal.add(t) ;
        }
        
        private Node createNode(int line, AST thing) 
        {
            //String tokenType = N3AntlrParser._tokenNames[thing.getType()] ;
            //System.out.println("Token type: "+tokenType) ;
            String text = thing.getText() ;
            switch (thing.getType())
            {
                case N3Parser.NUMBER :
                    Resource xsdType = XSD.integer ;
                    if ( text.indexOf('.') >= 0 )
                        // The choice of XSD:decimal is for compatibility with N3/cwm.
                        xsdType = XSD.decimal ;
                    if ( text.indexOf('e') >= 0 || text.indexOf('E') >= 0 )
                        xsdType = XSD.xdouble ;
                    return model.createTypedLiteral(text, xsdType.getURI()).asNode();
                    
                case N3Parser.LITERAL :
                    // Literals have three part: value (string), lang tag, datatype
                    // Can't have a lang tag and a data type - if both, just use the datatype
                    
                    AST a1 = thing.getNextSibling() ;
                    AST a2 = (a1==null?null:a1.getNextSibling()) ;
                    AST datatype = null ;
                    AST lang = null ;
  
                    if ( a2 != null )
                    {
                        if ( a2.getType() == N3Parser.DATATYPE )
                            datatype = a2.getFirstChild() ;
                        else
                            lang = a2 ;
                    }
                    // First takes precedence over second.
                    if ( a1 != null )
                    {
                        if ( a1.getType() == N3Parser.DATATYPE )
                            datatype = a1.getFirstChild() ;
                        else
                            lang = a1 ;
                    }
  
                    // Chop leading '@'
                    String langTag = (lang!=null)?lang.getText().substring(1):null ;
                    
                    if ( datatype == null )
                        return model.createLiteral(text, langTag).asNode() ;
                    
                    // If there is a datatype, it takes predence over lang tag.
                    String typeURI = datatype.getText();
  
                    if ( datatype.getType() != N3Parser.QNAME &&
                         datatype.getType() != N3Parser.URIREF )
                    {
                        error("Line "+ line+ ": N3toRDF: Must use URIref or QName datatype URI: "
                                + text+ "^^"+ typeURI+"("+N3Parser.getTokenNames()[datatype.getType()]+")");
                        return model.createLiteral("Illegal literal: " + text + "^^" + typeURI).asNode();
     
                    }
                    
                    // Can't have bNodes here so the code is slightly different for expansion
                    
                    if ( datatype.getType() == N3Parser.QNAME )
                    {
                        if (typeURI.startsWith("_:") || typeURI.startsWith("=:"))
                        {
                            error("Line "+ line+ ": N3toRDF: Can't use bNode for datatype URI: "
                                    + text+ "^^"+ typeURI);
                            return model.createLiteral("Illegal literal: " + text + "^^" + typeURI).asNode();
                        }
  
                        String typeURI2 = model.expandPrefix(typeURI) ;
                        if ( typeURI2 == typeURI )
                        {
                            error("Line "+line+": N3toRDF: Undefined qname namespace in datatype: " + typeURI);
                        }
                        
                        typeURI = typeURI2 ;
                    }
  
  //                  typeURI = expandURIRef(typeURI, line);
                    // 2003-08 - Ignore lang tag when there is an type. 
                    return model.createTypedLiteral(text, typeURI).asNode() ;
  
                case N3Parser.QNAME :
                    // Is it a labelled bNode?
                    // Check if _ has been defined.
                    if ( text.startsWith("_:") && ( model.getNsPrefixURI("_") == null ) )
                    {
                      error("no bnodes bplz, kthx");
                      break;
  //                      if ( ! bNodeMap.containsKey(text) )
  //                          bNodeMap.put(text, model.createResource()) ;
  //                      return (Resource)bNodeMap.get(text) ;
                    }
                
                    String uriref = model.expandPrefix(text) ;
                    if ( uriref == text )
                    {
                        error("Line "+line+": N3toRDF: Undefined qname namespace: " + text);
                        return null ;
                    }
                    return model.createResource(uriref).asNode() ;
  
                // Normal URIref - may be <> or <#>
                case N3Parser.URIREF :
                    return model.createResource(text).asNode() ;
  
                // Lists
                case N3Parser.TK_LIST_NIL:
                    return RDF.nil.asNode() ;
                case N3Parser.TK_LIST:
                    return RDF.List.asNode() ;
  
                case N3Parser.KW_A :
                  return RDF.type.asNode() ;
  
                case N3Parser.ANON:         // bNodes via [] or [:- ] QNAME starts "=:"
                  error("no bnodes bplz, kthx");
                  break;
  
                case N3Parser.UVAR:
                    return Node.createVariable(text.substring(1));
  
                default:
                    error("Line "+line+": N3toRDF: Can't map to a resource or literal: "+AntlrUtils.ASTout(thing)) ;
                    break ;
            }
            return null ;
        }
  
      };
      
      try {
        N3Parser p = new N3Parser(new StringReader(s), neh);
        p.parse();
      } catch (RecognitionException e) {
        throw new RuntimeException("Error parsing", e);
      } catch (TokenStreamException e) {
        throw new RuntimeException("Error parsing", e);
      }
  
      return retVal;
    }



  private static Query createConstructQuery(Set<Triple> pre, Set<Triple> post) {
    if (post == null || post.isEmpty())
      return null;

    //TODO: also check pre?
    
    StringBuilder sb = new StringBuilder();
    
    sb.append("CONSTRUCT {\n");
    appendPatterns(sb, post);
    sb.append(" } WHERE { \n");
    appendPatterns(sb, pre);
    sb.append("}");
    
    return QueryFactory.create(sb.toString(), Syntax.syntaxSPARQL);
  }

  private static Query createAskQuery(Set<Triple> pre) {
    if (pre == null || pre.isEmpty())
      return null;
    
    StringBuilder sb = new StringBuilder();
    
    sb.append("ASK {\n");
    appendPatterns(sb, pre);
    sb.append("}");
    
    return QueryFactory.create(sb.toString(), Syntax.syntaxSPARQL);
  }
  
  private static Query createSelectQuery(Set<Triple> pre) {
    if (pre == null || pre.isEmpty())
      return null;
    
    StringBuilder sb = new StringBuilder();
    
    sb.append("SELECT ");
    appendVariables(sb, pre);
    sb.append(" WHERE {\n");
    appendPatterns(sb, pre);
    sb.append("}");
    
    return QueryFactory.create(sb.toString(), Syntax.syntaxSPARQL);
  }


  private static void appendVariables(StringBuilder sb, Set<Triple> ts) {
    Set<Node_Variable> vars = new HashSet<Node_Variable>();
    
    for (Triple t : ts) {
      appendIfVar(t.getSubject(), vars);
      appendIfVar(t.getPredicate(), vars);
      appendIfVar(t.getObject(), vars);
    }
    
    for (Node_Variable var : vars) {
      sb.append("?");
      sb.append(var.getName());
      sb.append(" ");
    }
    
  }



  private static void appendIfVar(Node n, Set<Node_Variable> vars) {
    if (n.isVariable())
      vars.add((Node_Variable)n);
  }



  private static void appendPatterns(StringBuilder sb, Set<Triple> ts) {
    for (Triple t : ts) {
      append(sb, t.getSubject());
      sb.append(" ");
      append(sb, t.getPredicate());
      sb.append(" ");
      append(sb, t.getObject());
      sb.append(" .\n");
    }
  }



  private static void append(StringBuilder sb, Node n) {
    if (n.isURI()) {
      sb.append("<");
      sb.append(n.getURI());
      sb.append(">");
    } else {
      sb.append(n);
    }
  }



  public static ServicePreAndPostConditions parse(String modelPre, String modelPost) {
    Set<Triple> pre = parse(modelPre);
    Set<Triple> post = parse(modelPost);
    
    return new ServicePreAndPostConditions(pre, post);
  }

}
