/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.osSso.service.impl;

import java.util.Map;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.AbstractService;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;
import at.m2n.IntelligenceManagement.osSso.service.ServiceResult;

import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.rdf.model.Model;

public class DummyService extends AbstractService {
  public static DummyService create(String name, String modelPre, String modelPost) {
    return new DummyService(name, ServicePreAndPostConditions.parse(modelPre, modelPost));
  }
  
  private DummyService(String name, ServicePreAndPostConditions pp) {
    super(name, pp);
  }


  @Override
  public ServiceExecution doCall(final Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, final OsssoModel model) {
    if (pp.preconditionsMet(model.getModel())) { 
      return new ServiceExecution() {
        @Override
        public ServiceResult getResultBlocking() throws InterruptedException {
          Model modelAdd = pp.constructOutput(model.getModel(), bindings);
          return new MonotonuousServiceResult(modelAdd);
        }
      };
    } else throw new RuntimeException("Preconditions not met");
  }

}

