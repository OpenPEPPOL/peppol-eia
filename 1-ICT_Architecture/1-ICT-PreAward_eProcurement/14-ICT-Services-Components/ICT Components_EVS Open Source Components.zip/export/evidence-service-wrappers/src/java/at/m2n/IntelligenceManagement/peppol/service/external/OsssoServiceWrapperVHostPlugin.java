/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.picocontainer.Disposable;
import org.picocontainer.Startable;

import at.m2n.IntelligenceManagement.component.lifecycle.ComponentLifecycle;
import at.m2n.IntelligenceManagement.osSso.OsssoMachine;
import at.m2n.IntelligenceManagement.osSso.OsssoVHostPlugin;
import at.m2n.IntelligenceManagement.peppol.service.external.edikt.EdiktServiceWrapper;
import at.m2n.IntelligenceManagement.peppol.service.external.edikt.UnschuldServiceWrapper;
import at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.FirmenbuchServiceWrapper;
import at.m2n.IntelligenceManagement.plugIn.BuildInfo;
import at.m2n.IntelligenceManagement.plugIn.PlugIn;
import at.m2n.IntelligenceManagement.plugIn.PlugInInitialisationException;
import at.m2n.IntelligenceManagement.uis.UISPlugin;
import at.m2n.configuration.Configuration;
import at.m2n.configuration.ConfigurationException;

/**
 * Service wrapper plugin for osSso machine.
 * 
 * @author schwingenschloegl
 */
public class OsssoServiceWrapperVHostPlugin implements PlugIn, Startable, Disposable {
	private static final String NAME = "Service Wrappers for osSso/peppol.at";
	private static final String DESCRIPTION = "A bunch of wrappers of external services for use with osSso/peppol.at";

	private static final BuildInfo BUILD_INFO = new BuildInfo("OsssoServiceWrapperPlugin", "m2n gmbh", "0.1", OsssoServiceWrapperVHostPlugin.class);
	private static final String OSSSO_MACHINE_URI = "at.m2n.IntelligenceManagement.peppol.service.external.osssoMachineURI";

	Logger logger = Logger.getLogger(this.getClass());
	ComponentLifecycle lifecycle = ComponentLifecycle.createFullLifecycle(getClass().getName());
	ResourceBundle bundle = ResourceBundle.getBundle(this.getClass().getName());

	Configuration configuration;
	OsssoVHostPlugin osssoVHostPlugin;
	UISPlugin uisPlugin;

	public OsssoServiceWrapperVHostPlugin(Configuration configuration, OsssoVHostPlugin osssoVHostPlugin, UISPlugin uisPlugin) throws PlugInInitialisationException {
		this.configuration = configuration;
		this.osssoVHostPlugin = osssoVHostPlugin;
		this.uisPlugin = uisPlugin;
		
		registerServices();
		
		logger.info("Service Wrapper Plugin for osSso constructed.");
	}

	private void registerServices() {
		try {
			String osssoMachineURI = configuration.getValue(OSSSO_MACHINE_URI);
			if (osssoMachineURI != null) {
				OsssoMachine osssoMachine = osssoVHostPlugin.getOsssoMachine(osssoMachineURI);
				if (osssoMachine != null) {
					logger.info("Registering service wrapper for Ediktsdatei for OsssoMachine " + osssoMachineURI);
					osssoMachine.getServiceRegistry().register(new EdiktServiceWrapper("Ediktsdatei"));
					osssoMachine.getServiceRegistry().register(new UnschuldServiceWrapper("Unschuldsbestätigungs-Service", uisPlugin));
					osssoMachine.getServiceRegistry().register(new FirmenbuchServiceWrapper("Firmenbuch"));
				}
				else {
					logger.fatal("No OsssoMachine found with identifier '" + osssoMachineURI + "'.");
				}
			}
			else {
				logger.fatal("No OsssoMachine configured with configuration key " + OSSSO_MACHINE_URI);
			}
		}
		catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
		catch (ConfigurationException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @see at.m2n.IntelligenceManagement.plugIn.PlugIn#getName()
	 */
	public String getName() {
		return NAME;
	}

	/**
	 * @see at.m2n.IntelligenceManagement.plugIn.PlugIn#getDescription()
	 */
	public String getDescription() {
		return DESCRIPTION;
	}

	/**
	 * @see org.picocontainer.Startable#start()
	 */
	public void start() {
		lifecycle.start();
		logger.info("Service Wrapper Plugin for osSso started.");
	}

	/**
	 * @see org.picocontainer.Startable#stop()
	 */
	public void stop() {
		lifecycle.stop();
		// FIXME: unregister service wrappers from osSso's ServiceRegistry
		logger.info("Service Wrapper Plugin for osSso stopped.");
	}

	/**
	 * @see org.picocontainer.Disposable#dispose()
	 */
	public void dispose() {
		lifecycle.dispose();
		logger.info("Service Wrapper Plugin for osSso disposed.");
	}

	/**
	 * @see at.m2n.IntelligenceManagement.plugIn.PlugIn#getBuildInfo()
	 */
	public BuildInfo getBuildInfo() {
		return BUILD_INFO;
	}
}
