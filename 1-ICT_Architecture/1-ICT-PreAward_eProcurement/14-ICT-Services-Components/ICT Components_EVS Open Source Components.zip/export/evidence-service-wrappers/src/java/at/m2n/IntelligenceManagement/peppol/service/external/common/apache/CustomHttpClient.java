/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common.apache;

import org.apache.commons.logging.LogFactory;
import org.apache.http.ConnectionReuseStrategy;
import org.apache.http.client.AuthenticationHandler;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.RedirectStrategy;
import org.apache.http.client.RequestDirector;
import org.apache.http.client.UserTokenHandler;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.routing.HttpRoutePlanner;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpProcessor;
import org.apache.http.protocol.HttpRequestExecutor;

/**
 * Merely needed for injecting our own, custom request director.
 * 
 * @author schwingenschloegl
 */
public class CustomHttpClient extends DefaultHttpClient {

	public CustomHttpClient() {
		super();
	}

	public CustomHttpClient(ClientConnectionManager conman, HttpParams params) {
		super(conman, params);
	}

	public CustomHttpClient(ClientConnectionManager conman) {
		super(conman);
	}

	public CustomHttpClient(HttpParams params) {
		super(params);
	}

	@Override
	protected RequestDirector createClientRequestDirector(HttpRequestExecutor requestExec, ClientConnectionManager conman, ConnectionReuseStrategy reustrat,
														  ConnectionKeepAliveStrategy kastrat, HttpRoutePlanner rouplan, HttpProcessor httpProcessor,
														  HttpRequestRetryHandler retryHandler, RedirectStrategy redirectStrategy, AuthenticationHandler targetAuthHandler,
														  AuthenticationHandler proxyAuthHandler, UserTokenHandler stateHandler, HttpParams params) {
		return new CustomRequestDirector(LogFactory.getLog(CustomHttpClient.class),
										 requestExec,
										 conman,
										 reustrat,
										 kastrat,
										 rouplan,
										 httpProcessor,
										 retryHandler,
										 redirectStrategy,
										 targetAuthHandler,
										 proxyAuthHandler,
										 stateHandler,
										 params);
	}
}
