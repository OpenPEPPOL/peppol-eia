/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.stages;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

import org.apache.http.Header;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.log4j.Logger;

import sun.misc.BASE64Encoder;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpRequestFactory;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpResponseHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration;
import at.m2n.IntelligenceManagement.peppol.service.external.common.params.HttpRequestArgumentsHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStage;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.impl.ResponseHandlerWrappingServiceStage;
import at.m2n.util.Util;

/**
 * Stage in a HTTP-based service call that authenticates against a portal site (HTTP GET/POST) and stores authentication data.
 * 
 * @author schwingenschloegl
 */
public class PortalAuthenticatingServiceStage implements HttpServiceStage {

	private final HttpServiceConfiguration serviceConfiguration;

	private static final Logger LOG = Logger.getLogger(PortalAuthenticatingServiceStage.class);

	public PortalAuthenticatingServiceStage(HttpServiceConfiguration serviceConfiguration) {
		this.serviceConfiguration = serviceConfiguration;
	}

	@Override
	public HttpServiceStageResult call(HttpClient httpClient, HttpServiceContext context) {

		HttpResponseHandler authorization = new HttpResponseHandler() {

			@Override
			public void handleResponse(InputStream responseStream, HttpResponse response, HttpServiceContext context) throws IOException {
				int statusCode = response.getStatusLine().getStatusCode();
				if (statusCode == HttpStatus.SC_OK || statusCode == 500) {
					HeaderIterator it = response.headerIterator("Set-Cookie");
					while (it.hasNext()) {
						Header cookie = (Header) it.next();
						String name = cookie.getName();
						String value = cookie.getValue();
						LOG.info("  > header: " + name + "=" + value);

						setContextVariableIfApplicable(context, "SMSESSION", value);
						setContextVariableIfApplicable(context, "JSESSIONID", value);
					}
				}
				else {
					throw new RuntimeException("HTTP Status " + statusCode + " returned, but needed a 200");
				}
			}

			private void setContextVariableIfApplicable(HttpServiceContext context, String checkedKey, String value) {
				if (value.startsWith(checkedKey + "=")) {
					value = value.substring((checkedKey + "=").length());
					if (value.contains(";")) {
						value = value.substring(0, value.indexOf(';'));
					}
					context.setValue(checkedKey, value);
				}
			}
		};

		HttpRequestArgumentsHandler argumentsHandler = null;
		HttpRequestFactory requestFactory = new HttpRequestFactory() {

			@Override
			public HttpRequestBase createForConfiguration(HttpServiceConfiguration configuration, HttpServiceContext context) {
				String portalBaseURL = context.getValue("portal.baseURL", null);
				HttpPost request = new HttpPost(portalBaseURL);

				String authUser = context.getValue("portal.auth.user", null);
				String authPassword = context.getValue("portal.auth.password", null);
				String authorization = new BASE64Encoder().encode((authUser + ":" + authPassword).getBytes());

				request.setHeader("Cookie", "SMCHALLENGE=YES");
				request.setHeader("Authorization", "Basic " + authorization);
				
				return request;
			}
		};

		HttpServiceStage delegate = new ResponseHandlerWrappingServiceStage(serviceConfiguration, authorization, requestFactory, argumentsHandler, getRequiredKeys());
		return delegate.call(httpClient, context);
	}

	@Override
	public Collection<String> getRequiredKeys() {
		return Util.toSet("companyId", "portal.auth.user", "portal.auth.password", "portal.baseURL");
	}
}
