/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common.failure.impl;

import org.apache.http.client.HttpClient;
import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.peppol.service.external.common.failure.FailureHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStage;

public class RetryingFailureHandler implements FailureHandler {

	private final int base;
	private final int maxAttempts;

	private static final Logger logger = Logger.getLogger(RetryingFailureHandler.class);

	public RetryingFailureHandler(int base, int maxAttempts) {
		this.base = base;
		this.maxAttempts = maxAttempts;
	}

	@Override
	public boolean shouldRetry(int attempt, HttpServiceStage stage, HttpClient httpClient, HttpServiceContext context) {
 
		if (attempt < maxAttempts) {
			long waitFor = (long) (base * (1L << attempt));
			logger.info("Retry attempt #" + attempt + " (of max. " + maxAttempts + ") after waiting for " + waitFor + " ms.");
			try {
				Thread.sleep(waitFor);
			}
			catch (InterruptedException e) {
			}

			return true;
		}

		logger.info("Not retrying. Attempt #" + attempt + "/" + maxAttempts);
		return false;
	}
}
