/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.edikt;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.peppol.service.external.common.AbstractHTTPServiceWrapper;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpRequestFactory;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpResponseHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceUtil;
import at.m2n.IntelligenceManagement.peppol.service.external.common.failure.impl.ErrorDocumentGeneratingFailureHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceErrorHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStage;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.impl.ResponseHandlerWrappingServiceStage;
import at.m2n.IntelligenceManagement.peppol.service.external.edikt.fallback.EdiktFallbackErrorHandler;
import at.m2n.util.Util;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;

public class EdiktServiceWrapper extends AbstractHTTPServiceWrapper implements HttpServiceErrorHandler {

	public static final Logger logger = Logger.getLogger(EdiktServiceWrapper.class);

	public static final String CTX_TEMP_DIR = "edikt.tempBaseDir";

	private Map<String, String> replacements;

	public EdiktServiceWrapper(String name) {
		this(name, new HttpServiceConfiguration(EdiktServiceWrapper.class, Collections.<String> emptySet(), HttpServiceConfiguration.EVAL_STRICT));
	}

	private EdiktServiceWrapper(String name, HttpServiceConfiguration configuration) {
		super(name, configuration);

		setup();
	}

	private void setup() {
		replacements = loadReplacements(getServiceConfiguration());

		HttpResponseHandler blobSavingResponseHandler = new HttpResponseHandler() {

			@Override
			public void handleResponse(InputStream responseStream, HttpResponse response, HttpServiceContext context) throws IOException {
				InputStream replacingStream = new UglyHack_RegexReplacementInputStream(responseStream, replacements);
				String fileName = "Auszug aus Ediktsdatei der Firma " + context.getValue("companyId", null) + ".html";
				HttpServiceUtil.saveBlobFromStream(replacingStream, fileName, "text/html", context.getOsssoModel(), context.getAdditionsModel(), context);
			}
		};
		HttpRequestFactory requestFactory = new HttpRequestFactory() {

			@Override
			public HttpGet createForConfiguration(HttpServiceConfiguration configuration, HttpServiceContext context) {
				HttpGet httpGetMethod = new HttpGet(context.getValue("baseURL", null));
				return httpGetMethod;
			}
		};

		HttpServiceStage blobFetchingStage = new ResponseHandlerWrappingServiceStage(getServiceConfiguration(), blobSavingResponseHandler, requestFactory, null,
																						Util.toList("baseURL", "coll", "companyId"));
		addServiceStage(blobFetchingStage);

		// FIXME: add "new" stages (see package stages)
		// addServiceStage(new InitialRetrievalStage(getServiceConfiguration()));
		// addServiceStage(new ExternalDependenciesDownloadStage());
		// addServiceStage(new ExternalLinkLocalizerStage());
		// addServiceStage(new ZippingStage());
	}

	/**
	 * Small (and ugly hacky hacky) helper class that acts as an InputStream and performs (simple, read: regex-based) replacements in another InputStream. Due to the hacky and
	 * temporary nature of it all, the following code is by far not optimal or pwetty. Read it at your own risk.
	 * 
	 * @author schwingenschloegl
	 */
	private static class UglyHack_RegexReplacementInputStream extends InputStream {

		private BufferedInputStream delegate;
		private Map<String, String> replacements;
		private String source = null;
		private int currIdx = 0;

		public UglyHack_RegexReplacementInputStream(InputStream delegate, Map<String, String> replacements) {
			if (delegate instanceof BufferedInputStream) {
				this.delegate = (BufferedInputStream) delegate;
			}
			else {
				this.delegate = new BufferedInputStream(delegate);
			}
			this.replacements = replacements;
		}

		@Override
		public int read() throws IOException {
			if (source == null) {
				// internal (string) buffer is empty -> rebuild (only on first call to this method)
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				Util.copyStream(delegate, baos);
				source = baos.toString();

				for (Map.Entry<String, String> replacement : replacements.entrySet()) {
					source = source.replaceAll(replacement.getKey(), replacement.getValue());
				}

				if (!source.contains("Sie haben nach <span id=\"expquery\">(Firmenbuchnummer=(")) {
					// Nomadix or something similarly evil?!
					throw new RuntimeException("Not a valid Ediktsdatei response!");
				}
			}

			if (currIdx < source.length()) {
				char currChar = source.charAt(currIdx);
				++currIdx;
				return currChar;
			}
			else {
				// no more characters left in the string
				return -1;
			}
		}
	}

	private Map<String, String> loadReplacements(HttpServiceConfiguration configuration) {
		Map<String, String> replacements = new HashMap<String, String>();
		try {
			ResourceBundle bundle = ResourceBundle.getBundle(this.getClass().getName());
			for (String key : bundle.keySet()) {
				if (key.startsWith("service.replacement.regex.")) {
					String id = key.substring("service.replacement.regex.".length());
					try {
						String value = bundle.getString("service.replacement.value." + id);
						if ("NULL".equalsIgnoreCase(value)) {
							value = ""; // make empty string
						}
						replacements.put(bundle.getString(key), value);
					}
					catch (Exception e) {
					}
				}
			}
		}
		catch (Exception e) {
		}
		return replacements;
	}

	private String getBaseURL(Map<Node_Variable, Node_Concrete> bindings, HttpServiceConfiguration configuration) {
		String companyId = at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceUtil.getCompanyId(bindings);
		String baseURL = configuration.getBaseURL();
		return baseURL.replaceAll("\\$FN\\$", companyId);
	}

	@Override
	protected void fillInitialServiceContext(HttpServiceContext context, Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model) {
		HttpServiceConfiguration configuration = getServiceConfiguration();
		String baseURL = getBaseURL(bindings, configuration);

		context.setValue("baseURL", baseURL);
		context.setValue("companyId", HttpServiceUtil.getCompanyId(bindings));
		context.setValue("coll", bindings.get(Node.createVariable("coll")).getURI());
	}

	@Override
	public HttpServiceStageResult handleError(HttpClient httpClient, HttpServiceContext context) {
		// TODO: Make this configurable which error handling strategy we want to apply? (presentation vs. production)
		HttpServiceErrorHandler delegate = null;
		if (System.getProperty("presentation") != null) {
			delegate = new EdiktFallbackErrorHandler();
		}
		else {
			delegate = new ErrorDocumentGeneratingFailureHandler("ediktsdatei_fehler.pdf", "Fehlerhafter Aufruf Ediktsdatei.pdf", "application/pdf");
		}
		return delegate.handleError(httpClient, context);
	}
}
