/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.osSso.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.osSso.MissingTripleProblem;
import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.impl.ServicePreAndPostConditions;
import at.m2n.IntelligenceManagement.osSso.service.impl.ServiceUtil;

import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.graph.Triple;

/**
 * A base class that does lots of work for you if you want to build a Service.
 * 
 * Basically all that you have to do is pass a name, pre- and postconditions in the constructor and provide an implementation of doCall.
 */

public abstract class AbstractService implements Service {
	private final static Logger logger = Logger.getLogger(AbstractService.class);
	
	/* quality-of-service parameters */
	private Map<String, Float> qosParameters = new HashMap<String, Float>();

	private String name;
	private int callCount = 0;

	protected ServicePreAndPostConditions pp;

	public AbstractService(String name, ServicePreAndPostConditions pp) {
		this.name = name;
		this.pp = pp;
	}


	protected abstract ServiceExecution doCall(Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model);




	public AbstractService qosParameter(String uri, float value) {
		setQOSParameter(uri, value);
		return this;
	}


	@Override
	public boolean canResolve(Problem problem) {
		if (problem instanceof MissingTripleProblem) { // TODO: this is evil! make more general?
			MissingTripleProblem p = (MissingTripleProblem) problem;

			for (Triple t : pp.getPost()) { // TODO: this might be inexact
				if (ServiceUtil.matches(t, p.getTriple().asTriple())) return true;
			}
		}

		return false;

	}

	@Override
	public boolean canResolve(Problem problem, OsssoModel model) {
		return canResolve(problem) && pp.preconditionsMet(model.getModel());
	}

	@Override
	public boolean hasPreconditions() {
		return notNullOrEmpty(pp.getPre());
	}

	@Override
	public float getQOSParameter(String uri) {
		if (qosParameters.containsKey(uri)) return qosParameters.get(uri);

		return 1;
	}

	protected void setQOSParameter(String uri, float value) {
		qosParameters.put(uri, value);
	}

	public String getName() {
		return name;
	}


	public String toString() {
		return name;
	}

	public int getCallCount() {
		return callCount;
	}

	@Override
	public final ServiceExecution call(Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model) {
		++callCount;
		logger.info(" calling > " + this + " with " + bindings);

		return doCall(bindings, problem, problems, model);
	}


	private static boolean notNullOrEmpty(Collection<?> c) {
		if (c == null) return false;

		if (c.isEmpty()) return false;

		return true;
	}




	@Override
	public Set<Triple> getPreconditions() {
		return pp.getPre();
	}

	@Override
	public Set<Triple> predictResults() {
		return pp.getPost();
	}

	@Override
	public Map<Node_Variable, Node_Concrete> getVariableBindings(Problem solveThis) {
		return pp.getVariableBindings(solveThis);
	}

	@Override
	public boolean isPassive() {
		return false;
	}
}
