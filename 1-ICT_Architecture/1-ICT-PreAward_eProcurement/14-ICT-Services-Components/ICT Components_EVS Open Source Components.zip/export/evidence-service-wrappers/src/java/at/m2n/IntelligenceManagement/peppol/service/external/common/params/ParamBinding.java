/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common.params;

import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;

/**
 * Binds a (named) HTTP PARAM to a value source
 * 
 * @author schwingenschloegl
 */
public class ParamBinding {

	private final ParamValueSource valueSource;
	private final String name;

	public ParamBinding(ParamValueSource valueSource, String name) {
		if (name == null || name.isEmpty()) { throw new IllegalArgumentException("Name must not be null or an empty string."); }
		if (valueSource == null) { throw new IllegalArgumentException("valueSource must not be null."); }

		// invariant: valueSource != null
		// invariant: name != null && !name.isEmpty()
		this.valueSource = valueSource;
		this.name = name;
	}

	public String getName() {
		// invariant: name != null && !name.isEmpty()
		return name;
	}

	public String getValue(HttpServiceContext context) {
		// invariant: valueSource != null
		return valueSource.getValue(context);
	}
}
