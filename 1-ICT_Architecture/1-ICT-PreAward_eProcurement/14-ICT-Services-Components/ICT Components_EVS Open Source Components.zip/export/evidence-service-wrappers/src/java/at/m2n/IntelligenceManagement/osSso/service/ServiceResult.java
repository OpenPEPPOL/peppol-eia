/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.osSso.service;

import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;

/** ServiceResult encapsulates the result of a service execution.
 */

public interface ServiceResult {
  /** Returns whether the service call was successful.
   *  There are two reasons for this to be false:
   *  <ul>
   *    <li>There was a technical problem which leads to the service not being reachable or operational at the moment. An exception will be provided by the getException() method. </li>
   *    <li>The service couldn't answer the request for non-technical reasons. For example, you might have tried to look up a nonexistant key in a database.</li>
   *  </ul>   
   *  
   *  The applyToModel method should throw an IllegalStateException if this method returns false.
   * 
   * @return true iff applyToModel can be called without getting an IllegalStateException.
   */
  boolean wasSuccess();
  

  /** @return an Exception that describes the technical problem that prevented successful execution, or null if no technical problem occured. */
  Exception getException();

  
  /** If the execution was successful, apply its results to the given model. 
   * 
   * Don't forget locking. The ossso machine doesn't guarantee exclusive access to you when this method is called!
   * 
   * If the execution wasn't successful, throw an IllegalStateException
   */
  void applyToModel(OsssoModel model);
}
