/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.fallback;

import java.io.InputStream;

import org.apache.http.client.HttpClient;
import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceUtil;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceErrorHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult.State;

public class FirmenbuchFallbackErrorHandler implements HttpServiceErrorHandler {

	private static final Logger logger = Logger.getLogger(FirmenbuchFallbackErrorHandler.class);

	@Override
	public HttpServiceStageResult handleError(HttpClient client, HttpServiceContext context) {
		// error handling routine
		InputStream fallbackStream = getClass().getClassLoader().getResourceAsStream("fb_auszug_183286p.pdf");
		if (!HttpServiceUtil.saveBlobFromStream(fallbackStream, "Firmenbuchauszug für Firma 183286p.pdf", "application/pdf", context.getOsssoModel(), context.getAdditionsModel(),
												context)) {
			logger.fatal("Could not even save BLOB from fallback variant! Failing ignominiously!");
			return new HttpServiceStageResult(State.FAILURE, HttpServiceStageResult.NO_RETRY);
		}

		return new HttpServiceStageResult(State.SUCCESS);
	}
}
