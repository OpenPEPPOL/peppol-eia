/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.AbstractService;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;
import at.m2n.IntelligenceManagement.osSso.service.ServiceResult;
import at.m2n.IntelligenceManagement.osSso.service.impl.MonotonuousServiceResult;
import at.m2n.IntelligenceManagement.peppol.service.external.common.failure.FailureHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.failure.impl.RetryingFailureHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceErrorHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStage;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult;

import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

/**
 * Base class for external services that rely on HTTP GET/POST and need to be integrated as OsSsO service.
 * 
 * @author schwingenschloegl
 */
public abstract class AbstractHTTPServiceWrapper extends AbstractService {

	private HttpServiceConfiguration serviceConfiguration;
	private List<HttpServiceStage> stages = new ArrayList<HttpServiceStage>();

	/* A service should be called multiple times in parallel by different processes, but we want to protect against concurrent modifications -> WORM needed */
	private ReadWriteLock stagesLock = new ReentrantReadWriteLock();
	private FailureHandler failureHandler = new RetryingFailureHandler(500, 4);

	protected static final Logger logger = Logger.getLogger(AbstractHTTPServiceWrapper.class);

	public AbstractHTTPServiceWrapper(String name, HttpServiceConfiguration serviceConfiguration) {
		super(name, serviceConfiguration.getServicePreAndPostConditions());
		this.serviceConfiguration = serviceConfiguration;
	}

	protected final HttpServiceConfiguration getServiceConfiguration() {
		return serviceConfiguration;
	}

	protected final void addServiceStage(HttpServiceStage stage) {
		if (stage == null) {
			// Ignore invalid method call
			return;
		}

		stagesLock.writeLock().lock();
		try {
			stages.add(stage);
		}
		finally {
			stagesLock.writeLock().unlock();
		}
	}

	@Override
	protected final ServiceExecution doCall(Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model) {

		assertStages();

		if (pp.preconditionsMet(model.getModel())) {
			Map<Node_Variable, Node_Concrete> resolvedBindings = null;
			if (bindings != null) {
				// Only when there are any bindings at all, do we need to extract input
				// (bindings aren't available or needed in the context of test cases)
				resolvedBindings = pp.extractInput(model.getModel(), bindings);
			}
			final Model modelAdd = ModelFactory.createDefaultModel();

			logger.info("Performing service call with bindings "+resolvedBindings);
			
			HttpServiceStageResult resultFromStages = executeHttpRequest(resolvedBindings, problem, problems, model, modelAdd);
			if (resultFromStages.getState().isFailure()) {
				logger.error("External service call failed!\n" + resultFromStages.getState());
				// FIXME: Propagate error handling to ossso machine?
			}
			else if (resultFromStages.getState().isSuccess()) {
				logger.info("External service call was completed successfully!");
			}

			return new ServiceExecution() {
				@Override
				public ServiceResult getResultBlocking() throws InterruptedException {
					return new MonotonuousServiceResult(modelAdd);
				}
			};
		}
		else {
			throw new RuntimeException("Preconditions not met!");
		}
	}

	/**
	 * Checks if there are any stages defined. If not, the method throws an IllegalStateException.
	 * 
	 * @throws IllegalStateException
	 *             if and only if no stages are defined
	 */
	private void assertStages() {
		stagesLock.readLock().lock();
		try {
			if (stages.isEmpty()) {
				// This must never happen for a properly configured service
				throw new IllegalStateException("Misconfigured service! No stages defined!");
			}
		}
		finally {
			stagesLock.readLock().unlock();
		}
	}

	protected abstract void fillInitialServiceContext(HttpServiceContext context, Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model);

	protected final HttpServiceStageResult executeHttpRequest(Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model, Model additionsModel) {
		HttpServiceContext context = new HttpServiceContext(additionsModel, model);
		fillInitialServiceContext(context, bindings, problem, problems, model);

		// invariant: context != null
		return executeHttpRequest(context);
	}

	private HttpServiceStageResult executeHttpRequest(HttpServiceContext context) {
		HttpClient client = createHttpClient();

		HttpServiceStageResult result = null;
		stagesLock.readLock().lock();
		try {
			for (HttpServiceStage stage : stages) {
				int numAttempts = 0;

				if (!preconditionSatisfied(stage, context)) {
					// We can't continue our work. This should only happen in a misconfigured or otherwise "badly behaving" service.
					logger.error("Precondition not met for service stage " + stage);
					logger.error("Required context variables that were not satisfied: " + context.getPreconditionViolations(stage.getRequiredKeys()));
					break;
				}

				result = stage.call(client, context);

				// NOTE: failureHandler.shouldRetry might be blocking for a given time
				while (result.getState().isFailure() && failureHandler.shouldRetry(numAttempts, stage, null, context)) {
					++numAttempts;
					result = stage.call(client, context);
				}

				// If after possible retries, we still have a failure, notify the stage's error handler
				if (result.getState().isFailure()) {
					HttpServiceErrorHandler errorHandler = findErrorHandler(stage);
					if (errorHandler != null) {
						// try to reach a "good state" gracefully
						result = errorHandler.handleError(client, context);
					}

					// ... if we still could not recover from the error, we don't even need to consider the following stages
					if (result.getState().isFailure()) {
						logger.error("Failed call to stage, failed to restore gracefully. Exiting service call with error.");
						break;
					}
				}
			}
		}
		finally {
			stagesLock.readLock().unlock();
			client.getConnectionManager().shutdown();
		}

		if (result == null) {
			// This should not happen if the service is properly configured
			throw new IllegalStateException("No stage defined in service: service misconfigured or last stage did not obey contract!");
		}

		return result;
	}

	/**
	 * Creates the {@link HttpClient} that is to be used for requests. Override this method if you need to make some further adaptations.
	 * 
	 * @return
	 */
	protected HttpClient createHttpClient() {
		HttpClient client = new DefaultHttpClient();
		return client;
	}

	private HttpServiceErrorHandler findErrorHandler(HttpServiceStage stage) {
		if (stage instanceof HttpServiceErrorHandler) { return ((HttpServiceErrorHandler) stage); }

		if (this instanceof HttpServiceErrorHandler) { return ((HttpServiceErrorHandler) this); }

		// Oh no, we can't find an error handler
		return null;
	}

	private boolean preconditionSatisfied(HttpServiceStage stage, HttpServiceContext context) {
		assert stage != null : "HttpServiceStage must not be null";
		assert context != null : "HttpServiceContext must not be null";

		Collection<String> requiredKeys = stage.getRequiredKeys();
		return context.satisfiesPrecondition(requiredKeys);
	}
}
