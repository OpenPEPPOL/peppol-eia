/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.params.HttpParams;
import org.apache.log4j.Logger;

import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.peppol.service.external.common.params.HttpRequestArgumentsHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.uis.UISPlugin;
import at.m2n.jena.util.URIGenerator;
import at.m2n.jena.util.transaction.ModelTransaction;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;
import com.hp.hpl.jena.vocabulary.RDF;

/**
 * Collection of utility methods.
 * 
 * @author schwingenschloegl
 */
public final class HttpServiceUtil {

	private static final Logger logger = Logger.getLogger(HttpServiceUtil.class);

	// -- only needed because packaging doesn't yet fully work on the "old" vcd branch
	@Deprecated
	private static UISPlugin uisPlugin = null;

	/**
	 * @deprecated only needed because packaging doesn't yet fully work on the "old" vcd branch
	 * 
	 * @param uisPlugin
	 */
	@Deprecated
	public static void setUISPlugin(UISPlugin uisPlugin) {
		HttpServiceUtil.uisPlugin = uisPlugin;
	}

	public static void executeHttpRequest(HttpClient httpClient, HttpServiceContext context, HttpServiceConfiguration serviceConfiguration, HttpResponseHandler responseHandler,
											HttpRequestFactory requestFactory, HttpRequestArgumentsHandler argumentsHandler) throws ClientProtocolException, IOException {
		HttpRequestBase request = requestFactory.createForConfiguration(serviceConfiguration, context);
		if (argumentsHandler != null) {
			HttpParams params = request.getParams();
			HttpParams newParams = argumentsHandler.getParams(request, params, context);
			if (newParams != null) {
				request.setParams(newParams);
			}
		}
		HttpResponse response = httpClient.execute(request);

		HttpEntity entity = response.getEntity();

		// When entity == null, there is no need for manual connection release
		if (entity != null) {
			InputStream is = entity.getContent();
			try {
				responseHandler.handleResponse(is, response, context);
			}
			catch (RuntimeException e) {
				// In case of an unexpected exception, we want to make sure the connection is released with as much grace as possible
				request.abort();
				throw e;
			}
			finally {
				// Closing the inputstream triggers connection release
				is.close();
			}
		}
	}

	public static String getCompanyId(Map<Node_Variable, Node_Concrete> bindings) {
		Node companyIdNode = bindings.get(Node.createVariable("economicOperatorID"));
		if (companyIdNode != null) {
			String companyId = companyIdNode.getLiteralLexicalForm();
			return companyId;
		}

		// invariant: If control reaches this point, there was no econmic operator ID specified in the binding
		throw new RuntimeException("No 'economicOperatorID' provided for service. Preconditions not met!");
	}

	public static Resource createDocumentResource(Model targetModel, Resource blob, String fileName, String mimeType, long fileSize) {
		Resource document = targetModel.getResource(URIGenerator.getForURI("m2n://Document/ExtService"));
		document.addProperty(RDF.type, new ResourceImpl("m2n://Document"));
		document.addProperty(new PropertyImpl("m2n://Document#blob"), blob);
		document.addProperty(new PropertyImpl("m2n://Document#fileName"), fileName);
		document.addProperty(new PropertyImpl("m2n://Document#mimeType"), mimeType);
		document.addProperty(new PropertyImpl("m2n://Document#fileSize"), fileSize);
		return document;
	}

	public static boolean saveBlobFromStream(InputStream responseStream, String fileName, String mimeType, OsssoModel model, Model modelAdd, HttpServiceContext context) {
		AtomicLong savedBlobSize = new AtomicLong();
		String savedBlobURI = model.saveBlob(responseStream, null, savedBlobSize);
		if (savedBlobURI != null) {
			// invariant: The blob could be saved successfully
			Resource blob = new ResourceImpl(savedBlobURI);

			Resource rCollector = (Resource) modelAdd.getResource(context.getValue("coll", null));
			Property pDocument = new PropertyImpl("http://m2n.at/2009/05/peppol/evidenceDocument");
			Resource rTheDocument = createDocumentResource(modelAdd, blob, fileName, mimeType, savedBlobSize.get());
			modelAdd.add(modelAdd.createStatement(rCollector, pDocument, rTheDocument));

			// -- merged back, needed only on "old" vcd branch (with old packager)
			Resource rRequest = findRequest(model);
			Property pAddToRequest = new PropertyImpl("http://m2n.at/2009/05/peppol/resultArchiveFull");
			attachToRequest(rRequest, pAddToRequest, blob, fileName, mimeType, savedBlobSize.get());
			// -- you can remove above block once the packager also works with evidences

			return true;
		}
		else {
			logger.fatal("Could not save the BLOB!");
			return false;
		}
	}

	/**
	 * @deprecated only needed because packaging doesn't yet fully work on the "old" vcd branch
	 * 
	 * @param rRequest
	 * @param pAddToRequest
	 * @param blob
	 * @param fileName
	 * @param mimeType
	 * @param fileSize
	 */
	@Deprecated
	private static void attachToRequest(Resource rRequest, Property pAddToRequest, Resource blob, String fileName, String mimeType, long fileSize) {
		final Model m = ModelFactory.createDefaultModel();
		if (rRequest != null) {
			Resource rTheDocument = createDocumentResource(m, blob, fileName, mimeType, fileSize);
			rRequest = (Resource) rRequest.inModel(m).as(Resource.class);
			rRequest.addProperty(pAddToRequest, rTheDocument);
		}


		// we also want to write this into the process metadata model!
		if (uisPlugin != null) {
			ModelTransaction mt = ModelTransaction.create(uisPlugin.getOsssoProcessMetadataModel());
			try {
				mt.add(m);
				mt.commit();
			}
			finally {
				mt.close();
			}
		}
	}

	/**
	 * @deprecated only needed because packaging doesn't yet fully work on the "old" vcd branch
	 * 
	 * @param model
	 * @return
	 */
	@Deprecated
	private static Resource findRequest(OsssoModel model) {
		StmtIterator iRequests = model.getModel().listStatements(null, RDF.type, new ResourceImpl("http://m2n.at/2009/05/peppol/VCDRequest"));
		try {
			if (iRequests.hasNext()) { return iRequests.nextStatement().getSubject(); }
		}
		finally {
			iRequests.close();
		}

		return null;
	}
}
