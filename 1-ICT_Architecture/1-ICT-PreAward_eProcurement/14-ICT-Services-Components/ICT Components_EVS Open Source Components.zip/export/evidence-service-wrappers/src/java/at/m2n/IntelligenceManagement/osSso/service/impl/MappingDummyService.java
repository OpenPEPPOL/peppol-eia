/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.osSso.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.AbstractService;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;
import at.m2n.IntelligenceManagement.osSso.service.ServiceResult;

import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.rdf.model.Model;

public class MappingDummyService extends AbstractService {

  private Node_Variable inVar;
  private Node_Variable outVar;
  private Map<Node_Concrete, Node_Concrete> valueMap = new HashMap<Node_Concrete, Node_Concrete>();
  
  
  public static MappingDummyService create(String name, String modelPre, String inVar, String modelPost, String outVar) {
    return new MappingDummyService(name, ServicePreAndPostConditions.parse(modelPre, modelPost), inVar, outVar);
  }

  public MappingDummyService(String name, ServicePreAndPostConditions pp, String inVar, String outVar) {
    super(name, pp);
    this.inVar = (Node_Variable)Node.createVariable(inVar);
    this.outVar = (Node_Variable)Node.createVariable(outVar);
  }
  
  public AbstractService map(String from, String to) {
    valueMap.put((Node_Concrete)Node.createLiteral(from, null, XSDDatatype.XSDstring), 
                 (Node_Concrete)Node.createLiteral(to, null, XSDDatatype.XSDstring));
    
    return this;
  }
  
  public MappingDummyService map(Node from, Node to) {
    valueMap.put((Node_Concrete)from, 
                 (Node_Concrete)to);
    
    return this;
  }

  @Override
  public ServiceExecution doCall(final Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, final OsssoModel model) {
    
    return new ServiceExecution() {
      @Override
      public ServiceResult getResultBlocking() throws InterruptedException {
        try {
          Map<Node_Variable, Node_Concrete> mappedBindings = map(fillMissingBindings(model, bindings)); 
          Model result = pp.constructOutput(model.getModel(), mappedBindings);
          return new MonotonuousServiceResult(result);
        } catch (NoSuchElementException nsee) {
          return new EmptyServiceResult();
        }
      }


    };
  }


  private Map<Node_Variable, Node_Concrete> fillMissingBindings(OsssoModel model, Map<Node_Variable, Node_Concrete> bindings) {
    return pp.extractInput(model.getModel(), bindings);
  }
  

  /** @throws NoSuchElementException to signal that there is no entry in the map for the supposed value
   */
  private Map<Node_Variable, Node_Concrete> map(Map<Node_Variable, Node_Concrete> bindings) throws NoSuchElementException {
    Node_Concrete value = bindings.get(inVar);
    Node_Concrete newValue = valueMap.get(value);
    Map<Node_Variable, Node_Concrete> newMap = new HashMap<Node_Variable, Node_Concrete>(bindings);
    newMap.put(outVar, newValue);
    
    return newMap;
  }

}
