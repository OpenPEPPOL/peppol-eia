/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.osSso.service.impl;

import java.util.Map;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.AbstractService;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;

import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;

public class DoNothingService extends AbstractService {

  public DoNothingService(String name, ServicePreAndPostConditions pp) {
    super(name, pp);
  }

  @Override
  protected ServiceExecution doCall(Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model) {
    throw new UnsupportedOperationException("DoNothingService does nothing and doesn't expect to be actually called either!");
  }

}
