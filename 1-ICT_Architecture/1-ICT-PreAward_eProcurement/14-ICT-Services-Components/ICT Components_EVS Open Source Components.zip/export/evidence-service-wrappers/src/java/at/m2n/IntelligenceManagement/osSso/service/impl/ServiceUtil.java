/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.osSso.service.impl;

import java.util.Map;
import java.util.Set;

import at.m2n.IntelligenceManagement.osSso.Problem;
import at.m2n.IntelligenceManagement.osSso.Problems;
import at.m2n.IntelligenceManagement.osSso.model.OsssoModel;
import at.m2n.IntelligenceManagement.osSso.service.Service;
import at.m2n.IntelligenceManagement.osSso.service.ServiceExecution;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Node_Concrete;
import com.hp.hpl.jena.graph.Node_Variable;
import com.hp.hpl.jena.graph.Triple;

public class ServiceUtil {

	public static boolean matches(Triple variable, Triple fixed) {
		return ServiceUtil.matches(variable.getSubject(), fixed.getSubject()) && ServiceUtil.matches(variable.getPredicate(), fixed.getPredicate())
				&& ServiceUtil.matches(variable.getObject(), fixed.getObject());
	}

	static boolean matches(Node var, Node fix) {
		// if there's no need to match, we're good.
		if (!fix.isConcrete()) return true;

		// if var is actually variable, we're good too.
		if (var.isVariable()) return true;

		return var.matches(fix);
	}

	public static Service addPrecondition(final Service delegate, final String additionalPrecondition) {
		Set<Triple> additional = ServicePreAndPostConditions.parse(additionalPrecondition);
		Set<Triple> pre = delegate.getPreconditions();
		Set<Triple> post = delegate.predictResults();

		additional.addAll(pre);

		ServicePreAndPostConditions pp = new ServicePreAndPostConditions(additional, post);
		return new DelegatingService(delegate, pp);
	}

	private static class DelegatingService implements Service {
		private Service delegate;
		private ServicePreAndPostConditions pp;

		public DelegatingService(Service delegate, ServicePreAndPostConditions pp) {
			this.delegate = delegate;
			this.pp = pp;
		}

		@Override
		public String toString() {
			return "DelegatingService [delegate=" + delegate + "]";
		}

		public Set<Triple> getPreconditions() {
			return pp.getPre();
		}

		public boolean hasPreconditions() {
			return !pp.getPre().isEmpty();
		}

		public ServiceExecution call(Map<Node_Variable, Node_Concrete> bindings, Problem problem, Problems problems, OsssoModel model) {
			return delegate.call(bindings, problem, problems, model);
		}

		public boolean canResolve(Problem problem, OsssoModel model) {
			return delegate.canResolve(problem, model);
		}

		public boolean canResolve(Problem problem) {
			return delegate.canResolve(problem);
		}

		public float getQOSParameter(String uri) {
			return delegate.getQOSParameter(uri);
		}

		public Map<Node_Variable, Node_Concrete> getVariableBindings(Problem solveThis) {
			return delegate.getVariableBindings(solveThis);
		}

		public Set<Triple> predictResults() {
			return delegate.predictResults();
		}

		public boolean isPassive() {
			return delegate.isPassive();
		}
	}
}
