/*
* Copyright 2011 Austrian Federal Ministry of Finance
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and limitations under the Licence.
*/
package at.m2n.IntelligenceManagement.peppol.service.external.firmenbuch.stages;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.log4j.Logger;

import sun.misc.BASE64Encoder;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpRequestFactory;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpResponseHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceConfiguration;
import at.m2n.IntelligenceManagement.peppol.service.external.common.HttpServiceUtil;
import at.m2n.IntelligenceManagement.peppol.service.external.common.params.HttpRequestArgumentsHandler;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceContext;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStage;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.HttpServiceStageResult;
import at.m2n.IntelligenceManagement.peppol.service.external.common.stages.impl.ResponseHandlerWrappingServiceStage;
import at.m2n.util.Util;

public class FirmenbuchAuszugRetrievalStage implements HttpServiceStage {

	private final HttpServiceConfiguration serviceConfiguration;
	private static final Logger LOG = Logger.getLogger(FirmenbuchAuszugRetrievalStage.class);

	public FirmenbuchAuszugRetrievalStage(HttpServiceConfiguration serviceConfiguration) {
		this.serviceConfiguration = serviceConfiguration;
	}

	@Override
	public HttpServiceStageResult call(HttpClient httpClient, HttpServiceContext context) {
		HttpResponseHandler authorization = new HttpResponseHandler() {

			@Override
			public void handleResponse(InputStream responseStream, HttpResponse response, HttpServiceContext context) throws IOException {
				int statusCode = response.getStatusLine().getStatusCode();
				if (statusCode == HttpStatus.SC_OK || statusCode == HttpStatus.SC_MOVED_TEMPORARILY) {
					// content-type also needs to be PDF to be a successful
					// call!
					String mimeType = response.getEntity().getContentType().getValue();

					if (!mimeType.matches("(.*)pdf")) {
					throw new RuntimeException("Expected PDF document, but got " + mimeType + " instead!");
					}

					String fileName = context.getValue("fbService.fileNamePattern", "Firmenbuchauszug für Firma $FN$.pdf");
					String companyId = context.getValue("companyId", null);
					fileName = fileName.replaceAll("\\$FN\\$", companyId);
					if (!HttpServiceUtil.saveBlobFromStream(responseStream, fileName, mimeType, context.getOsssoModel(), context.getAdditionsModel(), context)) {
						// This should not have happened ...
						throw new RuntimeException("Could not save BLOB for some reason.");
					}
				} else {
					throw new RuntimeException("HTTP Status " + statusCode + " returned, but needed a 200");
				}
			}
		};

		HttpRequestArgumentsHandler argumentsHandler = null;
		HttpRequestFactory requestFactory = new HttpRequestFactory() {

			@Override
			public HttpRequestBase createForConfiguration(HttpServiceConfiguration configuration, HttpServiceContext context) {
				String cookie = "SMSESSION=" + context.getValue("SMSESSION", null);
				cookie += "; JSESSIONID=" + context.getValue("JSESSIONID", null);
				String authUser = context.getValue("portal.auth.user", null);
				String authPassword = context.getValue("portal.auth.password", null);
				String authorization = new BASE64Encoder().encode((authUser + ":" + authPassword).getBytes());

				String content = createPOSTContent(context);
				
				String fbServiceBaseURL = context.getValue("fbService.baseURL", null);
				HttpPost request = new HttpPost(fbServiceBaseURL);
				try {
					HttpEntity entity = new StringEntity(content, "application/x-www-form-urlencoded", "utf-8");
					request.setEntity(entity);
					request.setHeader("Cookie", cookie);
					request.setHeader("Authorization", "Basic " + authorization);

					return request;
				} catch (UnsupportedEncodingException e) {
					throw new RuntimeException("Could not create HTTP entity.", e);
				}
			}

			private String createPOSTContent(HttpServiceContext context) {
				StringBuilder sb = new StringBuilder("auszugArt=AKT&");
				sb.append("signierterStichtagsauszug=true&");
				sb.append("_signierterStichtagsauszug=on&");
				sb.append("verrechnungsArt=LEER&");
				sb.append("person1=&person2=&");
				sb.append("_auszugHistorisch=on&");
				sb.append("_auszugMitGewerberegisterdaten=on&");
				sb.append("_auszugMitVerlinkung=on&");
				sb.append("_teilAuszugHistorisch=on&");
				String companyId = context.getValue("companyId", null);
				sb.append("fnr=");
				sb.append(companyId);
				sb.append("&");

				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				String today = dateFormat.format(new Date());

				sb.append("stichtag=");
				sb.append(today);
				return sb.toString();
			}
		};

		HttpServiceStage delegate = new ResponseHandlerWrappingServiceStage(serviceConfiguration, authorization, requestFactory, argumentsHandler, getRequiredKeys());
		return delegate.call(httpClient, context);
	}

	@Override
	public Collection<String> getRequiredKeys() {
		return Util.toSet("SMSESSION", "JSESSIONID", "portal.auth.user", "portal.auth.password", "companyId", "fbService.baseURL", "fbService.fileNamePattern");
	}
}
