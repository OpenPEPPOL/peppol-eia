package eu.peppol.demo.client.eProcurement.functions;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.rpc.ServiceException;

import ontology_service.web_service.tech.ed_1._20._29002.ts.iso.std.iso.Ontology_service;

import org.apache.commons.configuration.tree.ConfigurationNode;
import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.BrowserFunction;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXParseException;

import resolution_service_data.xml_schema.tech.ed_1._20._29002.ts.iso.std.iso.Implementation_exception_Type;
import resolution_service_data.xml_schema.tech.ed_1._20._29002.ts.iso.std.iso.Object_not_found_exception_Type;
import at.paradine.iso29002.part20.Session;
import eu.peppol.demo.client.eProcurement.utils.EPPsService;
import eu.peppol.demo.client.eProcurement.utils.FactoryStructureItem;
import eu.peppol.demo.client.eProcurement.utils.IEClassStructureItem;
import eu.peppol.demo.client.eProcurement.utils.TemplateStructureItem;
import eu.peppol.demo.client.eProcurement.utils.TenderStructureItem;
import eu.peppol.demo.client.util.Constants;
import eu.peppol.demo.client.util.Util;
import eu.peppol.demo.client.xml.general.ReadXmlDocument;
import eu.peppol.demo.client.xml.general.ReadXmlDocumentCache;
import eu.peppol.demo.client.xml.general.XmlFormatter;
import eu.peppol.demo.client.xml.template.Template;
import eu.peppol.demo.client.xml.template.TemplateProperty;
import eu.peppol.demo.client.xml.template.TemplateUtils;
import eu.peppol.demo.client.xml.template.interfaces.ITemplateParser;
import eu.peppol.demo.client.xml.template.parsers.TemplateXPathParser;
import eu.peppol.demo.client.xml.tender.TenderItem;
import eu.peppol.demo.client.xml.tender.interfaces.ITenderParser;
import eu.peppol.demo.client.xml.tender.parsers.TenderSAXParser;
import eu.peppol.demo.client.xml.tender.parsers.TenderXPathParser;

/**
 *
 * @author Paradine
 *
 */
public class EPPsWebServiceFunction extends BrowserFunction {

	private String CLASSID;
	private ReadXmlDocument xmlMapping;

	private ReadXmlDocument xmlResult;
	private String eClassResultFile;

	Logger log = LoggerFactory.getLogger(EPPsWebServiceFunction.class);

	public EPPsWebServiceFunction(Browser browser, String name) {

        super (browser, name);

	}

	 public Object function (Object[] arguments) {
		 
		 CLASSID = "" + arguments[1];

		 xmlMapping = new ReadXmlDocument(Constants.eClass + arguments[0] + "-eClassMapping.xml");
		 eClassResultFile = Constants.eClass + "classInfo.xml";

		 if (arguments[2].equals("eClassValues")) {
			return getEClassValues();
		 } else if (arguments[2].equals("cenbiiValues")) {
			return getCenbiiValues();
		 } else if (arguments[2].equals("unboundedValues")) {
			 return getUnboundedValues();
		 } 
		 return null;

	 }

	 @SuppressWarnings("unchecked")
	 private String[] getUnboundedValues() {
		 List < ConfigurationNode >  maps = xmlMapping.getRootNode().getChildren("map");

		 ArrayList < String > results = new ArrayList < String > ();

		 for (int i = 0; i < maps.size(); i++) {
			 ConfigurationNode map = maps.get(i);

			 ConfigurationNode mapUnboundedGroup = (ConfigurationNode) map.getAttributes("unboundedGroup").get(0);
			 String mapUnboundedGroupString = "" + mapUnboundedGroup.getValue();

			 ConfigurationNode mapId = (ConfigurationNode) map.getAttributes("id").get(0);
			 String mapIdString = "" + mapId.getValue();

			 //TODO fix this validation
			 if(!mapUnboundedGroupString.equals("")) {
				 boolean alreadyExist = false;
				 for (int j = 0; j < results.size(); j++) {
					if(results.get(j).equals(mapUnboundedGroupString + ":" + mapIdString)) {
						alreadyExist = true;
					}
				 }
				 if (!alreadyExist) {
					 results.add(mapUnboundedGroupString + ":" + mapIdString);
				}
			 }
		 }

		 String[] result = new String[results.size()];
		 for (int i = 0; i < results.size(); i++) {
			 result[i] = results.get(i);
		 }

		 return result;
	 }

	@SuppressWarnings("unchecked")
	private String[] getCenbiiValues() {
		List < ConfigurationNode >  maps = xmlMapping.getRootNode().getChildren("map");

		String[] result = new String[maps.size()];

		for (int i = 0; i < maps.size(); i++) {
			ConfigurationNode map = maps.get(i);
			ConfigurationNode mapUnboundedGroup = (ConfigurationNode) map.getAttributes("unboundedGroup").get(0);
			String mapIdString = "" + mapUnboundedGroup.getValue();
			ConfigurationNode mapUnboundedField = (ConfigurationNode) map.getAttributes("unboundedField").get(0);
			String mapUnboundedFieldString = "" + mapUnboundedField.getValue();

			ConfigurationNode cenbii = (ConfigurationNode) map.getChildren("cenbii").get(0);
			result[i] = mapIdString + ":" + mapUnboundedFieldString + ":" + cenbii.getValue();
		}

		return result;
	}

	private void showErrorMessageBox() {
		this.getBrowser().execute("alert('ID Inserted is not valid.');");
	}
	
	@SuppressWarnings("uncheched")
	public String[] getEClassValues()
	{

		ReadXmlDocument xmlResult;
		List<String> resultList = new ArrayList<String>();
		Session s;
		String classId = CLASSID;
		try {
			s = Session.openSession(
							"http://beta.peppol.paradine.at/eptos4catalog-eptos4catalog/LoginWebService?wsdl",
							"peppol-ws", "peppolwsuser");
			if (s.isLoggedIn()) {


				String info = EPPsService.retrieveXml(s, classId);
			
				if(!checkServiceResponse(info))
					return null;
				
				Util.createXmlFile(info, eClassResultFile);
				xmlResult = new ReadXmlDocument(eClassResultFile);
				
				ConfigurationNode cfgNode = xmlResult.getRootNode();
				String cfgNodeString = cfgNode.getName();
				FactoryStructureItem factoryStructureItem = new FactoryStructureItem(s,info);
				IEClassStructureItem currentStructure = factoryStructureItem.createItem(cfgNodeString);
				resultList = currentStructure.retrieveList();
				
				s.close();

			}
		} catch (RemoteException e) {
			e.printStackTrace();

		} catch (ServiceException e) {
			e.printStackTrace();

		} 	catch (Exception e) {

			e.printStackTrace();
		}
		return (String[]) resultList.toArray(new String[]{});
	}

	private boolean checkServiceResponse(String info) {
		if(info.length()==0)
		{
			showErrorMessageBox();
			return false;
		}
		return true;
	}
	
	
	@SuppressWarnings("unchecked")
	public String[] getEClassValues2() {

		String[] result = new String[1];

		try {

			//TODO FAILING!! missing jar
			Session s = Session.openSession(
					"http://beta.peppol.paradine.at/eptos4catalog-eptos4catalog/LoginWebService?wsdl",
					"peppol-ws", "peppolwsuser");

			if (s.isLoggedIn()) {

				//Terminology_service ts = s.connectTerminologyService("http://beta.peppol.paradine.at/eptos4catalog-eptos4catalog/TerminologyService");
				//Concept_Type conctype = ts.get_concept(CLASSID);
				//System.out.println(">> Content of first term: " + conctype.getTerm()[0].getContent());

				//------------------------------------------------------------------------------
				//Location_service ls = s.connectLocationService("http://beta.peppol.paradine.at/eptos4catalog-eptos4catalog/LocationService?wsdl");
				//Source_identification_Type[] locatioInfo = ls.get_source_identification(CLASSID);

				//-------------------------------------------------------------------------------
				Ontology_service os = s.connectOntologyService("http://beta.peppol.paradine.at/eptos4catalog-eptos4catalog/OntologyService");
				/*String propInfo = *///os.get_concept_information(PROPERTY, "ONTOML");
				String classInfo = os.get_concept_information(CLASSID, "ONTOML");

				s.close();

				classInfo = XmlFormatter.format(classInfo);

			//	Util.createXmlFile(classInfo, eClassResultFile);
			//	xmlResult = new ReadXmlDocument(eClassResultFile);

				xmlResult = new ReadXmlDocumentCache(classInfo);

				List < ConfigurationNode >  maps = xmlMapping.getRootNode().getChildren("map");

				result = new String[maps.size()];

				for (int i = 0; i < maps.size(); i++) {
					ConfigurationNode map = maps.get(i);
					//ConfigurationNode mapId = (ConfigurationNode) map.getAttributes("id").get(0);
					//String mapIdString = "" + mapId.getValue();

					ConfigurationNode eclass = (ConfigurationNode) map.getChildren("eclass").get(0);
					List < ConfigurationNode > gets = eclass.getChildren("get");

					String results = getResult(gets, xmlResult, 0, "");

					//System.out.println(mapIdString);
					log.info(results);
					//if(results.indexOf("___") > -1){
						//System.out.println("tiene 9: " + results.split("___").length);
					//}

					result[i] = results;
				}
			}
		} catch (ServiceException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			result[0] = "eClass Fault:ClassID wrong";
		} catch (RemoteException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			result[0] = "eClass Fault:ClassID wrong";
		}

		return result;
	 }

	@SuppressWarnings("rawtypes")
	private String getResult(List<ConfigurationNode> gets,ReadXmlDocument xmlResult,int getNumber, String beforeResult) {

		ConfigurationNode get = gets.get(getNumber);

		String result = "";

		String node = "" + ((ConfigurationNode)get.getAttributes("node").get(0)).getValue();
		String nodeAddress = "" + ((ConfigurationNode)get.getAttributes("nodeAddress").get(0)).getValue();
		String getAttribute = "" + ((ConfigurationNode)get.getAttributes("getAttribute").get(0)).getValue();
		String attributeParameter = "" + ((ConfigurationNode)get.getAttributes("attributeParameter").get(0)).getValue();
		String unboundedGet = "" + ((ConfigurationNode)get.getAttributes("unbounded").get(0)).getValue();

		String getValue = "" + get.getValue();

		if(!beforeResult.equals("")) {
			getValue = changeResultParameter(getValue, beforeResult);
		}

		ConfigurationNode lastNode = getLastNode(getValue, xmlResult);

		List nodes = lastNode.getChildren(node);

		if (nodes.size() == 0) {
			result += "___";
		}

		for (int k = 0; k < nodes.size(); k++) {

			ConfigurationNode childNode = (ConfigurationNode) nodes.get(k);
			String value = "";
			if(unboundedGet.equals("1")) {
				String unboundedValues = "" + ((ConfigurationNode)get.getAttributes("unboundedValues").get(0)).getValue();
				ConfigurationNode unboundedNode = getLastNode(childNode, unboundedValues, attributeParameter);
				result += unboundedNode.getValue();
				if(k < nodes.size()-1) {
					result += "__";
				} else {
					result += "___";
				}
			}
			else if(!getAttribute.equals("")) {
				ConfigurationNode childAttribute = (ConfigurationNode) childNode.getAttributes(getAttribute).get(0);
				value = "" + childAttribute.getValue();
			}
			else if(!nodeAddress.equals("")) {
				ConfigurationNode childNodeAddres = getLastNode(childNode, nodeAddress, attributeParameter);
				value = "" + childNodeAddres.getValue();
			}
			else if(!attributeParameter.equals("")) {
				List childAttributes = childNode.getAttributes();
				for (int l = 0; l < childAttributes.size(); l++) {
					ConfigurationNode childAttribute = (ConfigurationNode) childAttributes.get(l);
					if(childAttribute.getValue().equals(attributeParameter)) {
						value = "" + childNode.getValue();
					}
				}
			} else {
				value = "" + childNode.getValue();
			}

			if(!value.equals("")) {
				if (gets.size() > getNumber+1) {
					result += getResult(gets,xmlResult, getNumber+1, value);
				}  else {
					result += value + "___";
				}
			}

		}

		return result;

	}

	@SuppressWarnings("rawtypes")
	private ConfigurationNode getLastNode(ConfigurationNode document, String string, String attributeParameter) {
		String[] nodes = string.split("\\.");
		for (int i = 0; i < nodes.length; i++) {
			String node = nodes[i];

			//document = (ConfigurationNode) document.getChildren(node).get(0);
			if(i == nodes.length-1) {
				for (int j = 0; j < document.getChildren(node).size(); j++) {
					ConfigurationNode searchNode = (ConfigurationNode) document.getChildren(node).get(j);
					List childAttributes = searchNode.getAttributes();
					for (int l = 0; l < childAttributes.size(); l++) {
						ConfigurationNode childAttribute = (ConfigurationNode) childAttributes.get(l);
						if(childAttribute.getValue().equals(attributeParameter)) {
							document = searchNode;
						}
					}
				}
			} else {
				document = (ConfigurationNode) document.getChildren(node).get(0);
			}
		}
		return document;
	}

	private String changeResultParameter(String getValue, String valueForNextGet) {
		getValue = getValue.replaceAll("@result", valueForNextGet);
		return getValue;
	}

	@SuppressWarnings("rawtypes")
	private ConfigurationNode getLastNode(String string, ReadXmlDocument xmlResult) {

		String[] nodes = string.split("\\.");
		ConfigurationNode document = xmlResult.getRootNode();
		for (int i = 0; i < nodes.length; i++) {
			String node = nodes[i];
			if(node.indexOf("=") > -1){

				String attribute = node.substring(node.indexOf("[") + 1, node.indexOf("]"));
				String nameAttribute = attribute.split("=")[0];
				String valueAttribute = attribute.split("=")[1];

				node = node.substring(0, node.indexOf("["));

				List similarNodes = document.getChildren(node);
				ConfigurationNode similarNode = null;

				for (int j = 0; j < similarNodes.size(); j++) {

					similarNode = (ConfigurationNode) similarNodes.get(j);

					String similarNodeAttributeValue = "" + ((ConfigurationNode) similarNode.getAttributes(nameAttribute).get(0)).getValue();

					if(valueAttribute.equalsIgnoreCase(similarNodeAttributeValue)) {
						break;
					}
				}

				document = similarNode;

			} else {
				if(document.getChildren(node).size() > 0) {
					document = (ConfigurationNode) document.getChildren(node).get(0);
				}
			}
		}
		return document;
	}


	public ITenderParser createTenderParser()
	{
		return new TenderSAXParser();
	}
	
	public ITemplateParser createTemplateParser()
	{
		return new TemplateXPathParser();
	}
}
