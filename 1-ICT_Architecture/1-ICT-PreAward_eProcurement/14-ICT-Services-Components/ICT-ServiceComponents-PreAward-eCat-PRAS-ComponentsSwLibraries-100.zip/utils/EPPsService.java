package eu.peppol.demo.client.eProcurement.utils;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import eu.peppol.demo.client.xml.general.XmlFormatter;
import ontology_service.web_service.tech.ed_1._20._29002.ts.iso.std.iso.Ontology_service;
import resolution_service_data.xml_schema.tech.ed_1._20._29002.ts.iso.std.iso.Implementation_exception_Type;
import resolution_service_data.xml_schema.tech.ed_1._20._29002.ts.iso.std.iso.Invalid_identifier_exception_Type;
import resolution_service_data.xml_schema.tech.ed_1._20._29002.ts.iso.std.iso.Object_not_found_exception_Type;
import at.paradine.iso29002.part20.Session;

public class EPPsService {

	public static String retrieveXml(Session s, String classId) {
		String classInfo = "";
		Ontology_service os;
		try {
			os = s.connectOntologyService("http://beta.peppol.paradine.at/eptos4catalog-eptos4catalog/OntologyService");
			String info = os.get_concept_information(classId, "ONTOML");
			classInfo = XmlFormatter.format(info);
		} catch (ServiceException e) {
			classInfo = "";
		} catch (Invalid_identifier_exception_Type e) {
			classInfo = "";
		} catch (Object_not_found_exception_Type e) {
			classInfo = "";
		} catch (Implementation_exception_Type e) {
			classInfo = "";
		} catch (RemoteException e) {
			classInfo = "";
		}
		return classInfo;
	}

}
