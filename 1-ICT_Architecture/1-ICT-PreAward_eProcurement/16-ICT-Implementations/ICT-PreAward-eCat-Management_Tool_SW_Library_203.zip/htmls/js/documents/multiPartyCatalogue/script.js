function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {

	providerSchemeAgencyName = askIssuingAgency("schemeAgencyName", providerNumericCode);
	providerSchemeID = askIssuingAgency("schemeID", providerNumericCode);
	providerSchemeURI = askIssuingAgency("schemeURI", providerNumericCode);

	receiverSchemeAgencyName = askIssuingAgency("schemeAgencyName", receiverNumericCode);
	receiverSchemeID = askIssuingAgency("schemeID", receiverNumericCode);
	receiverSchemeURI = askIssuingAgency("schemeURI", receiverNumericCode);

	supplierSchemeAgencyName = askIssuingAgency("schemeAgencyName", supplierNumericCode);
	supplierSchemeID = askIssuingAgency("schemeID", supplierNumericCode);
	supplierSchemeURI = askIssuingAgency("schemeURI", supplierNumericCode);

	customerSchemeAgencyName = askIssuingAgency("schemeAgencyName", customerNumericCode);
	customerSchemeID = askIssuingAgency("schemeID", customerNumericCode);
	customerSchemeURI = askIssuingAgency("schemeURI", customerNumericCode);

	//Component Related Item//
	var lastId = parseInt(document.getElementById("ComponentRelatedItemLastId").value);
	var txtCatalogueLineComponentRelatedItemIDs = "";
	var txtCatalogueLineComponentRelatedItemQuantities = "";
	var txtCatalogueLineComponentRelatedItemDescriptions = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("ComponentRelatedItem" + i + "txtCatalogueLineComponentRelatedItemID") != null){
			txtCatalogueLineComponentRelatedItemIDs += document.getElementById("ComponentRelatedItem" + i + "txtCatalogueLineComponentRelatedItemID").value + "___";
			txtCatalogueLineComponentRelatedItemQuantities += document.getElementById("ComponentRelatedItem" + i + "txtCatalogueLineComponentRelatedItemQuantity").value + "___";
			txtCatalogueLineComponentRelatedItemDescriptions += document.getElementById("ComponentRelatedItem" + i + "txtCatalogueLineComponentRelatedItemDescription").value + "___";
		}
	}

	//Required Related Item//
	var lastId = parseInt(document.getElementById("RequiredRelatedItemLastId").value);
	var txtCatalogueLineRequiredRelatedItemIDs = "";
	var txtCatalogueLineRequiredRelatedItemQuantities = "";
	var txtCatalogueLineRequiredRelatedItemDescriptions = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("RequiredRelatedItem" + i + "txtCatalogueLineRequiredRelatedItemID") != null){
			txtCatalogueLineRequiredRelatedItemIDs += document.getElementById("RequiredRelatedItem" + i + "txtCatalogueLineRequiredRelatedItemID").value + "___";
			txtCatalogueLineRequiredRelatedItemQuantities += document.getElementById("RequiredRelatedItem" + i + "txtCatalogueLineRequiredRelatedItemQuantity").value + "___";
			txtCatalogueLineRequiredRelatedItemDescriptions += document.getElementById("RequiredRelatedItem" + i + "txtCatalogueLineRequiredRelatedItemDescription").value + "___";
		}
	}

	//Required Item Location Quantity//
	var lastId = parseInt(document.getElementById("RequiredItemLocationQuantityLastId").value);
	var txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasures = "";
	var txtCatalogueLineRequiredItemLocationQuantityMinimumQuantities = "";
	var txtCatalogueLineRequiredItemLocationQuantityMaximumQuantities = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCitySubdivisionNames = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetNames = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityNames = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZones = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBlockNames ="";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegions = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumbers = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressTimezoneOffsets = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressInhouseMails = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPlotIdentifications = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateCoordinateSystemCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeDegreesMeasures = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeDegreesMeasures = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeMinutesMeasures = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeMinutesMeasures = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeDirectionCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeDirectionCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityPricePriceAmounts = "";
	var txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyIDs = "";
	var txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantities = "";
	var txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDates = "";
	var txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDates = "";

	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityName") != null){
			txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasures += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasure").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityMinimumQuantities += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityMinimumQuantity").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityMaximumQuantities += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityMaximumQuantity").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCitySubdivisionNames += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCitySubdivisionName").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetNames += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetName").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityNames += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityName").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetName").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZones += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZone").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBlockNames += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBlockName").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegions += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegion").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumbers += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumber").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressTimezoneOffsets += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressTimezoneOffset").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressInhouseMails += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressInhouseMail").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPlotIdentifications += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPlotIdentification").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateCoordinateSystemCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateCoordinateSystemCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeDegreesMeasures += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeDegreesMeasure").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeDegreesMeasures += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeDegreesMeasure").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeMinutesMeasures += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeMinutesMeasure").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeMinutesMeasures += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeMinutesMeasure").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeDirectionCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeDirectionCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeDirectionCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeDirectionCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPricePriceAmounts += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPricePriceAmount").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyIDs += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyID").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantities += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantity").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDates += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDate").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDates += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDate").value + "___";
		}
	}

	//keyword//
	var lastId = parseInt(document.getElementById("KeywordLastId").value);
	var txtCatalogueLineItemKeywords = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("Keyword" + i + "txtCatalogueLineItemKeyword") != null){
			txtCatalogueLineItemKeywords += document.getElementById("Keyword" + i + "txtCatalogueLineItemKeyword").value + "___";
		}
	}

	//Item Specification Document Reference//
	var lastId = parseInt(document.getElementById("ItemSpecificationDocumentReferenceLastId").value);
	var txtCatalogueLineItemItemSpecificationDocumentReferenceIDs = "";
	var txtCatalogueLineItemItemSpecificationDocumentReferenceDocumentTypes = "";
	var txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects = "";
	var txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjectMimeCodes = "";
	var txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentExternalReferenceURIs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("ItemSpecificationDocumentReference" + i + "txtCatalogueLineItemItemSpecificationDocumentReferenceID") != null){
			txtCatalogueLineItemItemSpecificationDocumentReferenceIDs += document.getElementById("ItemSpecificationDocumentReference" + i + "txtCatalogueLineItemItemSpecificationDocumentReferenceID").value + "___";
			txtCatalogueLineItemItemSpecificationDocumentReferenceDocumentTypes += document.getElementById("ItemSpecificationDocumentReference" + i + "txtCatalogueLineItemItemSpecificationDocumentReferenceDocumentType").value + "___";
			txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects += document.getElementById("ItemSpecificationDocumentReference" + i + "txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObject").value + "___";
			txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjectMimeCodes += document.getElementById("ItemSpecificationDocumentReference" + i + "txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjectMimeCode").value + "___";
			txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentExternalReferenceURIs += document.getElementById("ItemSpecificationDocumentReference" + i + "txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentExternalReferenceURI").value + "___";
		}
	}

	//Commodity Classification//
	var lastId = parseInt(document.getElementById("CommodityClassificationLastId").value);
	var txtCatalogueLineItemCommodityClassificationCommodityCodes = "";
	var txtCatalogueLineItemCommodityClassificationItemClassificationCodes = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationCommodityCode") != null){
			txtCatalogueLineItemCommodityClassificationCommodityCodes += document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationCommodityCode").value + "___";
			txtCatalogueLineItemCommodityClassificationItemClassificationCodes += document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationItemClassificationCode").value + "___";
		}
	}

	//Hazardous Item//
	var lastId = parseInt(document.getElementById("HazardousItemLastId").value);
	var txtCatalogueLineItemHazardousItemUNDGCodes = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("HazardousItem" + i + "txtCatalogueLineItemHazardousItemUNDGCode") != null){
			txtCatalogueLineItemHazardousItemUNDGCodes += document.getElementById("HazardousItem" + i + "txtCatalogueLineItemHazardousItemUNDGCode").value + "___";
		}
	}

	//Additional Item Property//
	var lastId = parseInt(document.getElementById("AdditionalItemPropertyLastId").value);
	var txtCatalogueLineItemAdditionalItemPropertyNames = "";
	var txtCatalogueLineItemAdditionalItemPropertyValues = "";
	var txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs = "";
	var txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalItemProperty" + i + "txtCatalogueLineItemAdditionalItemPropertyName") != null){
			txtCatalogueLineItemAdditionalItemPropertyNames += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueLineItemAdditionalItemPropertyName").value + "___";
			txtCatalogueLineItemAdditionalItemPropertyValues += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueLineItemAdditionalItemPropertyValue").value + "___";

			var lastID = document.getElementById("ItemPropertyGroupLastId").value;
			var found = 0;
			for ( var j = 1; j <= lastID; j++) {
				var itemPropertyGroup = document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupID");
				if(itemPropertyGroup) {
					if(found > 0){
						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs += "__";
						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames += "__";
					}
					txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupID").value;
					txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupName").value;
					found++;
				}
			}
			txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs += "___";
			txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames += "___";
		}
	}

	return createNewDocument( form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
						validationType,
						"",

						form.txtUBLVersionID.value,
						form.txtCustomizationID.value,
						defaultCustomizationSchemeID,
						form.txtProfileID.value,
						form.txtID.value,
						form.txtName.value,
						form.txtIssueDate.value,
						form.txtVersionID.value,

						form.txtValidityPeriodStartDate.value,
						form.txtValidityPeriodEndDate.value,

						form.txtReferencedContractID.value,
						form.txtReferencedContractContractType.value,

						providerEndpoint,
						providerSchemeAgencyName,
						providerSchemeID,
						providerSchemeURI,
						providerEndpoint,
						providerSchemeAgencyName,
						providerSchemeID,
						providerSchemeURI,
						providerName,

						receiverEndpoint,
						receiverSchemeAgencyName,
						receiverSchemeID,
						receiverSchemeURI,
						receiverEndpoint,
						receiverSchemeAgencyName,
						receiverSchemeID,
						receiverSchemeURI,
						receiverName,

						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierName,

						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerName,

						form.editLine.value,
						form.txtLineID.value,

						form.txtLineID.value,
						form.txtCatalogueLineActionCode.value,
						form.cboCatalogueLineOrderableIndicator.value,
						form.txtCatalogueLineOrderableUnit.value,
						form.txtCatalogueLineContentUnitQuantity.value,
						form.txtCatalogueLineOrderQuantityIncrementNumeric.value,
						form.txtCatalogueLineMinimumOrderQuantity.value,
						form.txtCatalogueLineMaximumOrderQuantity.value,
						form.txtCatalogueLineWarrantyInformation.value,
						form.txtCatalogueLineLineValidityPeriodStartDate.value,
						form.txtCatalogueLineLineValidityPeriodEndDate.value,

						form.txtCatalogueLineItemComparisonPriceAmount.value,
						form.txtCatalogueLineItemComparisonPriceAmountCurrencyID.value,
						form.txtCatalogueLineItemComparisonQuantity.value,

						txtCatalogueLineComponentRelatedItemIDs,
						txtCatalogueLineComponentRelatedItemQuantities,
						txtCatalogueLineComponentRelatedItemDescriptions,

						txtCatalogueLineRequiredRelatedItemIDs,
						txtCatalogueLineRequiredRelatedItemQuantities,
						txtCatalogueLineRequiredRelatedItemDescriptions,

						txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasures,
						txtCatalogueLineRequiredItemLocationQuantityMinimumQuantities,
						txtCatalogueLineRequiredItemLocationQuantityMaximumQuantities,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetNames,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBlockNames,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumbers,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressInhouseMails,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPlotIdentifications,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCitySubdivisionNames,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityNames,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZones,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegions,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressTimezoneOffsets,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateCoordinateSystemCodes,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeDegreesMeasures,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeMinutesMeasures,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLatitudeDirectionCodes,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeDegreesMeasures,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeMinutesMeasures,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressLocationCoordinateLongitudeDirectionCodes,
						txtCatalogueLineRequiredItemLocationQuantityPricePriceAmounts,
						txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyIDs,
						txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantities,
						txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDates,
						txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDates,

						form.txtCatalogueLineItemDescription.value,
						form.txtCatalogueLineItemPackQuantity.value,
						form.txtCatalogueLineItemPackSizeNumeric.value,
						form.txtCatalogueLineItemName.value,
						txtCatalogueLineItemKeywords,
						form.txtCatalogueLineItemSellersItemIdentificationID.value,
						form.txtCatalogueLineItemSellersItemIdentificationExtendedID.value,
						form.txtCatalogueLineItemManufacturersItemIdentificationID.value,
						form.txtCatalogueLineItemStandardItemIdentificationID.value,
						txtCatalogueLineItemItemSpecificationDocumentReferenceIDs,
						txtCatalogueLineItemItemSpecificationDocumentReferenceDocumentTypes,
						txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects,
						txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjectMimeCodes,
						txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentExternalReferenceURIs,
						form.txtCatalogueLineItemOriginCountryIdentificationCode.value,
						txtCatalogueLineItemCommodityClassificationCommodityCodes,
						txtCatalogueLineItemCommodityClassificationItemClassificationCodes,
						txtCatalogueLineItemHazardousItemUNDGCodes,
						form.txtCatalogueLineItemClassifiedTaxCategoryID.value,
						form.txtCatalogueLineItemClassifiedTaxCategoryTaxSchemeID.value,
						txtCatalogueLineItemAdditionalItemPropertyNames,
						txtCatalogueLineItemAdditionalItemPropertyValues,
						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs,
						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames,
						form.txtCatalogueLineItemItemInstanceLotIdentificationExpiryDate.value);
}

function setReferencedContractID(form) {
	form.txtReferencedContractID.value = form.referencedContractID.value;
}

function getProviderEndpoint(form) {
	return form.currentId.value;
}

function getProviderName(form) {
	return form.currentName.value;
}

function getReceiverEndpoint(form) {
	return form.otherPartyId.value;
}

function getReceiverName(form) {
	return form.otherPartyName.value;
}

function cleanTables() {
	cleanTable("ComponentRelatedItemLastId", "ComponentRelatedItem");
	cleanTable("RequiredRelatedItemLastId", "RequiredRelatedItem");
	cleanTable("RequiredItemLocationQuantityLastId", "RequiredItemLocationQuantity");
	cleanTable("KeywordLastId", "Keyword");
	cleanTable("ItemSpecificationDocumentReferenceLastId", "ItemSpecificationDocumentReference");
	cleanTable("CommodityClassificationLastId", "CommodityClassification");
	cleanTable("HazardousItemLastId", "HazardousItem");
	cleanTable("AdditionalItemPropertyLastId", "AdditionalItemProperty");
}