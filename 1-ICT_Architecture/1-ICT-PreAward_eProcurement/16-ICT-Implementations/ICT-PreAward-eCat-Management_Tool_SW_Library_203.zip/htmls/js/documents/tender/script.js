function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {

	supplierSchemeAgencyName = askIssuingAgency("schemeAgencyName", supplierNumericCode);
	supplierSchemeID = askIssuingAgency("schemeID", supplierNumericCode);
	supplierSchemeURI = askIssuingAgency("schemeURI", supplierNumericCode);

	customerSchemeAgencyName = askIssuingAgency("schemeAgencyName", customerNumericCode);
	customerSchemeID = askIssuingAgency("schemeID", customerNumericCode);
	customerSchemeURI = askIssuingAgency("schemeURI", customerNumericCode);

	//Required Item Location Quantity//
	var lastId = parseInt(document.getElementById("OfferedItemLocationQuantityLastId").value);
	var txtTenderLineOfferedItemLocationQuantityLeadTimeMeasures = "";
	var txtTenderLineOfferedItemLocationQuantityMinimumQuantities = "";
	var txtTenderLineOfferedItemLocationQuantityMaximumQuantities = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressIDs = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCityNames = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressStreetNames = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressPostalZones = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCountrySubentities = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressBuildingNumbers = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressRegions = "";
	var txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes = "";
	var txtTenderLineOfferedItemLocationQuantityPricePriceAmounts = "";
	var txtTenderLineOfferedItemLocationQuantityPricePriceAmountCurrencyIDs = "";
	var txtTenderLineOfferedItemLocationQuantityPriceBaseQuantities = "";
	var txtTenderLineOfferedItemLocationQuantityPriceValidityPeriodEndDates = "";
	var txtTenderLineOfferedItemLocationQuantityPriceValidityPeriodStartDates = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressID") != null){
			txtTenderLineOfferedItemLocationQuantityLeadTimeMeasures += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityLeadTimeMeasure").value + "___";
			txtTenderLineOfferedItemLocationQuantityMaximumQuantities += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityMaximumQuantity").value + "___";
			txtTenderLineOfferedItemLocationQuantityMinimumQuantities += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityMinimumQuantity").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressIDs += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressID").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressAddressTypeCode").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCityNames += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCityName").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressStreetNames += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressStreetName").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressPostalZones += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressPostalZone").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressAdditionalStreetName").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCountrySubentities += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCountrySubentity").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressBuildingNumbers += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressBuildingNumber").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressRegions += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressRegion").value + "___";
			txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCode").value + "___";
			txtTenderLineOfferedItemLocationQuantityPricePriceAmounts += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityPricePriceAmount").value + "___";
			txtTenderLineOfferedItemLocationQuantityPricePriceAmountCurrencyIDs += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityPricePriceAmountCurrencyID").value + "___";
			txtTenderLineOfferedItemLocationQuantityPriceBaseQuantities += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityPriceBaseQuantity").value + "___";
			txtTenderLineOfferedItemLocationQuantityPriceValidityPeriodEndDates += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityPriceValidityPeriodEndDate").value + "___";
			txtTenderLineOfferedItemLocationQuantityPriceValidityPeriodStartDates += document.getElementById("OfferedItemLocationQuantity" + i + "txtTenderLineOfferedItemLocationQuantityPriceValidityPeriodStartDate").value + "___";
		}
	}

	//keyword//
	var lastId = parseInt(document.getElementById("KeywordLastId").value);
	var txtTenderLineItemKeywords = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("Keyword" + i + "txtTenderLineItemKeyword") != null){
			txtTenderLineItemKeywords += document.getElementById("Keyword" + i + "txtTenderLineItemKeyword").value + "___";
		}
	}

	//BrandName//
	var lastId = parseInt(document.getElementById("BrandNameLastId").value);
	var txtTenderLineItemBrandNames = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("BrandName" + i + "txtTenderLineItemBrandName") != null){
			txtTenderLineItemBrandNames += document.getElementById("BrandName" + i + "txtTenderLineItemBrandName").value + "___";
		}
	}

	//ModelName//
	var lastId = parseInt(document.getElementById("ModelNameLastId").value);
	var txtTenderLineItemModelNames = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("ModelName" + i + "txtTenderLineItemModelName") != null){
			txtTenderLineItemModelNames += document.getElementById("ModelName" + i + "txtTenderLineItemModelName").value + "___";
		}
	}

	//Commodity Classification//
	var lastId = parseInt(document.getElementById("CommodityClassificationLastId").value);
	var txtTenderLineItemCommodityClassificationCommodityCodes = "";
	var txtTenderLineItemCommodityClassificationItemClassificationCodes = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("CommodityClassification" + i + "txtTenderLineItemCommodityClassificationCommodityCode") != null){
			txtTenderLineItemCommodityClassificationCommodityCodes += document.getElementById("CommodityClassification" + i + "txtTenderLineItemCommodityClassificationCommodityCode").value + "___";
			txtTenderLineItemCommodityClassificationItemClassificationCodes += document.getElementById("CommodityClassification" + i + "txtTenderLineItemCommodityClassificationItemClassificationCode").value + "___";
		}
	}

	//Hazardous Item//
	var lastId = parseInt(document.getElementById("HazardousItemLastId").value);
	var txtTenderLineItemHazardousItemUNDGCodes = "";
	var txtTenderLineItemHazardousItemHazardClassIDs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("HazardousItem" + i + "txtTenderLineItemHazardousItemHazardClassID") != null){
			txtTenderLineItemHazardousItemUNDGCodes += document.getElementById("HazardousItem" + i + "txtTenderLineItemHazardousItemUNDGCode").value + "___";
			txtTenderLineItemHazardousItemHazardClassIDs += document.getElementById("HazardousItem" + i + "txtTenderLineItemHazardousItemHazardClassID").value + "___";
		}
	}

	//Additional Item Property//
	var lastId = parseInt(document.getElementById("AdditionalItemPropertyLastId").value);
	var txtTenderLineItemAdditionalItemPropertyIDs = "";
	var txtTenderLineItemAdditionalItemPropertyNames = "";
	var txtTenderLineItemAdditionalItemPropertyTestMethods = "";
	var txtTenderLineItemAdditionalItemPropertyValues = "";
	var txtTenderLineItemAdditionalItemPropertyListValues = "";
	var txtTenderLineItemAdditionalItemPropertyItemPropertyRangeMinimumValueTexts = "";
	var txtTenderLineItemAdditionalItemPropertyItemPropertyRangeMaximumValueTexts = "";
	var txtTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs = "";
	var txtTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs = "";
	var txtTenderLineItemAdditionalItemPropertyItemPropertyGroupNames = "";

	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalItemProperty" + i + "txtTenderLineItemAdditionalItemPropertyID") != null){
			txtTenderLineItemAdditionalItemPropertyIDs += document.getElementById("AdditionalItemProperty" + i + "txtTenderLineItemAdditionalItemPropertyID").value + "___";
			txtTenderLineItemAdditionalItemPropertyNames += document.getElementById("AdditionalItemProperty" + i + "txtTenderLineItemAdditionalItemPropertyName").value + "___";
			txtTenderLineItemAdditionalItemPropertyTestMethods += document.getElementById("AdditionalItemProperty" + i + "txtTenderLineItemAdditionalItemPropertyTestMethod").value + "___";
			txtTenderLineItemAdditionalItemPropertyValues += document.getElementById("AdditionalItemProperty" + i + "txtTenderLineItemAdditionalItemPropertyValue").value + "___";

			var lastID = document.getElementById("ListValueLastId").value;
			var found = 0;
			for ( var j = 1; j <= lastID; j++) {
				var listValue = document.getElementById("AdditionalItemProperty" + i + "ListValue" + j + "txtTenderLineItemAdditionalItemPropertyListValue");
				if(listValue) {
					if(found > 0){
						txtTenderLineItemAdditionalItemPropertyListValues += "__";
					}
					txtTenderLineItemAdditionalItemPropertyListValues += listValue.value;
					found++;
				}
			}
			txtTenderLineItemAdditionalItemPropertyListValues += "___";

			txtTenderLineItemAdditionalItemPropertyItemPropertyRangeMinimumValueTexts += document.getElementById("AdditionalItemProperty" + i + "txtTenderLineItemAdditionalItemPropertyItemPropertyRangeMinimumValueText").value + "___";
			txtTenderLineItemAdditionalItemPropertyItemPropertyRangeMaximumValueTexts += document.getElementById("AdditionalItemProperty" + i + "txtTenderLineItemAdditionalItemPropertyItemPropertyRangeMaximumValueText").value + "___";

			var lastID = document.getElementById("ItemPropertyGroupLastId").value;
			var found = 0;
			for ( var j = 1; j <= lastID; j++) {
				var itemPropertyGroup = document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtTenderLineItemAdditionalItemPropertyItemPropertyGroupID");
				if(itemPropertyGroup) {
					if(found > 0){
						txtTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs += "__";
						txtTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs += "__";
						txtTenderLineItemAdditionalItemPropertyItemPropertyGroupNames += "__";
					}
					txtTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtTenderLineItemAdditionalItemPropertyItemPropertyGroupID").value;
					txtTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtTenderLineItemAdditionalItemPropertyItemPropertyGroupParentID").value;
					txtTenderLineItemAdditionalItemPropertyItemPropertyGroupNames += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtTenderLineItemAdditionalItemPropertyItemPropertyGroupName").value;
					found++;
				}
			}
			txtTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs += "___";
			txtTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs += "___";
			txtTenderLineItemAdditionalItemPropertyItemPropertyGroupNames += "___";
		}
	}

	return createNewDocument( form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
						validationType,
						"",

						form.txtUBLVersionID.value,
						form.txtCustomizationID.value,
						defaultCustomizationSchemeID,
						form.txtProfileID.value,
						form.txtID.value,
						form.txtContractFolderID.value,
						form.txtIssueDate.value,
						form.txtPeriodStartDate.value,
						form.txtPeriodEndDate.value,

						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierName,
						form.txtTendererPartyPartyPostalAddressID.value,
						form.txtTendererPartyPartyPostalAddressPostbox.value,
						form.txtTendererPartyPartyPostalAddressStreetName.value,
						form.txtTendererPartyPartyPostalAddressAdditionalStreetName.value,
						form.txtTendererPartyPartyPostalAddressBuildingNumber.value,
						form.txtTendererPartyPartyPostalAddressDepartment.value,
						form.txtTendererPartyPartyPostalAddressCityName.value,
						form.txtTendererPartyPartyPostalAddressPostalZone.value,
						form.txtTendererPartyPartyPostalAddressCountrySubentity.value,
						form.txtTendererPartyPartyPostalAddressCountryIdentificationCode.value,
						form.txtTendererPartyPartyPartyTaxSchemeCompanyID.value,
						form.txtTendererPartyPartyPartyLegalEntityCompanyID.value,
						form.txtTendererPartyPartyContactTelephone.value,
						form.txtTendererPartyPartyContactTelefax.value,
						form.txtTendererPartyPartyContactElectronicMail.value,
						form.txtTendererPartyPartyPersonFirstName.value,
						form.txtTendererPartyPartyPersonFamilyName.value,
						form.txtTendererPartyPartyPersonMiddleName.value,
						form.txtTendererPartyPartyPersonJobTitle.value,

						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerName,
						form.txtContractingPartyPartyPostalAddressID.value,
						form.txtContractingPartyPartyPostalAddressPostbox.value,
						form.txtContractingPartyPartyPostalAddressStreetName.value,
						form.txtContractingPartyPartyPostalAddressAdditionalStreetName.value,
						form.txtContractingPartyPartyPostalAddressBuildingNumber.value,
						form.txtContractingPartyPartyPostalAddressCityName.value,
						form.txtContractingPartyPartyPostalAddressPostalZone.value,
						form.txtContractingPartyPartyPostalAddressCountrySubentity.value,
						form.txtContractingPartyPartyPostalAddressCountryIdentificationCode.value,
						form.txtContractingPartyPartyPartyTaxSchemeCompanyID.value,
						form.txtContractingPartyPartyPartyLegalEntityCompanyID.value,
						form.txtContractingPartyPartyContactTelephone.value,
						form.txtContractingPartyPartyContactTelefax.value,
						form.txtContractingPartyPartyContactElectronicMail.value,
						form.txtContractingPartyPartyPersonFirstName.value,
						form.txtContractingPartyPartyPersonFamilyName.value,
						form.txtContractingPartyPartyPersonMiddleName.value,
						form.txtContractingPartyPartyPersonJobTitle.value,

						form.txtTenderedProjectID.value,
						form.txtTenderedProjectDescription.value,

						form.editLine.value,
						form.txtLineID.value,

						form.txtLineID.value,
						form.txtTenderLineReferenceID.value,
						form.txtTenderLineNote.value,
						form.txtTenderLineOrderableUnit.value,
						form.txtTenderLineContentUnit.value,
						form.txtTenderLineOrderQuantityIncrement.value,
						form.txtTenderLineMinimumOrderQuantity.value,
						form.txtTenderLineMaximumOrderQuantity.value,
						form.txtTenderLineWarrantyInformation.value,

						txtTenderLineOfferedItemLocationQuantityLeadTimeMeasures,
						txtTenderLineOfferedItemLocationQuantityMinimumQuantities,
						txtTenderLineOfferedItemLocationQuantityMaximumQuantities,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressIDs,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressStreetNames,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressBuildingNumbers,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCityNames,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressPostalZones,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCountrySubentities,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressRegions,
						txtTenderLineOfferedItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes,
						txtTenderLineOfferedItemLocationQuantityPricePriceAmounts,
						txtTenderLineOfferedItemLocationQuantityPricePriceAmountCurrencyIDs,
						txtTenderLineOfferedItemLocationQuantityPriceBaseQuantities,
						txtTenderLineOfferedItemLocationQuantityPriceValidityPeriodStartDates,
						txtTenderLineOfferedItemLocationQuantityPriceValidityPeriodEndDates,

						form.txtTenderLineItemDescription.value,
						form.txtTenderLineItemPackQuantity.value,
						form.txtTenderLineItemPackSizeNumeric.value,
						form.txtTenderLineItemName.value,
						form.txtTenderLineItemHazardousRiskIndicator.value,
						txtTenderLineItemKeywords,
						txtTenderLineItemBrandNames,
						txtTenderLineItemModelNames,
						form.txtTenderLineItemSellersItemIdentificationID.value,
						form.txtTenderLineItemSellersItemIdentificationExtendedID.value,
						form.txtTenderLineItemManufacturersItemIdentificationID.value,
						form.txtTenderLineItemStandardItemIdentificationID.value,
						form.txtTenderLineItemItemSpecificationDocumentReferenceID.value,
						form.txtTenderLineItemItemSpecificationDocumentReferenceDocumentType.value,
						form.txtTenderLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObject.value,
						form.txtTenderLineItemItemSpecificationDocumentReferenceAttachmentExternalReferenceURI.value,
						form.txtTenderLineItemOriginCountryIdentificationCode.value,
						txtTenderLineItemCommodityClassificationCommodityCodes,
						txtTenderLineItemCommodityClassificationItemClassificationCodes,
						txtTenderLineItemHazardousItemUNDGCodes,
						txtTenderLineItemHazardousItemHazardClassIDs,
						form.txtTenderLineItemClassifiedTaxCategoryId.value,
						form.txtTenderLineItemClassifiedTaxCategoryTaxSchemeId.value,
						txtTenderLineItemAdditionalItemPropertyIDs,
						txtTenderLineItemAdditionalItemPropertyNames,
						txtTenderLineItemAdditionalItemPropertyTestMethods,
						txtTenderLineItemAdditionalItemPropertyValues,
						txtTenderLineItemAdditionalItemPropertyListValues,
						txtTenderLineItemAdditionalItemPropertyItemPropertyRangeMinimumValueTexts,
						txtTenderLineItemAdditionalItemPropertyItemPropertyRangeMaximumValueTexts,
					    txtTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs,
					    txtTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs,
					    txtTenderLineItemAdditionalItemPropertyItemPropertyGroupNames,
						form.txtTenderLineItemManufacturerPartyPartyNameName.value,
						form.txtTenderLineItemItemInstanceLotIdentificationExpiryDate.value);

}

function setReferencedContractID(form) {
	form.txtReferencedContractID.value = form.referencedContractID.value;
}

function getSupplierEndpoint(form) {
	return form.currentId.value;
}

function getSupplierName(form) {
	return form.currentName.value;
}

function getCustomerEndpoint(form) {
	return form.otherPartyId.value;
}

function getCustomerName(form) {
	return form.otherPartyName.value;
}

function cleanTables() {
	/*
	 * TODO update
	 */
}