var lastRedText;
var defaultCustomizationSchemeID = "PEPPOL";

function saveDocument(form, documentName, xmlDraft, xmlDrop, validationType){
	
	var keyWord = getKeyWord();

	var result = null;
	
	var customerEndpoint = "";
	var customerNumericCode = "";
	var customerName = "";

	if(form.txtCustomerNewName){
		if(form.customerRadios[0].checked){
			customerEndpoint = form.txtCustomerEndpoint.value;
			if(form.cboCustomerName.selectedIndex > 0) {
				customerName = form.cboCustomerName.options[form.cboCustomerName.selectedIndex].text;
			}
		}
		else if(form.customerRadios[1].checked){
			customerEndpoint = form.txtCustomerNewEndpoint.value;
			customerName = form.txtCustomerNewName.value;
		}
		customerEndpoint = trim(customerEndpoint);
		if(customerEndpoint != "" || (askForCustomer && xmlDrop != "")) {
			validation = validateEndpoint("Customer", customerEndpoint);
			if(validation != "") {
				form.txtCustomerEndpoint.style.backgroundColor="yellow";
				form.txtCustomerNewEndpoint.style.backgroundColor="yellow";
//				return validation;
			} else {
				form.txtCustomerEndpoint.style.backgroundColor="white";
				form.txtCustomerNewEndpoint.style.backgroundColor="white";
				customerNumericCode = customerEndpoint.split(":")[0];
				customerEndpoint = customerEndpoint.split(":")[1];
			}
		}
	}

	
	var supplierEndpoint = "";
	var supplierNumericCode = "";
	var supplierName = "";
	if(form.txtSupplierNewName){
		if(form.supplierRadios[0].checked){
			supplierEndpoint = form.txtSupplierEndpoint.value;
			if(form.cboSupplierName.selectedIndex > 0) {
				supplierName = form.cboSupplierName.options[form.cboSupplierName.selectedIndex].text;
			}
		}
		else if(form.supplierRadios[1].checked){
			supplierEndpoint = form.txtSupplierNewEndpoint.value;
			supplierName = form.txtSupplierNewName.value;
		}
		supplierEndpoint = trim(supplierEndpoint);
		if(supplierEndpoint != "" || (askForSupplier && xmlDrop != "")) {
			validation = validateEndpoint("Supplier", supplierEndpoint);
			if(validation != "") {
				form.txtSupplierEndpoint.style.backgroundColor="yellow";
				form.txtSupplierNewEndpoint.style.backgroundColor="yellow";
//				return validation;
			} else {
				form.txtSupplierEndpoint.style.backgroundColor="white";
				form.txtSupplierNewEndpoint.style.backgroundColor="white";
				supplierNumericCode = supplierEndpoint.split(":")[0];
				supplierEndpoint = supplierEndpoint.split(":")[1];
			}
		}
	}

	var receiverEndpoint = "";
	var receiverNumericCode = "";
	var receiverName = "";
	if(form.txtReceiverNewName){
		if(form.receiverRadios[0].checked){
			receiverEndpoint = form.txtReceiverEndpoint.value;
			if(form.cboReceiverName.selectedIndex > 0) {
				receiverName = form.cboReceiverName.options[form.cboReceiverName.selectedIndex].text;
			}
		}
		else if(form.receiverRadios[1].checked){
			receiverEndpoint = form.txtReceiverNewEndpoint.value;
			receiverName = form.txtReceiverNewName.value;
		}
		receiverEndpoint = trim(receiverEndpoint);
		if(receiverEndpoint != "" || (askForReceiver && xmlDrop != "")) {
			validation = validateEndpoint("Receiver", receiverEndpoint);
			if(validation != "") {
				form.txtReceiverEndpoint.style.backgroundColor="yellow";
				form.txtReceiverNewEndpoint.style.backgroundColor="yellow";
//				return validation;
			} else {
				form.txtReceiverEndpoint.style.backgroundColor="white";
				form.txtReceiverNewEndpoint.style.backgroundColor="white";
				receiverNumericCode = receiverEndpoint.split(":")[0];
				receiverEndpoint = receiverEndpoint.split(":")[1];
			}
		}
	}


	var providerEndpoint = "";
	var providerNumericCode = "";
	var providerName = "";
	if(form.txtProviderNewName){
		if(form.providerRadios[0].checked){
			providerEndpoint = form.txtProviderEndpoint.value;
			if(form.cboProviderName.selectedIndex > 0) {
				providerName = form.cboProviderName.options[form.cboProviderName.selectedIndex].text;
			}
		}
		else if(form.providerRadios[1].checked){
			providerEndpoint = form.txtProviderNewEndpoint.value;
			providerName = form.txtProviderNewName.value;
		}
		providerEndpoint = trim(providerEndpoint);
		if(providerEndpoint != "" || (askForProvider && xmlDrop != "")) {
			validation = validateEndpoint("Provider", providerEndpoint);
			if(validation != "") {
				form.txtProviderEndpoint.style.backgroundColor="yellow";
				form.txtProviderNewEndpoint.style.backgroundColor="yellow";
//				return validation;
			} else {
				form.txtProviderEndpoint.style.backgroundColor="white";
				form.txtProviderNewEndpoint.style.backgroundColor="white";
				providerNumericCode = providerEndpoint.split(":")[0];
				providerEndpoint = providerEndpoint.split(":")[1];
			}
		}
	}

	
	result = createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
								customerEndpoint, customerNumericCode, customerName,
								supplierEndpoint, supplierNumericCode, supplierName,
								receiverEndpoint, receiverNumericCode, receiverName,
								providerEndpoint, providerNumericCode, providerName);


	
	return result;

}

function validateEndpoint(name, endpoint) {
	if(endpoint.split(":").length > 2 || endpoint.indexOf(":") == -1 || endpoint.split(":")[1] == "") {
		return 	"Wrong " + name + " Endpoint" +
				"\nFormat: \"####:#########\"";
	} else if(askIssuingAgency("schemeAgencyName", endpoint.split(":")[0]) == "") {
		return "Invalid " + name + " Numeric Code";
	} else {
		return "";
	}
}

function validateStructure(form, documentName, validationType){

	var result = saveDocument(form, documentName, form.xmlDraftAddress.value, "", validationType);
	

	openResult();
	
	if(lastRedText!=null) {
		document.getElementById(lastRedText).style.backgroundColor = "white";
	}

	var field = "txt" + result;

	if(result == "CatalogueLine" || result == "CatalogueRequestLine"){
		field = "txt" + result + "ID";
	}

	if(document.getElementById(field) != null) {
		lastRedText = field;
		document.getElementById(field).style.backgroundColor = "red";
		document.getElementById(field).focus();
	}

}

function saveToDraftFolder(form, documentName){

	if(document.getElementById("editLine") != null && form.editLine.value != ""){
		var result = validateFields(documentName);
		if(result != ""){
			alert(result);
			return;
		}
	}

	var result = validateAutoCompleteFields();
	if(result != ""){
	
		alert(result);
		return;
	}

	if(validateIfCustomerEndpointAlreadyExist(form) == false)
		alert("Customer Endpoint already exist in Contact List");
	else if(validateIfSupplierEndpointAlreadyExist(form) == false)
		alert("Supplier Endpoint already exist in Contact List");
	else if(validateIfReceiverEndpointAlreadyExist(form) == false)
		alert("Receiver Endpoint already exist in Contact List");
	else if(validateIfProviderEndpointAlreadyExist(form) == false)
		alert("Provider Endpoint already exist in Contact List");
	else{
	
		var result = saveDocument(form, documentName, form.xmlDraftAddress.value, "", "");
		if(result != null){
			alert(result);
		}
		else{
			var line = "";
			if(document.getElementById("editLine") != null)
				line = form.editLine.value;
			updateInterface(form.txtID.value, line);
			alert("Document Saved in Draft Folder");
		}
	}
}

function validateAutoCompleteFields() {
	var textElements = document.getElementsByTagName('input');
	 for ( var int = 0; int < textElements.length; int++) {
		 if(textElements[int].id != null){
			 if(textElements[int].id.indexOf('Currency') > -1 || textElements[int].id.indexOf('CountryIdentificationCode') > -1) {
				 if(textElements[int].style.color == "red" && textElements[int].value != "" ){
					 return "Autocomplete fields must be selected from the Code List";
				 }
			 }
		 }
	 }

	return "";
}

function validateFields(documentName){
	if(validateField("txtLineID")){
		return "The Line Id cannot be empty";
	}
//	else if(validateEndPointFields()){
//		return "The Party Identification Line cannot be empty";
//	} 
	return "";
}

function validateEndPointFields()
{
	if(validateField("txtCustomerEndpoint") && 
	   document.getElementById("txtCustomerNewEndpoint").style.display == "none"){
		return true;
	} 	if(validateField("txtCustomerNewEndpoint") && 
	    document.getElementById("txtCustomerEndpoint").style.display == "none"){
		return true;
	}
	
	return false;
}

function validateField(field){
	if(document.getElementById(field).value == ""){
		document.getElementById(field).select();
		document.getElementById(field).style.backgroundColor="yellow";
		return true;
	}else{
		document.getElementById(field).style.backgroundColor="white";
		return false;
	}
}

function pasteClassID() {
	   document.getElementById("txtClassID").focus();

	   document.getElementById("txtClassID").select();

	   CopiedTxt = document.selection.createRange();

	   CopiedTxt.execCommand("Paste");

	   activeLookUp();

}

function openEClassWebPage(){

	EClassWebPage();

}

function openCPVWebPage(){

	CPVWebPage();

}

function AddEClassCommodityCode()
{
	var eclassValue = document.getElementById("txtClassID").value;
	document.getElementById("txtRequestForTenderLineItemCommodityClassificationCommodityCode").value = "eCl@ss";
	document.getElementById("txtRequestForTenderLineItemCommodityClassificationItemClassificationCode").value = eclassValue;
	document.getElementById("AddCommodityClassificationCommodityCodeButton").click();
}

function AddCPVCommodityCode() {
	
	var cpvValue = document.getElementById("txtCPVClassID").value;
	document.getElementById("txtRequestForTenderLineItemCommodityClassificationCommodityCode").value = "CPV";
	document.getElementById("txtRequestForTenderLineItemCommodityClassificationItemClassificationCode").value = cpvValue;
	document.getElementById("AddCommodityClassificationCommodityCodeButton").click();
	
}


function RemoveCPVCommodityCode() {
	
	document.getElementById("RemoveCommodityClassificationCommodityCodeButton").click();
	
}


function activeLookUp(){

	var text = document.getElementById("txtClassID").value;
	text = trim(text);

	if(text != ""){
		document.getElementById("lookUpButton").disabled = false;
	} else {
		document.getElementById("lookUpButton").disabled = true;
	}

}

function requestWebService(form, documentName){

	eClassValues = 	EPPsWebService(documentName, form.txtClassID.value,
					"eClassValues");
	cenbiiValues = 	EPPsWebService(documentName, form.txtClassID.value,
					"cenbiiValues");
	unboundedValues = EPPsWebService(documentName, form.txtClassID.value,
					"unboundedValues");


	if(eClassValues[0].indexOf("eClass Fault") > -1) {
		alert(eClassValues[0].split(":")[1]);
	} else {
//		for (i=0; i < cenbiiValues.length; i++) {
//			cenbiiValue = cenbiiValues[i].split(":")[2];
//			cenbiiValue = getField(cenbiiValue);
//			document.getElementById(cenbiiValue).value = eClassValues[i].split("__")[0];
//			document.getElementById(cenbiiValue).className = "SubTittleBoldLetter";
//
//		}
//	
//		workWithUnboundedFields(unboundedValues, cenbiiValues, eClassValues);
	    
		 
		showInfoOnWebPage(eClassValues);
		AddEClassCommodityCode();
		
		alert("Fields filled by eCl@ass");
	}


	document.getElementById("txtClassID").focus();
}



function showInfoOnWebPage(eClassValues){
	
	var namesValues = new Array();
	namesValues = eClassValues[0].split("___");
	
	document.getElementById("txtRequestForTenderLineItemName").value = namesValues[0];
	document.getElementById("txtRequestForTenderLineItemName").className = "SubTittleBoldLetter";

	var propertiesValues = new Array();
	propertiesValues = eClassValues[1].split("___");
	
	var propertiesId = new Array();
	propertiesID = eClassValues[2].split("___");
	
	for(var i=0;i< propertiesValues.length-1; i++)
	{
		var propertyName = new Array();
		propertyName = propertiesValues[i].split("|||");
		
		var listValues = new  Array();
		listValues = propertyName[1].split("&&&");
		
		document.getElementById("txtRequestForTenderLineItemAdditionalItemPropertyName").value = propertyName[0];
		document.getElementById("txtRequestForTenderLineItemAdditionalItemPropertyID").value = i+1;

		for(var countList = 0; countList < listValues.length -1; countList++)
		{
			document.getElementById("txtRequestForTenderLineItemAdditionalItemPropertyListValue").value= listValues[countList];
			document.getElementById("ListValueButton").click();
		}
		
		document.getElementById("txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupID").value = propertiesID[i];
	    document.getElementById("ItemPropertyGroupButton").click();
	    
		document.getElementById("AdditionalItemPropertyButton").click();
		cleanTable("","ListValue");
		cleanTable("","ItemPropertyGroup");
	}
	
}

function workWithUnboundedFields(unboundedValues, cenbiiValues, eClassValues){

 
	for (i=0; i < unboundedValues.length; i++) {
		unboundedValue = unboundedValues[i].split(":")[0];
		fieldsCounter = 0;
		unboundedCounter = 0;
		for ( var int = 0; int < cenbiiValues.length; int++) {
			cenbiiValueId = cenbiiValues[int].split(":")[0];
			if(cenbiiValueId == unboundedValue) {
				fieldsCounter++;
				if(eClassValues[int].split("___")[0] != "") {
					unboundedCounter = eClassValues[int].split("___").length - 1;

				}
			}
		}

		for ( var int2 = 0; int2 < unboundedCounter; int2++) {
			fields = new Array(fieldsCounter);
			counter = 0;
			for ( var int = 0; int < cenbiiValues.length; int++) {
				cenbiiValueId = cenbiiValues[int].split(":")[0];
				
				if(cenbiiValueId == unboundedValue) {
					
					fields[counter] = eClassValues[int].split("___")[int2];

					cenbiiValue = cenbiiValues[int].split(":")[2];
					cenbiiValue = getField(cenbiiValue);
					// fields : Name of Property
					// cenbiiValue : txt + <cenbii>
					for ( var int3 = 0; int3 < fields[counter].split("__").length; int3++) {
						var value = fields[counter].split("__")[int3];
						document.getElementById(cenbiiValue).value = value;

						document.getElementById(getField(unboundedValues[i].split(":")[1])).value = int2 + 1;

						unboundedField = cenbiiValues[int].split(":")[1];

					if(unboundedField != "") {
						
							document.getElementById(unboundedField + "Button").click();
						}
					}

					counter++;
				}
			}


			document.getElementById(unboundedValue + "Button").click();

			for ( var int = 0; int < cenbiiValues.length; int++) {
				cenbiiValueId = cenbiiValues[int].split(":")[0];
				if(cenbiiValueId == unboundedValue) {
					unboundedField = cenbiiValues[int].split(":")[1];
					if(unboundedField != "" && int2 < unboundedCounter-1) {
						cleanTable(unboundedField + "LastId", unboundedField);
					}

				}
			}


		}

	}

}

function saveToDropFolder(form, documentName){

	if(document.getElementById("editLine") != null){
		if(form.editLine.value != ""){
			var result = validateFields(documentName);
			if(result != ""){
				alert(result);
				return;
			}
		}
	}

	/*if(validateIfIsMissingParticipants(form) == false)
		alert("Missing names and endpoints of the main participants");
	else{*/
		if(validateIfCustomerEndpointAlreadyExist(form) == false)
			alert("Customer Endpoint already exist in Contact List");
		else if(validateIfSupplierEndpointAlreadyExist(form) == false)
			alert("Supplier Endpoint already exist in Contact List");
		else if(validateIfReceiverEndpointAlreadyExist(form) == false)
			alert("Receiver Endpoint already exist in Contact List");
		else if(validateIfProviderEndpointAlreadyExist(form) == false)
			alert("Provider Endpoint already exist in Contact List");
		else{
			var result = saveDocument(form, documentName, form.xmlDraftAddress.value, form.xmlDropAddress.value, "");
			if(result != null){
				alert(result);
			}
			else{
				deleteDocument(form.xmlDraftAddress.value);
				updateInterface("", "");
				alert("Document saved in 'Pending' folder");
			}
		}
	//}

}

function deleteDocument(file){

	deleteDraftDocument(file);

}

function deleteFromDemoRepository(form){

	if(confirm("Are you sure to delete this file?")){
		deleteDocument(form.xmlDraftAddress.value);
		updateInterface("", "");
	}

}

var askForSupplier = false;
var askForCustomer = false;
var askForProvider = false;
var askForReceiver = false;

/*function validateIfIsMissingParticipants(form){

	if(form.txtSupplierEndpoint && askForSupplier){
		if(form.supplierRadios[1].checked){
			if(	form.txtSupplierNewName.value == "" ||
				form.txtSupplierNewEndpoint.value == "")
				return false;
		}
		else{
			if(form.txtSupplierEndpoint.value == "")
				return false;
		}
	}

	if(form.txtCustomerEndpoint && askForCustomer){
		if(form.customerRadios[1].checked){
			if(	form.txtCustomerNewName.value == "" ||
				form.txtCustomerNewEndpoint.value == "" )
				return false;
		}
		else{
			if(form.txtCustomerEndpoint.value == "")
				return false;
		}
	}

	if(form.txtProviderEndpoint && askForProvider){
		if(form.providerRadios[1].checked){
			if(	form.txtProviderNewName.value == "" ||
				form.txtProviderNewEndpoint.value == "" )
				return false;
		}
		else{
			if(form.txtProviderEndpoint.value == "")
				return false;
		}
	}

	if(form.txtReceiverEndpoint && askForReceiver){
		if(form.receiverRadios[1].checked){
			if(	form.txtReceiverNewName.value == "" ||
				form.txtReceiverNewEndpoint.value == "" )
				return false;
		}
		else{
			if(form.txtReceiverEndpoint.value == "")
				return false;
		}
	}

	return true;
}*/

function showEndpoint(form){

	if(form.txtSupplierEndpoint){
		form.txtSupplierEndpoint.value = form.cboSupplierName.options[form.cboSupplierName.selectedIndex].value;
	}if(form.txtCustomerEndpoint){
		form.txtCustomerEndpoint.value = form.cboCustomerName.options[form.cboCustomerName.selectedIndex].value;
	}if(form.txtProviderEndpoint){
		form.txtProviderEndpoint.value = form.cboProviderName.options[form.cboProviderName.selectedIndex].value;
	}if(form.txtReceiverEndpoint){
		form.txtReceiverEndpoint.value = form.cboReceiverName.options[form.cboReceiverName.selectedIndex].value;
	}
}

function validateIfReceiverEndpointAlreadyExist(form){

	var validated = true;

	if(form.txtReceiverEndpoint){
		if(form.receiverRadios[1].checked){
			var newEndpoint = form.txtReceiverNewEndpoint.value
			for(var i=1 ; i < form.cboReceiverName.length; i++){
				var endpoint = form.cboReceiverName.options[i].value;
				if(endpoint != "" && endpoint == newEndpoint)
					validated = false;
			}
		}
	}

	return validated;

}

function validateIfProviderEndpointAlreadyExist(form){

	var validated = true;

	if(form.txtProviderEndpoint) {
		if(form.providerRadios[1].checked){
			var newEndpoint = form.txtProviderNewEndpoint.value
			for(var i=1 ; i < form.cboProviderName.length; i++){
				var endpoint = form.cboProviderName.options[i].value;
				if(endpoint != "" && endpoint == newEndpoint)
					validated = false;
			}
		}
	}

	return validated;

}

function validateIfSupplierEndpointAlreadyExist(form){

	var validated = true;

	if(form.txtSupplierEndpoint) {
		if(form.supplierRadios[1].checked){
			var newEndpoint = form.txtSupplierNewEndpoint.value
			for(var i=1 ; i < form.cboSupplierName.length; i++){
				var endpoint = form.cboSupplierName.options[i].value;
				if(endpoint != "" && endpoint == newEndpoint)
					validated = false;
			}
		}
	}

	return validated;

}

function validateIfCustomerEndpointAlreadyExist(form){

	var validated = true;

	if(form.txtCustomerEndpoint) {
		if(form.customerRadios[1].checked){
			var newEndpoint = form.txtCustomerNewEndpoint.value
			for(var i=1 ; i < form.cboCustomerName.length; i++){
				var endpoint = form.cboCustomerName.options[i].value;
				if(endpoint != "" && endpoint == newEndpoint)
					validated = false;
			}
		}
	}

	return validated;

}

var Browser = {
		Version: function() {
			var version = 999; // we assume a sane browser
			if (navigator.appVersion.indexOf("MSIE") != -1)      // bah, IE again, lets downgrade version number
				version = parseFloat(navigator.appVersion.split("MSIE")[1]);
			return version;
	}
}

function background(){

	document.getElementById("img").style.height = document.getElementById("div").style.height;

}

function chargeCalendar(formName, inputTestName){
	new tcal ({
		// form name
		'formname': formName,
		// input name
		'controlname': inputTestName
	});
}

function chargeInformation(form, type){

	form.txtProfileID.value = form.profileID.value;

	if(form.documentID.value != "") {
		form.txtID.value = form.documentID.value;
	}

	form.txtCustomizationID.value = form.customizationID.value;

	if(form.referencedContractID.value != "") {
		setReferencedContractID(form);
	}

	if(form.isDraftDocument.value == "true"){
		form.deleteButton.style.display = "";
	} else if(form.isDraftDocument.value == "false"){
		form.deleteButton.style.display = "none";
	}

	var customer = false;
	var supplier = false;
	var provider = false;
	var receiver = false;

	var customerEndpoint;
	var customerName;
	var supplierEndpoint;
	var supplierName;

	var receiverEndpoint;
	var receiverName;
	var providerEndpoint;
	var providerName;

	if (form.txtCustomerNewName){
		schemeID = form.txtCustomerEndpointSchemeID.value;
		numericCode = askIssuingAgency("numericCode", schemeID);
		if(numericCode != "") {
			form.txtCustomerNewEndpoint.value = numericCode + ":" + form.txtCustomerNewEndpoint.value;
		}
		customerEndpoint = form.txtCustomerNewEndpoint.value;
		customerName = form.txtCustomerNewName.value;
	}
	if (form.txtSupplierNewName){
		schemeID = form.txtSupplierEndpointSchemeID.value;
		numericCode = askIssuingAgency("numericCode", schemeID);
		if(numericCode != "") {
			form.txtSupplierNewEndpoint.value = numericCode + ":" + form.txtSupplierNewEndpoint.value;
		}
		supplierEndpoint = form.txtSupplierNewEndpoint.value;
		supplierName = form.txtSupplierNewName.value;
	}
	if (form.txtReceiverNewName){
		schemeID = form.txtReceiverEndpointSchemeID.value;
		numericCode = askIssuingAgency("numericCode", schemeID);
		if(numericCode != "") {
			form.txtReceiverNewEndpoint.value = numericCode + ":" + form.txtReceiverNewEndpoint.value;
		}
		receiverEndpoint = form.txtReceiverNewEndpoint.value;
		receiverName = form.txtReceiverNewName.value;
	}
	if (form.txtProviderNewName){
		schemeID = form.txtProviderEndpointSchemeID.value;
		numericCode = askIssuingAgency("numericCode", schemeID);
		if(numericCode != "") {
			form.txtProviderNewEndpoint.value = numericCode + ":" + form.txtProviderNewEndpoint.value;
		}
		providerEndpoint = form.txtProviderNewEndpoint.value;
		providerName = form.txtProviderNewName.value;
	}

	if(form.isDraftDocument.value == "false") {

		if (form.txtSupplierNewName && form.txtSupplierNewName.value == "" && askForSupplier){
			supplierEndpoint = getSupplierEndpoint(form);
			supplierName = getSupplierName(form);
		}
		if (form.txtProviderNewName && form.txtProviderNewName.value == "" && askForProvider){
			providerEndpoint = getProviderEndpoint(form);
			providerName = getProviderName(form);
		}
		if (form.txtCustomerNewName && form.txtCustomerNewName.value == "" && askForCustomer){
			customerEndpoint = getCustomerEndpoint(form);
			customerName = getCustomerName(form);
		}
		if (form.txtReceiverNewName && form.txtReceiverNewName.value == "" && askForReceiver){
			receiverEndpoint = getReceiverEndpoint(form);
			receiverName = getReceiverName(form);
		}

	}

	if (form.txtCustomerNewName){
		for(var i=1 ; i < form.cboCustomerName.length; i++){
			var endpoint = form.cboCustomerName.options[i].value;

			if(endpoint == customerEndpoint){
				form.cboCustomerName.options[i].selected = true;
				form.txtCustomerEndpoint.value = customerEndpoint;
				customer = true;
				form.txtCustomerNewEndpoint.value = "";
				form.txtCustomerNewName.value = "";
			}
		}
	}

	if (form.txtSupplierNewName){
		for(var i=1 ; i < form.cboSupplierName.length; i++){
			var endpoint = form.cboSupplierName.options[i].value;
			if(endpoint == supplierEndpoint){
				form.cboSupplierName.options[i].selected = true;
				form.txtSupplierEndpoint.value = supplierEndpoint;
				supplier = true;
				form.txtSupplierNewEndpoint.value = "";
				form.txtSupplierNewName.value = "";
			}
		}
	}

	if (form.txtReceiverNewName){
		for(var i=1 ; i < form.cboReceiverName.length; i++){
			var endpoint = form.cboReceiverName.options[i].value;
			if(endpoint == receiverEndpoint){
				form.cboReceiverName.options[i].selected = true;
				form.txtReceiverEndpoint.value = receiverEndpoint;
				receiver = true;
				form.txtReceiverNewEndpoint.value = "";
				form.txtReceiverNewName.value = "";
			}
		}
	}

	if (form.txtProviderNewName){
		for(var i=1 ; i < form.cboProviderName.length; i++){
			var endpoint = form.cboProviderName.options[i].value;
			if(endpoint == providerEndpoint){
				form.cboProviderName.options[i].selected = true;
				form.txtProviderEndpoint.value = providerEndpoint;
				provider = true;
				form.txtProviderNewEndpoint.value = "";
				form.txtProviderNewName.value = "";
			}
		}
	}

	if (form.txtCustomerNewName){
		if(customer == false){
			if(askForCustomer) {
				form.txtCustomerEndpoint.value = "";
				form.txtCustomerNewEndpoint.value = customerEndpoint;
				form.txtCustomerNewName.value = customerName;
			}

			if(customerEndpoint != ""){
				form.customerRadios[1].checked = true;
				activateCustomer(form, "newContact");
			}
		}
	}

	if (form.txtSupplierNewName){
		if(supplier == false){
			if(askForSupplier) {
				form.txtSupplierEndpoint.value = "";
				form.txtSupplierNewEndpoint.value = supplierEndpoint;
				form.txtSupplierNewName.value = supplierName;
			}

			if(supplierEndpoint != ""){
				form.supplierRadios[1].checked = true;
				activateSupplier(form, "newContact");
			}
		}
	}

	if (form.txtReceiverNewName){
		if(receiver == false){
			if(askForReceiver) {
				form.txtReceiverEndpoint.value = "";
				form.txtReceiverNewEndpoint.value = receiverEndpoint;
				form.txtReceiverNewName.value = receiverName;
			}
			if(receiverEndpoint != ""){
				form.receiverRadios[1].checked = true;
				activateReceiver(form, "newContact");
			}
		}
	}

	if (form.txtProviderNewName){
		if(provider == false){
			if(askForProvider) {
				form.txtProviderEndpoint.value = "";
				form.txtProviderNewEndpoint.value = providerEndpoint;
				form.txtProviderNewName.value = providerName;
			}

			if(providerEndpoint != ""){
				form.providerRadios[1].checked = true;
				activateProvider(form, "newContact");
			}
		}
	}
}

function activateCustomer(form, type){

	if (type == "readContactsList"){
		form.cboCustomerName.style.display = "";
		form.txtCustomerEndpoint.style.display = "";
		form.txtCustomerNewName.style.display = "none";
		form.txtCustomerNewEndpoint.style.display = "none";
	}
	else if (type == "newContact"){
		form.cboCustomerName.style.display = "none";
		form.txtCustomerEndpoint.style.display = "none";
		form.txtCustomerNewName.style.display = "";
		form.txtCustomerNewEndpoint.style.display = "";
		resetCustomerValues(form);
	}

}


function resetCustomerValues(form)
{
	form.txtCustomerEndpointSchemeID.value = "";
	form.txtCustomerNewEndpoint.value = "";
	form.txtCustomerNewName.value = "";
	form.txtCustomerPartyPartyPostalAddressID.value = "";
	form.txtCustomerPartyPartyPostalAddressPostbox.value = "";
	form.txtCustomerPartyPartyPostalAddressStreetName.value = "";
	form.txtCustomerPartyPartyPostalAddressAdditionalStreetName.value = "";
	form.txtCustomerPartyPartyPostalAddressBuildingNumber.value = "";
	form.txtCustomerPartyPartyPostalAddressCityName.value = "";
	form.txtCustomerPartyPartyPostalAddressPostalZone.value = "";
	form.txtCustomerPartyPartyPostalAddressCountrySubentity.value = "";
	form.txtCustomerPartyPartyPostalAddressCountryIdentificationCode.value = "";
	form.txtCustomerPartyPartyPartyTaxSchemeCompanyID.value = "";
	form.txtCustomerPartyPartyPartyTaxSchemeTaxSchemeID.value = "";
	form.txtCustomerPartyPartyPartyLegalEntityCompanyID.value = "";
	form.txtCustomerPartyPartyContactTelephone.value = "";
	form.txtCustomerPartyPartyContactTelefax.value = "";
	form.txtCustomerPartyPartyContactElectronicMail.value = "";
	form.txtCustomerPartyPartyPersonFirstName.value = "";
	form.txtCustomerPartyPartyPersonFamilyName.value = "";
	form.txtCustomerPartyPartyPersonMiddleName.value = "";
	form.txtCustomerPartyPartyPersonJobTitle.value = "";
}

function activateReceiver(form, type){

	if (type == "readContactsList"){
		form.cboReceiverName.style.display = "";
		form.txtReceiverEndpoint.style.display = "";
		form.txtReceiverNewName.style.display = "none";
		form.txtReceiverNewEndpoint.style.display = "none";
	}
	else if (type == "newContact"){
		form.cboReceiverName.style.display = "none";
		form.txtReceiverEndpoint.style.display = "none";
		form.txtReceiverNewName.style.display = "";
		form.txtReceiverNewEndpoint.style.display = "";
	}

}

function activateProvider(form, type){

	if (type == "readContactsList"){
		form.cboProviderName.style.display = "";
		form.txtProviderEndpoint.style.display = "";
		form.txtProviderNewName.style.display = "none";
		form.txtProviderNewEndpoint.style.display = "none";
	}
	else if (type == "newContact"){
		form.cboProviderName.style.display = "none";
		form.txtProviderEndpoint.style.display = "none";
		form.txtProviderNewName.style.display = "";
		form.txtProviderNewEndpoint.style.display = "";
	}

}

function activateSupplier(form, type){

	if (type == "readContactsList"){
		form.cboSupplierName.style.display = "";
		form.txtSupplierEndpoint.style.display = "";
		form.txtSupplierNewName.style.display = "none";
		form.txtSupplierNewEndpoint.style.display = "none";
	}
	else if (type == "newContact"){
		form.cboSupplierName.style.display = "none";
		form.txtSupplierEndpoint.style.display = "none";
		form.txtSupplierNewName.style.display = "";
		form.txtSupplierNewEndpoint.style.display = "";
	}

}

function editRow(tableID, arrayString, identifier){

	for (var i = 0; i < arrayString.length; i++){
		document.getElementById(arrayString[i]).value = document.getElementById(tableID + identifier + arrayString[i]).value;
	}

	argument = 3;

	while (arguments[argument] != null) {

		unboundedOfUnbounded = arguments[argument];

		var table = document.getElementById(unboundedOfUnbounded[0]);
		var rowCount = table.rows.length;

		while(table.rows.length > 2) {
			table.deleteRow(2);
		}

		var position = 2;

		var lastID = document.getElementById(unboundedOfUnbounded[0] + "LastId").value;

		for ( var i = 1; i <= lastID; i++) {
			if (document.getElementById(tableID + identifier + unboundedOfUnbounded[0]  + i + unboundedOfUnbounded[1])) {

				var row = table.insertRow(position);

				var cell1 = row.insertCell(0);
				var element1 = document.createElement("input");
				element1.type = "checkbox";
				cell1.appendChild(element1);

				var cell2 = row.insertCell(1);
				var element2 = document.createElement("input");
				element2.type = "button";
				var id = unboundedOfUnbounded[0] + "___";
				for ( var int = 1; int < unboundedOfUnbounded.length; int++) {
					if(int > 1) {
						id += "__";
					}
					id += unboundedOfUnbounded[int];
				}
				id += "___" + i;
				element2.id = id;
				var id = i * 1;
				element2.onclick = function(){
					var text = this.id.split("___");

					var tName = text[0];
					var tUnboundeds = text[1].split("__");
					var tID = text[text.length - 1];

					editRow(tName, tUnboundeds, tID);
				}
				cell2.appendChild(element2);
				for ( var k = 1; k < unboundedOfUnbounded.length; k++) {
					var text = document.getElementById(tableID + identifier + unboundedOfUnbounded[0]  + i + unboundedOfUnbounded[k]);
					var element = document.createElement("input");
					element.name = unboundedOfUnbounded[0]  + i + unboundedOfUnbounded[k];
					element.id = unboundedOfUnbounded[0]  + i + unboundedOfUnbounded[k];
					//element.size = "2";
					element.type = "hidden";
					element.value = text.value;
					cell1.appendChild(element);

					var cell = row.insertCell(k + 1);
					cell.innerHTML = text.value;
					cell.className = "normalLetter";
				}
				position++;

			}
		}

		argument++;
	}
}

function trim(stringToTrim) {
	return stringToTrim.replace(/^\s+|\s+$/g,"");
}

function addRow(tableID, arrayString, arrayTDs, id, idPosition) {

	var result = validateAutoCompleteFields();
	if(result != ""){
		alert(result);
		return;
	}

	if(trim(document.getElementById(id).value) == ""){
		document.getElementById(id).select();
		document.getElementById(id).value = "";
		document.getElementById(id).style.backgroundColor="yellow";
		return;
	}
	else{
		document.getElementById(id).value = trim(document.getElementById(id).value);
		document.getElementById(id).style.backgroundColor="white";
	}

	var table = document.getElementById(tableID);

	var rowCount = table.rows.length;

	var position = rowCount;

	for (i = 1; i < table.rows.length; i++) {
		var searchRow = table.rows[i];
		if(searchRow.cells[idPosition] != null) {
			if(searchRow.cells[idPosition].innerHTML == document.getElementById(id).value){
				table.deleteRow(i);
				position = i;
			}
		}
	}

	var row = table.insertRow(position);

	var lastId = parseInt(document.getElementById(tableID + "LastId").value) + 1;
	document.getElementById(tableID + "LastId").value = lastId;

	var cell1 = row.insertCell(0);
	var element1 = document.createElement("input");
	element1.type = "checkbox";
	cell1.appendChild(element1);

	var cell2 = row.insertCell(1);
	var element2 = document.createElement("input");
	element2.type = "button";
	var argument5 = arguments[5];
	var argument6 = arguments[6];
	element2.onclick = function(){
		editRow(tableID, arrayString, lastId, argument5, argument6);
	}
	cell2.appendChild(element2);

	for (var i = 0; i < arrayString.length; i++){
		var element = document.createElement("input");
		element.name = tableID + lastId + arrayString[i];
		element.id = tableID + lastId + arrayString[i];
		element.type = "hidden";
		element.value = document.getElementById(arrayString[i]).value;
		cell1.appendChild(element);
	}

	argument = 5;

	while (arguments[argument] != null) {

		unboundedOfUnbounded = arguments[argument];

		var lastID = document.getElementById(unboundedOfUnbounded[0] + "LastId").value;

		for ( var i = 1; i <= lastID; i++) {
			if (document.getElementById(unboundedOfUnbounded[0]  + i + unboundedOfUnbounded[1])) {
				for ( var int = 1; int < unboundedOfUnbounded.length; int++) {
					var text = document.getElementById(unboundedOfUnbounded[0]  + i + unboundedOfUnbounded[int]);
					var element = document.createElement("input");
					element.name = tableID + lastId + text.name;
					element.id = tableID + lastId + text.id;
					//element.size = "2";
					element.type = "hidden";
					element.value = text.value;
					cell1.appendChild(element);
				}
			}
		}

		argument++;
	}

	for (var i = 0; i < arrayTDs.length; i++){

		var cell = row.insertCell(i + 2);
		for (var j = 0; j < arrayString.length; j++){
			if(arrayTDs[i] == j){
				cell.innerHTML = document.getElementById(arrayString[j]).value;
				cell.className = "normalLetter";
			}
		}
	}

	document.getElementById(id).select();
}

function deleteRow(tableID) {
	try {
	var table = document.getElementById(tableID);
	var rowCount = table.rows.length;

	for(var i=0; i<rowCount; i++) {
		var row = table.rows[i];
		var chkbox = row.cells[0].childNodes[0];
		if(null != chkbox && true == chkbox.checked) {
			table.deleteRow(i);
			rowCount--;
			i--;
		}

	}
	}catch(e) {
		alert(e);
	}
}

function hideCatalogueLine(){

	var elem = document.getElementById("linesTable");
	elem.style.display="none";

}

function showCatalogueLine(){

	var elem = document.getElementById("linesTable");
	elem.style.display="";
	document.getElementById("txtLineID").disabled = true;

}

function hideLine(form, documentName){
	cleanForm(form, documentName, 0);
	form.editLine.value = "";
	document.getElementById("title").innerHTML = "";
	hideCatalogueLine();
}

function newLine(form, documentName){
	showCatalogueLine();
	document.getElementById("txtLineID").disabled = false;
	cleanForm(form, documentName, 0);
	form.editLine.value = 0;
	document.getElementById("title").innerHTML = "New Line";
	
	/* copy the validity dates from details tab to catalogue line */
	var startDate=document.getElementById("txtValidityPeriodStartDate");
	var endDate=document.getElementById("txtValidityPeriodEndDate");
	
	var startDateLine=document.getElementById("txtCatalogueLineLineValidityPeriodStartDate");
	var endDateLine=document.getElementById("txtCatalogueLineLineValidityPeriodEndDate");

	if(eval(startDateLine)) {
		if(eval(startDate))
			startDateLine.value=startDate.value
	}
	
	
	if(eval(endDateLine)) {
		if(eval(endDate))
			endDateLine.value=endDate.value
	}
	
}

function askEditLine(form, id){
	editLine(form.xmlDraftAddress.value, "" + id, arguments[2]);

}

function askDeleteLine(form, id, documentName){

	if(confirm("Are you sure to delete this line?")){
		deleteLine(form.xmlDraftAddress.value, form.xmlBasedAddress.value, "" + id, documentName);
	}

}

function getField(cenbiiValue){
	nodes = cenbiiValue.split('.');
	cenbiiValue = "";
	for ( j = 0; j < nodes.length; j++) {
		cenbiiValue += nodes[j];
	}
	return "txt" + cenbiiValue;
}

function cleanForm(form, documentName, editLine){
	if (editLine == "0"){
		form.txtLineID.value = "";
		cleanTables();
	}
}

function cleanTable(lastIdName, tableName){
	//document.getElementById(lastIdName).value = "0";
	var table = document.getElementById(tableName);
	var rowCount = table.rows.length;
	for(var i = 2; i < rowCount; i++) {
			table.deleteRow(i);
			rowCount--;
			i--;
	}
}

function chargeOrderableIndicator(form) {
	if(form.catalogueLineOrderableIndicator.value == "true")
		form.cboCatalogueLineOrderableIndicator.selectedIndex = 0;
	if(form.catalogueLineOrderableIndicator.value == "false")
		form.cboCatalogueLineOrderableIndicator.selectedIndex = 1;
}

var higherPrice;
var smallerPrice

function cleanPrices(){
	higherPrice = 0;
	smallerPrice = 0;
}

function keepSmallerAndHigherPrice(price){
	if(price >= higherPrice || higherPrice == 0)
		higherPrice = price;
	if(price <= smallerPrice || smallerPrice == 0)
		smallerPrice = price;
}

function showPrice(form, id){
	var text = "";
	if(smallerPrice > 0 && smallerPrice < higherPrice)
		text = smallerPrice + " - ";
	if(higherPrice > 0)
		text += higherPrice;

	if(text == "")
		text = "no price added"

	document.getElementById("prices" + id).innerHTML = text;
}

function catalogueLineDefaultVisibility(form, documentName) {

	 if(form.editLine.value == "" || form.editLine.value == "0") {
		 hideLine(form, documentName);//hideCatalogueLine();
	 }
	 else {
		 showCatalogueLine();
	 }

	 var divElements = document.getElementsByTagName('div');

	 for ( var int = 0; int < divElements.length; int++) {
		 if(divElements[int].id != null){
			 if(divElements[int].id.indexOf('Div') > -1) {
				 divElements[int].style.display = "none";
			 }
		 }
	 }
}

function showForm(name) {
	if(document.getElementById(name).style.display == ""){
		document.getElementById(name).style.display = "none";
		document.getElementById(name + "Button").src = "img/arrow_down.png";
	}else{
		document.getElementById(name).style.display = "";
		document.getElementById(name + "Button").src = "img/arrow_up.png";
	}
}

function calculateAmount(form, price, amount){

	var basePrice = 0;

	var txtBasePrice = document.getElementById(price);
	var txtAmount = document.getElementById(amount);

	if (txtBasePrice.value != "")
		basePrice = parseFloat(txtBasePrice.value);

	if(basePrice >= 0){
		var tax = basePrice * 0.25;
		var amount = basePrice + tax;
		txtAmount.value = amount;
	}
	else{
		alert("The base price must be a number");
		txtBasePrice.value = "";
	}

	txtBasePrice.focus();

}

function upper(ustr)
{
	var str=ustr.value;
	ustr.value=str.toUpperCase();
}

function numbersonly(e, decimal) {

	var key;
	var keychar;

	if (window.event)
   		key = window.event.keyCode;
	else if (e)
   		key = e.which;
	else
   		return true;

	keychar = String.fromCharCode(key);

	if ((key==null) || (key==0) || (key==8) ||  (key==9) || (key==13) || (key==27) )
   		return true;
	else if ((("0123456789").indexOf(keychar) > -1))
   		return true;
	else if (decimal && (keychar == "."))
  		return true;
	else
 	  	return false;

}
	
	function loadActionCode(form) {
		if(form.txtCatalogueLineActionCode.value == "add")
			form.cboCatalogueLineActionCode.selectedIndex = 0;
		if(form.txtCatalogueLineActionCode.value == "update")
			form.cboCatalogueLineActionCode.selectedIndex = 1;
		if(form.txtCatalogueLineActionCode.value == "delete")
			form.cboCatalogueLineActionCode.selectedIndex = 2;
	}
	
function changeActionCode(form) {
		
		if(form.cboCatalogueLineActionCode.selectedIndex == 0)
			form.txtCatalogueLineActionCode.value = "add";
		if(form.cboCatalogueLineActionCode.selectedIndex == 1)
			form.txtCatalogueLineActionCode.value = "update";
		if(form.cboCatalogueLineActionCode.selectedIndex == 2)
			form.txtCatalogueLineActionCode.value = "delete";
		
	}

function checkEndDate(form,endDate,startDate) {

	var start = tcalParseDate(startDate.value);
	var end = tcalParseDate(endDate.value);

	if (end < start) {alert ("EndDate should be later than Start date"); return false}
	
}


function tcalParseDate (s_date) {

var re_date = /^\s*(\d{2,4})\-(\d{1,2})\-(\d{1,2})\s*$/;

if (!re_date.exec(s_date)){
	this.e_input.value = "";
	document.getElementById(this.e_input.id).focus();
	return alert ("Invalid date: '" + s_date + "'.\nAccepted format is yyyy-mm-dd.")
}
var n_day = Number(RegExp.$3),
	n_month = Number(RegExp.$2),
	n_year = Number(RegExp.$1);

if (n_year < 100)
	n_year += (n_year < this.a_tpl.centyear ? 2000 : 1900);
if (n_month < 1 || n_month > 12)
	return alert ("Invalid month value: '" + n_month + "'.\nAllowed range is 01-12.");
var d_numdays = new Date(n_year, n_month, 0);
if (n_day > d_numdays.getDate())
	return alert("Invalid day of month value: '" + n_day + "'.\nAllowed range for selected month is 01 - " + d_numdays.getDate() + ".");

return new Date (n_year, n_month - 1, n_day);
}	
