function changeImage(code, imageName) {
	var currentImageAddres = document.getElementById("layerImage" + code).src;
	if(currentImageAddres.indexOf("img/Error.png") == -1)  {
		document.getElementById("layerImage" + code).src = "img/" + imageName + ".png";
	}
}

function updateStatusBar() {

	var fails = 0;
	var total = 0;
	var images = document.getElementsByTagName('img');

	for ( var int = 0; int < images.length; int++) {
		if(images[int].id != null){
			if(images[int].id.indexOf('layerImage') > -1) {
				total++;
			}
			if(images[int].src.indexOf('img/Error.png') > -1) {
				fails++;
			}
		}
	}

	var failed = fails * 100 / total;

	failed = failed.toFixed(2);
	var el = document.getElementsByTagName("td");

		for(var i = 0; i < el.length; i++){

			el[i].align = "center";

			if(el[i].id == "td1") {
				el[i].style.backgroundColor = "#000066";
				el[i].style.width = (100 - failed) + "%";
				el[i].className = "Style5";
				var success = 100 - failed;
				if(success > 10){
					el[i].innerHTML = success + "% success";
				}
			}
			else if (el[i].id == "td2"){
				el[i].style.width = failed + "%";
				el[i].className = "Style6";
				if(failed > 10){
					el[i].innerHTML = failed + "% failed";
				}
			}
		}
	}