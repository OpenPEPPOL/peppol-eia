function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {
	alert("submitCounterOffer");
	supplierSchemeAgencyName = askIssuingAgency("schemeAgencyName", supplierNumericCode);
	supplierSchemeID = askIssuingAgency("schemeID", supplierNumericCode);
	supplierSchemeURI = askIssuingAgency("schemeURI", supplierNumericCode);

	customerSchemeAgencyName = askIssuingAgency("schemeAgencyName", customerNumericCode);
	customerSchemeID = askIssuingAgency("schemeID", customerNumericCode);
	customerSchemeURI = askIssuingAgency("schemeURI", customerNumericCode);

	return createNewDocument( form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
						validationType,
						"",

						form.txtUBLVersionID.value,
						form.txtCustomizationID.value,
						defaultCustomizationSchemeID,
						form.txtProfileID.value,
						form.txtID.value,
						form.txtIssueDate.value,
						form.txtSequenceNumber.value,
						keyWord + "-3",
						form.txtOrderReferenceID.value,
						form.txtQuotationDocumentReferenceID.value,
						keyWord + "-4",
						form.txtContractID.value,
						keyWord + "-1",

						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerName,
						keyWord + "-7",

						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierName,
						keyWord + "-7",

						keyWord + "-6",

						keyWord + "-48",
						form.txtAnticipatedMonetaryTotalPayableAmount.value,
						keyWord + "-111",
						form.txtOrderLineLineItemPricePriceAmount.value,
						keyWord + "-1",
						form.txtOrderLineLineItemItemName.value,
						keyWord + "-115",
						form.txtOrderLineSellerProposedSubstituteLineItemPricePriceAmount.value,
						keyWord + "-1",
						form.txtOrderLineSellerProposedSubstituteLineItemItemName.value,
						keyWord + "-4");

}

function setReferencedContractID(form) {
	form.txtOrderReferenceID.value = form.referencedContractID.value;
}

function getSupplierEndpoint(form) {
	return form.currentId.value;
}

function getSupplierName(form) {
	return form.currentName.value;
}

function getCustomerEndpoint(form) {
	return form.otherPartyId.value;
}

function getCustomerName(form) {
	return form.otherPartyName.value;
}