function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {

	alert("disputeInvoice");
	
	receiverSchemeAgencyName = askIssuingAgency("schemeAgencyName", receiverNumericCode);
	receiverSchemeID = askIssuingAgency("schemeID", receiverNumericCode);
	receiverSchemeURI = askIssuingAgency("schemeURI", receiverNumericCode);

	providerSchemeAgencyName = askIssuingAgency("schemeAgencyName", providerNumericCode);
	providerSchemeID = askIssuingAgency("schemeID", providerNumericCode);
	providerSchemeURI = askIssuingAgency("schemeURI", providerNumericCode);

	return createNewDocument( form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
						validationType,
						"",

						form.txtUBLVersionID.value,
						form.txtCustomizationID.value,
						defaultCustomizationSchemeID,
						form.txtProfileID.value,
						form.txtID.value,
						form.txtIssueDate.value,
						form.txtIssueTime.value,
						form.txtNote.value,

						providerEndpoint,
						providerSchemeAgencyName,
						providerSchemeID,
						providerSchemeURI,
						providerEndpoint,
						providerSchemeAgencyName,
						providerSchemeID,
						providerSchemeURI,
						providerName,

						receiverEndpoint,
						receiverSchemeAgencyName,
						receiverSchemeID,
						receiverSchemeURI,
						receiverEndpoint,
						receiverSchemeAgencyName,
						receiverSchemeID,
						receiverSchemeURI,
						receiverName,

						form.txtDocumentResponseResponseReferenceID.value,
						form.txtDocumentResponseResponseResponseCode.value,
						form.txtDocumentResponseResponseDescription.value,
						form.txtDocumentResponseDocumentReferenceID.value,
						form.txtDocumentResponseDocumentReferenceDocumentTypeCode.value);

}

function setReferencedContractID(form) {
	form.txtDocumentResponseDocumentReferenceID.value = form.referencedContractID.value;
}

function getReceiverEndpoint(form) {
	return form.otherPartyId.value;
}

function getReceiverName(form) {
	return form.otherPartyName.value;
}

function getProviderEndpoint(form) {
	return form.currentId.value;
}

function getProviderName(form) {
	return form.currentName.value;
}