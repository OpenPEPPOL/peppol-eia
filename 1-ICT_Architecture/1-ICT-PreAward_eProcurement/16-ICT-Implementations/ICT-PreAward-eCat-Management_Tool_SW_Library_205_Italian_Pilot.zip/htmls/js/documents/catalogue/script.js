function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {
		
	
	providerSchemeAgencyName = askIssuingAgency("schemeAgencyName", providerNumericCode);
	providerSchemeID = askIssuingAgency("schemeID", providerNumericCode);
	providerSchemeURI = askIssuingAgency("schemeURI", providerNumericCode);

	receiverSchemeAgencyName = askIssuingAgency("schemeAgencyName", receiverNumericCode);
	receiverSchemeID = askIssuingAgency("schemeID", receiverNumericCode);
	receiverSchemeURI = askIssuingAgency("schemeURI", receiverNumericCode);

	supplierSchemeAgencyName = askIssuingAgency("schemeAgencyName", supplierNumericCode);
	supplierSchemeID = askIssuingAgency("schemeID", supplierNumericCode);
	supplierSchemeURI = askIssuingAgency("schemeURI", supplierNumericCode);

	customerSchemeAgencyName = askIssuingAgency("schemeAgencyName", customerNumericCode);
	customerSchemeID = askIssuingAgency("schemeID", customerNumericCode);
	customerSchemeURI = askIssuingAgency("schemeURI", customerNumericCode);

	//Component Related Item//
	var lastId = parseInt(document.getElementById("ComponentRelatedItemLastId").value);
	var txtCatalogueLineComponentRelatedItemIDs = "";
	var txtCatalogueLineComponentRelatedItemQuantities = "";
	var txtCatalogueLineComponentRelatedItemDescriptions = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("ComponentRelatedItem" + i + "txtCatalogueLineComponentRelatedItemID") != null){
			txtCatalogueLineComponentRelatedItemIDs += document.getElementById("ComponentRelatedItem" + i + "txtCatalogueLineComponentRelatedItemID").value + "___";
			txtCatalogueLineComponentRelatedItemQuantities += document.getElementById("ComponentRelatedItem" + i + "txtCatalogueLineComponentRelatedItemQuantity").value + "___";
			txtCatalogueLineComponentRelatedItemDescriptions += document.getElementById("ComponentRelatedItem" + i + "txtCatalogueLineComponentRelatedItemDescription").value + "___";
		}
	}

	//Required Related Item//
	var lastId = parseInt(document.getElementById("RequiredRelatedItemLastId").value);
	var txtCatalogueLineRequiredRelatedItemIDs = "";
	var txtCatalogueLineRequiredRelatedItemQuantities = "";
	var txtCatalogueLineRequiredRelatedItemDescriptions = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("RequiredRelatedItem" + i + "txtCatalogueLineRequiredRelatedItemID") != null){
			txtCatalogueLineRequiredRelatedItemIDs += document.getElementById("RequiredRelatedItem" + i + "txtCatalogueLineRequiredRelatedItemID").value + "___";
			txtCatalogueLineRequiredRelatedItemQuantities += document.getElementById("RequiredRelatedItem" + i + "txtCatalogueLineRequiredRelatedItemQuantity").value + "___";
			txtCatalogueLineRequiredRelatedItemDescriptions += document.getElementById("RequiredRelatedItem" + i + "txtCatalogueLineRequiredRelatedItemDescription").value + "___";
		}
	}

	//Accessory Related Item//
	var lastId = parseInt(document.getElementById("AccessoryRelatedItemLastId").value);
	var txtCatalogueLineAccessoryRelatedItemIDs = "";
	var txtCatalogueLineAccessoryRelatedItemQuantities = "";
	var txtCatalogueLineAccessoryRelatedItemDescriptions = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AccessoryRelatedItem" + i + "txtCatalogueLineAccessoryRelatedItemID") != null){
			txtCatalogueLineAccessoryRelatedItemIDs += document.getElementById("AccessoryRelatedItem" + i + "txtCatalogueLineAccessoryRelatedItemID").value + "___";
			txtCatalogueLineAccessoryRelatedItemQuantities += document.getElementById("AccessoryRelatedItem" + i + "txtCatalogueLineAccessoryRelatedItemQuantity").value + "___";
			txtCatalogueLineAccessoryRelatedItemDescriptions += document.getElementById("AccessoryRelatedItem" + i + "txtCatalogueLineAccessoryRelatedItemDescription").value + "___";
		}
	}

	//Required Item Location Quantity//
	var lastId = parseInt(document.getElementById("RequiredItemLocationQuantityLastId").value);
	var txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasures = "";
	var txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasureUnitCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityMinimumQuantities = "";
	var txtCatalogueLineRequiredItemLocationQuantityMinimumQuantitiesUnitCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityMaximumQuantities = "";
	var txtCatalogueLineRequiredItemLocationQuantityMaximumQuantitiesUnitCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressIDs = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityNames = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetNames = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZones = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountrySubentities = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumbers = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegions = "";
	var txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes = "";
	var txtCatalogueLineRequiredItemLocationQuantityPricePriceAmounts = "";
	var txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyIDs = "";
	var txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantities = "";
	var txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDates = "";
	var txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDates = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressID") != null){
			txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasures += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasure").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasureUnitCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasureUnitCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityMaximumQuantities += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityMaximumQuantity").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityMaximumQuantitiesUnitCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityMaximumQuantityUnitCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityMinimumQuantities += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityMinimumQuantity").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityMinimumQuantitiesUnitCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityMinimumQuantityUnitCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressIDs += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressID").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityNames += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityName").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetNames += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetName").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZones += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZone").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetName").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountrySubentities += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountrySubentity").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumbers += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumber").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegions += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegion").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCode").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPricePriceAmounts += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPricePriceAmount").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyIDs += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyID").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantities += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantity").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDates += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDate").value + "___";
			txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDates += document.getElementById("RequiredItemLocationQuantity" + i + "txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDate").value + "___";
		}
	}

	//Note//
	var lastId = parseInt(document.getElementById("NoteLastId").value);
	var txtCatalogueLineNotes = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("Note" + i + "txtCatalogueLineNote") != null){
			txtCatalogueLineNotes += document.getElementById("Note" + i + "txtCatalogueLineNote").value + "___";
		}
	}

	//keyword//
	var lastId = parseInt(document.getElementById("KeywordLastId").value);
	var txtCatalogueLineItemKeywords = "";
	
	txtCatalogueLineItemKeywords += document.getElementById("txtCatalogueLineItemKeyword").value + "___";
	
/*	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("Keyword" + i + "txtCatalogueLineItemKeyword") != null){
			txtCatalogueLineItemKeywords += document.getElementById("Keyword" + i + "txtCatalogueLineItemKeyword").value + "___";
		}
	}
	*/

	//Commodity Classification//
	var lastId = parseInt(document.getElementById("CommodityClassificationLastId").value);
	var txtCatalogueLineItemCommodityClassificationCommodityCodes = "";
	//var txtCatalogueLineItemCommodityClassificationCommodityCodeSchemeIDs = "";
	var txtCatalogueLineItemCommodityClassificationItemClassificationCodes = "";
	var txtCatalogueLineItemCommodityClassificationItemClassificationCodeListIDs = "";
	var txtCatalogueLineItemCommodityClassificationItemClassificationCodeListVersionIDs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationCommodityCode") != null){
			txtCatalogueLineItemCommodityClassificationCommodityCodes += document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationCommodityCode").value + "___";
			//txtCatalogueLineItemCommodityClassificationCommodityCodeSchemeIDs += document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationCommodityCodeSchemeID").value + "___";
			txtCatalogueLineItemCommodityClassificationItemClassificationCodes += document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationItemClassificationCode").value + "___";
			txtCatalogueLineItemCommodityClassificationItemClassificationCodeListIDs += document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationItemClassificationCodeListID").value + "___";
			txtCatalogueLineItemCommodityClassificationItemClassificationCodeListVersionIDs += document.getElementById("CommodityClassification" + i + "txtCatalogueLineItemCommodityClassificationItemClassificationCodeListVersionID").value + "___";
		}
	}

	//Hazardous Item//
	var lastId = parseInt(document.getElementById("HazardousItemLastId").value);
	var txtCatalogueLineItemHazardousItemUNDGCodes = "";
	var txtCatalogueLineItemHazardousItemHazardClassIDs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("HazardousItem" + i + "txtCatalogueLineItemHazardousItemUNDGCode") != null){
			txtCatalogueLineItemHazardousItemUNDGCodes += document.getElementById("HazardousItem" + i + "txtCatalogueLineItemHazardousItemUNDGCode").value + "___";
			txtCatalogueLineItemHazardousItemHazardClassIDs += document.getElementById("HazardousItem" + i + "txtCatalogueLineItemHazardousItemHazardClassID").value + "___";
		}
	}

	//Additional Item Property//
	var lastId = parseInt(document.getElementById("AdditionalItemPropertyLastId").value);
	var txtCatalogueLineItemAdditionalItemPropertyNames = "";
	var txtCatalogueLineItemAdditionalItemPropertyValues = "";
	var txtCatalogueLineItemAdditionalItemPropertyTestMethods = "";
	var txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs = "";
	var txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalItemProperty" + i + "txtCatalogueLineItemAdditionalItemPropertyName") != null){
			txtCatalogueLineItemAdditionalItemPropertyNames += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueLineItemAdditionalItemPropertyName").value + "___";
			txtCatalogueLineItemAdditionalItemPropertyValues += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueLineItemAdditionalItemPropertyValue").value + "___";
			txtCatalogueLineItemAdditionalItemPropertyTestMethods += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueLineItemAdditionalItemPropertyTestMethod").value + "___";
			var lastID = document.getElementById("ItemPropertyGroupLastId").value;
			var found = 0;
			for ( var j = 1; j <= lastID; j++) {
				var itemPropertyGroup = document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupID");
				if(itemPropertyGroup) {
					if(found > 0){
						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs += "__";
						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames += "__";
					}
					txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupID").value;
					txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupName").value;
					found++;
				}
			}
			txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs += "___";
			txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames += "___";
		}
	}
	

	
	return createNewDocument(form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
						validationType,
						"",

						form.txtUBLVersionID.value,
						form.txtCustomizationID.value,
						defaultCustomizationSchemeID,
						form.txtProfileID.value,
						form.txtID.value,
						form.txtName.value,
						form.txtIssueDate.value,
						form.txtVersionID.value,

						form.txtValidityPeriodStartDate.value,
						form.txtValidityPeriodEndDate.value,

						form.txtReferencedContractID.value,
						form.txtReferencedContractContractType.value,

						providerEndpoint,
						providerSchemeAgencyName,
						providerSchemeID,
						providerSchemeURI,
						providerEndpoint,
						providerSchemeAgencyName,
						providerSchemeID,
						providerSchemeURI,
						providerName,
						form.txtProviderPartyPostalAddressStreetName.value,
						form.txtProviderPartyPostalAddressCityName.value,
						form.txtProviderPartyPostalAddressPostalZone.value,
						form.txtProviderPartyPostalAddressCountryIdentificationCode.value,
						form.txtProviderPartyPartyTaxSchemeCompanyID.value,
						form.txtProviderPartyPartyTaxSchemeID.value,

						receiverEndpoint,
						receiverSchemeAgencyName,
						receiverSchemeID,
						receiverSchemeURI,
						receiverEndpoint,
						receiverSchemeAgencyName,
						receiverSchemeID,
						receiverSchemeURI,
						receiverName,
						form.txtReceiverPartyPostalAddressStreetName.value,
						form.txtReceiverPartyPostalAddressCityName.value,
						form.txtReceiverPartyPostalAddressPostalZone.value,
						form.txtReceiverPartyPostalAddressCountryIdentificationCode.value,
						form.txtReceiverPartyPartyTaxSchemeCompanyID.value,
						form.txtReceiverPartyPartyTaxSchemeID.value,

						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierName,
						form.txtSellerSupplierPartyPartyPostalAddressID.value,
						form.txtSellerSupplierPartyPartyPostalAddressPostbox.value,
						form.txtSellerSupplierPartyPartyPostalAddressStreetName.value,
						form.txtSellerSupplierPartyPartyPostalAddressAdditionalStreetName.value,
						form.txtSellerSupplierPartyPartyPostalAddressBuildingNumber.value,
						form.txtSellerSupplierPartyPartyPostalAddressDepartment.value,
						form.txtSellerSupplierPartyPartyPostalAddressCityName.value,
						form.txtSellerSupplierPartyPartyPostalAddressPostalZone.value,
						form.txtSellerSupplierPartyPartyPostalAddressCountrySubentity.value,
						form.txtSellerSupplierPartyPartyPostalAddressCountryIdentificationCode.value,
						form.txtSellerSupplierPartyPartyPartyTaxSchemeCompanyID.value,
						form.txtSellerSupplierPartyPartyPartyTaxSchemeID.value,
						form.txtSellerSupplierPartyPartyPartyLegalEntityCompanyID.value,
						form.txtSellerSupplierPartyPartyContactTelephone.value,
						form.txtSellerSupplierPartyPartyContactTelefax.value,
						form.txtSellerSupplierPartyPartyContactElectronicMail.value,
						form.txtSellerSupplierPartyPartyPersonFirstName.value,
						form.txtSellerSupplierPartyPartyPersonFamilyName.value,
						form.txtSellerSupplierPartyPartyPersonMiddleName.value,
						form.txtSellerSupplierPartyPartyPersonJobTitle.valuea,

						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerName,
						form.txtContractorCustomerPartyPartyPostalAddressID.value,
						form.txtContractorCustomerPartyPartyPostalAddressPostbox.value,
						form.txtContractorCustomerPartyPartyPostalAddressStreetName.value,
						form.txtContractorCustomerPartyPartyPostalAddressAdditionalStreetName.value,
						form.txtContractorCustomerPartyPartyPostalAddressBuildingNumber.value,
						form.txtContractorCustomerPartyPartyPostalAddressCityName.value,
						form.txtContractorCustomerPartyPartyPostalAddressPostalZone.value,
						form.txtContractorCustomerPartyPartyPostalAddressCountrySubentity.value,
						form.txtContractorCustomerPartyPartyPostalAddressCountryIdentificationCode.value,
						form.txtContractorCustomerPartyPartyPartyTaxSchemeCompanyID.value,
						form.txtContractorCustomerPartyPartyPartyTaxSchemeID.value,
						form.txtContractorCustomerPartyPartyPartyLegalEntityCompanyID.value,
						form.txtContractorCustomerPartyPartyContactTelephone.value,
						form.txtContractorCustomerPartyPartyContactTelefax.value,
						form.txtContractorCustomerPartyPartyContactElectronicMail.value,
						form.txtContractorCustomerPartyPartyPersonFirstName.value,
						form.txtContractorCustomerPartyPartyPersonFamilyName.value,
						form.txtContractorCustomerPartyPartyPersonMiddleName.value,
						form.txtContractorCustomerPartyPartyPersonJobTitle.value,

						form.editLine.value,
						form.txtLineID.value,

						form.txtLineID.value,
						form.txtCatalogueLineActionCode.value,
						txtCatalogueLineNotes,
						form.cboCatalogueLineOrderableIndicator.value,
						form.txtCatalogueLineOrderableUnit.value,
						form.txtCatalogueLineContentUnitQuantity.value,
						form.txtCatalogueLineOrderQuantityIncrementNumeric.value,
						form.txtCatalogueLineMinimumOrderQuantity.value,
						form.txtCatalogueLineMaximumOrderQuantity.value,
						form.txtCatalogueLineWarrantyInformation.value,

						form.txtCatalogueLineLineValidityPeriodStartDate.value,
						form.txtCatalogueLineLineValidityPeriodEndDate.value,
						form.txtCatalogueLineItemComparisonPriceAmount.value,
						form.txtCatalogueLineItemComparisonPriceAmountCurrencyID.value,
						form.txtCatalogueLineItemComparisonQuantity.value,

						txtCatalogueLineComponentRelatedItemIDs,
						txtCatalogueLineComponentRelatedItemQuantities,
						txtCatalogueLineComponentRelatedItemDescriptions,

						txtCatalogueLineRequiredRelatedItemIDs,
						txtCatalogueLineRequiredRelatedItemQuantities,
						txtCatalogueLineRequiredRelatedItemDescriptions,

						txtCatalogueLineAccessoryRelatedItemIDs,
						txtCatalogueLineAccessoryRelatedItemQuantities,
						txtCatalogueLineAccessoryRelatedItemDescriptions,

						txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasures,
						txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasureUnitCodes,
						txtCatalogueLineRequiredItemLocationQuantityMinimumQuantities,
						txtCatalogueLineRequiredItemLocationQuantityMinimumQuantitiesUnitCodes,
						txtCatalogueLineRequiredItemLocationQuantityMaximumQuantities,
						txtCatalogueLineRequiredItemLocationQuantityMaximumQuantitiesUnitCodes,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressIDs,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetNames,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumbers,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityNames,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZones,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountrySubentities,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegions,
						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes,
						txtCatalogueLineRequiredItemLocationQuantityPricePriceAmounts,
						txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyIDs,
						txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantities,
						txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDates,
						txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDates,

						form.txtCatalogueLineItemDescription.value,
						form.txtCatalogueLineItemPackQuantity.value,
						form.txtCatalogueLineItemPackQuantityUnitCode.value,
						form.txtCatalogueLineItemPackSizeNumeric.value,
						form.txtCatalogueLineItemName.value,
						form.txtCatalogueLineItemHazardousRiskIndicator.value,
						txtCatalogueLineItemKeywords,
						form.txtCatalogueLineItemBrandName.value,
						form.txtCatalogueLineItemModelName.value,
						form.txtCatalogueLineItemBuyersItemIdentificationID.value,
						form.txtCatalogueLineItemSellersItemIdentificationID.value,
						form.txtCatalogueLineItemSellersItemIdentificationExtendedID.value,
						form.txtCatalogueLineItemManufacturersItemIdentificationID.value,
						form.txtCatalogueLineItemStandardItemIdentificationID.value,
						form.txtCatalogueLineItemStandardItemIdentificationIDSchemeID.value,
						form.txtCatalogueLineItemItemSpecificationDocumentReferenceID.value,
						form.txtCatalogueLineItemItemSpecificationDocumentReferenceDocumentType.value,
						form.txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObject.value,
						form.txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjectMimeCode.value,
						form.txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentExternalReferenceURI.value,
						form.txtCatalogueLineItemOriginCountryIdentificationCode.value,
						txtCatalogueLineItemCommodityClassificationCommodityCodes,
//					    txtCatalogueLineItemCommodityClassificationCommodityCodeSchemeIDs//,
						txtCatalogueLineItemCommodityClassificationItemClassificationCodes,
						txtCatalogueLineItemCommodityClassificationItemClassificationCodeListIDs,
						txtCatalogueLineItemCommodityClassificationItemClassificationCodeListVersionIDs,
						txtCatalogueLineItemHazardousItemUNDGCodes,
						txtCatalogueLineItemHazardousItemHazardClassIDs,
						form.txtCatalogueLineItemClassifiedTaxCategoryID.value,
						form.txtCatalogueLineItemClassifiedTaxCategoryTaxSchemeID.value,
						form.txtCatalogueLineItemClassifiedTaxCategoryPercent.value,
						txtCatalogueLineItemAdditionalItemPropertyNames,
						txtCatalogueLineItemAdditionalItemPropertyValues,
						txtCatalogueLineItemAdditionalItemPropertyTestMethods,
						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs,
						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames,
						form.txtCatalogueLineItemManufacturerPartyPartyNameName.value,
						form.txtCatalogueLineItemItemInstanceLotIdentificationExpiryDate.value
						);

//	return createNewDocument(form.txtID.value, documentName,
//						form.xmlBasedAddress.value,
//						xmlDraft,
//						xmlDrop,
//						form.isDraftDocument.value,
//						validationType,
//						"",
//
//						form.txtUBLVersionID.value,
//						form.txtCustomizationID.value,
//						defaultCustomizationSchemeID,
//						form.txtProfileID.value,
//						form.txtID.value,
//						form.txtName.value,
//						form.txtIssueDate.value,
//						form.txtVersionID.value,
//
//						form.txtValidityPeriodStartDate.value,
//						form.txtValidityPeriodEndDate.value,
//
//						form.txtReferencedContractID.value,
//						form.txtReferencedContractContractType.value,
//
//						providerEndpoint,
//						providerSchemeAgencyName,
//						providerSchemeID,
//						providerSchemeURI,
//						providerEndpoint,
//						providerSchemeAgencyName,
//						providerSchemeID,
//						providerSchemeURI,
//						providerName,
//						form.txtProviderPartyPostalAddressStreetName.value,
//						form.txtProviderPartyPostalAddressCityName.value,
//						form.txtProviderPartyPostalAddressPostalZone.value,
//						form.txtProviderPartyPostalAddressCountryIdentificationCode.value,
//						form.txtProviderPartyPartyTaxSchemeCompanyID.value,
//						form.txtProviderPartyPartyTaxSchemeID.value,
//
//						receiverEndpoint,
//						receiverSchemeAgencyName,
//						receiverSchemeID,
//						receiverSchemeURI,
//						receiverEndpoint,
//						receiverSchemeAgencyName,
//						receiverSchemeID,
//						receiverSchemeURI,
//						receiverName,
//						form.txtReceiverPartyPostalAddressStreetName.value,
//						form.txtReceiverPartyPostalAddressCityName.value,
//						form.txtReceiverPartyPostalAddressPostalZone.value,
//						form.txtReceiverPartyPostalAddressCountryIdentificationCode.value,
//						form.txtReceiverPartyPartyTaxSchemeCompanyID.value,
//						form.txtReceiverPartyPartyTaxSchemeID.value,
//
//						supplierEndpoint,
//						supplierSchemeAgencyName,
//						supplierSchemeID,
//						supplierSchemeURI,
//						supplierEndpoint,
//						supplierSchemeAgencyName,
//						supplierSchemeID,
//						supplierSchemeURI,
//						supplierName,
//						form.txtSellerSupplierPartyPartyPostalAddressID.value,
//						form.txtSellerSupplierPartyPartyPostalAddressPostbox.value,
//						form.txtSellerSupplierPartyPartyPostalAddressStreetName.value,
//						form.txtSellerSupplierPartyPartyPostalAddressAdditionalStreetName.value,
//						form.txtSellerSupplierPartyPartyPostalAddressBuildingNumber.value,
//						form.txtSellerSupplierPartyPartyPostalAddressDepartment.value,
//						form.txtSellerSupplierPartyPartyPostalAddressCityName.value,
//						form.txtSellerSupplierPartyPartyPostalAddressPostalZone.value,
//						form.txtSellerSupplierPartyPartyPostalAddressCountrySubentity.value,
//						form.txtSellerSupplierPartyPartyPostalAddressCountryIdentificationCode.value,
//						form.txtSellerSupplierPartyPartyPartyTaxSchemeCompanyID.value,
//						form.txtSellerSupplierPartyPartyPartyTaxSchemeID.value,
//						form.txtSellerSupplierPartyPartyPartyLegalEntityCompanyID.value,
//						form.txtSellerSupplierPartyPartyContactTelephone.value,
//						form.txtSellerSupplierPartyPartyContactTelefax.value,
//						form.txtSellerSupplierPartyPartyContactElectronicMail.value,
//						form.txtSellerSupplierPartyPartyPersonFirstName.value,
//						form.txtSellerSupplierPartyPartyPersonFamilyName.value,
//						form.txtSellerSupplierPartyPartyPersonMiddleName.value,
//						form.txtSellerSupplierPartyPartyPersonJobTitle.value,
//
//						customerEndpoint,
//						customerSchemeAgencyName,
//						customerSchemeID,
//						customerSchemeURI,
//						customerEndpoint,
//						customerSchemeAgencyName,
//						customerSchemeID,
//						customerSchemeURI,
//						customerName,
//						form.txtContractorCustomerPartyPartyPostalAddressID.value,
//						form.txtContractorCustomerPartyPartyPostalAddressPostbox.value,
//						form.txtContractorCustomerPartyPartyPostalAddressStreetName.value,
//						form.txtContractorCustomerPartyPartyPostalAddressAdditionalStreetName.value,
//						form.txtContractorCustomerPartyPartyPostalAddressBuildingNumber.value,
//						form.txtContractorCustomerPartyPartyPostalAddressCityName.value,
//						form.txtContractorCustomerPartyPartyPostalAddressPostalZone.value,
//						form.txtContractorCustomerPartyPartyPostalAddressCountrySubentity.value,
//						form.txtContractorCustomerPartyPartyPostalAddressCountryIdentificationCode.value,
//						form.txtContractorCustomerPartyPartyPartyTaxSchemeCompanyID.value,
//						form.txtContractorCustomerPartyPartyPartyTaxSchemeID.value,
//						form.txtContractorCustomerPartyPartyPartyLegalEntityCompanyID.value,
//						form.txtContractorCustomerPartyPartyContactTelephone.value,
//						form.txtContractorCustomerPartyPartyContactTelefax.value,
//						form.txtContractorCustomerPartyPartyContactElectronicMail.value,
//						form.txtContractorCustomerPartyPartyPersonFirstName.value,
//						form.txtContractorCustomerPartyPartyPersonFamilyName.value,
//						form.txtContractorCustomerPartyPartyPersonMiddleName.value,
//						form.txtContractorCustomerPartyPartyPersonJobTitle.value,
//
//						form.editLine.value,
//						form.txtLineID.value,
//
//						form.txtLineID.value,
//						form.txtCatalogueLineActionCode.value,
//						txtCatalogueLineNotes,
//						form.cboCatalogueLineOrderableIndicator.value,
//						form.txtCatalogueLineOrderableUnit.value,
//						form.txtCatalogueLineContentUnitQuantity.value,
//						form.txtCatalogueLineOrderQuantityIncrementNumeric.value,
//						form.txtCatalogueLineMinimumOrderQuantity.value,
//						form.txtCatalogueLineMaximumOrderQuantity.value,
//						form.txtCatalogueLineWarrantyInformation.value,
//
//						form.txtCatalogueLineLineValidityPeriodStartDate.value,
//						form.txtCatalogueLineLineValidityPeriodEndDate.value,
//						form.txtCatalogueLineItemComparisonPriceAmount.value,
//						form.txtCatalogueLineItemComparisonPriceAmountCurrencyID.value,
//						form.txtCatalogueLineItemComparisonQuantity.value,
//
//						txtCatalogueLineComponentRelatedItemIDs,
//						txtCatalogueLineComponentRelatedItemQuantities,
//						txtCatalogueLineComponentRelatedItemDescriptions,
//
//						txtCatalogueLineRequiredRelatedItemIDs,
//						txtCatalogueLineRequiredRelatedItemQuantities,
//						txtCatalogueLineRequiredRelatedItemDescriptions,
//
//						txtCatalogueLineAccessoryRelatedItemIDs,
//						txtCatalogueLineAccessoryRelatedItemQuantities,
//						txtCatalogueLineAccessoryRelatedItemDescriptions,
//
//						txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasures,
//						txtCatalogueLineRequiredItemLocationQuantityLeadTimeMeasureUnitCodes,
//						txtCatalogueLineRequiredItemLocationQuantityMinimumQuantities,
//						txtCatalogueLineRequiredItemLocationQuantityMinimumQuantitiesUnitCodes,
//						txtCatalogueLineRequiredItemLocationQuantityMaximumQuantities,
//						txtCatalogueLineRequiredItemLocationQuantityMaximumQuantitiesUnitCodes,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressIDs,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAddressTypeCodes,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressStreetNames,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressAdditionalStreetNames,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressBuildingNumbers,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCityNames,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressPostalZones,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountrySubentities,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressRegions,
//						txtCatalogueLineRequiredItemLocationQuantityApplicableTerritoryAddressCountryIdentificationCodes,
//						txtCatalogueLineRequiredItemLocationQuantityPricePriceAmounts,
//						txtCatalogueLineRequiredItemLocationQuantityPricePriceAmountCurrencyIDs,
//						txtCatalogueLineRequiredItemLocationQuantityPriceBaseQuantities,
//						txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodStartDates,
//						txtCatalogueLineRequiredItemLocationQuantityPriceValidityPeriodEndDates,
//
//						form.txtCatalogueLineItemDescription.value,
//						form.txtCatalogueLineItemPackQuantity.value,
//						form.txtCatalogueLineItemPackQuantityUnitCode.value,
//						form.txtCatalogueLineItemPackSizeNumeric.value,
//						form.txtCatalogueLineItemName.value,
//						form.txtCatalogueLineItemHazardousRiskIndicator.value,
//						txtCatalogueLineItemKeywords,
//						form.txtCatalogueLineItemBrandName.value,
//						form.txtCatalogueLineItemModelName.value,
//						form.txtCatalogueLineItemBuyersItemIdentificationID.value,
//						form.txtCatalogueLineItemSellersItemIdentificationID.value,
//						form.txtCatalogueLineItemSellersItemIdentificationExtendedID.value,
//						form.txtCatalogueLineItemManufacturersItemIdentificationID.value,
//						form.txtCatalogueLineItemStandardItemIdentificationID.value,
//						form.txtCatalogueLineItemStandardItemIdentificationIDSchemeID.value,
//						form.txtCatalogueLineItemItemSpecificationDocumentReferenceID.value,
//						form.txtCatalogueLineItemItemSpecificationDocumentReferenceDocumentType.value,
//						form.txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObject.value,
//						form.txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentEmbeddedDocumentBinaryObjectMimeCode.value,
//						form.txtCatalogueLineItemItemSpecificationDocumentReferenceAttachmentExternalReferenceURI.value,
//						form.txtCatalogueLineItemOriginCountryIdentificationCode.value,
//						txtCatalogueLineItemCommodityClassificationCommodityCodes,
//					    txtCatalogueLineItemCommodityClassificationCommodityCodeSchemeIDs,
//						txtCatalogueLineItemCommodityClassificationItemClassificationCodes,
//						txtCatalogueLineItemCommodityClassificationItemClassificationCodeListIDs,
//						txtCatalogueLineItemCommodityClassificationItemClassificationCodeListVersionIDs,
//						txtCatalogueLineItemHazardousItemUNDGCodes,
//						txtCatalogueLineItemHazardousItemHazardClassIDs,
//						form.txtCatalogueLineItemClassifiedTaxCategoryID.value,
//						form.txtCatalogueLineItemClassifiedTaxCategoryTaxSchemeID.value,
//						form.txtCatalogueLineItemClassifiedTaxCategoryPercent.value,
//						txtCatalogueLineItemAdditionalItemPropertyNames,
//						txtCatalogueLineItemAdditionalItemPropertyValues,
//						txtCatalogueLineItemAdditionalItemPropertyTestMethods,
//						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupIDs,
//						txtCatalogueLineItemAdditionalItemPropertyItemPropertyGroupNames,
//						form.txtCatalogueLineItemManufacturerPartyPartyNameName.value,
//						form.txtCatalogueLineItemItemInstanceLotIdentificationExpiryDate.value);

}

function setReferencedContractID(form) {
	form.txtReferencedContractID.value = form.referencedContractID.value;
}

function getProviderEndpoint(form) {
	return form.currentId.value;
}

function getProviderName(form) {
	return form.currentName.value;
}

function getReceiverEndpoint(form) {
	return form.otherPartyId.value;
}

function getReceiverName(form) {
	return form.otherPartyName.value;
}

function cleanTables() {
	cleanTable("ComponentRelatedItemLastId", "ComponentRelatedItem");
	cleanTable("RequiredRelatedItemLastId", "RequiredRelatedItem");
	cleanTable("RequiredItemLocationQuantityLastId", "RequiredItemLocationQuantity");
	cleanTable("KeywordLastId", "Keyword");
	cleanTable("CommodityClassificationLastId", "CommodityClassification");
	cleanTable("HazardousItemLastId", "HazardousItem");
	cleanTable("AdditionalItemPropertyLastId", "AdditionalItemProperty");
}