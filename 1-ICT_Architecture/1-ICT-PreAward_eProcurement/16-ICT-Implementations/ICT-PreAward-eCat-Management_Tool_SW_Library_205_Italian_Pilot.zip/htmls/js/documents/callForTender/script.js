function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {

	alert("callForTender");
	customerSchemeAgencyName = askIssuingAgency("schemeAgencyName", customerNumericCode);
	customerSchemeID = askIssuingAgency("schemeID", customerNumericCode);
	customerSchemeURI = askIssuingAgency("schemeURI", customerNumericCode);

	//Commodity Classification//
	var lastId = parseInt(document.getElementById("CommodityClassificationLastId").value);
	var txtRequestForTenderLineItemCommodityClassificationCommodityCodes = "";
	var txtRequestForTenderLineItemCommodityClassificationItemClassificationCodes = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("CommodityClassification" + i + "txtRequestForTenderLineItemCommodityClassificationCommodityCode") != null){
			txtRequestForTenderLineItemCommodityClassificationCommodityCodes += document.getElementById("CommodityClassification" + i + "txtRequestForTenderLineItemCommodityClassificationCommodityCode").value + "___";
			txtRequestForTenderLineItemCommodityClassificationItemClassificationCodes += document.getElementById("CommodityClassification" + i + "txtRequestForTenderLineItemCommodityClassificationItemClassificationCode").value + "___";
		}
	}
	
	
	//Additional Item Property//
	var lastId = parseInt(document.getElementById("AdditionalItemPropertyLastId").value);
	var txtRequestForTenderLineItemAdditionalItemPropertyIDs = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyNames = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyTestMethods = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyValues = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyListValues = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyRangeMinimumValueTexts = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyRangeMaximumValueTexts = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs = "";
	var txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupNames = "";

	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalItemProperty" + i + "txtRequestForTenderLineItemAdditionalItemPropertyID") != null){
			txtRequestForTenderLineItemAdditionalItemPropertyIDs += document.getElementById("AdditionalItemProperty" + i + "txtRequestForTenderLineItemAdditionalItemPropertyID").value + "___";
			txtRequestForTenderLineItemAdditionalItemPropertyNames += document.getElementById("AdditionalItemProperty" + i + "txtRequestForTenderLineItemAdditionalItemPropertyName").value + "___";
			txtRequestForTenderLineItemAdditionalItemPropertyTestMethods += document.getElementById("AdditionalItemProperty" + i + "txtRequestForTenderLineItemAdditionalItemPropertyTestMethod").value + "___";
			txtRequestForTenderLineItemAdditionalItemPropertyValues += document.getElementById("AdditionalItemProperty" + i + "txtRequestForTenderLineItemAdditionalItemPropertyValue").value + "___";

			var lastID = document.getElementById("ListValueLastId").value;
			var found = 0;
			for ( var j = 1; j <= lastID; j++) {
				var listValue = document.getElementById("AdditionalItemProperty" + i + "ListValue" + j + "txtRequestForTenderLineItemAdditionalItemPropertyListValue");
				if(listValue) {
					if(found > 0){
						txtRequestForTenderLineItemAdditionalItemPropertyListValues += "__";
					}
					txtRequestForTenderLineItemAdditionalItemPropertyListValues += listValue.value;
					found++;
				}
			}
			txtRequestForTenderLineItemAdditionalItemPropertyListValues += "___";

			txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyRangeMinimumValueTexts += document.getElementById("AdditionalItemProperty" + i + "txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyRangeMinimumValueText").value + "___";
			txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyRangeMaximumValueTexts += document.getElementById("AdditionalItemProperty" + i + "txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyRangeMaximumValueText").value + "___";

			var lastID = document.getElementById("ItemPropertyGroupLastId").value;
			var found = 0;
			for ( var j = 1; j <= lastID; j++) {
				var itemPropertyGroup = document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupID");
				if(itemPropertyGroup) {
					if(found > 0){
						txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs += "__";
						txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs += "__";
						txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupNames += "__";
					}
					txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupID").value;
					txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupParentID").value;
					txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupNames += document.getElementById("AdditionalItemProperty" + i + "ItemPropertyGroup" + j + "txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupName").value;
					found++;
				}
			}
			txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs += "___";
			txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs += "___";
			txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupNames += "___";
		}
	}

	return createNewDocument( form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
					    validationType,
					    "",

					    form.txtUBLVersionID.value,
					    form.txtCustomizationID.value,
					    defaultCustomizationSchemeID,
					    form.txtProfileID.value,
					    form.txtID.value,
					    form.txtContractFolderID.value,
					    form.txtIssueDate.value,

						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
					    customerName,
					    form.txtCustomerPartyPartyPostalAddressID.value,
					    form.txtCustomerPartyPartyPostalAddressPostbox.value,
					    form.txtCustomerPartyPartyPostalAddressStreetName.value,
					    form.txtCustomerPartyPartyPostalAddressAdditionalStreetName.value,
					    form.txtCustomerPartyPartyPostalAddressBuildingNumber.value,
					    form.txtCustomerPartyPartyPostalAddressCityName.value,
					    form.txtCustomerPartyPartyPostalAddressPostalZone.value,
					    form.txtCustomerPartyPartyPostalAddressCountrySubentity.value,
					    form.txtCustomerPartyPartyPostalAddressCountryIdentificationCode.value,
					    form.txtCustomerPartyPartyPartyTaxSchemeCompanyID.value,
					    form.txtCustomerPartyPartyPartyTaxSchemeTaxSchemeID.value,
					    form.txtCustomerPartyPartyPartyLegalEntityCompanyID.value,
					    form.txtCustomerPartyPartyContactTelephone.value,
					    form.txtCustomerPartyPartyContactTelefax.value,
					    form.txtCustomerPartyPartyContactElectronicMail.value,
					    form.txtCustomerPartyPartyPersonFirstName.value,
					    form.txtCustomerPartyPartyPersonFamilyName.value,
					    form.txtCustomerPartyPartyPersonMiddleName.value,
					    form.txtCustomerPartyPartyPersonJobTitle.value,

					    form.txtTenderingTermsNote.value,
					    form.txtTenderingProcessType.value,

					    form.txtProcurementProjectID.value,
					    form.txtProcurementProjectDescription.value,

					    form.editLine.value,
					    form.txtLineID.value,

					    form.txtLineID.value,
					    form.txtRequestForTenderLineNote.value,
					    form.txtRequestForTenderLineQuantity.value,
					    form.txtRequestForTenderLineMaximumTaxExclusiveAmount.value,
					    form.txtRequestForTenderLineMaximumTaxExclusiveAmountCurrencyID.value,
					    form.txtRequestForTenderLineMaximumTaxInclusiveAmount.value,
					    form.txtRequestForTenderLineMaximumTaxInclusiveAmountCurrencyID.value,
					    form.txtRequestForTenderLineItemDescription.value,
					    form.txtRequestForTenderLineItemPackQuantity.value,
					    form.txtRequestForTenderLineItemPackSizeNumeric.value,
					    form.txtRequestForTenderLineItemName.value,
						txtRequestForTenderLineItemCommodityClassificationCommodityCodes,
						txtRequestForTenderLineItemCommodityClassificationItemClassificationCodes,
						txtRequestForTenderLineItemAdditionalItemPropertyIDs,
						txtRequestForTenderLineItemAdditionalItemPropertyNames,
						txtRequestForTenderLineItemAdditionalItemPropertyTestMethods,
						txtRequestForTenderLineItemAdditionalItemPropertyValues,
						txtRequestForTenderLineItemAdditionalItemPropertyListValues,
						txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyRangeMinimumValueTexts,
						txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyRangeMaximumValueTexts,
					    txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupIDs,
					    txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupParentIDs,
					    txtRequestForTenderLineItemAdditionalItemPropertyItemPropertyGroupNames);

}

function setReferencedContractID(form) {
}

function getCustomerEndpoint(form) {
	return form.currentId.value;
}

function getCustomerName(form) {
	return form.currentName.value;
}

function cleanTables() {
	/*
	 * TODO update
	 */
	 
	 }
	 
	 function addHiddenRow(tableId2,tableID, arrayString, arrayTDs, id,id2, idPosition) {


	var result = validateAutoCompleteFields();
	if(result != ""){
		alert(result);
		return;
	}

	if(trim(document.getElementById(id).value) == ""){
		document.getElementById(id).select();
		document.getElementById(id).value = "";
		document.getElementById(id).style.backgroundColor="yellow";
		return;
	}
	else{
		document.getElementById(id).value = trim(document.getElementById(id).value);
		document.getElementById(id).style.backgroundColor="white";
	}

	var table = document.getElementById(tableId2);

	var rowCount = table.rows.length;

	var position = rowCount;

	var table = document.getElementById(tableID);

	var rowCount = table.rows.length;

	var position = rowCount;
var row = table.insertRow(position);

//remove fisrt two lines wich is headings
	var lastId = rowCount -2;


	var parentId = parseInt(document.getElementById(id2).value); 
	
	var cell1 = row.insertCell(0);
	
	for (var i = 0; i < arrayString.length; i++){
		var element = document.createElement("input");
		
		
		element.name =tableId2+parentId+ tableID + lastId + arrayString[i];
		element.id = tableId2+parentId+tableID + lastId + arrayString[i];
		element.type = "hidden";
		element.value = document.getElementById(arrayString[i]).value;
		cell1.appendChild(element);
	}

	



	

	document.getElementById(id).select();
}
	 
