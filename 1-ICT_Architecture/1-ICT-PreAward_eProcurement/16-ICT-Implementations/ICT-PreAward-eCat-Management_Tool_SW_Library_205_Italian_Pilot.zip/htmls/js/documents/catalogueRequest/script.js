function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {

	
	receiverSchemeAgencyName = askIssuingAgency("schemeAgencyName", receiverNumericCode);
	receiverSchemeID = askIssuingAgency("schemeID", receiverNumericCode);
	receiverSchemeURI = askIssuingAgency("schemeURI", receiverNumericCode);

	providerSchemeAgencyName = askIssuingAgency("schemeAgencyName", providerNumericCode);
	providerSchemeID = askIssuingAgency("schemeID", providerNumericCode);
	providerSchemeURI = askIssuingAgency("schemeURI", providerNumericCode);

	//Additional Item Property//
	var lastId = parseInt(document.getElementById("AdditionalItemPropertyLastId").value);
	var txtCatalogueRequestLineItemAdditionalItemPropertyNames = "";
	var txtCatalogueRequestLineItemAdditionalItemPropertyValues = "";
	var txtCatalogueRequestLineItemAdditionalItemPropertyItemPropertyGroupIDs = "";
	var txtCatalogueRequestLineItemAdditionalItemPropertyItemPropertyGroupNames = "";

	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalItemProperty" + i + "txtCatalogueRequestLineItemAdditionalItemPropertyName") != null){
			txtCatalogueRequestLineItemAdditionalItemPropertyNames += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueRequestLineItemAdditionalItemPropertyName").value + "___";
			txtCatalogueRequestLineItemAdditionalItemPropertyValues += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueRequestLineItemAdditionalItemPropertyValue").value + "___";
			txtCatalogueRequestLineItemAdditionalItemPropertyItemPropertyGroupIDs += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueRequestLineItemAdditionalItemPropertyItemPropertyGroupID").value + "___";
			txtCatalogueRequestLineItemAdditionalItemPropertyItemPropertyGroupNames += document.getElementById("AdditionalItemProperty" + i + "txtCatalogueRequestLineItemAdditionalItemPropertyItemPropertyGroupName").value + "___";
		}
	}

	return createNewDocument( form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
						validationType,
						"",

						form.txtUBLVersionID.value,
						form.txtCustomizationID.value,
						defaultCustomizationSchemeID,
						form.txtProfileID.value,
						form.txtID.value,
						form.txtIssueDate.value,
						form.txtDescription.value,

						form.txtValidityPeriodEndDate.value,
						form.txtValidityPeriodEndTime.value,

						providerEndpoint,
						providerSchemeAgencyName,
						providerSchemeID,
						providerSchemeURI,
						providerEndpoint,
						providerSchemeAgencyName,
						providerSchemeID,
						providerSchemeURI,
						providerName,
						form.txtReceiverPartyContactTelephone.value,
						form.txtReceiverPartyContactTelefax.value,
						form.txtReceiverPartyContactElectronicMail.value,
						form.txtReceiverPartyPersonFirstName.value,
						form.txtReceiverPartyPersonFamilyName.value,
						form.txtReceiverPartyPersonMiddleName.value,
						form.txtReceiverPartyPersonJobTitle.value,

						receiverEndpoint,
						receiverSchemeAgencyName,
						receiverSchemeID,
						receiverSchemeURI,
						receiverEndpoint,
						receiverSchemeAgencyName,
						receiverSchemeID,
						receiverSchemeURI,
						receiverName,
						form.txtProviderPartyPostalAddressID.value,
						form.txtProviderPartyPostalAddressPostbox.value,
						form.txtProviderPartyPostalAddressStreetName.value,
						form.txtProviderPartyPostalAddressAdditionalStreetName.value,
						form.txtProviderPartyPostalAddressBuildingNumber.value,
						form.txtProviderPartyPostalAddressCityName.value,
						form.txtProviderPartyPostalAddressPostalZone.value,
						form.txtProviderPartyPostalAddressCountrySubentity.value,
						form.txtProviderPartyPostalAddressCountryIdentificationCode.value,
						form.txtProviderPartyContactTelephone.value,
						form.txtProviderPartyContactTelefax.value,
						form.txtProviderPartyContactElectronicMail.value,
						form.txtProviderPartyPersonFirstName.value,
						form.txtProviderPartyPersonFamilyName.value,
						form.txtProviderPartyPersonMiddleName.value,
						form.txtProviderPartyPersonJobTitle.value,

						form.txtReferencedContractID.value,
						form.txtReferencedContractContractType.value,

						form.editLine.value,
						form.txtLineID.value,

						form.txtLineID.value,
						form.txtCatalogueRequestLineItemDescription.value,
						form.txtCatalogueRequestLineItemName.value,
						form.txtCatalogueRequestLineItemSellersItemIdentificationID.value,
						form.txtCatalogueRequestLineItemSellersItemIdentificationExtendedID.value,
						form.txtCatalogueRequestLineItemStandardItemIdentificationID.value,
						form.txtCatalogueRequestLineItemStandardItemIdentificationExtendedID.value,
						form.txtCatalogueRequestLineItemCatalogueItemIdentificationID.value,
						form.txtCatalogueRequestLineItemCatalogueItemIdentificationExtendedID.value,
						form.txtCatalogueRequestLineItemCommodityClassificationItemClassificationCode.value,
						txtCatalogueRequestLineItemAdditionalItemPropertyNames,
						txtCatalogueRequestLineItemAdditionalItemPropertyValues,
						txtCatalogueRequestLineItemAdditionalItemPropertyItemPropertyGroupIDs,
						txtCatalogueRequestLineItemAdditionalItemPropertyItemPropertyGroupNames);

}

function setReferencedContractID(form) {
	form.txtReferencedContractID.value = form.referencedContractID.value;
}

function getReceiverEndpoint(form) {
	return form.otherPartyId.value;
}

function getReceiverName(form) {
	return form.otherPartyName.value;
}

function getProviderEndpoint(form) {
	return form.currentId.value;
}

function getProviderName(form) {
	return form.currentName.value;
}

function cleanTables() {
	cleanTable("AdditionalItemPropertyLastId", "AdditionalItemProperty");
}