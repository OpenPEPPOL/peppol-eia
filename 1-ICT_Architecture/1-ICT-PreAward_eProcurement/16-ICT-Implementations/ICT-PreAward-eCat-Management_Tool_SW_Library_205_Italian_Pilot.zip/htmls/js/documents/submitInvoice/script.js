function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {

	alert("submitInvoice");
	supplierSchemeAgencyName = askIssuingAgency("schemeAgencyName", supplierNumericCode);
	supplierSchemeID = askIssuingAgency("schemeID", supplierNumericCode);
	supplierSchemeURI = askIssuingAgency("schemeURI", supplierNumericCode);

	customerSchemeAgencyName = askIssuingAgency("schemeAgencyName", customerNumericCode);
	customerSchemeID = askIssuingAgency("schemeID", customerNumericCode);
	customerSchemeURI = askIssuingAgency("schemeURI", customerNumericCode);

	//Additional Document Reference//
	var lastId = parseInt(document.getElementById("AdditionalDocumentReferenceLastId").value);
	var txtAdditionalDocumentReferenceIDs = "";
	var txtAdditionalDocumentReferenceDocumentTypes = "";
	var txtAdditionalDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects = "";
	var txtAdditionalDocumentReferenceAttachmentExternalReferenceURIs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceID") != null){
			txtAdditionalDocumentReferenceIDs += document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceID").value + "___";
			txtAdditionalDocumentReferenceDocumentTypes += document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceDocumentType").value + "___";
			txtAdditionalDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects += document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceAttachmentEmbeddedDocumentBinaryObject").value + "___";
			txtAdditionalDocumentReferenceAttachmentExternalReferenceURIs += document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceAttachmentExternalReferenceURI").value + "___";
		}
	}

	//Payment Means//
	var lastId = parseInt(document.getElementById("PaymentMeansLastId").value);
	var txtPaymentMeansPaymentMeansCodes = "";
	var txtPaymentMeansPaymentDueDates = "";
	var txtPaymentMeansPaymentChannelCodes = "";
	var txtPaymentMeansPaymentIDs = "";
	var txtPaymentMeansPayeeFinancialAccountIDs = "";
	var txtPaymentMeansPayeeFinancialAccountFinancialInstitutionBranchIDs = "";
	var txtPaymentMeansPayeeFinancialAccountFinancialInstitutionBranchFinancialInstitutionIDs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("PaymentMeans" + i + "txtPaymentMeansPaymentMeansCode") != null){
			txtPaymentMeansPaymentMeansCodes += document.getElementById("PaymentMeans" + i + "txtPaymentMeansPaymentMeansCode").value + "___";
			txtPaymentMeansPaymentDueDates += document.getElementById("PaymentMeans" + i + "txtPaymentMeansPaymentDueDate").value + "___";
			txtPaymentMeansPaymentChannelCodes += document.getElementById("PaymentMeans" + i + "txtPaymentMeansPaymentChannelCode").value + "___";
			txtPaymentMeansPaymentIDs += document.getElementById("PaymentMeans" + i + "txtPaymentMeansPaymentID").value + "___";
			txtPaymentMeansPayeeFinancialAccountIDs += document.getElementById("PaymentMeans" + i + "txtPaymentMeansPayeeFinancialAccountID").value + "___";
			txtPaymentMeansPayeeFinancialAccountFinancialInstitutionBranchIDs += document.getElementById("PaymentMeans" + i + "txtPaymentMeansPayeeFinancialAccountFinancialInstitutionBranchID").value + "___";
			txtPaymentMeansPayeeFinancialAccountFinancialInstitutionBranchFinancialInstitutionIDs += document.getElementById("PaymentMeans" + i + "txtPaymentMeansPayeeFinancialAccountFinancialInstitutionBranchFinancialInstitutionID").value + "___";
		}
	}

	//Allowance Charge//
	var lastId = parseInt(document.getElementById("AllowanceChargeLastId").value);
	var txtAllowanceChargeIds = "";
	var txtAllowanceChargeChargeIndicators = "";
	var txtAllowanceChargeAllowanceChargeReasons = "";
	var txtAllowanceChargeAmounts = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeId") != null){
			txtAllowanceChargeIds += document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeId").value + "___";
			txtAllowanceChargeChargeIndicators += document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeChargeIndicator").value + "___";
			txtAllowanceChargeAllowanceChargeReasons += document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeAllowanceChargeReason").value + "___";
			txtAllowanceChargeAmounts += document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeAmount").value + "___";
		}
	}

	//Tax Subtotal//
	var lastId = parseInt(document.getElementById("TaxSubtotalLastId").value);
	var txtTaxTotalTaxSubtotalTaxableAmounts = "";
	var txtTaxTotalTaxSubtotalTaxAmounts = "";
	var txtTaxTotalTaxSubtotalTaxCategoryIDs = "";
	var txtTaxTotalTaxSubtotalTaxCategoryPercents = "";
	var txtTaxTotalTaxSubtotalTaxCategoryTaxExemptionReasonCodes = "";
	var txtTaxTotalTaxSubtotalTaxCategoryTaxExemptionReasons = "";
	var txtTaxTotalTaxSubtotalTaxCategoryTaxSchemeIDs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("TaxSubtotal" + i + "txtTaxTotalTaxSubtotalTaxCategoryID") != null){
			txtTaxTotalTaxSubtotalTaxableAmounts += document.getElementById("TaxSubtotal" + i + "txtTaxTotalTaxSubtotalTaxableAmount").value + "___";
			txtTaxTotalTaxSubtotalTaxAmounts += document.getElementById("TaxSubtotal" + i + "txtTaxTotalTaxSubtotalTaxAmount").value + "___";
			txtTaxTotalTaxSubtotalTaxCategoryIDs += document.getElementById("TaxSubtotal" + i + "txtTaxTotalTaxSubtotalTaxCategoryID").value + "___";
			txtTaxTotalTaxSubtotalTaxCategoryPercents += document.getElementById("TaxSubtotal" + i + "txtTaxTotalTaxSubtotalTaxCategoryPercent").value + "___";
			txtTaxTotalTaxSubtotalTaxCategoryTaxExemptionReasonCodes += document.getElementById("TaxSubtotal" + i + "txtTaxTotalTaxSubtotalTaxCategoryTaxExemptionReasonCode").value + "___";
			txtTaxTotalTaxSubtotalTaxCategoryTaxExemptionReasons += document.getElementById("TaxSubtotal" + i + "txtTaxTotalTaxSubtotalTaxCategoryTaxExemptionReason").value + "___";
			txtTaxTotalTaxSubtotalTaxCategoryTaxSchemeIDs += document.getElementById("TaxSubtotal" + i + "txtTaxTotalTaxSubtotalTaxCategoryTaxSchemeID").value + "___";
		}
	}

	//Order Line Reference Line//
	var lastId = parseInt(document.getElementById("OrderLineReferenceLastId").value);
	var txtInvoiceLineOrderLineReferenceLineIDs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("OrderLineReference" + i + "txtInvoiceLineOrderLineReferenceLineID") != null){
			txtInvoiceLineOrderLineReferenceLineIDs += document.getElementById("OrderLineReference" + i + "txtInvoiceLineOrderLineReferenceLineID").value + "___";
		}
	}

	//Line Allowance Charge//
	var lastId = parseInt(document.getElementById("LineAllowanceChargeLastId").value);
	var txtInvoiceLineAllowanceChargeIds = "";
	var txtInvoiceLineAllowanceChargeChargeIndicators = "";
	var txtInvoiceLineAllowanceChargeAllowanceChargeReasons = "";
	var txtInvoiceLineAllowanceChargeAmounts = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("LineAllowanceCharge" + i + "txtInvoiceLineAllowanceChargeId") != null){
			txtInvoiceLineAllowanceChargeIds += document.getElementById("LineAllowanceCharge" + i + "txtInvoiceLineAllowanceChargeId").value + "___";
			txtInvoiceLineAllowanceChargeChargeIndicators += document.getElementById("LineAllowanceCharge" + i + "txtInvoiceLineAllowanceChargeChargeIndicator").value + "___";
			txtInvoiceLineAllowanceChargeAllowanceChargeReasons += document.getElementById("LineAllowanceCharge" + i + "txtInvoiceLineAllowanceChargeAllowanceChargeReason").value + "___";
			txtInvoiceLineAllowanceChargeAmounts += document.getElementById("LineAllowanceCharge" + i + "txtInvoiceLineAllowanceChargeAmount").value + "___";
		}
	}

	//Commodity Classification//
	var lastId = parseInt(document.getElementById("CommodityClassificationLastId").value);
	var txtInvoiceLineItemCommodityClassificationItemClassificationCodes = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("CommodityClassification" + i + "txtInvoiceLineItemCommodityClassificationItemClassificationCode") != null){
			txtInvoiceLineItemCommodityClassificationItemClassificationCodes += document.getElementById("CommodityClassification" + i + "txtInvoiceLineItemCommodityClassificationItemClassificationCode").value + "___";
		}
	}

	//Additional Item Property//
	var lastId = parseInt(document.getElementById("AdditionalItemPropertyLastId").value);
	var txtInvoiceLineItemAdditionalItemPropertyNames = "";
	var txtInvoiceLineItemAdditionalItemPropertyValues = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalItemProperty" + i + "txtInvoiceLineItemAdditionalItemPropertyName") != null){
			txtInvoiceLineItemAdditionalItemPropertyNames += document.getElementById("AdditionalItemProperty" + i + "txtInvoiceLineItemAdditionalItemPropertyName").value + "___";
			txtInvoiceLineItemAdditionalItemPropertyValues += document.getElementById("AdditionalItemProperty" + i + "txtInvoiceLineItemAdditionalItemPropertyValue").value + "___";
		}
	}

	return createNewDocument( form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
						validationType,
						form.txtDocumentCurrencyCode.value,//Default CurrencyCode attributes

						form.txtUBLVersionID.value,
						form.txtCustomizationID.value,
						defaultCustomizationSchemeID,
						form.txtProfileID.value,
						form.txtID.value,
						form.txtIssueDate.value,
						form.txtInvoiceTypeCode.value,
						form.txtNote.value,
						form.txtTaxPointDate.value,
						form.txtDocumentCurrencyCode.value,
						form.txtAccountingCost.value,

						form.txtInvoicePeriodStartDate.value,
						form.txtInvoicePeriodEndDate.value,

						form.txtOrderReferenceID.value,

						form.txtContractDocumentReferenceID.value,
						form.txtContractDocumentReferenceDocumentType.value,

						txtAdditionalDocumentReferenceIDs,
						txtAdditionalDocumentReferenceDocumentTypes,
						txtAdditionalDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects,
						txtAdditionalDocumentReferenceAttachmentExternalReferenceURIs,

						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierName,
						form.txtAccountingSupplierPartyPartyPostalAddressID.value,
						form.txtAccountingSupplierPartyPartyPostalAddressPostbox.value,
						form.txtAccountingSupplierPartyPartyPostalAddressStreetName.value,
						form.txtAccountingSupplierPartyPartyPostalAddressAdditionalStreetName.value,
						form.txtAccountingSupplierPartyPartyPostalAddressBuildingNumber.value,
						form.txtAccountingSupplierPartyPartyPostalAddressDepartment.value,
						form.txtAccountingSupplierPartyPartyPostalAddressCityName.value,
						form.txtAccountingSupplierPartyPartyPostalAddressPostalZone.value,
						form.txtAccountingSupplierPartyPartyPostalAddressCountrySubentity.value,
						form.txtAccountingSupplierPartyPartyPostalAddressCountryIdentificationCode.value,
						form.txtAccountingSupplierPartyPartyPartyTaxSchemeCompanyID.value,
						form.txtAccountingSupplierPartyPartyPartyTaxSchemeTaxSchemeID.value,
						form.txtAccountingSupplierPartyPartyPartyPartyLegalEntityRegistrationName.value,
						form.txtAccountingSupplierPartyPartyPartyPartyLegalEntityCompanyID.value,
						form.txtAccountingSupplierPartyPartyPartyPartyLegalEntityRegistrationAddressCityName.value,
						form.txtAccountingSupplierPartyPartyPartyPartyLegalEntityCountrySubentity.value,
						form.txtAccountingSupplierPartyPartyPartyPartyLegalEntityCountryIdentificationCode.value,
						form.txtAccountingSupplierPartyPartyContactID.value,
						form.txtAccountingSupplierPartyPartyContactTelephone.value,
						form.txtAccountingSupplierPartyPartyContactTelefax.value,
						form.txtAccountingSupplierPartyPartyContactElectronicMail.value,
						form.txtAccountingSupplierPartyPartyPersonFirstName.value,
						form.txtAccountingSupplierPartyPartyPersonFamilyName.value,
						form.txtAccountingSupplierPartyPartyPersonMiddleName.value,
						form.txtAccountingSupplierPartyPartyPersonJobTitle.value,

						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerName,
						form.txtAccountingCustomerPartyPartyPostalAddressID.value,
						form.txtAccountingCustomerPartyPartyPostalAddressPostbox.value,
						form.txtAccountingCustomerPartyPartyPostalAddressStreetName.value,
						form.txtAccountingCustomerPartyPartyPostalAddressAdditionalStreetName.value,
						form.txtAccountingCustomerPartyPartyPostalAddressBuildingNumber.value,
						form.txtAccountingCustomerPartyPartyPostalAddressDepartment.value,
						form.txtAccountingCustomerPartyPartyPostalAddressCityName.value,
						form.txtAccountingCustomerPartyPartyPostalAddressPostalZone.value,
						form.txtAccountingCustomerPartyPartyPostalAddressCountrySubentity.value,
						form.txtAccountingCustomerPartyPartyPostalAddressCountryIdentificationCode.value,
						form.txtAccountingCustomerPartyPartyTaxSchemeCompanyID.value,
						form.txtAccountingCustomerPartyPartyTaxSchemeID.value,
						form.txtAccountingCustomerPartyPartyPartyLegalEntityRegistrationName.value,
						form.txtAccountingCustomerPartyPartyPartyLegalEntityCompanyID.value,
						form.txtAccountingCustomerPartyPartyPartyLegalEntityRegistrationAddressCityName.value,
						form.txtAccountingCustomerPartyPartyPartyLegalEntityRegistrationAddressCountrySubentity.value,
						form.txtAccountingCustomerPartyPartyPartyLegalEntityRegistrationAddressCountryIdentificationCode.value,
						form.txtAccountingCustomerPartyPartyContactID.value,
						form.txtAccountingCustomerPartyPartyContactTelephone.value,
						form.txtAccountingCustomerPartyPartyContactTelefax.value,
						form.txtAccountingCustomerPartyPartyContactElectronicMail.value,
						form.txtAccountingCustomerPartyPartyPersonFirstName.value,
						form.txtAccountingCustomerPartyPartyPersonFamilyName.value,
						form.txtAccountingCustomerPartyPartyPersonMiddleName.value,
						form.txtAccountingCustomerPartyPartyPersonJobTitle.value,

						form.txtPayeePartyPartyIdentificationID.value,
						form.txtPayeePartyPartyNameName.value,
						form.txtPayeePartyPartyLegalEntityCompanyID.value,

						form.txtDeliveryActualDeliveryDate.value,
						form.txtDeliveryDeliveryLocationID.value,
						form.txtDeliveryDeliveryLocationAddressStreetName.value,
						form.txtDeliveryDeliveryLocationAddressAdditionalStreetName.value,
						form.txtDeliveryDeliveryLocationAddressBuildingNumber.value,
						form.txtDeliveryDeliveryLocationAddressCityName.value,
						form.txtDeliveryDeliveryLocationAddressPostalZone.value,
						form.txtDeliveryDeliveryLocationAddressCountrySubentity.value,
						form.txtDeliveryDeliveryLocationAddressCountryIdentificationCode.value,

						txtPaymentMeansPaymentMeansCodes,
						txtPaymentMeansPaymentDueDates,
						txtPaymentMeansPaymentChannelCodes,
						txtPaymentMeansPaymentIDs,
						txtPaymentMeansPayeeFinancialAccountIDs,
						txtPaymentMeansPayeeFinancialAccountFinancialInstitutionBranchIDs,
						txtPaymentMeansPayeeFinancialAccountFinancialInstitutionBranchFinancialInstitutionIDs,

						form.txtPaymentTermsNote.value,

						txtAllowanceChargeChargeIndicators,
						txtAllowanceChargeAllowanceChargeReasons,
						txtAllowanceChargeAmounts,

						form.txtTaxTotalTaxAmount.value,
						txtTaxTotalTaxSubtotalTaxableAmounts,
						txtTaxTotalTaxSubtotalTaxAmounts,
						txtTaxTotalTaxSubtotalTaxCategoryIDs,
						txtTaxTotalTaxSubtotalTaxCategoryPercents,
						txtTaxTotalTaxSubtotalTaxCategoryTaxExemptionReasonCodes,
						txtTaxTotalTaxSubtotalTaxCategoryTaxExemptionReasons,
						txtTaxTotalTaxSubtotalTaxCategoryTaxSchemeIDs,

						form.txtLegalMonetaryTotalLineExtensionAmount.value,
						form.txtLegalMonetaryTotalTaxExclusiveAmount.value,
						form.txtLegalMonetaryTotalTaxInclusiveAmount.value,
						form.txtLegalMonetaryTotalAllowanceTotalAmount.value,
						form.txtLegalMonetaryTotalChargeTotalAmount.value,
						form.txtLegalMonetaryTotalPrepaidAmount.value,
						form.txtLegalMonetaryTotalPayableRoundingAmount.value,
						form.txtLegalMonetaryTotalPayableAmount.value,

						form.editLine.value,
						form.txtLineID.value,

						form.txtLineID.value,
						form.txtInvoiceLineNote.value,
						form.txtInvoiceLineInvoicedQuantity.value,
						form.txtInvoiceLineInvoicedQuantityUnitCode.value,
						form.txtInvoiceLineLineExtensionAmount.value,
						form.txtInvoiceLineAccountingCost.value,
						txtInvoiceLineOrderLineReferenceLineIDs,
						txtInvoiceLineAllowanceChargeChargeIndicators,
						txtInvoiceLineAllowanceChargeAllowanceChargeReasons,
						txtInvoiceLineAllowanceChargeAmounts,
						form.txtInvoiceLineTaxTotalTaxAmount.value,
						form.txtInvoiceLineItemDescription.value,
						form.txtInvoiceLineItemName.value,
						form.txtInvoiceLineItemSellersItemIdentificationID.value,
						form.txtInvoiceLineItemStandardItemIdentificationID.value,
						txtInvoiceLineItemCommodityClassificationItemClassificationCodes,
						form.txtInvoiceLineItemClassifiedTaxCategoryID.value,
						form.txtInvoiceLineItemClassifiedTaxCategoryPercent.value,
						form.txtInvoiceLineItemClassifiedTaxCategoryTaxSchemeID.value,
						txtInvoiceLineItemAdditionalItemPropertyNames,
						txtInvoiceLineItemAdditionalItemPropertyValues,
						form.txtInvoiceLinePricePriceAmount.value,
						form.txtInvoiceLinePriceBaseQuantity.value,
						form.txtInvoiceLinePriceAllowanceChargeChargeIndicator.value,
						form.txtInvoiceLinePriceAllowanceChargeAllowanceChargeReason.value,
						form.txtInvoiceLinePriceAllowanceChargeMultiplierFactorNumeric.value,
						form.txtInvoiceLinePriceAllowanceChargeAmount.value,
						form.txtInvoiceLinePriceAllowanceChargeBaseAmount.value);
}

function setReferencedContractID(form) {
	form.txtOrderReferenceID.value = form.referencedContractID.value;
}

function getSupplierEndpoint(form) {
	return form.currentId.value;
}

function getSupplierName(form) {
	return form.currentName.value;
}

function getCustomerEndpoint(form) {
	return form.otherPartyId.value;
}

function getCustomerName(form) {
	return form.otherPartyName.value;
}

function cleanTables() {
	/*
	 * TODO update
	 */
}