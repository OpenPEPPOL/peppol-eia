function createDocument(form, documentName, xmlDraft, xmlDrop, validationType, keyWord,
		customerEndpoint, customerNumericCode, customerName,
		supplierEndpoint, supplierNumericCode, supplierName,
		receiverEndpoint, receiverNumericCode, receiverName,
		providerEndpoint, providerNumericCode, providerName) {

	alert("submitOrder");
	supplierSchemeAgencyName = askIssuingAgency("schemeAgencyName", supplierNumericCode);
	supplierSchemeID = askIssuingAgency("schemeID", supplierNumericCode);
	supplierSchemeURI = askIssuingAgency("schemeURI", supplierNumericCode);

	customerSchemeAgencyName = askIssuingAgency("schemeAgencyName", customerNumericCode);
	customerSchemeID = askIssuingAgency("schemeID", customerNumericCode);
	customerSchemeURI = askIssuingAgency("schemeURI", customerNumericCode);

	//Additional Document Reference//
	var lastId = parseInt(document.getElementById("AdditionalDocumentReferenceLastId").value);
	var txtAdditionalDocumentReferenceIDs = "";
	var txtAdditionalDocumentReferenceDocumentTypes = "";
	var txtAdditionalDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects = "";
	var txtAdditionalDocumentReferenceAttachmentExternalReferenceURIs = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceID") != null){
			txtAdditionalDocumentReferenceIDs += document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceID").value + "___";
			txtAdditionalDocumentReferenceDocumentTypes += document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceDocumentType").value + "___";
			txtAdditionalDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects += document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceAttachmentEmbeddedDocumentBinaryObject").value + "___";
			txtAdditionalDocumentReferenceAttachmentExternalReferenceURIs += document.getElementById("AdditionalDocumentReference" + i + "txtAdditionalDocumentReferenceAttachmentExternalReferenceURI").value + "___";
		}
	}

	//Party Tax Scheme//
	var lastId = parseInt(document.getElementById("PartyTaxSchemeLastId").value);
	var txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationNames = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeCompanyIDs = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationAddressCityNames = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationAddressCountryIdentificationCodes = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeIDs = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeNames = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeTaxTypeCodes = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeCurrencyCodes = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressAddressTypeCodes = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressBlockNames = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressInhouseMails = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionPlotIdentifications = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCitySubdivisionNames = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressTimezoneOffsets = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCountryIdentificationCodes = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCountryNames = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateCoordinateSystemCodes = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeDegreesMeasures = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeMinutesMeasures = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeDirectionCodes = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeDegreesMeasures = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeMinutesMeasures = "";
	var txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeDirectionCodes = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeID") != null){
			txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationNames += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationName").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeCompanyIDs += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeCompanyID").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationAddressCityNames += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationAddressCityName").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationAddressCountryIdentificationCodes += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationAddressCountryIdentificationCode").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeIDs += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeID").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeNames += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeName").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeTaxTypeCodes += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeTaxTypeCode").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeCurrencyCodes += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeCurrencyCode").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressAddressTypeCodes += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressAddressTypeCode").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressBlockNames += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressBlockName").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressInhouseMails += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressInhouseMail").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionPlotIdentifications += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionPlotIdentification").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCitySubdivisionNames += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCitySubdivisionName").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressTimezoneOffsets += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressTimezoneOffset").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCountryIdentificationCodes += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCountryIdentificationCode").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCountryNames += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCountryName").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateCoordinateSystemCodes += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateCoordinateSystemCode").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeDegreesMeasures += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeDegreesMeasure").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeMinutesMeasures += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeMinutesMeasure").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeDirectionCodes += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeDirectionCode").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeDegreesMeasures += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeDegreesMeasure").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeMinutesMeasures += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeMinutesMeasure").value + "___";
			txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeDirectionCodes += document.getElementById("PartyTaxScheme" + i + "txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeDirectionCode").value + "___";
		}
	}

	//Allowance Charge//
	var lastId = parseInt(document.getElementById("AllowanceChargeLastId").value);
	var txtAllowanceChargeIds = "";
	var txtAllowanceChargeChargeIndicators = "";
	var txtAllowanceChargeAllowanceChargeReasons = "";
	var txtAllowanceChargeAmounts = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeId") != null){
			txtAllowanceChargeIds += document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeId").value + "___";
			txtAllowanceChargeChargeIndicators += document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeChargeIndicator").value + "___";
			txtAllowanceChargeAllowanceChargeReasons += document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeAllowanceChargeReason").value + "___";
			txtAllowanceChargeAmounts += document.getElementById("AllowanceCharge" + i + "txtAllowanceChargeAmount").value + "___";
		}
	}

	//Tax Total//
	var lastId = parseInt(document.getElementById("TaxTotalLastId").value);
	var txtTaxTotalIds = "";
	var txtTaxTotalTaxAmounts = "";
	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("TaxTotal" + i + "txtTaxTotalId") != null){
			txtTaxTotalIds += document.getElementById("TaxTotal" + i + "txtTaxTotalId").value + "___";
			txtTaxTotalTaxAmounts += document.getElementById("TaxTotal" + i + "txtTaxTotalTaxAmount").value + "___";
		}
	}

	//Additional Item Property//
	var lastId = parseInt(document.getElementById("DeliveryLastId").value);
	var txtOrderLineDeliveryRequestedDeliveryPeriodStartDates = "";
	var txtOrderLineDeliveryRequestedDeliveryPeriodEndDates = "";

	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("Delivery" + i + "txtOrderLineDeliveryRequestedDeliveryPeriodStartDate") != null){
			txtOrderLineDeliveryRequestedDeliveryPeriodStartDates += document.getElementById("Delivery" + i + "txtOrderLineDeliveryRequestedDeliveryPeriodStartDate").value + "___";
			txtOrderLineDeliveryRequestedDeliveryPeriodEndDates += document.getElementById("Delivery" + i + "txtOrderLineDeliveryRequestedDeliveryPeriodEndDate").value + "___";
		}
	}

	//Additional Item Property//
	var lastId = parseInt(document.getElementById("AdditionalItemPropertyLastId").value);
	var txtOrderLineItemAdditionalItemPropertyNames = "";
	var txtOrderLineItemAdditionalItemPropertyValues = "";

	for (var i = 1; i <= lastId; i++){
		if(document.getElementById("AdditionalItemProperty" + i + "txtOrderLineItemAdditionalItemPropertyName") != null){
			txtOrderLineItemAdditionalItemPropertyNames += document.getElementById("AdditionalItemProperty" + i + "txtOrderLineItemAdditionalItemPropertyName").value + "___";
			txtOrderLineItemAdditionalItemPropertyValues += document.getElementById("AdditionalItemProperty" + i + "txtOrderLineItemAdditionalItemPropertyValue").value + "___";
		}
	}

	return createNewDocument( form.txtID.value, documentName,
						form.xmlBasedAddress.value,
						xmlDraft,
						xmlDrop,
						form.isDraftDocument.value,
						validationType,
						form.txtDocumentCurrencyCode.value,//Default CurrencyCode attributes

						form.txtUBLVersionID.value,
						form.txtCustomizationID.value,
						defaultCustomizationSchemeID,
						form.txtProfileID.value,
						form.txtID.value,
						form.txtIssueDate.value,
						form.txtIssueTime.value,
						form.txtNote.value,
						form.txtDocumentCurrencyCode.value,
						form.txtAccountingCost.value,
						form.txtValidityPeriodEndDate.value,
						form.txtQuotationDocumentReferenceID.value,
						form.txtOrderDocumentReferenceID.value,
						form.txtOriginatorDocumentReferenceID.value,
						form.txtOriginatorDocumentReferenceDocumentType.value,
						txtAdditionalDocumentReferenceIDs,
						txtAdditionalDocumentReferenceDocumentTypes,
						txtAdditionalDocumentReferenceAttachmentEmbeddedDocumentBinaryObjects,
						txtAdditionalDocumentReferenceAttachmentExternalReferenceURIs,
						form.txtContractID.value,
						form.txtContractContractType.value,

						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerEndpoint,
						customerSchemeAgencyName,
						customerSchemeID,
						customerSchemeURI,
						customerName,
						form.txtBuyerCustomerPartyPartyPostalAddressID.value,
						form.txtBuyerCustomerPartyPartyPostalAddressPostbox.value,
						form.txtBuyerCustomerPartyPartyPostalAddressStreetName.value,
						form.txtBuyerCustomerPartyPartyPostalAddressAdditionalStreetName.value,
						form.txtBuyerCustomerPartyPartyPostalAddressBuildingNumber.value,
						form.txtBuyerCustomerPartyPartyPostalAddressDepartment.value,
						form.txtBuyerCustomerPartyPartyPostalAddressCityName.value,
						form.txtBuyerCustomerPartyPartyPostalAddressPostalZone.value,
						form.txtBuyerCustomerPartyPartyPostalAddressCountrySubentity.value,
						form.txtBuyerCustomerPartyPartyPostalAddressCountryIdentificationCode.value,
						txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationNames,
						txtBuyerCustomerPartyPartyPartyTaxSchemeCompanyIDs,
						txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationAddressCityNames,
						txtBuyerCustomerPartyPartyPartyTaxSchemeRegistrationAddressCountryIdentificationCodes,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeIDs,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeNames,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeTaxTypeCodes,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeCurrencyCodes,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressAddressTypeCodes,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressBlockNames,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressInhouseMails,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionPlotIdentifications,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCitySubdivisionNames,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressTimezoneOffsets,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCountryIdentificationCodes,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressCountryNames,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateCoordinateSystemCodes,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeDegreesMeasures,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeMinutesMeasures,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLatitudeDirectionCodes,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeDegreesMeasures,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeMinutesMeasures,
						txtBuyerCustomerPartyPartyPartyTaxSchemeTaxSchemeJurisdictionRegionAddressLocationCoordinateLongitudeDirectionCodes,
						form.txtBuyerCustomerPartyPartyPartyLegalEntityRegistrationName.value,
						form.txtBuyerCustomerPartyPartyPartyLegalEntityCompanyID.value,
						form.txtBuyerCustomerPartyPartyPartyLegalEntityRegistrationAddressCityName.value,
						form.txtBuyerCustomerPartyPartyPartyLegalEntityRegistrationAddressCountrySubentity.value,
						form.txtBuyerCustomerPartyPartyPartyLegalEntityRegistrationAddressCountryIdentificationCode.value,
						form.txtBuyerCustomerPartyPartyContactTelephone.value,
						form.txtBuyerCustomerPartyPartyContactTelefax.value,
						form.txtBuyerCustomerPartyPartyContactElectronicMail.value,
						form.txtBuyerCustomerPartyPartyPersonFirstName.value,
						form.txtBuyerCustomerPartyPartyPersonFamilyName.value,
						form.txtBuyerCustomerPartyPartyPersonMiddleName.value,
						form.txtBuyerCustomerPartyPartyPersonJobTitle.value,
						form.txtBuyerCustomerPartyDeliveryContactName.value,
						form.txtBuyerCustomerPartyDeliveryContactTelephone.value,
						form.txtBuyerCustomerPartyDeliveryContactTelefax.value,
						form.txtBuyerCustomerPartyDeliveryContactElectronicMail.value,

						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierEndpoint,
						supplierSchemeAgencyName,
						supplierSchemeID,
						supplierSchemeURI,
						supplierName,
						form.txtSellerSupplierPartyPartyPostalAddressID.value,
						form.txtSellerSupplierPartyPartyPostalAddressPostbox.value,
						form.txtSellerSupplierPartyPartyPostalAddressStreetName.value,
						form.txtSellerSupplierPartyPartyPostalAddressAdditionalStreetName.value,
						form.txtSellerSupplierPartyPartyPostalAddressBuildingNumber.value,
						form.txtSellerSupplierPartyPartyPostalAddressDepartment.value,
						form.txtSellerSupplierPartyPartyPostalAddressCityName.value,
						form.txtSellerSupplierPartyPartyPostalAddressPostalZone.value,
						form.txtSellerSupplierPartyPartyPostalAddressCountrySubentity.value,
						form.txtSellerSupplierPartyPartyPostalAddressCountryIdentificationCode.value,
						form.txtSellerSupplierPartyPartyPartyLegalEntityRegistrationName.value,
						form.txtSellerSupplierPartyPartyPartyLegalEntityCompanyID.value,
						form.txtSellerSupplierPartyPartyPartyLegalEntityRegistrationAddressCityName.value,
						form.txtSellerSupplierPartyPartyPartyLegalEntityRegistrationAddressCountrySubentity.value,
						form.txtSellerSupplierPartyPartyPartyLegalEntityRegistrationAddressCountryIdentificationCode.value,
						form.txtSellerSupplierPartyPartyContactTelephone.value,
						form.txtSellerSupplierPartyPartyContactTelefax.value,
						form.txtSellerSupplierPartyPartyContactElectronicMail.value,
						form.txtSellerSupplierPartyPartyPersonFirstName.value,
						form.txtSellerSupplierPartyPartyPersonFamilyName.value,
						form.txtSellerSupplierPartyPartyPersonMiddleName.value,
						form.txtSellerSupplierPartyPartyPersonJobTitle.value,

						form.txtOriginatorCustomerPartyPartyPartyIdentificationID.value,
						form.txtOriginatorCustomerPartyPartyPartyNameName.value,
						form.txtOriginatorCustomerPartyPartyContactTelephone.value,
						form.txtOriginatorCustomerPartyPartyContactTelefax.value,
						form.txtOriginatorCustomerPartyPartyContactElectronicMail.value,
						form.txtOriginatorCustomerPartyPartyPersonFirstName.value,
						form.txtOriginatorCustomerPartyPartyPersonFamilyName.value,
						form.txtOriginatorCustomerPartyPartyPersonMiddleName.value,
						form.txtOriginatorCustomerPartyPartyPersonJobTitle.value,

						form.txtDeliveryDeliveryLocationAddressID.value,
						form.txtDeliveryDeliveryLocationAddressPostbox.value,
						form.txtDeliveryDeliveryLocationAddressStreetName.value,
						form.txtDeliveryDeliveryLocationAddressAdditionalStreetName.value,
						form.txtDeliveryDeliveryLocationAddressBuildingNumber.value,
						form.txtDeliveryDeliveryLocationAddressDepartment.value,
						form.txtDeliveryDeliveryLocationAddressCityName.value,
						form.txtDeliveryDeliveryLocationAddressPostalZone.value,
						form.txtDeliveryDeliveryLocationAddressCountrySubentity.value,
						form.txtDeliveryDeliveryLocationAddressCountryIdentificationCode.value,
						form.txtDeliveryRequestedDeliveryPeriodStartDate.value,
						form.txtDeliveryRequestedDeliveryPeriodEndDate.value,
						form.txtDeliveryDeliveryPartyPartyIdentificationID.value,
						form.txtDeliveryDeliveryPartyPartyNameName.value,
						form.txtDeliveryDeliveryPartyContactName.value,
						form.txtDeliveryDeliveryPartyContactTelephone.value,
						form.txtDeliveryDeliveryPartyContactTelefax.value,
						form.txtDeliveryDeliveryPartyContactElectronicMail.value,

						form.txtDeliveryTermsID.value,
						form.txtDeliveryTermsSpecialTerms.value,
						form.txtDeliveryTermsDeliveryLocationID.value,

						//txtAllowanceChargeIds,
						txtAllowanceChargeChargeIndicators,
						txtAllowanceChargeAllowanceChargeReasons,
						txtAllowanceChargeAmounts,
						//txtTaxTotalIds,
						txtTaxTotalTaxAmounts,
						form.txtAnticipatedMonetaryTotalLineExtensionAmount.value,
						form.txtAnticipatedMonetaryTotalAllowanceTotalAmount.value,
						form.txtAnticipatedMonetaryTotalChargeTotalAmount.value,
						form.txtAnticipatedMonetaryTotalPayableAmount.value,

						form.editLine.value,
						form.txtLineID.value,

						form.txtOrderLineNote.value,
						form.txtLineID.value,
						form.txtOrderLineQuantity.value,
						form.txtOrderLineQuantityUnitCode.value,
						form.txtOrderLineLineExtensionAmount.value,
						form.txtOrderLineTotalTaxAmount.value,
						form.txtOrderLinePartialDeliveryIndicator.value,
						form.txtOrderLineAccountingCost.value,
						txtOrderLineDeliveryRequestedDeliveryPeriodStartDates,
						txtOrderLineDeliveryRequestedDeliveryPeriodEndDates,
						form.txtOrderLineOriginatorPartyPartyIdentificationID.value,
						form.txtOrderLineOriginatorPartyPartyNameName.value,
						form.txtOrderLinePricePriceAmount.value,
						form.txtOrderLinePriceBaseQuantity.value,
						form.txtOrderLineItemDescription.value,
						form.txtOrderLineItemName.value,
						form.txtOrderLineItemSellersItemIdentificationID.value,
						form.txtOrderLineItemStandardItemIdentificationID.value,
						txtOrderLineItemAdditionalItemPropertyNames,
						txtOrderLineItemAdditionalItemPropertyValues);

}

function setReferencedContractID(form) {
	form.txtOrderDocumentReferenceID.value = form.referencedContractID.value;
}

function getSupplierEndpoint(form) {
	return form.otherPartyId.value;
}

function getSupplierName(form) {
	return form.otherPartyName.value;
}

function getCustomerEndpoint(form) {
	return form.currentId.value;
}

function getCustomerName(form) {
	return form.currentName.value;
}

function cleanTables() {
	/*
	 * TODO update
	 */
}