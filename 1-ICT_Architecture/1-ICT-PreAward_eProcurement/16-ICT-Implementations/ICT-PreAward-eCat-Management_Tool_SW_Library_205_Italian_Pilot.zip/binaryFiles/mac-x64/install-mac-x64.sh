echo
echo Continuing will delete your old repository and files.
echo
echo Your old files are located in the directory:
echo "$HOME/DEMORepository"
echo
echo If you want to make a backup of these files you should do before continuing,
echo or N now to abort.
echo
echo "Do you wish to continue? (y/n)"
read ans
case $ans in
Y|y)
echo
echo Now installed - creating DemoClient-mac-x64.sh
read -p "Press any key to continue . . ."
rm -rf "$HOME/DEMORepository/"
cp "./bin/mac-x64/DemoClient-mac-x64.tmp" "./DemoClient-mac-x64.sh"
cp "./bin/mac-x64/demo_client-mac-x64.jar" "./demo_client-mac-x64.jar"
chmod +x "./DemoClient-mac-x64.sh"
rm "./install-mac-x64.sh"
;;
N|n) exit ;;
*) echo "Invalid command"
esac
