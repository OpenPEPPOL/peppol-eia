echo
echo Continuing will delete your old repository and files.
echo
echo Your old files are located in the directory:
echo "$HOME/DEMORepository"
echo
echo If you want to make a backup of these files you should do before continuing,
echo or N now to abort.
echo
echo "Do you wish to continue? (y/n)"
read ans
case $ans in
Y|y)
echo
echo Now installed - creating DemoClient-unix-x86.sh
read -p "Press any key to continue . . ."
rm -rf "$HOME/DEMORepository/"
cp "./bin/unix-i386/DemoClient-unix-i386.tmp" "./DemoClient-unix-i386.sh"
cp "./bin/unix-i386/demo_client-unix-i386.jar" "./demo_client-unix-i386.jar"
chmod +x "./DemoClient-unix-i386.sh"
rm "./install-unix-i386.sh"
;;
N|n) exit ;;
*) echo "Invalid command"
esac
