echo
echo Continuing will delete your old repository and files.
echo
echo Your old files are located in the directory:
echo "$HOME/DEMORepository"
echo
echo If you want to make a backup of these files you should do before continuing,
echo or N now to abort.
echo
echo "Do you wish to continue? (y/n)"
read ans
case $ans in
Y|y)
echo
echo Now installed - creating DemoClient-mac-x86.sh
read -p "Press any key to continue . . ."
rm -rf "$HOME/DEMORepository/"
cp "./bin/mac-x86/DemoClient-mac-x86.tmp" "./DemoClient-mac-x86.sh"
cp "./bin/mac-x86/demo_client-mac-x86.jar" "./demo_client-mac-x86.jar"
chmod +x "./DemoClient-mac-x86.sh"
rm "./install-mac-x86.sh"
;;
N|n) exit ;;
*) echo "Invalid command"
esac
